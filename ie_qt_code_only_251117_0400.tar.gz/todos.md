
#todo : 

Zoom 
  Mouse tekerleğine zoom bağla gitsin

Pan
  orta butonla pan moduna girsin
  move ile slider değeri değişsin
  butonu bırakınca öyle kalsın
Fikir: Recolor , target color ile renklerin değişmesini sağlayın
Fikir: Renklerde Cyclic özelliği eklenebilir. Spray güzel durur
Fikir: Ayna ile çizim
Şekiller , yıldız, üçgen , yuvarlak  dikdörtgen, ay, elips,ok falan
curve , eğriler
select tools
move tools
rotate tools
png brush
Fix:
  pen line cap falan


Next : 
- [X] Fix Color Palette position
- [ ] Correct slider values


dark mode

Renk kutusu absuttrik
Filtre için kutu yapılacak
Filtreler ile effektler ayrı menülere konabilir
Mouse hareketi ile araçların yanına açıklama , koordinat gibi detaylar
Zoom ortalamıyor
Silgi yapılacak
Copy-paste
Mark - move - selection
Spray güzel değil
Alpha kanalı ne olacak
Layer mümkün olabilir belki
Statusbar yapılacak
Rotate yapılacak
Mirror - Bekli
Resim şifreleme gelişebilir
Print
Splash about gelişmeli
Dockpanel daha sonra silinebilir
Şablon - stencil eklenebilir
Resmin etrafına Cetvel 
Resim bilgileri
Histogram
RGB ayarı
Blend
Pen köşeli çiziyor



# FUNCTIONALITIES
- [x] basic drawing functionality -ok
- [ ] undo/redo functionality 
- [ ] zoom in/out functionality
- [ ] import/export functionality
- [ ] multiple layers functionality
- [ ] multiple documents functionality
- [ ] multiple users functionality
- [ ] real-time collaboration functionality
- [ ] image filters functionality
- [ ] image effects functionality
- [ ] image adjustments functionality
- [ ] image color palette functionality
- [ ] image crop functionality
- [ ] image resize functionality
- [ ] image rotation functionality
- [ ] image flip functionality
- [ ] image layer functionality
- [ ] image file functionality

# TOOLS
- [x] pen tool -ok  
  - [ ] TODO: Add more customization options for the pen tool (e.g., stroke width, opacity).

- [x] line tool -ok
- [ ] brush tool
- [ ] eraser tool
- [ ] fill tool
- [ ] spray tool - needsoptimize
- [ ] circle tool
- [ ] rectangle tool
- [ ] polyline tool
- [ ] select tool
- [ ] circular select tool
- [ ] move tool
- [ ] rotate tool
- [ ] scale tool
- [ ] text tool


# FILTERS
- [ ] grayscale filter
- [ ] sepia filter
- [ ] invert filter
- [ ] blur filter
- [ ] sharpen filter
- [ ] emboss filter
- [ ] edge detect filter
- [ ] colorize filter

# EFFECTS
- [ ] color balance effect
- [ ] color swap effect

# BORDERS
- [ ] border tool
- [ ] frame tool
- [ ] erode border tool
- [ ] dilate border tool

# IMAGE MANIPULATION
- [ ] crop tool
- [ ] resize tool
- [ ] rotate tool
- [ ] flip tool

# ADJUSTMENTS
- [ ] brightness tool
- [ ] contrast tool
- [ ] saturation tool
- [ ] hue tool

# COLOR PALETTE
- [ ] color picker tool
- [ ] color palette tool

# LAYERS
- [ ] layer tool
- [ ] layer mask tool
- [ ] layer opacity tool
- [ ] layer blend tool

# FILE
- [ ] open file tool
- [ ] save file tool

# HELP
- [ ] about tool
- [ ] help tool


