HC Image Editor written with Python and PySide6
