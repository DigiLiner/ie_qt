from dataclasses import dataclass

@dataclass
class ToolDefinition:
    name: str
    icon: str
    tool_id: int
    shortcut: str = ""
    description: str = ""
    finished: bool = False

TOOL_PEN = ToolDefinition("Pen", "svgicons/pen-gray.svg", 1000, "P", "Pen Tool", True)
TOOL_BRUSH = ToolDefinition("Brush", "svgicons/brush.svg", 1001, "B", "Brush Tool", False)
TOOL_LINE = ToolDefinition("Line", "svgicons/line-gray.svg", 1002, "L", "Line Tool", True)
TOOL_RECT = ToolDefinition("Rectangle", "svgicons/rectangle.svg", 1003, "R", "Rectangle Tool", True)
TOOL_CIRCLE = ToolDefinition("Circle", "svgicons/circle-gray.svg", 1004, "C", "Circle Tool", True)
TOOL_SPRAY = ToolDefinition("Spray", "svgicons/spray-gray.svg", 1005, "S", "Spray Tool", True)
TOOL_FILL = ToolDefinition("Fill", "svgicons/fill.svg", 1006, "F", "Fill Tool", True)
TOOL_TEXT = ToolDefinition("Text", "svgicons/text.svg", 1007, "T", "Text Tool", False)
TOOL_ERASER = ToolDefinition("Eraser", "svgicons/eraser-gray.svg", 1008, "E", "Eraser Tool", False)
TOOL_PAN = ToolDefinition("Pan", "svgicons/pan-gray.svg", 1010, "P", "Pan Tool", False)
TOOL_DROPPER = ToolDefinition("Dropper", "svgicons/dropper.svg", 1011, "D", "Dropper Tool", True)
TOOL_ROUNDED_RECT = ToolDefinition("Rounded Rectangle", "svgicons/rounded-rectangle.svg", 1012, "O", "Rounded Rectangle Tool", True)
TOOL_ELLIPSE = ToolDefinition("Ellipse", "svgicons/ellipse-gray.svg", 1013, "L", "Ellipse Tool", True)
TOOL_WAND = ToolDefinition("Wand", "svgicons/wand.svg", 1014, "W", "Wand Tool", False)
TOOL_POLYGON = ToolDefinition("Polygon", "svgicons/polygon-gray.svg", 1015, "G", "Polygon Tool", False)
TOOL_BEZIER = ToolDefinition("Bezier", "svgicons/bezier-gray.svg", 1016, "B", "Bezier Tool", False)
TOOL_SELECT_RECT = ToolDefinition("Select Rectangle", "svgicons/select-rectangle-gray.svg", 1017, "S", "Select Rectangle Tool", False)
TOOL_SELECT_CIRCLE = ToolDefinition("Select Circle", "svgicons/select-circle-gray.svg", 1018, "S", "Select Circle Tool", False)
TOOL_SELECT_POLYGON = ToolDefinition("Select Polygon", "svgicons/select-polygon.svg", 1019, "S", "Select Polygon Tool", False)
TOOL_SELECT_LASSO = ToolDefinition("Select Lasso", "svgicons/lasso_select.svg", 1020, "S", "Select Lasso Tool", False)
TOOL_SELECT_PATH = ToolDefinition("Select Path", "svgicons/select-path.svg", 1021, "S", "Select Path Tool", False)
TOOL_CROP = ToolDefinition("Crop", "svgicons/crop.svg", 1022, "C", "Crop Tool", False)

ALL_TOOLS = [
    TOOL_PEN,
    TOOL_BRUSH,
    TOOL_LINE,
    TOOL_RECT,
    TOOL_CIRCLE,
    TOOL_SPRAY,
    TOOL_FILL,
    TOOL_TEXT,
    TOOL_ERASER,
    TOOL_PAN,
    TOOL_DROPPER,
    TOOL_ROUNDED_RECT,
    TOOL_ELLIPSE,
    TOOL_WAND,
    TOOL_POLYGON,
    TOOL_BEZIER,
    TOOL_SELECT_RECT,
    TOOL_SELECT_CIRCLE,
    TOOL_SELECT_POLYGON,
    TOOL_SELECT_LASSO,
    TOOL_SELECT_PATH,
    TOOL_CROP
]
