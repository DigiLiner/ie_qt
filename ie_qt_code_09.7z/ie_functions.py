import random
import math
from PySide6.QtGui import QImage
from PIL import Image
import numpy as np

def melt_image(img: QImage) -> QImage:
    # Ensure image is in a compatible format to prevent errors
    if img.format() != QImage.Format.Format_ARGB32:
        img = img.convertToFormat(QImage.Format.Format_ARGB32)

    buffer = img.bits().tobytes() # type: ignore
    pil_img = Image.frombytes("RGBA", (img.width(), img.height()), buffer, "raw", "BGRA")

    arr = np.array(pil_img)
    h, w, _ = arr.shape

    # New vertical melt effect
    for x in range(w):
        # Random shift amount for each column
        shift = random.randint(0, h // 10) # Drip up to 10% of height
        if shift > 0:
            arr[:, x] = np.roll(arr[:, x], shift, axis=0)

    pil_out = Image.fromarray(arr)

    # Geri QImage'e dönüştür
    result = QImage(pil_out.tobytes(), w, h, QImage.Format.Format_RGBA8888)
    return result.copy()

def shear_image(img: QImage, amount: int = 40, horizontal: bool = True, direction: int = 1) -> QImage:
    """
    Applies a shear effect to the image.

    Args:
        img (QImage): The input image.
        amount (int): The maximum shear amount in pixels.
        horizontal (bool): True for horizontal shear, False for vertical.
        direction (int): 1 for right/down, -1 for left/up.

    Returns:
        QImage: The sheared image.
    """
    # Ensure image is in a compatible format to prevent errors
    if img.format() != QImage.Format.Format_ARGB32:
        img = img.convertToFormat(QImage.Format.Format_ARGB32)

    buffer = img.bits().tobytes() # type: ignore
    pil_img = Image.frombytes("RGBA", (img.width(), img.height()), buffer, "raw", "BGRA")

    arr = np.array(pil_img)
    h, w, _ = arr.shape

    if horizontal:
        # Horizontal Shear
        for y in range(h):
            shift = int((y / h) * amount) * direction
            arr[y] = np.roll(arr[y], shift, axis=0)
    else:
        # Vertical Shear
        for x in range(w):
            shift = int((x / w) * amount) * direction
            arr[:, x] = np.roll(arr[:, x], shift, axis=0)

    pil_out = Image.fromarray(arr)

    # Convert back to QImage
    result = QImage(pil_out.tobytes(), w, h, QImage.Format.Format_RGBA8888)
    return result.copy()
