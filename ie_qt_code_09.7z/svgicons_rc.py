# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.10.0
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x00\x9f\
\x89\
PNG\x0d\x0a\x1a\x0a\x00\x00\x00\x0dIHDR\x00\
\x00\x002\x00\x00\x002\x02\x03\x00\x00\x00cQ`\x22\
\x00\x00\x00\x01sRGB\x01\xd9\xc9,\x7f\x00\x00\x00\
\x09PLTE\x00\x00\x00\xd8\xd8\xd8\x9f\x9f\x9fGM\
5\xa1\x00\x00\x00\x03tRNS\x00\xff\xffDP\xd6\
!\x00\x00\x00\x09pHYs\x00\x00\x0e\xc4\x00\x00\x0e\
\xc4\x01\x95+\x0e\x1b\x00\x00\x00 IDATx\x9c\
c\x08\x05\x83\xacU \xb0\x80a\x94G]\x1e\x98Z\
5\x15,\x160\xca\xa3.\x0f\x00\x89\xc9BT~\xa0\
uR\x00\x00\x00\x00IEND\xaeB`\x82\
\x00\x00\x00\x86\
\x89\
PNG\x0d\x0a\x1a\x0a\x00\x00\x00\x0dIHDR\x00\
\x00\x00\x14\x00\x00\x00\x14\x08\x06\x00\x00\x00\x8d\x89\x1d\x0d\
\x00\x00\x00\x01sRGB\x00\xae\xce\x1c\xe9\x00\x00\x00\
@IDAT8Oc\xbcq\xe3\xc6\x7f\x06\x22\xc0\
\xf1\xe3\xc7\x89P\xc5\xc0\xc08j \xcep\x1a\x0dC\
\x9cA3\x04\x92\xcd\xfc\xf9\xf3\x89\xca)\x96\x96\x96\xc4\
\xe5\x94Q\x03q\x86\xd3h\x18\xe2\xce)\x83>\xd9\x00\
\x00\x88\x10]\xf3\x99F\x92\xae\x00\x00\x00\x00IEN\
D\xaeB`\x82\
\x00\x00\x07\x9e\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2.002\
5 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg2\x22\x0a   sodipo\
di:docname=\x22uplo\
ad.svg\x22\x0a   inksc\
ape:version=\x221.4\
 (86a8ad7, 2024-\
10-11)\x22\x0a   xmlns\
:inkscape=\x22http:\
//www.inkscape.o\
rg/namespaces/in\
kscape\x22\x0a   xmlns\
:sodipodi=\x22http:\
//sodipodi.sourc\
eforge.net/DTD/s\
odipodi-0.dtd\x22\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0a   xmlns:sv\
g=\x22http://www.w3\
.org/2000/svg\x22>\x0a\
  <defs\x0a     id=\
\x22defs2\x22 />\x0a  <so\
dipodi:namedview\
\x0a     id=\x22namedv\
iew2\x22\x0a     pagec\
olor=\x22#000000\x22\x0a \
    bordercolor=\
\x22#000000\x22\x0a     b\
orderopacity=\x220.\
25\x22\x0a     inkscap\
e:showpageshadow\
=\x222\x22\x0a     inksca\
pe:pageopacity=\x22\
0.0\x22\x0a     inksca\
pe:pagecheckerbo\
ard=\x22true\x22\x0a     \
inkscape:deskcol\
or=\x22#d1d1d1\x22\x0a   \
  inkscape:zoom=\
\x2224.3125\x22\x0a     i\
nkscape:cx=\x2215.9\
79434\x22\x0a     inks\
cape:cy=\x2216\x22\x0a   \
  inkscape:windo\
w-width=\x221920\x22\x0a \
    inkscape:win\
dow-height=\x22996\x22\
\x0a     inkscape:w\
indow-x=\x22-9\x22\x0a   \
  inkscape:windo\
w-y=\x22-9\x22\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22 /\
>\x0a  <g\x0a     tran\
sform=\x22translate\
(0, -0.0032)\x22\x0a  \
   id=\x22g2\x22\x0a     \
style=\x22fill:#fff\
fff;fill-opacity\
:1\x22>\x0a    <g\x0a    \
   transform=\x22ma\
trix(0.054687496\
2747097, 0, 0, 0\
.054687496274709\
7, 0, 0)\x22\x0a      \
 id=\x22g1\x22\x0a       \
style=\x22fill:#fff\
fff;fill-opacity\
:1\x22>\x0a      <path\
\x0a         d=\x22M28\
8, 109.3L288, 35\
2C288, 369.7 273\
.7, 384 256, 384\
C238.3, 384 224,\
 369.7 224, 352L\
224, 109.3L150.6\
, 182.7C138.1, 1\
95.2 117.8, 195.\
2 105.3, 182.7C9\
2.8, 170.2 92.8,\
 149.9 105.3, 13\
7.4L233.3, 9.4C2\
45.8, -3.1 266.1\
, -3.1 278.6, 9.\
4L406.6, 137.4C4\
19.1, 149.9 419.\
1, 170.2 406.6, \
182.7C394.1, 195\
.2 373.8, 195.2 \
361.3, 182.7L288\
, 109.3zM64, 352\
L192, 352C192, 3\
87.3 220.7, 416 \
256, 416C291.3, \
416 320, 387.3 3\
20, 352L448, 352\
C483.3, 352 512,\
 380.7 512, 416L\
512, 448C512, 48\
3.3 483.3, 512 4\
48, 512L64, 512C\
28.7, 512 0, 483\
.3 0, 448L0, 416\
C0, 380.7 28.7, \
352 64, 352zM432\
, 456A24 24 0 1 \
0 432, 408A24 24\
 0 1 0 432, 456z\
\x22\x0a         id=\x22p\
ath1\x22\x0a         s\
tyle=\x22fill:#ffff\
ff;fill-opacity:\
1\x22 />\x0a    </g>\x0a \
 </g>\x0a</svg>\x0a\
\x00\x00\x05\xd1\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-6.675 -2\
 32 32\x22\x0a   versi\
on=\x221.1\x22\x0a   id=\x22\
svg1\x22\x0a   sodipod\
i:docname=\x22curso\
r-gray.svg\x22\x0a   i\
nkscape:version=\
\x221.4 (86a8ad7, 2\
024-10-11)\x22\x0a   x\
mlns:inkscape=\x22h\
ttp://www.inksca\
pe.org/namespace\
s/inkscape\x22\x0a   x\
mlns:sodipodi=\x22h\
ttp://sodipodi.s\
ourceforge.net/D\
TD/sodipodi-0.dt\
d\x22\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0a   xmln\
s:svg=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a  <defs\x0a    \
 id=\x22defs1\x22 />\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview1\x22\x0a     p\
agecolor=\x22#00000\
0\x22\x0a     borderco\
lor=\x22#FFFFFF\x22\x0a  \
   borderopacity\
=\x220.25\x22\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0a     in\
kscape:pageopaci\
ty=\x220.0\x22\x0a     in\
kscape:pagecheck\
erboard=\x220\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   inkscape:zoom\
=\x2224.3125\x22\x0a     \
inkscape:cx=\x2215.\
979434\x22\x0a     ink\
scape:cy=\x2216\x22\x0a  \
   inkscape:wind\
ow-width=\x221920\x22\x0a\
     inkscape:wi\
ndow-height=\x22996\
\x22\x0a     inkscape:\
window-x=\x22-9\x22\x0a  \
   inkscape:wind\
ow-y=\x22-9\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg1\x22 \
/>\x0a  <g\x0a     id=\
\x22Select\x22\x0a     tr\
ansform=\x22transla\
te(-11.6575, -4.\
6628)\x22\x0a     styl\
e=\x22enable-backgr\
ound:new 0 0 32 \
32\x22>\x0a    <g\x0a    \
   transform=\x22ma\
trix(1.165696382\
52258, 0, 0, 1.1\
6569638252258, 0\
, 0)\x22\x0a       id=\
\x22g1\x22>\x0a      <pat\
h\x0a         d=\x22M1\
8.2, 20L26, 20L1\
0, 4L10, 26L15.3\
, 20.7L18, 27.4C\
18.2, 27.9 18.8,\
 28.2 19.3, 27.9\
L20.2, 27.5C20.7\
, 27.3 21, 26.7 \
20.7, 26.2L18.2,\
 20z\x22\x0a         f\
ill=\x22#FFFFFF\x22\x0a  \
       class=\x22Bl\
ack\x22\x0a         id\
=\x22path1\x22\x0a       \
  style=\x22fill:#F\
FFFFF;fill-opaci\
ty:1\x22 />\x0a    </g\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x0b]\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x2232\x22\x0a   heig\
ht=\x2232\x22\x0a   fill=\
\x22currentColor\x22\x0a \
  class=\x22bi bi-m\
agic\x22\x0a   viewBox\
=\x220 0 32 32\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg1\x22\x0a   so\
dipodi:docname=\x22\
magic.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (e7c3feb100,\
 2024-10-09)\x22\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0a  \
 xmlns:sodipodi=\
\x22http://sodipodi\
.sourceforge.net\
/DTD/sodipodi-0.\
dtd\x22\x0a   xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22\x0a   xm\
lns:svg=\x22http://\
www.w3.org/2000/\
svg\x22>\x0a  <defs\x0a  \
   id=\x22defs1\x22 />\
\x0a  <sodipodi:nam\
edview\x0a     id=\x22\
namedview1\x22\x0a    \
 pagecolor=\x22#000\
000\x22\x0a     border\
color=\x22#FFFFFF\x22\x0a\
     borderopaci\
ty=\x220.25\x22\x0a     i\
nkscape:showpage\
shadow=\x222\x22\x0a     \
inkscape:pageopa\
city=\x220.0\x22\x0a     \
inkscape:pageche\
ckerboard=\x220\x22\x0a  \
   inkscape:desk\
color=\x22#d1d1d1\x22\x0a\
     showgrid=\x22t\
rue\x22\x0a     inksca\
pe:zoom=\x2212.5\x22\x0a \
    inkscape:cx=\
\x2216.44\x22\x0a     ink\
scape:cy=\x2219.28\x22\
\x0a     inkscape:w\
indow-width=\x22192\
0\x22\x0a     inkscape\
:window-height=\x22\
1008\x22\x0a     inksc\
ape:window-x=\x220\x22\
\x0a     inkscape:w\
indow-y=\x220\x22\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0a \
    inkscape:cur\
rent-layer=\x22svg1\
\x22>\x0a    <inkscape\
:grid\x0a       id=\
\x22grid1\x22\x0a       u\
nits=\x22px\x22\x0a      \
 originx=\x220\x22\x0a   \
    originy=\x220\x22\x0a\
       spacingx=\
\x221\x22\x0a       spaci\
ngy=\x221\x22\x0a       e\
mpcolor=\x22#0099e5\
\x22\x0a       empopac\
ity=\x220.30196078\x22\
\x0a       color=\x22#\
0099e5\x22\x0a       o\
pacity=\x220.149019\
61\x22\x0a       empsp\
acing=\x225\x22\x0a      \
 enabled=\x22true\x22\x0a\
       visible=\x22\
true\x22 />\x0a  </sod\
ipodi:namedview>\
\x0a  <path\x0a     d=\
\x22m 18.632458,7.1\
97339 a 0.841877\
5,0.84971561 0 1\
 0 1.683755,0 V \
4.0890806 a 0.84\
18775,0.84971561\
 0 0 0 -1.683755\
,0 z m 7.576894,\
0.05948 A 0.8418\
7713,0.84971524 \
0 0 0 25.018937,\
6.0553216 l -2.1\
77094,2.1973637 \
a 0.84187713,0.8\
4971524 0 1 0 1.\
190415,1.2014974\
 z M 14.916413,9\
.4541827 A 0.841\
87713,0.84971524\
 0 1 0 16.106827\
,8.2526853 L 13.\
929732,6.0553216\
 a 0.84187713,0.\
84971524 0 0 0 -\
1.190415,1.20149\
75 z m -1.045611\
,4.2485763 a 0.8\
4187729,0.849715\
4 0 1 0 0,-1.699\
43 h -3.079588 a\
 0.84187729,0.84\
97154 0 1 0 0,1.\
69943 z m 14.286\
654,0 a 0.841877\
29,0.8497154 0 1\
 0 0,-1.69943 h \
-3.079587 a 0.84\
187729,0.8497154\
 0 0 0 0,1.69943\
 z m -3.138519,5\
.948007 a 0.8418\
7713,0.84971524 \
0 1 0 1.190415,-\
1.201497 l -2.17\
7094,-2.197365 a\
 0.84187713,0.84\
971524 0 1 0 -1.\
190415,1.201497 \
z m -6.386479,1.\
966241 a 0.84187\
75,0.84971561 0 \
0 0 1.683755,0 v\
 -3.108259 a 0.8\
418775,0.8497156\
1 0 0 0 -1.68375\
5,0 z m 3.12168,\
-8.661997 a 0.84\
187713,0.8497152\
4 0 0 0 0,-1.199\
799 l -1.192097,\
-1.203197 a 0.84\
187713,0.8497152\
4 0 0 0 -1.19041\
5,0 l -2.177095,\
2.199064 a 0.841\
87713,0.84971524\
 0 0 0 0,1.20149\
8 l 1.192099,1.2\
03196 a 0.841877\
13,0.84971524 0 \
0 0 1.190414,0 l\
 2.177094,-2.197\
364 z m -5.05126\
3,5.09829 a 0.84\
187713,0.8497152\
4 0 0 0 0,-1.199\
797 l -1.192097,\
-1.203196 a 0.84\
187713,0.8497152\
4 0 0 0 -1.19041\
4,0 L 3.7244976,\
26.346521 a 0.84\
187713,0.8497152\
4 0 0 0 0,1.2014\
99 l 1.192098,1.\
203195 a 0.84187\
713,0.84971524 0\
 0 0 1.1904143,0\
 z\x22\x0a     id=\x22pat\
h1\x22\x0a     style=\x22\
stroke-width:1.6\
9157;fill:#FFFFF\
F;fill-opacity:1\
\x22 />\x0a</svg>\x0a\
\x00\x00\x08\x9b\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -3.502\
5 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg2\x22\x0a   sodipo\
di:docname=\x22fill\
.svg\x22\x0a   inkscap\
e:version=\x221.4 (\
86a8ad7, 2024-10\
-11)\x22\x0a   xmlns:i\
nkscape=\x22http://\
www.inkscape.org\
/namespaces/inks\
cape\x22\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0a   \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22\x0a   xmlns:svg=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a  \
<defs\x0a     id=\x22d\
efs2\x22 />\x0a  <sodi\
podi:namedview\x0a \
    id=\x22namedvie\
w2\x22\x0a     pagecol\
or=\x22#000000\x22\x0a   \
  bordercolor=\x22#\
FFFFFF\x22\x0a     bor\
deropacity=\x220.25\
\x22\x0a     inkscape:\
showpageshadow=\x22\
2\x22\x0a     inkscape\
:pageopacity=\x220.\
0\x22\x0a     inkscape\
:pagecheckerboar\
d=\x220\x22\x0a     inksc\
ape:deskcolor=\x22#\
d1d1d1\x22\x0a     ink\
scape:zoom=\x2225.2\
1875\x22\x0a     inksc\
ape:cx=\x2216\x22\x0a    \
 inkscape:cy=\x2215\
.980173\x22\x0a     in\
kscape:window-wi\
dth=\x221920\x22\x0a     \
inkscape:window-\
height=\x22996\x22\x0a   \
  inkscape:windo\
w-x=\x22-9\x22\x0a     in\
kscape:window-y=\
\x22-9\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22svg2\x22 />\x0a  \
<g\x0a     transfor\
m=\x22translate(-0.\
1208, -0.0013)\x22\x0a\
     id=\x22g2\x22\x0a   \
  style=\x22stroke:\
#FFFFFF;stroke-o\
pacity:1;fill:#F\
FFFFF;fill-opaci\
ty:1\x22>\x0a    <g\x0a  \
     transform=\x22\
matrix(0.0488209\
053874016, 0, 0,\
 0.0488209053874\
016, 0, 0)\x22\x0a    \
   id=\x22g1\x22\x0a     \
  style=\x22stroke:\
#FFFFFF;stroke-o\
pacity:1;fill:#F\
FFFFF;fill-opaci\
ty:1\x22>\x0a      <pa\
th\x0a         d=\x22M\
41.4, 9.4C53.9, \
-3.1 74.1, -3.1 \
86.6, 9.4L168, 9\
0.7L221.1, 37.6C\
249.2, 9.5 294.8\
, 9.5 322.9, 37.\
6L474.3, 189.1C5\
02.4, 217.2 502.\
4, 262.8 474.3, \
290.9L283.9, 481\
.4C246.4, 518.9 \
185.6, 518.9 148\
.1, 481.4L30.6, \
363.9C-6.9, 326.\
4 -6.9, 265.6 30\
.6, 228.1L122.7,\
 136L41.4, 54.6C\
28.9, 42.1 28.9,\
 21.8 41.4, 9.3z\
M217.4, 230.7L16\
8, 181.3L75.9, 2\
73.4C71.7, 277.6\
 68.9, 282.7 67.\
5, 288L386.7, 28\
8L429, 245.7C432\
.1, 242.6 432.1,\
 237.5 429, 234.\
4L277.7, 82.9C27\
4.6, 79.8 269.5,\
 79.8 266.4, 82.\
9L213.3, 136L262\
.7, 185.4C275.2,\
 197.9 275.2, 21\
8.2 262.7, 230.7\
C250.2, 243.2 22\
9.9, 243.2 217.4\
, 230.7zM512, 51\
2C476.7, 512 448\
, 483.3 448, 448\
C448, 422.8 480.\
6, 368.4 499.2, \
339.3C505.2, 329\
.9 518.7, 329.9 \
524.7, 339.3C543\
.4, 368.4 576, 4\
22.8 576, 448C57\
6, 483.3 547.3, \
512 512, 512z\x22\x0a \
        id=\x22path\
1\x22\x0a         styl\
e=\x22stroke:#FFFFF\
F;stroke-opacity\
:1;fill:#FFFFFF;\
fill-opacity:1\x22 \
/>\x0a    </g>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x0b]\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   he\
ight=\x2232\x22\x0a   vie\
wBox=\x220 0 32 32\x22\
\x0a   width=\x2232\x22\x0a \
  version=\x221.1\x22\x0a\
   id=\x22svg1\x22\x0a   \
sodipodi:docname\
=\x22selection-elli\
pse.svg\x22\x0a   inks\
cape:version=\x221.\
4 (e7c3feb100, 2\
024-10-09)\x22\x0a   x\
mlns:inkscape=\x22h\
ttp://www.inksca\
pe.org/namespace\
s/inkscape\x22\x0a   x\
mlns:sodipodi=\x22h\
ttp://sodipodi.s\
ourceforge.net/D\
TD/sodipodi-0.dt\
d\x22\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0a   xmln\
s:svg=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a  <defs\x0a    \
 id=\x22defs1\x22 />\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview1\x22\x0a     p\
agecolor=\x22#00000\
0\x22\x0a     borderco\
lor=\x22#FFFFFF\x22\x0a  \
   borderopacity\
=\x220.25\x22\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0a     in\
kscape:pageopaci\
ty=\x220.0\x22\x0a     in\
kscape:pagecheck\
erboard=\x220\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   showgrid=\x22tru\
e\x22\x0a     inkscape\
:zoom=\x2211.313708\
\x22\x0a     inkscape:\
cx=\x22-0.13258252\x22\
\x0a     inkscape:c\
y=\x2218.605747\x22\x0a  \
   inkscape:wind\
ow-width=\x221920\x22\x0a\
     inkscape:wi\
ndow-height=\x22969\
\x22\x0a     inkscape:\
window-x=\x220\x22\x0a   \
  inkscape:windo\
w-y=\x220\x22\x0a     ink\
scape:window-max\
imized=\x221\x22\x0a     \
inkscape:current\
-layer=\x22svg1\x22>\x0a \
   <inkscape:gri\
d\x0a       id=\x22gri\
d1\x22\x0a       units\
=\x22px\x22\x0a       ori\
ginx=\x220\x22\x0a       \
originy=\x220\x22\x0a    \
   spacingx=\x221\x22\x0a\
       spacingy=\
\x221\x22\x0a       empco\
lor=\x22#0099e5\x22\x0a  \
     empopacity=\
\x220.30196078\x22\x0a   \
    color=\x22#0099\
e5\x22\x0a       opaci\
ty=\x220.14901961\x22\x0a\
       empspacin\
g=\x225\x22\x0a       ena\
bled=\x22true\x22\x0a    \
   visible=\x22true\
\x22 />\x0a  </sodipod\
i:namedview>\x0a  <\
path\x0a     d=\x22m 8\
.0608586,27.6500\
77 1.7052486,-2.\
240781 c 1.21199\
48,0.803299 2.57\
90118,1.381111 4\
.0446808,1.67706\
3 l -0.38051,2.7\
90407 C 11.47135\
6,29.510349 9.68\
15494,28.70705 8\
.0608586,27.6500\
77 m 14.2057074,\
-2.240781 1.7052\
48,2.254874 c -1\
.606598,1.085159\
 -3.396404,1.846\
179 -5.355326,2.\
212596 l -0.3805\
1,-2.790407 c 1.\
465668,-0.295952\
 2.818593,-0.873\
764 4.030588,-1.\
677063 m 4.8057,\
-7.145132 2.8045\
,0.38051 C 29.51\
0349,20.603596 2\
8.70705,22.42158\
8 27.635985,24 l\
 -2.240782,-1.70\
5249 c 0.803299,\
-1.197901 1.3811\
11,-2.564919 1.6\
77063,-4.030587 \
M 2.17,18.616488\
 4.9604067,18.23\
5978 c 0.2959522\
,1.465668 0.8737\
637,2.832686 1.6\
770626,4.04468 L\
 4.3966882,23.98\
5907 C 3.3397159\
,22.365216 2.536\
417,20.57541 2.1\
7,18.616488 M 25\
.409296,9.766107\
2 27.650077,8.06\
08586 c 1.099252\
,1.6206908 1.874\
365,3.4245904 2.\
226689,5.3976054\
 l -2.790407,0.3\
8051 C 26.790407\
,12.359212 26.21\
2595,10.978102 2\
5.409296,9.76610\
72 M 18.235978,4\
.9604067 18.6164\
88,2.17 c 1.9589\
22,0.366417 3.74\
8728,1.1697159 5\
.369419,2.226688\
2 L 22.280658,6.\
6374693 C 21.068\
664,5.8341704 19\
.701646,5.256358\
9 18.235978,4.96\
04067 M 9.766107\
2,6.6374693 8.06\
08586,4.3966882 \
C 9.6815494,3.33\
97159 11.471356,\
2.536417 13.4302\
78,2.17 l 0.3805\
1,2.7904067 C 12\
.345119,5.256358\
9 10.978102,5.83\
41704 9.7661072,\
6.6374693 M 4.96\
04067,13.810788 \
2.17,13.430278 C\
 2.536417,11.471\
356 3.3397159,9.\
6815494 4.396688\
2,8.0608586 L 6.\
6374693,9.766107\
2 C 5.8341704,10\
.978102 5.256358\
9,12.345119 4.96\
04067,13.810788 \
Z\x22\x0a     id=\x22path\
1\x22\x0a      style=\x22\
stroke-width:1.3\
3333;fill:#fffff\
f;fill-opacity:1\
\x22 />\x0a</svg>\x0a\
\x00\x00\x0b0\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   width=\x22\
32mm\x22\x0a   height=\
\x2232mm\x22\x0a   viewBo\
x=\x220 0 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg1\x22\x0a   i\
nkscape:version=\
\x221.4 (e7c3feb100\
, 2024-10-09)\x22\x0a \
  sodipodi:docna\
me=\x22gradient.svg\
\x22\x0a   xmlns:inksc\
ape=\x22http://www.\
inkscape.org/nam\
espaces/inkscape\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:xlink=\x22http://\
www.w3.org/1999/\
xlink\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22>\x0a  <sodip\
odi:namedview\x0a  \
   id=\x22namedview\
1\x22\x0a     pagecolo\
r=\x22#000000\x22\x0a    \
 bordercolor=\x22#F\
FFFFF\x22\x0a     bord\
eropacity=\x220.25\x22\
\x0a     inkscape:s\
howpageshadow=\x222\
\x22\x0a     inkscape:\
pageopacity=\x220.0\
\x22\x0a     inkscape:\
pagecheckerboard\
=\x22true\x22\x0a     ink\
scape:deskcolor=\
\x22#d1d1d1\x22\x0a     i\
nkscape:document\
-units=\x22px\x22\x0a    \
 inkscape:zoom=\x22\
3.920673\x22\x0a     i\
nkscape:cx=\x22139.\
38934\x22\x0a     inks\
cape:cy=\x22119.494\
79\x22\x0a     inkscap\
e:window-width=\x22\
1920\x22\x0a     inksc\
ape:window-heigh\
t=\x22969\x22\x0a     ink\
scape:window-x=\x22\
0\x22\x0a     inkscape\
:window-y=\x220\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22la\
yer1\x22\x0a     showg\
rid=\x22true\x22\x0a     \
showborder=\x22true\
\x22>\x0a    <inkscape\
:grid\x0a       id=\
\x22grid1\x22\x0a       u\
nits=\x22px\x22\x0a      \
 originx=\x220\x22\x0a   \
    originy=\x220\x22\x0a\
       spacingx=\
\x220.26458333\x22\x0a   \
    spacingy=\x220.\
26458333\x22\x0a      \
 empcolor=\x22#0099\
e5\x22\x0a       empop\
acity=\x220.3019607\
8\x22\x0a       color=\
\x22#0099e5\x22\x0a      \
 opacity=\x220.1490\
1961\x22\x0a       emp\
spacing=\x225\x22\x0a    \
   enabled=\x22true\
\x22\x0a       visible\
=\x22true\x22 />\x0a  </s\
odipodi:namedvie\
w>\x0a  <defs\x0a     \
id=\x22defs1\x22>\x0a    \
<linearGradient\x0a\
       id=\x22linea\
rGradient6\x22\x0a    \
   inkscape:coll\
ect=\x22always\x22>\x0a  \
    <stop\x0a      \
   style=\x22stop-c\
olor:#8438a8;sto\
p-opacity:1;\x22\x0a  \
       offset=\x220\
\x22\x0a         id=\x22s\
top6\x22 />\x0a      <\
stop\x0a         st\
yle=\x22stop-color:\
#507dbe;stop-opa\
city:0.82741117;\
\x22\x0a         offse\
t=\x221\x22\x0a         i\
d=\x22stop7\x22 />\x0a   \
 </linearGradien\
t>\x0a    <linearGr\
adient\x0a       in\
kscape:collect=\x22\
always\x22\x0a       x\
link:href=\x22#line\
arGradient6\x22\x0a   \
    id=\x22linearGr\
adient7\x22\x0a       \
x1=\x22128.94836\x22\x0a \
      y1=\x2276.981\
72\x22\x0a       x2=\x223\
66.65533\x22\x0a      \
 y2=\x22416.46246\x22\x0a\
       gradientU\
nits=\x22userSpaceO\
nUse\x22\x0a       gra\
dientTransform=\x22\
matrix(0.0649978\
9,0,0,0.06499789\
,-0.23159838,-0.\
16141677)\x22 />\x0a  \
</defs>\x0a  <g\x0a   \
  inkscape:label\
=\x22Katman 1\x22\x0a    \
 inkscape:groupm\
ode=\x22layer\x22\x0a    \
 id=\x22layer1\x22>\x0a  \
  <circle\x0a      \
 id=\x22path5\x22\x0a    \
   style=\x22fill:#\
ef8946;stroke:#7\
07070;stroke-wid\
th:0.264583\x22\x0a   \
    cx=\x22183.8268\
6\x22\x0a       cy=\x2233\
0.94232\x22\x0a       \
r=\x220.035955299\x22 \
/>\x0a    <rect\x0a   \
    style=\x22vecto\
r-effect:non-sca\
ling-stroke;fill\
:url(#linearGrad\
ient7);fill-opac\
ity:1;stroke:non\
e;stroke-width:0\
.0171973;stroke-\
linecap:round;st\
roke-linejoin:ro\
und;stroke-dasha\
rray:0, 0.189171\
;stroke-dashoffs\
et:0;stroke-opac\
ity:1;-inkscape-\
stroke:hairline\x22\
\x0a       id=\x22rect\
6\x22\x0a       width=\
\x2226.45833\x22\x0a     \
  height=\x2226.458\
33\x22\x0a       x=\x222.\
6458333\x22\x0a       \
y=\x222.6458333\x22 />\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x03\x7f\
\x00\
\x00\x12Qx\xda\xedX\xcdn\xdb8\x10\xbe\x17\xe8;\
\x0c\xd8CZ \xa6\xf9O)\x88Z\xa0*zRo\
-z,T[\xb5\x85u\xe4@\xd6\xc6I_m\x0f\
}\xa4\xbeB\x87\x22%\xd1\xe9z\xdb\xc5\xe6\x10,\xec\
\x1f\x92\xf3\x893#r>\x8e\xc6\xfe\xfe\xd7\xb7\xcbW\
\xb7W\x1b\xb8\xa9\xda]\xbdm\xb23N\xd9\x19T\xcd\
b\xbb\xac\x9bUv\xf6\xe1\xfd\xdbYr\xf6\xea\xe5\xd3\
'\x97\xbb\x9b\x15\xdc\xd4\xd5\xfe\xf5\xf66#3\x013\
E%\xb3\x1a\xa4\xc0\x0f\x01\xb4\xd2\xec2\xb2\xee\xba\xeb\
\x8b\xf9|\xbf\xdf\xd3\xbd\xa4\xdbv5\x17\x8c\xb19*\
\x13@+\x00\x97+\xa8\x97\x19)\xca\xbb\xaa\xfd\xc4\x09\
tm\xd9\xec\xbel\xdb\xab\x8c\xf4\xc3M\xd9U\xcf\xd9\
9\xccDo\xfe\x05\x81]w\xb7\xa92R5\xe5\xe7\
M5\xfb\x5c.\xfeX\xb5\xdb?\x9b\xe5ES\xed\x81\
\xe1[s\xe1\xbe\xa4\xb7\xdf{\x88\x8c^\x95][\xdf\
>g4\xb1*=\x07\xe6?\x91\xf4b\xd0;\xa2\xc9\
)W\xc2\x0c\x9a\xb1\x14i\x1e\xf5\xca\xb4\xb2\x93\xd7I\
:\xd0u\xda\x07\x22\x02\xd7e\xb7\x06\xdc\xa8w\xca$\
T\x1au\x0e\xd2$\xc5$\xa4\x9c\x0a+\xf3\x080\x94\
\xa5\x12\x94\x15xA\x9c\x83b\x0c\x05\x8b \xef\x85\x5c\
%\x9c\xa6\x9c\x87+\x89\xa6\x09O\x06=\x11\x03\xbd\xe5\
b\x02\x0e\xfc\x9a\xe4+\x81/\xf5f\x93\x91go\xfb\
\x97\x17g\xdb\xebrQww\x19\xc1\xa0.6\xe5\x0e\
\xc9\xf0z\x83\xc1\x220?\x5c\xea<^k,M\xe3\
a4\xf6'\xd2\xfcK\xd2HI\x95\xd6\x11O& \
\xf0DZ\x8c\xa8\x0clP\x82\xf2D\x04\x9e($\x0d\
\x1b\x18\xa4\x19MY\x1a\xf1d\x02\x02OF\xc0\xf1\xa4\
w\xa3\xee\x0b~\xea\x898\x8f\x9f82M\xa8V\x11\
q\x22 \x10\x87\x09\x8c\xea@\x1cf\xc7l\x93+.\
\x1cE\xc2\x15\xaei\x9a\xc6\xc4\x99\x80@\x9c\x11@\xae\
x7\xea\xbep\x22\xce#'N[-:\xc0\x82@\
\x08\xe3\xb2\x00\x01\x0c\x87T\x8aZa\x09\xec\xebe\xb7\
\xce\x88N\x5cr!\xb0\xae\xea\xd5\xba\xc3pq\xe3\x1e\
&\x04ZTd\xd8\xdd\xf5\xdd)\xc4\x8f\x22\xc4c*\
\xc0\x85\xf4\xc71\xf7\x03\xab\xa8\x02\xcd\x0c\xb5}\x1d`\
Sj\xa4A\x80\x85\xc2\xc0\x03\x05\xe7\xae\x1b\xe5\x5cS\
\x11\x89\xce\xa3\xb7\xc4\xfcQ\xc7NKWg\xe48\xc2\
\x07\x8f\xe2\x09\x04\x15\xffL\x82\xc1\xa0\x17\x0b\xefP\x0e\
r\xee\xefh\x94q\xfb\xb9\xcf*\x83\xb1A\xf6n\x8a\
Q\xfe\xbdJ&\x84\xdc\xe1\x17\xe3\xac\xf9\x89k\x0f\xc3\
\xb5!{H5&\x0f_\xb1\x8e\xb9#T&S\xf2\
\x10\xc6:>\x1cI\x1e\x9c[\xfb\xc6\xfe*\x8e\xf2\x8d\
\xb4\xd2\x9e\xe2\xf8\xf09C\xa6:\x9cV\x93\xf6\xc7-\
\xe4\xfa\x11\xc89\x9e\xbf\xfe\xd9\x1e\x00\xe0\xcc\x05\xd4:\
\x00\xeb\x01\x1e\xcb\xdcQ!\x9f\x00m\xb0\x1a\xc0\x19\xa3\
\x09-\x9cq\x98\x9cx\xa0\xf0\xb7aG \xc7\x8a\x04\
\x8b\x96\x09\xc0\x12E\x0d*\xce\xa8\x88\x80\xe06\x02\xdc\
}q\xf06\xa6\xb5\xc1\xfd\xc5\xfe\xa72\xe5\x01\xf9g\
\x5c\xa0M*~\x8b~\xfe\xe7\xfb?\x93OO\x1c\xd0\
\x7fG;wK\x1f\xebf\xb9\xdd\x1fpjb\x85\xa3\
\x1e+\x5c\xa7s\xd7*\xaaA\xa4\xce\x98\xc2\x1e\xdb\xc2\
%\xf0\x5c\x04$L\xc0\xd9\x85\x1859\xfb\xfa\xcbt\
\xfc\x7f\xdb8\x91\xf4\xcbw\x9d0\x85\x1aZ\x07\x0d\xad\
\xb0y\xdf\xba\x0dsN\x04\xf2\xd2\xb5\x85\xdbW\x91\xe4\
~\x9b\x1d\xca\xc24?\x08{Zx\x17?S\xf7\x18\
S\x8fm\xf1\xa5\xfb\x8f\xe7\xe5\x0f\xe2\x9dSk\
\x00\x00\x07j\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-6 -4 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg4\
\x22\x0a   sodipodi:do\
cname=\x22new.svg\x22\x0a\
   inkscape:vers\
ion=\x221.4 (86a8ad\
7, 2024-10-11)\x22\x0a\
   xmlns:inkscap\
e=\x22http://www.in\
kscape.org/names\
paces/inkscape\x22\x0a\
   xmlns:sodipod\
i=\x22http://sodipo\
di.sourceforge.n\
et/DTD/sodipodi-\
0.dtd\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22>\x0a  <defs\x0a\
     id=\x22defs4\x22 \
/>\x0a  <sodipodi:n\
amedview\x0a     id\
=\x22namedview4\x22\x0a  \
   pagecolor=\x22#f\
fffff\x22\x0a     bord\
ercolor=\x22#000000\
\x22\x0a     borderopa\
city=\x220.25\x22\x0a    \
 inkscape:showpa\
geshadow=\x222\x22\x0a   \
  inkscape:pageo\
pacity=\x220.0\x22\x0a   \
  inkscape:pagec\
heckerboard=\x22tru\
e\x22\x0a     inkscape\
:deskcolor=\x22#d1d\
1d1\x22\x0a     inksca\
pe:zoom=\x2224.3125\
\x22\x0a     inkscape:\
cx=\x2215.979434\x22\x0a \
    inkscape:cy=\
\x2216\x22\x0a     inksca\
pe:window-width=\
\x221920\x22\x0a     inks\
cape:window-heig\
ht=\x22996\x22\x0a     in\
kscape:window-x=\
\x22-9\x22\x0a     inksca\
pe:window-y=\x22-9\x22\
\x0a     inkscape:w\
indow-maximized=\
\x221\x22\x0a     inkscap\
e:current-layer=\
\x22svg4\x22 />\x0a  <g\x0a \
    id=\x22Layer_1\x22\
\x0a     transform=\
\x22translate(-6, -\
4)\x22\x0a     style=\x22\
enable-backgroun\
d:new 0 0 32 32\x22\
>\x0a    <g\x0a       \
id=\x22New\x22>\x0a      \
<g\x0a         id=\x22\
g1\x22>\x0a        <pa\
th\x0a           d=\
\x22M19, 4L7, 4C6.4\
, 4 6, 4.4 6, 5L\
6, 27C6, 27.6 6.\
4, 28 7, 28L25, \
28C25.6, 28 26, \
27.6 26, 27L26, \
11L19, 4zM24, 26\
L8, 26L8, 6L18, \
6L18, 11C18, 11.\
6 18.4, 12 19, 1\
2L24, 12L24, 26z\
\x22\x0a           fil\
l=\x22#FFFFFF\x22\x0a    \
       class=\x22Bl\
ack\x22\x0a           \
id=\x22path1\x22 />\x0a  \
    </g>\x0a    </g\
>\x0a  </g>\x0a  <g\x0a  \
   id=\x22g4\x22\x0a     \
transform=\x22trans\
late(-6, -4)\x22\x0a  \
   style=\x22enable\
-background:new \
0 0 32 32\x22>\x0a    \
<g\x0a       id=\x22g3\
\x22>\x0a      <g\x0a    \
     id=\x22g2\x22>\x0a  \
      <path\x0a    \
       d=\x22M19, 4\
L7, 4C6.4, 4 6, \
4.4 6, 5L6, 27C6\
, 27.6 6.4, 28 7\
, 28L25, 28C25.6\
, 28 26, 27.6 26\
, 27L26, 11L19, \
4zM24, 26L8, 26L\
8, 6L18, 6L18, 1\
1C18, 11.6 18.4,\
 12 19, 12L24, 1\
2L24, 26z\x22\x0a     \
      fill=\x22#FFF\
FFF\x22\x0a           \
class=\x22Black\x22\x0a  \
         id=\x22pat\
h2\x22 />\x0a      </g\
>\x0a    </g>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x0d\x12\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-5.82 -2 \
32 32\x22\x0a   versio\
n=\x221.1\x22\x0a   id=\x22s\
vg12\x22\x0a   sodipod\
i:docname=\x22inspe\
ction.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (86a8ad7, 20\
24-10-11)\x22\x0a   xm\
lns:inkscape=\x22ht\
tp://www.inkscap\
e.org/namespaces\
/inkscape\x22\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:svg=\x22http://www\
.w3.org/2000/svg\
\x22>\x0a  <defs\x0a     \
id=\x22defs12\x22 />\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview12\x22\x0a     \
pagecolor=\x22#0000\
00\x22\x0a     borderc\
olor=\x22#000000\x22\x0a \
    borderopacit\
y=\x220.25\x22\x0a     in\
kscape:showpages\
hadow=\x222\x22\x0a     i\
nkscape:pageopac\
ity=\x220.0\x22\x0a     i\
nkscape:pagechec\
kerboard=\x220\x22\x0a   \
  inkscape:deskc\
olor=\x22#d1d1d1\x22\x0a \
    inkscape:zoo\
m=\x2224.3125\x22\x0a    \
 inkscape:cx=\x2215\
.979434\x22\x0a     in\
kscape:cy=\x2216\x22\x0a \
    inkscape:win\
dow-width=\x221920\x22\
\x0a     inkscape:w\
indow-height=\x2299\
6\x22\x0a     inkscape\
:window-x=\x22-9\x22\x0a \
    inkscape:win\
dow-y=\x22-9\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22g6\x22 /\
>\x0a  <g\x0a     tran\
sform=\x22translate\
(-5.0927, -3.433\
22753781905E-07)\
\x22\x0a     id=\x22g2\x22>\x0a\
    <g\x0a       tr\
ansform=\x22matrix(\
0.63636380434036\
3, 0, 0, 0.63636\
3804340363, 0, 0\
)\x22\x0a       id=\x22g1\
\x22>\x0a      <path\x0a \
        d=\x22M36, \
4L26, 4C26, 5.1 \
25.1, 6 24, 6C22\
.9, 6 22, 5.1 22\
, 4L12, 4C9.8, 4\
 8, 5.8 8, 8L8, \
40C8, 42.2 9.8, \
44 12, 44L36, 44\
C38.2, 44 40, 42\
.2 40, 40L40, 8C\
40, 5.8 38.2, 4 \
36, 4z\x22\x0a        \
 fill=\x22#455A64\x22\x0a\
         id=\x22pat\
h1\x22\x0a         sty\
le=\x22fill:#d2e8ed\
;fill-opacity:1\x22\
 />\x0a    </g>\x0a  <\
/g>\x0a  <g\x0a     tr\
ansform=\x22transla\
te(-5.0927002098\
0835, -5.5313110\
3586679E-07)\x22\x0a  \
   id=\x22g4\x22>\x0a    \
<g\x0a       transf\
orm=\x22matrix(0.63\
6363804340363, 0\
, 0, 0.636363804\
340363, 0, 0)\x22\x0a \
      id=\x22g3\x22>\x0a \
     <path\x0a     \
    d=\x22M36, 41L1\
2, 41C11.4, 41 1\
1, 40.6 11, 40L1\
1, 8C11, 7.4 11.\
4, 7 12, 7L36, 7\
C36.6, 7 37, 7.4\
 37, 8L37, 40C37\
, 40.6 36.6, 41 \
36, 41z\x22\x0a       \
  fill=\x22#fff\x22\x0a  \
       id=\x22path2\
\x22\x0a         style\
=\x22fill:#734f4f;f\
ill-opacity:1\x22 /\
>\x0a    </g>\x0a  </g\
>\x0a  <g\x0a     tran\
sform=\x22translate\
(-5.092700076293\
95, -3.433227537\
81905E-07)\x22\x0a    \
 id=\x22g7\x22>\x0a    <g\
\x0a       transfor\
m=\x22matrix(0.6363\
63804340363, 0, \
0, 0.63636380434\
0363, 0, 0)\x22\x0a   \
    id=\x22g6\x22>\x0a   \
   <g\x0a         f\
ill=\x22#90A4AE\x22\x0a  \
       id=\x22g5\x22>\x0a\
        <path\x0a  \
         d=\x22M26,\
 4C26, 5.1 25.1,\
 6 24, 6C22.9, 6\
 22, 5.1 22, 4L1\
5, 4L15, 8C15, 9\
.1 15.9, 10 17, \
10L31, 10C32.1, \
10 33, 9.1 33, 8\
L33, 4L26, 4z\x22\x0a \
          fill=\x22\
#90A4AE\x22\x0a       \
    id=\x22path4\x22\x0a \
          style=\
\x22fill:#90a4ae;fi\
ll-opacity:1\x22 />\
\x0a      </g>\x0a    \
</g>\x0a  </g>\x0a  <g\
\x0a     transform=\
\x22translate(-5.09\
270072479248, 0)\
\x22\x0a     id=\x22g10\x22>\
\x0a    <g\x0a       t\
ransform=\x22matrix\
(0.6363638043403\
63, 0, 0, 0.6363\
63804340363, 0, \
0)\x22\x0a       id=\x22g\
9\x22>\x0a      <g\x0a   \
      fill=\x22#90A\
4AE\x22\x0a         id\
=\x22g8\x22>\x0a        <\
path\x0a           \
d=\x22M24, 0C21.8, \
0 20, 1.8 20, 4C\
20, 6.2 21.8, 8 \
24, 8C26.2, 8 28\
, 6.2 28, 4C28, \
1.8 26.2, 0 24, \
0zM24, 6C22.9, 6\
 22, 5.1 22, 4C2\
2, 2.9 22.9, 2 2\
4, 2C25.1, 2 26,\
 2.9 26, 4C26, 5\
.1 25.1, 6 24, 6\
z\x22\x0a           fi\
ll=\x22#90A4AE\x22\x0a   \
        id=\x22path\
7\x22 />\x0a      </g>\
\x0a    </g>\x0a  </g>\
\x0a  <g\x0a     trans\
form=\x22translate(\
-5.0926999252319\
3, 3.20434576650\
541E-08)\x22\x0a     i\
d=\x22g12\x22>\x0a    <g\x0a\
       transform\
=\x22matrix(0.63636\
3804340363, 0, 0\
, 0.636363804340\
363, 0, 0)\x22\x0a    \
   id=\x22g11\x22>\x0a   \
   <polygon\x0a    \
     points=\x2230.\
6,18.6 21.6,27.6\
 17.4,23.3 14.9,\
25.8 21.7,32.5 3\
3.1,21.1\x22\x0a      \
   fill=\x22#4CAF50\
\x22\x0a         id=\x22p\
olygon10\x22\x0a      \
   style=\x22fill:#\
a6dda7;fill-opac\
ity:1\x22 />\x0a    </\
g>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x08Y\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   sodipodi:do\
cname=\x22select-ci\
rcle-gray.svg\x22\x0a \
  inkscape:versi\
on=\x221.4 (86a8ad7\
, 2024-10-11)\x22\x0a \
  xmlns:inkscape\
=\x22http://www.ink\
scape.org/namesp\
aces/inkscape\x22\x0a \
  xmlns:sodipodi\
=\x22http://sodipod\
i.sourceforge.ne\
t/DTD/sodipodi-0\
.dtd\x22\x0a   xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns:svg=\x22http:/\
/www.w3.org/2000\
/svg\x22>\x0a  <defs\x0a \
    id=\x22defs2\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     id=\
\x22namedview2\x22\x0a   \
  pagecolor=\x22#00\
0000\x22\x0a     borde\
rcolor=\x22#FFFFFF\x22\
\x0a     borderopac\
ity=\x220.25\x22\x0a     \
inkscape:showpag\
eshadow=\x222\x22\x0a    \
 inkscape:pageop\
acity=\x220.0\x22\x0a    \
 inkscape:pagech\
eckerboard=\x220\x22\x0a \
    inkscape:des\
kcolor=\x22#d1d1d1\x22\
\x0a     inkscape:z\
oom=\x2224.3125\x22\x0a  \
   inkscape:cx=\x22\
15.979434\x22\x0a     \
inkscape:cy=\x2216\x22\
\x0a     inkscape:w\
indow-width=\x22192\
0\x22\x0a     inkscape\
:window-height=\x22\
996\x22\x0a     inksca\
pe:window-x=\x22-9\x22\
\x0a     inkscape:w\
indow-y=\x22-9\x22\x0a   \
  inkscape:windo\
w-maximized=\x221\x22\x0a\
     inkscape:cu\
rrent-layer=\x22svg\
2\x22 />\x0a  <g\x0a     \
transform=\x22trans\
late(-3.0905, -3\
.0905)\x22\x0a     id=\
\x22g2\x22>\x0a    <g\x0a   \
    transform=\x22m\
atrix(1.42420983\
314514, 0, 0, 1.\
42420983314514, \
0, 0)\x22\x0a       id\
=\x22g1\x22>\x0a      <pa\
th\x0a         d=\x22M\
6.35, 20.25L7.56\
, 18.66C8.42, 19\
.23 9.39, 19.64 \
10.43, 19.85L10.\
16, 21.83C8.77, \
21.57 7.5, 21 6.\
35, 20.25M16.43,\
 18.66L17.64, 20\
.26C16.5, 21.03 \
15.23, 21.57 13.\
84, 21.83L13.57,\
 19.85C14.61, 19\
.64 15.57, 19.23\
 16.43, 18.66M19\
.84, 13.59L21.83\
, 13.86C21.57, 1\
5.25 21, 16.54 2\
0.24, 17.66L18.6\
5, 16.45C19.22, \
15.6 19.63, 14.6\
3 19.84, 13.59M2\
.17, 13.84L4.15,\
 13.57C4.36, 14.\
61 4.77, 15.58 5\
.34, 16.44L3.75,\
 17.65C3, 16.5 2\
.43, 15.23 2.17,\
 13.84M18.66, 7.\
56L20.25, 6.35C2\
1.03, 7.5 21.58,\
 8.78 21.83, 10.\
18L19.85, 10.45C\
19.64, 9.4 19.23\
, 8.42 18.66, 7.\
56M13.57, 4.15L1\
3.84, 2.17C15.23\
, 2.43 16.5, 3 1\
7.65, 3.75L16.44\
, 5.34C15.58, 4.\
77 14.61, 4.36 1\
3.57, 4.15M7.56,\
 5.34L6.35, 3.75\
C7.5, 3 8.77, 2.\
43 10.16, 2.17L1\
0.43, 4.15C9.39,\
 4.36 8.42, 4.77\
 7.56, 5.34M4.15\
, 10.43L2.17, 10\
.16C2.43, 8.77 3\
, 7.5 3.75, 6.35\
L5.34, 7.56C4.77\
, 8.42 4.36, 9.3\
9 4.15, 10.43z\x22\x0a\
         id=\x22pat\
h1\x22\x0a         sty\
le=\x22stroke:none;\
stroke-opacity:1\
;fill:#FFFFFF;fi\
ll-opacity:1\x22 />\
\x0a    </g>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x0a\xdf\
\x00\
\x00>\xf2x\xda\xdd\x9bIs[9\x0e\x80\xef\xf9\x15\
\xaf\xd4\x97tU\x8b&\xc1\xdd\x13\xa7\xab\xc6=sr\
\xdfz\xceS\x8a\xa5\xc8\xaa\xd8\x92KR\xe2$\xbf~\
@\x12 \x9f\x94\xc8\xc9\xa4\xdf;(Y\x05. H\
}\x5c\x01\xbf\xfa\xfd\xe3\xc3}\xf7a\xb1\xdd\xad6\xeb\
\xab\x89\x12r\xd2-\xd6\xb7\x9b\xf9j\xbd\xbc\x9a\xfc\xe7\
\xaf\x7fO\xc3\xa4\xdb\xedg\xeb\xf9\xec~\xb3^\x5cM\
\xd6\x9b\xc9\xef\xaf_\xbc\xda}X\xbe\xe8\xba\xee\xc3j\
\xf1\xf4\xcf\xcd\xc7\xab\xc9\x14\xba\xa9\x16^\x83\xed4\xe0\
\x9fI\xcemjUNX\xcd\xaf&X\xd3\xc6,\xed\
\xb0\x95G\xfc{9\xdf\xdc\xaeg\x0f\xa8|\xbe\x9d-\
\x05\x16(\x85\xd7\xefv\xb7\xb3\xc7\xc5eO\x8d\xe9^\
\x067\x0b\xb3\xb9\xff\xad\x03\x09f\xaa\xe4T\xa9_s\
y\xec\xc8zw\xc9\xb5\xae&w\xfb\xfd\xe3\xe5\xc5\xc5\
\xd3\xd3\x93\xe0D\xb1\xd9./RS\xbb\xc7\xd9\xedb\
w\xc1\xe9\xbd\xfalT\xad\xcf\x09b\xb7y\xbf\xbd]\
\xbcE\x15\x0b\xb1^\xec/\xfe\xf8\xeb\x8f\x9a9\x95b\
\xbe\x9f75\x07\xad?\xe9\xdc.H)/\xb8s\xd4\
\xd8\x87\xe5\xb3%_c\xd1W\xf3\xc5\xdb]\xaaR\x86\
/I8~\xddE\xce\xabC\x98:5O\xdfF+\
Y\x93h\xb8\xbb\xeeq\xb6\x5c\xdcn\xee7\xdb\xab\xc9\
/2\xff\xa2\x8c7\x9b\xed|\xb1}&k\x83\xe3\xb5\
\xda\x7f\xba\x9aH\x01\x96r\xea\xf7\xb3\xbb\xdb<%\xd5\
\xbb\xbb\xd9|\xf3t5\x81\xe3\x02)\xb3\xa7A~-\
\xff\xf6nq\xfbn\xb1}\xb3\x99m\xd1\xf6\xfd\xf6\xfd\
\xe2\xb8\xd4|\xb1{\xc7&\xceU\xfa}\x5c\xe2\xf3f\
\xf3\x80\xcd\x1b\xa1\xd5\x97V\xde\x22\xa5\xca\x8a\xe8\xa3\xd1\
\xe6\x8bL4L\xb9\xe3\xd4\xa7\xd5\x1a;4}Z\xcd\
\xf7w\x98\x1fA\x9e(q\xb7X-\xef\xf6W\x93\x18\
O\xe9HS$\x9e\xc8\xfb\xf4L\xde\xc3\xec\xe3\xeaa\
\xf5y\x81c\xf2Ewo\xdfo\xb7\x8b\xf5~z?\
\xfb\xb4\xd8\xf2\xc4\x220\x96\x8d\x83\xeb\xd9\xe3\xec\xbf\x5c\
y\xbf\x9d\xadw\xc8\xf0C\x1ac\xfcx?\xdb/^\
\xe2\xcc\x0d\xca\xb8\xe8\xc1E\xe5\xbdW\xff\x9aJ\x9c`\
S\x95'\xb4TA+i1\xffWR\xb2\xdb\x7f\xba\
\xc7\x09\xb6X\xcf\xde\xdc/\xa6of\xb7\xef\x96\xdb\xcd\
\xfb\xf5\xfcr\xbdx\xea$\xfe\x86\xe8\xd3\xdf\x7f\xbc]\
\xdd\xdf_\xfe\xf26\xff\xca\xc2\x940\xb8T\x99\xedf\
\xe8\x81e\x0f\xb3\xfdv\xf5\xf1%\x92\x12\x0dx'#\
D\xe3,\xfe\xf3['\xcb\x9f\x139l`\xe9\xf8\x12\
\xaaH\x16\x7f\xdb\x9e\xbeE\xa4EMZ\xc2\xff\xa1\x07\
5=\xce\xf6w\xadn\xd7\xa1\xb6?\x03\x8e\xb5\xcf\xab\
\x97\x16\xca\x98k\x1f\x846P\xe5\xcec\xbeM\xa2\x17\
\x0e\x5c\x15\x15\xe6zu]\xc5 \xbc\xb4]\xad\x0c\x98\
\x8dc^\x95\x17\xf9:DaT/?j\x11\xa5n\
\xf5\x9b\x5c\xd4W\x99Z\xaf\xf5\xc9\xb8#\xe3?O\xfa\
\xbdK\x83\x95z\xac\x0eR\xbfc\xc4\x0a\xb2y\xc4.\
\x96\x84E\xf9\xc0\xff\xf5h^\xdagI6B\x22\xaa\
\x1a\x14\x04\x15\xedOC\xb2\x19\x84d=(\xc9\xc6\x89\
hz$\x1bu\x08\x8b\xc6|h,\xb1H\xa8U\xb1\
\x90X+\x13\xa9U9\x91lA\x98\xd8\xcb\xb7\x98\xef\
{$7\xb9\xa8\xcf\xb2i\xad\xd7\xfad\xdc\x91\xf1_\
'\x19\xc6%9|cM\x96Vy\xeb\x83\xb28\xc7\
\x95\xffIH\xf6\x83\x90\xec\x06%Y\x81\x14A\xf6P\
VxP\x00\xa7\x1a.JI\xe1C\xc3\xa9\xca\x84[\
\x93\x0b\x8eM\x01\xf1\xda\x9a \xa0\x158\x5c\xbb\xfb%\
4\x96\xd0=\xa4{\x09\xd4HM`+\xaa\x0e6\xf3\
\xa8#_\xc7\xda\x8e\x8b\xb5z\xfe\xac\x91L\x8f:\x1a\
\xab\x83\xb6\xb8T\xff$\x5c+9\x08\xd8qX\xb0\xad\
\x17\x1e\xfa`\xe3:\xa8b\x9f\x18\x83%zD\x91\xc8\
\xc4\xb1HD\xd6\xda\xccl\xd5\xcfT;-\xc0\xf7K\
8,a\xfbT\xb7\x04j\xa3&\xb0\x0dYG\xcf\xc4\
\xa3N|\x1d\xea02\xd4\xe69\xa8\xe5\xcf\x00\xb0\x1e\
\xe6\xb4\x0c\xc3\x12\x8c\xd6\xf7\x01\xf6B\x87\xd8\xdb\xc6q\
\xb9\xcb\xbb\xba\x11\x88O\x07x\xa6\xc8\xab\xb4\x132\xc0\
\xb5\x12\xd2\x13X\xb8\xd9\xa7N\x03\xea\xb3\xa0\xcb\xc7\xc4\
\x1f\x5c\xe7\x8f\x16\xf5\xc4\x8e\xcb#\xaa:\xba\xac-\xb5\
\x85\x8b*\xb8\xeb\xd4T\xca\x04\x9c\x03\x80Go,\xc2\
\x98\x87.\x9b\x19\xaa\x8c\xab\xbbp\xce\xf5\xf2q;\xb0\
\xbd\xda\xca\x0b\xa5|\xd5\x8d\x0d\xc6\x00\xbd\x96Q\x9d\xb5\
\xcd\xb0&\x17\x9b\x9b\x9c\xba\x83S$\xd5\xef\xf5\xb4\xaa\
\xe7\x81H\xcd\xf7\xc6)\x9bg{S\xecp\x94O\x9c\
\xebG>\xd8+\xff\x9dSL:%\xb5U\xd6\x9d\xdd\
\x14s\xc3L1;\xca\x14S\x10\x05h\x8b\xa0\x9b\xc4\
\x22\x89\xa9\x1fJ\xeb\xb4\x02\x97\x8f\x98\xea\xf2\xacAP\
\x84OGu*o0'\xc4\xca\x12\xc9\x89=\xebz\
\xf9\x99]\xdd\xaaW\x994g\xd9\xb4Fs}\xdd\xec\
92\xf7\x04\xabf\x5cV\xebK\xd07\xb7\x03\x9c\xe1\
^j\x05g\xc7j\x1c\x86\xd50\x0a\xab\x11\xf0\x88P\
Q-R\xeaEt\xc2\xbb\x02\xaa\x04\xa1e\x01\x15W\
\xc5`B\x05\x15W?\x0d=P\x8b\xdc@\xa5\xfc\x0a\
&Uor\xd1\xcc\xa0R\x9b\xcc)\x19sh\xe9\x09\
J\xfd\xc8\x94\xea\xef]Q\x954Q\x1a\x15\xce\xee\x85\
o\x98'>P\xa3Pj-\x82\xe4\x98\xd2\x22\xa5^\
\xd8(\x82\xca\x94:L\xb3\x19R\x8f7\xb7P\x19\xf5\
\x98\x1e*CY\xaa|\x96<\xa6\x91\xea\xb1\x98\x15\xea\
\xca&\xb5\xc4l\x92\x09\x87\xf6\x9dx\xfb\x90#\xb3\xe9\
\xbe\x97M\xab\x8d\xb4\xde\x9d\xdd\x0a\x0av\x186\xcd8\
\xbb\xbdsB\x85\xb6\xdb\x171\xaf\x9c\x88\x94\xf3e\x11\
\xf5N\x80Ry\x11\x0d\xf8}\xd8\xb6\xdb\x07\xcc\xe9!\
Jr[D)\xbf.\x9a\xb9\xbak2i\xae\xbb=\
5Zw{\xb2\xe7\xc8\xdc\x13\xac\xea\x91Y\x8d\xdf\xc7\
\xea\xd9\x11\x1a\x86!\xd4\x8fC(\xde\x85\xbc\xe3\x1b_\
\x91\xf8\xc2\xa7\xa20:\xd6\xfb\x9e\xc2\x0d\xd9\xd4\xeb\x1e\
\xdea\x5c\xccW<\x9b\x99K\x9f\x820\xe50\xa0\xb1\
\x94\xe1\x9b\x1e\x1e1\x1dx\xbe\xe8i\x9b\xde\x88\xf9\xa2\
\xa7\xb1a\xe4\xbd\xdc\xf34\xd6\xd7\xf5\x96\x97\xa5z\xc7\
\xa3<\xbcb%WL\xae\x16\xea\x0d\x8ct\xf2\x05/\
5\xa8|\xbd\xcf\x15c\xeam\xae\x18Y\xc5b}\xbd\
\xdb\xa5\xab_S\x9c\xfb\xac\xeb\xcd\x8e\x06\x84/v4\
Z\x87Cyb\xf2\xb8q'\x8f\x86\x1f\x7f\x0e<\xb7\
\x09\xa5\xd50~\x1a9\xce+ q\xcbot\x04.\
\xbf\xbf!\x9b1!T\xdf\xe3\x12\x8e\xba\xf7>\x07\x22\
$\xb2\xb9z\x86\xaa\xf7\x06X\xe4\xf6\xc4\xc8\xf9\xf4\x86\
H\xb5I\x22\xdd(\xb9\x18\xa9\xed@\x0f\x8cmJ\xf5\
\xed>Ao\x1c\x99\xde\xe7\xdd\x8dN\x04\xe7\x8c\xb5\xd2\
9\x9c\xab\x1a\xce\x9b\xde\x81\xbc\x8c\xc3\xba\x19U4\xc2\
Y^gqu\x94=D\xd2\x83\x96\xa3\x855\xc1[\
e\x02\xac\xc9\x05?\xae\xcdl\xb2nf7D\xa1\xa0\
e\x07\x93V\xa7\x06o\x95\x09_\x96\x19_\xaaN\xf8\
\x1e\x18\xfeu|\xf5\xc8.F\x1d~<\xee\xe3\xec\xf0\
\x1d\xc6\xb5\xa8\xdd(\xf1\x1e|\x9a\xa1\x88\x0d\xda\xa09\
\x9e#\xf1\xe5\xabT\xce\x01$\x11[\x5c1\xc1\x04\xb1\
Fb\x14\xb1\x06zP.\xc7qP\xdd\x1a\xd6Q\x14\
W\xb1\xb4\xcau\xc9\xa4C\x83O`;\xb2\x0b\xd1\xa8\
\x1f\x0f\xf28\xbb\xd0\x8ea\x1c\x87:\x8e\x12\xdcA\xd8\
rx\x061\xc2\xc1\x1b\x05 \x96\x0a]$\x11z\x5c\
\x91\xc0d\xb5\x84-GeP.\x07qP\xdd\x1a\xd3\
Q\x14\xd7\x90\x8e\xd2*\xd7\xe5\x8b\xc1\x81\xc1'\xb0\x1d\
\xd9Ih\xcc\x8fGt\x9c\x1d\xb6\xc3\xb8\x0b\x0d\x8c\x13\
\xc9A\xdc\xd68\x0c\xbe\x10q\x9cFa\xa8\x8a\x850\
\x16y;\xe7\xca\x84gUN\xf4\xd6\xf0\x0b\xce\xe7\xf8\
\x0c\xae_\xe35H}\x95\xa9u\xae\xcf\xc6\x1d\x1a\xff\
u\x86\xcd\xc8^8\xe3\xbfq\xe0%\xdf\x9b\x96.\x18\
m\xce\x9b\xe1a\xfcqfX\x7f\x1ch%lh\x07\
^m\x04\x80\xae'^\x5c_\x83\xaa\xef\x0c\x80\xa9.\
\xad\x8a\xf4\xd0\x00F\x0a\xabc{\xda\xc0\x05\xd8)]\
\x9f\x1aX\xe4\xb7\x86*\x97\xc7\x86\x5c\xdd\xd47\x94\xaa\
\x9d^\x1b\xb8q~~a\xd32\xb0\xb6\xab\x96\x17\xf9\
\x1a\xb0\x15\x9c\x08-?\x01\xef\xa8:\xda\x0e\x06mv\
M;\xce\x0b\xa7U}\xea\x00L\xb76\x90q\xb6'\
\x93\xf1,S\xdfr\xf5\xf6\xc6\xc2\xdayd\xa8qz\
\xd7\xc9\xb6\xf1V\xa4\xbb\xc3A?1\xf5Fv*Z\
\xf9\xe3S\xef|\x1d\x8df\x18G\xa3\x09\xe3LB\xf6\
\x0e\x02r\xa3\xfa\xde\xc1<s\xa0\xe7\x1el\x09\xe4\x1f\
\xe4\x04r\x10\xb2\x86\xec\x11t\x8d\xb8\x22g>\xa5i\
\xd9\x19\xee\xd8j\xb3\x5c\xd5\xb7\x042\x80\x14T\x0b\x8f\
\xbap\x02\xea\x91}\x90V\xff\x0d\xa8\xcf\xd6/i\x87\
\xf1KZ5\x0e\xd4\xc5\xa1\xc8@\x92C\x91qe\x8f\
\x22\xcb\xecRd9\xfb\x14C\xc59;\x11}\xa3\xad\
\xc8\x15g\xcefZ\xb96\xcb\xac\x9den\x9d\xaa\x93\
m\x07\x86\x9f\x88j\x1d\xd9ai\xdd\xdf\x01\xf9\x5cC\
\x96\xec0NLkFZ\x9d)\xc8\xa8\xae\xce\x1cd\
T\x17c\x8e2\xaa\x09\x1cf\xd4\x12\xb4\xf0\xaa-\xcf\
%\xae\xa8\xb7>SB%\xba\x16\xa8\x0b0kh\x09\
\xd4FM`+X\x05\x9by\xd4\x8f\x13d\x8f\xec\xde\
\xb4\xcf\xba7\x11a>Z\x18\xed\xf0\x06\x8bd\xbb\x1e\
\xd9\x1e\x8c\x8f`\xceo\x89\x1e\xc6\xf9i\x87u~B\
\x94\x02\xf7\xbbtd\xd6\xb8\xd4\xb9\x1b\xe5\xf1\xb2\xe83\
\x22\x12\x13\x92?\x06Q\x01S(\xc3\xed\xb1S\xb8\x84\
*\xb0%!\xa6hN\x87\xfb}\xf6\x02\x1a<\x11\x07\
\xbc\x05\xe3\xa2\x8b\xdf\x5cJ\xc0\xb30$?K:\xd7\
\xc7\xc2\x9dU)\x01\xab\xe6\xd7\x14\x8bg\xef\xa0n\x00\
O\x196\xffh\x81W\xe9g&\xafShh4\xe9\
u\x12\xd7\xe0\xc8\xc1\xdaI\x0cX\x10\x0f\xd0\x0a\x81\xc8\
\xb1\xe1\x98\xe0\x00WtL\x08\xd9\x8f\x99\x13L.\x11\
S\xd7J\x82-\x09\xa1V\xc1\xfb\x82\xc2\xe9\xe1\xfb\x05\
b\x8a9H\x09\xb8\xbc\x9a<\xc1 \xbf\x90\xe2\xa0h\
mo\xd2\x9c\x05\x93\xac\xd0hnt7\x90\xb6\x8f\x84\
'8\x87\x1dC\xb3\xb1$\x1e\x9fR\x02\xda\x99\x8d\xd7\
I\x01\x0e\xa2\x89\xa8\xd1{\xbc\xa1\x98\x9ap\x0d\x01\xc7\
?\xbb[\xb9\x04~\x0fR\x03)\xc0\xb1\x83`\xd0j\
OMD\x5c\x17\x02\xde$ \xeb\xc0\xb6\xba,\x96[\
\x8bK[\x1b&X!]\xbec\x01~\xb7h\xb5\xc5\
nDS\xc2}!\x0d6~\xe9\xde\xe7\xb0f\xc8\xf1\
\xba\x90\x5c\x07\xe5\xe78\xf0>\xa6 \xcd\x17\x1c\x99\x84\
E:\x0e\xe2\x97\x0e\xf8\x7f\x8c9\x01\xbf\xe3\x14H\x91\
\x12\x8ak\x03o0>U1xN\xcc\xbe`S\x82\
\x88\x8f\xd0\xfa\xfc'\xe0J\x16J\xdc/r!q\xb4\
\x00/G\xa0J\xe0\xb0\xd1i\xc1\xc2\xf1\xd29\xa4:\
\xdd\x8bl\xbeU\xe9\xe2s\x97\xc8C\xbc\x01<\x5c\xda\
\xec\x90N|\xdap\x93\x22?d\xf6\xd8\xa7\xf1\xf1\xd8\
;d\x0b\xbb\x9cL\xd5I\xd9\xcdq\xb3'V\xbd\xa1\
\xfd\xd2\xaf\xd2\x8fT\xbf~\xf1?Ox\xe4\xab\
\x00\x00\x02\x7f\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!--\x0d\x0a // 1\
6pxls (c) by Pau\
l mackenzie <pau\
l@whatspauldoing\
.com>\x0d\x0a //\x0d\x0a // \
16pxls is licens\
ed under a\x0d\x0a // \
Creative Commons\
 Attribution-Sha\
reAlike 4.0 Inte\
rnational Licens\
e.\x0d\x0a //\x0d\x0a // You\
 should have rec\
eived a copy of \
the license alon\
g with this\x0d\x0a //\
 work. If not, s\
ee <http://creat\
ivecommons.org/l\
icenses/by-sa/4.\
0/>.\x0d\x0a-->\x0d\x0a\x0d\x0a<sv\
g fill=\x22#FFFFFF\x22\
 width=\x22800px\x22 h\
eight=\x22800px\x22 vi\
ewBox=\x220 0 16 16\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22>\x0d\x0a    <path\
 d=\x22M9 3.793V9H7\
V3.864L5.914 4.9\
5 4.5 3.536 8.03\
6 0l.707.707.707\
.707 2.121 2.122\
-1.414 1.414L9 3\
.793zM16 11v5H0v\
-5h2v3h12v-3h2z\x22\
 fill-rule=\x22even\
odd\x22/>\x0d\x0a</svg>\
\x00\x00\x03\xb0\
\x00\
\x00\x0f=x\xda\xdd\x97\xdbr\xa38\x10\x86\xef\xf3\x14\
\x94\xe6f\xa6*\xc8:sH\xc8TmM\xcd\x13\xcc\
>\x00\x01\x05S\xc1\x88\x02\x12\xdby\xfama0\x06\
\x1f\xe2\xecd/v0.\xa3\xfe[R\xab\xf5\xb5l\
\xdf\x7f\xdf\xac\x0a\xe7U\xd7Mn\xca\x08QL\x90\xa3\
\xcb\xc4\xa4y\x99E\xe8\xef_?]\x1f9M\x1b\x97\
i\x5c\x98RG\xa84\xe8\xfb\xc3\xcd}\xf3\x9a\xdd8\
\x8e\xf3\x9a\xeb\xf5_f\x13!\x979ps{\xa3N\
\x18G\xa4\x9d!O#\x04\x9dvj\x03\xe3W\xf0\x0e\
S\x93\x94\xf1\x0a\x86\xad\xe3m\x83A\xdf\xf9\x96\xcfM\
\x12W:<\x18E8_}\x15\xfbq\xea\xdd:\x8c\
0\xe1R\xe2R\xfam\xea\xaf7\x95\xa9[\xf7)/\
\xf4\xc1\xb0U\x99\x9dt\xdb\xa4U\x1e\xa1@\x9d\x14\xb7\
\x87\x22\xe4\xa8l\xc2\xc1%B\xcb\xb6\xad\xc2\xc5b\xbd\
^\xe3\xc1\x88M\x9d-\xec\xa4M\x15'\xbaY\x0c\xf6\
\x83\xfe\xc3\xaa\xf7\xfd\x07\x03n\xccK\x9d\xe8'\x18B\
\xe3R\xb7\x8b\x1f\xbf~\xecE\x97\xe0\xb4M\xc7a&\
\xb3\xafy7/#\x84,\x86\xec\xf5\x93\xbdf\x17=\
\x1f\xc0\xf5>\xd5O\x8d\xed\xb2\xdb\x1e\xdbb\xc8Yt\
\xd2~\x8b\xec\x9aR\xbb\xcf\xa3\xe3\xde\xb4\xdbM\xc7\xa9\
\xe2L'\xa60u\x84\xbe\x90\xee\xea\x85GS\xa7\xba\
\x1e\xa4\x9f\xdd5\x91\x0cd+o\xb7\x11\x22\x98\xc9^\
\xd9oE\xb34k;t\xb3\x8cS\xb3\x8e\x10\x9b;\
X\xf1`\x04rJO\x96:y\xd6\xf5\xa3\x89k\x08\
\xfd\xc8%\xd5\xcd\xf3\x10_J\xedk\xee\xf1f\xcc\x0a\
\x08\x14XR\xcf\xf3\xd5\x5cN\x80~\x0au#\xa5 \
G+H .\xeac\x8fK\xc5\x83\xb9\xb8\xceKX\
\x96\xbb\xce\xd3v\x09n\x01#g<\x96:\xcf\x96-\
\xd0\x18\xa83\x1e\xb6\x02\xcf\x8d\xbf\xbd\xa0\xad\xe2M\xbe\
\xca\xdf4d\xe6h\xdd\xc9K]\xeb\xb2u\x8bx\xab\
\xeb\xbex{8\xb2\x9dk[\xc7e\x03\xd4BzV\
q[\xe7\x9b\xaf\x04\xfb\xd2\xe3\xd4#\xde-\xb1\xaf\xb1\
\x09\x18SF\xa4\xa0b\xf2\xfc\x0d\x8dXe\xc3\xfe6\
\xed\xb6\x80*k\xda\xda<\xeb]~B\x86=\x110\
OHy\xd7\xdb\xd3\x18\xb8\xa8\xa1\xc2\xc3\x12N\xa6\xde\
\x1a~y\xea\xae\xc1\xa9\xa7#\xa4\x1d\xf0c\xe8\x93\xe0\
a\xbd\x85\x86\xd8\x89\x92\xbeO\x03\x7f\x08\xaa\x0f\x8b\xee\
\x9b\xa7\x02\x13\x14\xb6\x97\xb0@q\xf6[\x91AlE\
^\xeaa*\xa8c\x1a!I\xd0h\xd8\xce\x0d\x1b\x16\
!1u9\xb2\xecf\x9b\x17\xdf\xa8\x0c\xf81Ym\
\x8eE\x1b\x11\xc0\x00\x07\xa9y)\xd3\x03\xdd&\xc6\x8a\
t\xd2\xa7\xcb\x0e\x9c\xbeE\xd8Owg\x1b\xe3R\xdf\
K\xc5\xdd\xc72\xdb\xe3\x08\x99[d\x1d\x97\xfd\xc7Y\
<\x01<_1\xc6%\x1b\xf0\xb4\xad\x80\xb2[\xe6c\
F(\xe7\xca\xc2\x09O\x8a\x12\xa2&p\xf2Sp\xce\
W\xb2g\x95\x07\xdc\x97\x92_$\xe2S\xe0d\xfb\xda\
\xbe*4\xc8\xa9\xf4\x09\x0d\xc4;\xb4\xfe)x\xba\xe2\
\x18\xd0O\xce\xcf\xc1\xac\xc3\xd1Y\xc4\x8f\xba\x18#\xf8\
(\xa6\x04\xc3\x89I\x89\xf2|@TR\xe5+\xc9:\
0O\x99)\xc7\x01\x5c\x8c\xde\xba\x1c\x13\xa6(g\xc1\
\x14\x5c\xf8\x09w\x12\xdd\xbeD/\x17!\xc3\x82pE\
\x03z\xe6\xdc\xfd-t\xd99t\xaf\x0a\x8d+,|\
\xeeQ*\xc5\xc5\xd8\xfe\xb7\xe8\xca\xf7\xd9\x92\xe7\xf1\xfe\
\xa4\x1c~\x1c^I\x02.\xe1{\x7fN\xec`>\xb0\
\xba\x0c\x03\x18\x9c)\xbf\xe3X\x01fr\x06\xaf\x9c\xc2\
{\xcd\xb7\xcb\xb5`S\xc1\x08\x17\xfc\xbf\x00\xdb\x9b\x93\
\xfdiq\xc3\x8e)!\xb8R\xd2\xfb#\xa9W\xff\xe6\
\x17\xc5\xb5\xb9\xd9\xf5\xae_\x0am\x9bo\xf0\xff\xe3\xbd\
\xe4\x9f\xe4\xff\xde\xfe\x85z\xb8\xf9\x07\xbf-Kn\
\x00\x00\x0c\xf2\
\x00\
\x00c%x\xda\xed\x5cY\x8f\xe36\x12~\x9f_!\
x^2\xd8\x11\xcdC\x14)\xb7\xbb\x83d'\x01\x82\
E\xb0A\x92\xc5>\xab%\xda\xad\x8c-9\x92\xfa\xf0\
\xfc\xfa-\xd2\x92\xad\x83r\xbb\xdd\xee\xac\x93\xd8\x8d\xc1\
H\xbcT\xac\xfa\xea Y\xd2\xf4\xeb\xa7\xe5\xc2yP\
y\x91d\xe9\xf5\x88 <rT\x1aeq\x92\xce\xaf\
G\xff\xf9\xf5{W\x8e\x9c\xa2\x0c\xd38\x5cd\xa9\xba\
\x1e\xa5\xd9\xe8\xeb\x9bw\xd3\xe2a\xfe\xceq\x1c\xe8\x9c\
\x16\x938\xba\x1e\xdd\x95\xe5j2\x1e\xaf\xee\xf3\x05\xca\
\xf2\xf98\x8e\xc6j\xa1\x96*-\x8b1Ad<\xda\
5\x8fv\xcd\xa3\x5c\x85e\xf2\xa0\xa2l\xb9\xcc\xd2\xc2\
\xf4L\x8b\xf7\x8d\xc6y<\xdb\xb6~||D\x8f\xcc\
4\x22A\x10\x8c1\x1dS\xeaB\x0b\xb7X\xa7e\xf8\
\xe4\xb6\xbb\x02\x8d\xb6\xae\x14c<\x86\xba]\xcb\xc3Z\
M\x0a\xe0\xca\x0a\xfem\x9b\xd7\x05\xa8\xc8\xee\xf3H\xcd\
\xa0\x9fB\xa9*\xc7\x9f~\xfd\xb4\xadt1\x8a\xcb\xb8\
1L\x92~.\xa2p\xa5ZO\xad\x0b7\x1c\x08\x97\
\xaaX\x85\x91*\xc6u\xb9\xe9_\x0f9\x89\xb3H\xb7\
\xb9\x1e\x95j\xb9Z\x84\xa5B\xc9\xe7,\x0dQ\xb8Z\
\xa1\x9a\xe6\xba\xe7\xa4!\x5c\xe2\xc6\xea\xc1\xf9JP\x8f\
\x11I\xe3(\xfa\xe8PL\xb1\x8b\xa9\x8b\xfd\x0f\x9bn\
\xf1\xf5\x08\x86\x90\xe6\xa6\xd9uS\x90\xa8\xc7o\xb3\xa7\
\xeb\x11v\xb0\xc3}\x84\x03\xe2\xfb\xdc\xa1P\xef\xc3O\
\x98Fw*\x99\xdf\x95\xd7#\x89\xcd\xedc\x12\x97w\
\xd7#J\xe8\xe8\x06\xee\xa7\xb1\x9a\x15\xba|\xf3,}\
GG\xce\xd8Tm'\xa8g\x17\xeb\x87U\x0d\xeb\xb9\
\xdc\xdef \xe5,V \xb32\xbf\xdf\xb0\xa5Q_\
\xa4\xe1\xca5\x8d\x96I\xbc\xca\x12@\xdf\xf5h\x16.\
\x8a\xe1\x96\xad\x81fI\xe9.\xc3|\x9e\xa4\xeemV\
\x96\xd9\x12f\xda\xaf\xca7\xf3\xb3\xd4,\xd4\xcc^Q\
f\xab]\xf9\x96\x88\xc7$\x8d\xb3Gh\xf3\x94,\x93\
/\x0a\xd8A\x06\x9a\xac\xafG\x8c\x0e\xd4\xc1\x14\x08\x95\
C\x83\xd7\xd2\x08\xa4\x18hQ\x09\x88\x04\xb4\x1e\xe3>\
M4\xe3VO\xd5}q\x97=\xces-.\x1b\xd3\
\xa3\xfb<\x07=w\x17\xe1Z\xe5\xd7#\xf3_o\x1e\
\x00\xd9{m\x0d\xdc\xee\xd8\xbba`\x8e\x01\x92\x01&\
\xa2Oj\x04\x93\x94\x1c1\xccq\xe0w+\xbfdZ\
P^\xb7x\x15\xceUq\x17\xc2\x14\x01}\xb6\xca\x0c\
t,)\xe1\xb1\x18\xd53\xbf\xcd\xf2X\xe5\xdb\x0a\xd2\
\xa9\x88\xb2E\x06S|\xef\x9b_U\xa5\x87\xaa+\xb0\
\xf9\x8dv\xf8\xbe\x0d\x01{7\xe6~\xba}\xb8\xe6\xe5\
\xa6\x89\xe3d\x80\xa6$\x85g\xb9\x8c \xc1\xa1\xb7\x1c\
\xb5\xeb`\xea\x0c\x11\xe1\x81\xc9\x0b\xb6U\xa0\xf8\xdaD\
\x183\xedmK\xf5\x13\xf5\xe0\x92\xed\x06)\xd7\xda\xd6\
<\xaduy\xadh\xe3\xbe\xa6\x99\xf2\xa5*\xc38,\
\xc3\x1d\xfdu\x09\xaf'\x01\xe6v\xf2\xf3\xa7\xefo\xaa\
\xe1\xa7Q4\xf9o\x96\x7f\xae\x9f\xe68\xbaAx\x9b\
\xdd\x03\xe6F7\xdb\xe2i\x1cM\xc0@.\xc3\xf2&\
Y\x02\xc3\xb4m\xfd\x07\x18\xc4\xe9xW\xd1j\xac\xc9\
\xde\x0d\xba\x196W\x1bKku7q\xb4Lt\xa7\
\xf1/e\xb2X\xfc\xa0\x1fRM\xb71hR.\xd4\
\xaep:\xae\xa8\xaf\xe66nLn:\xae\xa7n\xee\
\xe6\x95&\xd4|K\xd2B\xa5E\xa2\x9dWK+\x8a\
r\xbd\x80\x928)\xc00\xaf\xa1\xd9\x22I{\x1a\xb3\
\x08o\xd5\xe2z\xf4-`\xc3\x98\xef\xa2\x01\x18\xa3>\
=\xb8\xce\xf3\xec~\xb5\x04\xc3W5\xa8\xa51\xaf\xa7\
\xf7,a\xfbI\xb3\x13\xd7\xc2\x95y.\xef\xb7\x1f \
MCEEe\x03\x17\xeb\x9d\x05\xd4?\xb8\x95\x88R\
\xe2\x07\xd2S\xe0\x7f\x1aU\x80x\x97\x22\xcf\xf3\x02\x16\
p\xa8\x93\x8d\xba\xda\x9e\xd5>\xa7\xd9\xaf\xb2d\xb5c\
\x12\x8d*=\x03M\x0f\xa1\xa49Z\xc5\x93J\xe1'\
\xe4\x0ab\x912\xcb]5\x9b\xc1\xc5$\x85\x98\xe7j\
\x06p\x9a\xbcWB\xff\x99\x1bw\xd7\xdc\xdc\xe6\xf7\x0b\
\xa5\x9b~\x01\xcbqU\x94y\xf6Ymzn\xae7\
\x06v\x82\x11c\x9caY\x97j\xee\x03\x03'\xc0\xbe\
4n\x16\xfe\x06~k\x02XVy]jn\x16\xe0\
#\xca\x89W\x97\xc5!\xd8\xb6<\x07A6\x1f\xa5K\
\xb3\xd9\xacP\xe5\x04\xd7e;jW!xD\xd7X\
2\xe8\x05:\xb7hh\xc8\xb4TO\x0dq\x81nN\
L\x10\x02\xb6\x1a\xf4N\xe5\x0f\xaa\xcf\xb7Y\x06\xe3\x99\
\xebj\xbc+S\xf2hd\xd4**\xc0\xbfM\x08F\
\x5c2\xb6z\xba\xd2\xf3\xac\x5c\xd3\x84 \xca7\x8df\
\xe12Y\xac'E\x98\x16.<1\x99]-T\x09\
Sw+S7\xc1\xd0\xf5\x11\xe8o\x15l\xe4\xf3\xbd\
\xf9u\xe5\xb3G\x1a\xd4\xf7\x80\x986\xea|$|\xc2\
\x00xm\x9c\x12\x00#aL\xf8\x1d@i\x8eIJ\
\x5c\xe6R\x97\xca\xd1\xcd\xb4\x04\xba\xd2\xa6\xd5\xda\xaae\
\x9ei~\xb54n;\x8a\xee$I\xe0r7p\x03\
\xd1\xaa\x1f\xa0i\x90\xaa\x8ed\x0c\xd3\xa1\x15\xfc\x80Q\
v\x06\xdcP\xbaz\x9a\x8e\x0d\x157\xf0?\xcc\xe9O\
\x0f\x89\xb6\x8d;%B\x08C~\xc0\xb8\xcf\xdb\x08\x09\
@H\x82{T\xeeE\x88\x1b\x9c\x08#.\xeb\xa2\xc4\
F\xd7 e\xc7\xa0\x84]Pr8J(C\xe0g\
z(\xe1\x883\x8f\xe2@<\x83\x12\xd7?\x19N\x5c\
\xdcE\x8a\x8d\xb6A\xea\xda\x02\xab\xc4s\x9b-\xe2\xab\
\x17@\xc7\x93\x17\xe8\x1c\x0c\x1d\xe6\xa3@\xf8\xb4\x15\xf3\
\x98\x95\x08\x95\x847\xe3\xfa!\xe8\xd0\xd3a\xc7\xefb\
\xc7F\xdc y\xc7X\x19\xdf\xbb@\xe5p_\x848\
\xa5\x82Q\xd2\x81\x8a\x87\xf4*\xf2\x99h\xc5%\xa7\xc2\
\x89\xec\xf9\x22\x0b]\x83\x94\x1d\x83\x12\xe2_Pr0\
J\xb8@\xc0L\x8f\xf8]\x83\x82\x89\xf0e\xc0\x9f5\
(\xae8\xa17r\x83.Zl\xf4\x0dRx\x12\x7f\
\xf4I\x15\xc9<\x05\xce;a\xea|\xb3Z9?D\
Yz\xc1\xd3\x0b\xf0\xc40\xee\xe2IoQqPn\
\xf6\xbc\x83rO\xe9\xa2\xfa\x01\x8e\x8d\xc0A\x12\x8f1\
?\xdf,\x16\xce:\xbbwR\xa5b')\x9c\xf2N\
9:\xc6qtw\xe4\xfc\x1b\xeess]8a\xae\
\x9c4\x89\xd4G\xe7\xf6\xbet\xd2\xactr\xf5\xfb}\
\x92\xab\x18]\x00\xf7:\xc0qD\x03\x02K\x1br\x08\
\xe0N\x0c\xb9\xfe\xfak\x10t62\x8f\x01\xdd\x8f\xe1\
g\xe5\x14\xf7\x80'\x0d\xbd\xa2\x0c\xd7\xcecR\xde%\
\xa9\x81\x1fxD\xbd\x91\xf8\xd1\x81\xc5\xfc\xe6\x82\xd5\x17\
\x80\xcc\xcdE\x98\xc6\x0e\xc4W\xfa\xc61\x9bv\xc5\x05\
\x83/\xc0 f\x8c\xf3\xce\xc6\x90@\x1e\x98\x13\x8fx\
\x87a\xf0\x94\x9e\xd4\xa0\xd0\xe5\x16\x1c\xf6\x08\x1d$\xf5\
\x18\x1c\xfe\xa0O\x1a\x9d\xfbB\x19\xbbW(\xa7\xcc\x1c\
\x98m\x1eF\xa5Ff\xee$\xe0L\x9dY\x9e-\xa1\
\x1e\x8c#\xf0]]p\xf6\x12\x9cQ\x16\x90NHO\
1\x92>\xe7\xe2`\x9c\x9dp\xa7\xa9F\x9aKmX\
\xeb\x12;H\xee1X\xfbE)G\x9f\xf4\x14\x93\xf1\
\xf8.\x99\xa3\xcf\xf1\xe6\x80\xdc\x8c4\xd6@+\xc6\xce\
,\xab0\x17\x9b\xb0\xce\x09\xe3\x07p\xb8\x03\x88\x9b\xb7\
\xf97'\x1e\x0d\x9a\xa7T\xed#\x8b\xcdd8h\x0e\
\xfc\xac&_\x1f\xca\xb5\xd7?\xdb\xf3\x09d&\xc1\xda\
\xdd\xea\xb3V\x8e\x98\xa9\xed\xb1\xdf\x9cQ\x10l]G\
\x1fpJ\xe1G\xfa\xefU\xa7\x14>\xc6\x5ct\x0f)\
 z)\xcf\xe0\x8cbPB>0; \x16\x09\x81\
\xc1\xe3\x92\x0cH\x88\xf4N\x90v\xe9\x0a\xd6\xca\xad\x84\
\xba\x8e\xfep\x09QF}\x1a\xbcJB\x1c\xfa\xff5\
\xe4\x13 \xce\x08\xf5\xfc\xb7\x90\x8f\xcb\x8e\x94\x10\x94\xe0\
\x19\xb9H\xc8\x1c>\x110c\x22 \xfcm$\xe4\x1e\
\xabE\xb3H\xff]ddd\xc4\x90\xd0\xbe\xe6\xadD\
\xd4Ya\x1f.$\x16\x87J]L\xddFH\x1cI\
\x09\xa6\xee\x0d\xa5t\xb42Q\x11*\x1f_\xe4d\xe4\
$P\x10\x80\xc1\x13o)\xa7N(\xfd\x02\xb3\xe7\x0b\
\x88E/\x92\xd2\x92\x12\x18\xf8\x0df\xcf\x7f[I\x1d\
\xadUq\xe8y\x9c\xfdEe5\x1d\xcf/\xab\xf8\xbd\
\xabx\x1f\xeb\xa5e{\x15\xef!\xecI\xc2\xd9\x01G\
.\xa7\x5c\xc0c\xb8\x10\xb6\xc5{\x97\xc6A*Or\
\xec\xf2\xcfl\xa1\xf7\x87~\xd69\x8f\xd1\xe6\xd5\x80\xcb\
\xbe\xd0+\xf7\x85\x02\x1d\x9eKr\xf0\xb6\x10;\xfd\xb6\
\x90\x7f\xf8\xb6P\x9f\xda\xe3w \x1f\x81\x9fN\x18\xc7\
N\xb4\x08\x0b\xb3\x1b\x999\xd9\xedo`\x84\x0b'\x9b\
U{\x93\x91\x81\x5c\x013\xd4\x05k\x07\xe0\xb3\x82\x16\
f\xcb\xbcX\x17\xa5ZVM\x9cUh\x04|\x01\xe4\
\xeb\x00\xa9s\xd8}\xcf\x13\xe2pD\x9e.\x11\xa1\x81\
\xc9\x17lV\xdaH>\x06\x96I\xea\xfc\xeb\xd3w\xce\
O\x00\xc7e\xe8\xa8\xf4!\xc9\xb3\xd4X9\xeb\xf6\xf7\
\xd6\x836r\xb8\xf7&h\x1f\x90\xe1\xdd\xcd\xe1\xfe\xa9\
\x99\x5c\xde\xc8\xe2\xf6\x8e\xcf\xe2^W\xd1\x93\x00fv\
\x12\x97\x80\xc1\x1e\x84U\xb6dm\xe2\xa3\x80\xc1\x8f\xf6\
\x93\xb5mU\x9a\xd0\xea\xa4\xaa\xb5\x8bce\xd0\xd5\x01\
\xb1X\xc8\xf5\xdf+b1\x82\x18\x15\xcc?\xd7h\xac\
\xb7\xad\xbd{\x09e\x18X{\xe2\xee\xc3\xa3\xdcWs\
\x16Cx\xcf|!\xcf\x8a\xb5]KS\x1d\xa6\xba\xd6\
\xd5\x84D\x9eYLP\xebB\xc4^\xbb\xc9\xd8\x15\xda\
\xe4\x8b^\xde\xcb\xc6\x15@\x00f\x8f\xb7\xbb\xc2\x0e\xe4\
\xf3\xb2\xde\xd5\x979\xb8\x10\xfd\xc2\x8d\xb6\x1dp\xa9\xe7\
\xf5\x95\xc9\x8c\xf8\xe8R\x0fb?x4\xf9p6\xe0\
\x08\x02\xce\x898kpT\x07\xec\x9d\xb3\xd8\xda\xbcQ\
d\xdfJ\xe8U<\x99s3\xa2\xf9\xdf;\xbc\xa5\x1c\
#\xcf\x18\xc9g!a\x95/\xd1\xbb\x1a\xfa\x8d\x18-\
c\x89\x18\x5c\xd2\x0f\xa3\x9e\xd1h%)\x9c\xb7\xd1\xf0\
\xb8OEp\xd6\xb8\xa8R1:\xa1H\xfd\x8e\x12\x92\
T\x8b\xdan4\xec\xb5\xfa\xb5(B\xc0\xfbR/\xe8\
e\xe0R\x9f n\xce\xba\xec\x10\xe9\xb9q\xe2!\xa9\
\xdd\xb5\xd7K*\x95:K\x8aZ\xdc\xb8\x87\xa8v\xd5\
\x8c\xf4\xdd\xb8\xadJ3\xa1JLi\xa5\xfd\xfd\xff\xdc\
\xb8~\x07\x8bHv\x9e\xbb*\x7fDD\xf8\xa3y\x1d\
\xd9\x12\x12\xb2\xe3C\xc2\xa3\xc5\x19K}\xae\xde\x16'\
X@\x9f\xca\xc0\x7fYpF\x05\x0f\xce\xd5\x18\xecN\
\xf5a\xe1#`\xa5Ba\x91B[q\xed\x9ePx\
\xeb.\x10\xd6A\x01\xf6\xecAw'/i\xb3\xc1)\
\x88l\x1a\x83\x8b\xd4N \xb5\xd6F\xda\xc9\xe5V\xf9\
i\xc1\x86\xe5\xd6\x0a\x10\xdf\xd9\x02J\xcfB\x06F\x22\
`\xc2c\xd8b\xbam\x11jw\xfa\xa33\x02\x0e\xcc\
E\x12&\xc9\xb9.\xc6\xfa\xf2\x92\x88B\xb8\xe2\xfb\x7f\
\x9c\xbcZA\xc7Eb/\x95\xd8.\xde~\xf7\x5c|\
\xbeO\xd1\xedk\x00\x9bi\x19\x9d\x95a\x86\x95\x00\xf6\
\xce\xd40\x1f\xb8~\xdd+]\x9f\x22,\xda1\xf4\x9b\
J\xf7\xbc\xb4\xf1o _\xb3\x14\x12\x1d\xf9Vk'\
n5\xb7\x5cg\xe9\xb7\xfd\xf1\x9e\x95ZS\xc8\xe7e\
h\xcf\xed\xc8\xf8\xa8\x8d\x89\xfd\xc2\xf5\x91\x04\xd7\xe8\xff\
!\xc2m\x85{\x17\xf1\x9eV\xbc\xd5\x82\xb7\xfeo\xfe\
\xfc\x17t\x0e4\x0e\x9d\xaf\xe9\x90g\xbf\xa6c\xff>\
O\xfdj`\xd1\xfb\xda\x8e\x95\x8e\xad\xff\xf8\xe8#\xa6\
\x13\xc3\xb9\xfc\xd0ZhW\x1b\x85{?\x90\x03!!\
\x0f8\x93\xbc\x9b:\xc0\x91~G\xb2\x1bBn\xdc\x12\
\xb5\xba\xac\xcd*\xc1z\xe6b\xa9\xda\xa1\x9e\xe9#\xb9\
\x13\xa0~f~\xaf\xda\xad!R\x06Rb\xffl\xbf\
\x99\xd3YS?\xbf!\xf3\x92mR\xdbA-~\x19\
\x03q\xe0\x09\xc2)?/\x06\xf6Q\xd7\xce0\xb6G\
V\x03;\xe7:rC\x02\xd4\x86\x0b_\xb9\xad\xc4=\
\xa38\x95Uh>\xb4\xa3\xe7\xef5\x05\x92\xf9\xfbv\
\xe2\x8e\xd3\xf8\xea\x10s\x9f\xc6W*\xcc{\x0a\x8fQ\
\x80\xdbo\x88<m7m[v`\xcb\x97\xaa\xce\xb6\
Ca\xa9j*\xfc\x99\xa8\xfb\xe6(\x9d\xd1\xbf\xa7\xba\
\xc7\x1e\xd5\x9a\xfa\x1au'\xb0\xb4\x91\xe2\x9c\x95\xfd\xcb\
S\xf4\xfb\xa3z\xe1\x1e\x9a\xa5\xae\xb1\x7f\xc2:\x9a\xc3\
\x02$\xbd\xe6\xb7\x12\x875\xdee\xa7\xd7\xf9\xea\xacx\
\xbf\x97\xf7\x02\xc2\x04\xc6=\xa5\x0f \x88\xc5\x1e\xe9\xc4\
\xb6\x12\x09\x06\xb1\xad\xf5;x\x10\x0d\x0b\x13\xdd\xf6y\
j\xabj\xbb\xf9\xd3,LO\xe1\xe8)\x95\x1e=7\
?\xf5'\xd2|\xec3\xe2\xb1?\x81\x9f\x17\x87mh\
\xeeK\x9f\xd0*\x11\xc0RHk\x9f\xdf\xd5\xa0\xcd*\
\x83\x1f\xa4\xfc\xee\x1b\xb8|z\x88\xfa3\x0f\x13\x11\xe0\
n~0'\xda0\xb4\x887K[X\xa5\xea#Y\
b=\x92\x15>0Bx\xb6#\xd9~UW\xfdO\
\xb3\xbe=\x81\x01\xc0\x92c\xcf\xe3\xc1\xc5\x00\x1ck\x00\
<\xa6\x13\x14\xfd\xf3\xb7\x00\xc1a\xdb0\xfbr!\x8c\
V\xf8\xc8\xd3gh\xdd\x80\x9fC\xe0\xec\xb7_\xb4\xda\
g\x01@\x03Nn\x03\xaa\xa4\x87gl\x00\xa6Lv\
i\xa7\x88wB\x17\xf3-\x5c\x82\xfc\xa0\xf3\xbax;\
'\x83\x10:\x94\x93\xd1\xae\xea\x1b\x80\xd3\x1c>\x9c\xc2\
\x04\xe8\xad\x0fO\xb2\x8b\x098\xd6\x040\xc2\x05\x11\xe7\
o\x02\xe8\x81\x09D\xfb\xf2\x8e\x86\xf4b@\x8d\xf6\x9b\
\x00\x97[7%\xa7\xfa+\xe57\xef\xfe\x07\x9c\x07T\
V\
\x00\x00\x06\xda\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2.0025 -\
2.0025 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg2\x22\x0a   s\
odipodi:docname=\
\x22line.svg\x22\x0a   in\
kscape:export-fi\
lename=\x22..\x5cpngic\
ons\x5c96px\x5cline-gr\
ay_96x96.png\x22\x0a  \
 inkscape:export\
-xdpi=\x22288\x22\x0a   i\
nkscape:export-y\
dpi=\x22288\x22\x0a   ink\
scape:version=\x221\
.4 (86a8ad7, 202\
4-10-11)\x22\x0a   xml\
ns:inkscape=\x22htt\
p://www.inkscape\
.org/namespaces/\
inkscape\x22\x0a   xml\
ns:sodipodi=\x22htt\
p://sodipodi.sou\
rceforge.net/DTD\
/sodipodi-0.dtd\x22\
\x0a   xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
>\x0a  <defs\x0a     i\
d=\x22defs2\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     id=\x22name\
dview2\x22\x0a     pag\
ecolor=\x22#000000\x22\
\x0a     bordercolo\
r=\x22#FFFFFF\x22\x0a    \
 borderopacity=\x22\
0.25\x22\x0a     inksc\
ape:showpageshad\
ow=\x222\x22\x0a     inks\
cape:pageopacity\
=\x220.0\x22\x0a     inks\
cape:pagechecker\
board=\x220\x22\x0a     i\
nkscape:deskcolo\
r=\x22#d1d1d1\x22\x0a    \
 inkscape:zoom=\x22\
24.3125\x22\x0a     in\
kscape:cx=\x2215.97\
9434\x22\x0a     inksc\
ape:cy=\x2216\x22\x0a    \
 inkscape:window\
-width=\x221920\x22\x0a  \
   inkscape:wind\
ow-height=\x22996\x22\x0a\
     inkscape:wi\
ndow-x=\x22-9\x22\x0a    \
 inkscape:window\
-y=\x22-9\x22\x0a     ink\
scape:window-max\
imized=\x221\x22\x0a     \
inkscape:current\
-layer=\x22svg2\x22 />\
\x0a  <g\x0a     trans\
form=\x22translate(\
-1.9116, -1.9116\
)\x22\x0a     id=\x22g2\x22\x0a\
     style=\x22fill\
:none;fill-opaci\
ty:1;stroke:#FFF\
FFF;stroke-opaci\
ty:1\x22>\x0a    <g\x0a  \
     transform=\x22\
matrix(0.0636360\
123753548, 0, 0,\
 0.0636360123753\
548, 0, 0)\x22\x0a    \
   id=\x22g1\x22\x0a     \
  style=\x22fill:no\
ne;fill-opacity:\
1;stroke:#FFFFFF\
;stroke-opacity:\
1\x22>\x0a      <line\x0a\
         x1=\x2250\x22\
\x0a         y1=\x2245\
0\x22\x0a         x2=\x22\
450\x22\x0a         y2\
=\x2250\x22\x0a         t\
ransform=\x22matrix\
(-1, 0, 0, -1, 5\
00, 500)\x22\x0a      \
   stroke=\x22#FFFF\
FF\x22\x0a         str\
oke-width=\x2240px\x22\
\x0a         stroke\
-linecap=\x22round\x22\
\x0a         id=\x22li\
ne1\x22\x0a         st\
yle=\x22fill:none;f\
ill-opacity:1;st\
roke:#FFFFFF;str\
oke-opacity:1\x22 /\
>\x0a    </g>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x06S\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   ar\
ia-hidden=\x22true\x22\
\x0a   focusable=\x22f\
alse\x22\x0a   role=\x22i\
mg\x22\x0a   class=\x22ic\
onify iconify--w\
hh\x22\x0a   width=\x221.\
01em\x22\x0a   height=\
\x221em\x22\x0a   preserv\
eAspectRatio=\x22xM\
idYMid meet\x22\x0a   \
viewBox=\x220 0 102\
4 1023\x22\x0a   style\
=\x22transform: rot\
ate(360deg);\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg1\x22\x0a   s\
odipodi:docname=\
\x22bucket.svg\x22\x0a   \
inkscape:version\
=\x221.4 (86a8ad7, \
2024-10-11)\x22\x0a   \
xmlns:inkscape=\x22\
http://www.inksc\
ape.org/namespac\
es/inkscape\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns=\x22ht\
tp://www.w3.org/\
2000/svg\x22\x0a   xml\
ns:svg=\x22http://w\
ww.w3.org/2000/s\
vg\x22>\x0a  <defs\x0a   \
  id=\x22defs1\x22 />\x0a\
  <sodipodi:name\
dview\x0a     id=\x22n\
amedview1\x22\x0a     \
pagecolor=\x22#0000\
00\x22\x0a     borderc\
olor=\x22#000000\x22\x0a \
    borderopacit\
y=\x220.25\x22\x0a     in\
kscape:showpages\
hadow=\x222\x22\x0a     i\
nkscape:pageopac\
ity=\x220.0\x22\x0a     i\
nkscape:pagechec\
kerboard=\x22false\x22\
\x0a     inkscape:d\
eskcolor=\x22#d1d1d\
1\x22\x0a     inkscape\
:zoom=\x220.7605083\
1\x22\x0a     inkscape\
:cx=\x22512.15745\x22\x0a\
     inkscape:cy\
=\x22511.5\x22\x0a     in\
kscape:window-wi\
dth=\x221920\x22\x0a     \
inkscape:window-\
height=\x22996\x22\x0a   \
  inkscape:windo\
w-x=\x22-9\x22\x0a     in\
kscape:window-y=\
\x22-9\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22svg1\x22 />\x0a  \
<path\x0a     d=\x22M9\
96 990q-28 33-68\
 33t-68-33t-28-7\
9t28-79l36-51V58\
4q0 26-17 43L517\
 990q-34 33-81 3\
3t-81-33L33 668Q\
0 634 0 587t33-8\
1l287-286v100q0 \
53 37.5 90.5T448\
 448t90.5-37.5T5\
76 320v-76l268 2\
68h52q27 0 45.5 \
18.5T960 576v205\
l36 51q28 33 28 \
79t-28 79zM448.5\
 384q-26.5 0-45.\
5-19t-19-45V64q0\
-27 19-45.5T448.\
5 0t45 18.5T512 \
64v256q0 26-18.5\
 45t-45 19z\x22\x0a   \
  id=\x22path1\x22\x0a   \
  style=\x22fill:#f\
fffff;fill-opaci\
ty:1;fill-rule:n\
onzero\x22 />\x0a</svg\
>\x0a\
\x00\x00\x08\x08\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg1\
\x22\x0a   sodipodi:do\
cname=\x22delete.sv\
g\x22\x0a   inkscape:v\
ersion=\x221.4 (86a\
8ad7, 2024-10-11\
)\x22\x0a   xmlns:inks\
cape=\x22http://www\
.inkscape.org/na\
mespaces/inkscap\
e\x22\x0a   xmlns:sodi\
podi=\x22http://sod\
ipodi.sourceforg\
e.net/DTD/sodipo\
di-0.dtd\x22\x0a   xml\
ns=\x22http://www.w\
3.org/2000/svg\x22\x0a\
   xmlns:svg=\x22ht\
tp://www.w3.org/\
2000/svg\x22>\x0a  <de\
fs\x0a     id=\x22defs\
1\x22 />\x0a  <sodipod\
i:namedview\x0a    \
 id=\x22namedview1\x22\
\x0a     pagecolor=\
\x22#000000\x22\x0a     b\
ordercolor=\x22#FFF\
FFF\x22\x0a     border\
opacity=\x220.25\x22\x0a \
    inkscape:sho\
wpageshadow=\x222\x22\x0a\
     inkscape:pa\
geopacity=\x220.0\x22\x0a\
     inkscape:pa\
gecheckerboard=\x22\
0\x22\x0a     inkscape\
:deskcolor=\x22#d1d\
1d1\x22\x0a     inksca\
pe:zoom=\x2217.8323\
49\x22\x0a     inkscap\
e:cx=\x2222.963884\x22\
\x0a     inkscape:c\
y=\x2216.655125\x22\x0a  \
   inkscape:wind\
ow-width=\x221920\x22\x0a\
     inkscape:wi\
ndow-height=\x22996\
\x22\x0a     inkscape:\
window-x=\x22-9\x22\x0a  \
   inkscape:wind\
ow-y=\x22-9\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg1\x22\x0a\
     showgrid=\x22t\
rue\x22>\x0a    <inksc\
ape:grid\x0a       \
id=\x22grid1\x22\x0a     \
  units=\x22px\x22\x0a   \
    originx=\x220\x22\x0a\
       originy=\x22\
0\x22\x0a       spacin\
gx=\x221\x22\x0a       sp\
acingy=\x221\x22\x0a     \
  empcolor=\x22#009\
9e5\x22\x0a       empo\
pacity=\x220.301960\
78\x22\x0a       color\
=\x22#0099e5\x22\x0a     \
  opacity=\x220.149\
01961\x22\x0a       em\
pspacing=\x225\x22\x0a   \
    enabled=\x22tru\
e\x22\x0a       visibl\
e=\x22true\x22 />\x0a  </\
sodipodi:namedvi\
ew>\x0a  <g\x0a     id\
=\x22Layer_1\x22\x0a     \
transform=\x22matri\
x(0.85714166,0,0\
,0.85714168,-1.9\
999999,-2)\x22\x0a    \
 style=\x22fill:#FF\
FFFF;fill-opacit\
y:1;stroke:none;\
stroke-opacity:1\
\x22>\x0a    <g\x0a      \
 transform=\x22scal\
e(1.5555577)\x22\x0a  \
     id=\x22g1\x22\x0a   \
    style=\x22fill:\
#FFFFFF;fill-opa\
city:1;stroke:no\
ne;stroke-opacit\
y:1\x22>\x0a      <pol\
ygon\x0a         po\
ints=\x223,19 5,21 \
12,14 19,21 21,1\
9 14,12 21,5 19,\
3 12,10 5,3 3,5 \
10,12 \x22\x0a        \
 class=\x22dx_gray\x22\
\x0a         id=\x22po\
lygon1\x22\x0a        \
 style=\x22fill:#FF\
FFFF;fill-opacit\
y:1;stroke:none;\
stroke-opacity:1\
;stroke-width:0.\
75;stroke-dashar\
ray:none;stroke-\
linecap:round;pa\
int-order:stroke\
 fill markers;ve\
ctor-effect:non-\
scaling-stroke;-\
inkscape-stroke:\
hairline\x22\x0a      \
   inkscape:labe\
l=\x22polygon1\x22 />\x0a\
    </g>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x05\xa7\
\x00\
\x00\x1d\xe8x\xda\xd5YYs\x9bH\x10~\xcf\xaf\x98\
\x22/I\x955\x9a\x8bK\xb1\x92\xaa\x90\xca\x93\xf6-\
[y\xdc\xc20\x96(K\xe0\x02l\xd9\xf9\xf5\xdb\x0d\
\xc3!\x09)\xf2\x1am\x12\x1d@\x1f\xd3=3|}\
 ]\x7fz\xda\xac\xc9\xa3\xce\x8b$K\xe7\x16\xa7\xcc\
\x22:\x8d\xb28I\x97s\xeb\xefo_'\x9eE\x8a\
2L\xe3p\x9d\xa5zn\xa5\x99\xf5\xe9\xe3\x9b\xeb\xe2\
q\xf9\x86\x10\xf2\x98\xe8\xed\xe7\xecinM\x04\x99(\
*\x99k\x13)\xe0cU\xd2\xce,\xaf\x18I<\xb7\
`\xa4t*\xaa\x00/\xf7\xf0\x9d\xc5Y\x94\x86\x1b0\
^\xae\xf4F\xaf\x93\xe5\xaa\xa4\xa0V\x0fI\xef\x8a(\
\xbc\xd7\xb3\x9e1E\xdeyN\xe8\x85\xb1{E\x04\x13\
j\xc2\xd9\x84\xf3\xf7\x95>,'-f\xcd\xa8\xb9\xb5\
*\xcb\xfb\xd9t\xba\xddni\xc3\xa4Y\xbe\x9c\xa2\xc3\
\xe2>\x8ct1m\xf8\xbd\xf1\xcd\xd4\xda\xf1\x0d\x83\x16\
\xd9C\x1e\xe9[0\xa1i\xaa\xcb\xe9\x97o_Z\xe1\
\x84\xd1\xb8\x8c;3;\xde\xb7\xb2\xf2+\x18c\xd3f\
q\xc6\xd9\xe3\xf2\xa4\xe6GP\xbd\x8e\xf5m\x81C\xea\
MD\x0av\x91L+Y\xbb\x91\xb8\xa8\x18\xefI\xa7\
\xd9\xb2\xcc\xa6\x13r\x1f.u\x94\xad\xb3|n\xbde\
6\xbe\x8d\xe0&\xcbc\x9d\xb7\xa2\xea\xb5#\xca`\xbf\
\x92\xf2yn1*\x9aA\xed\xfd)V\xd9\x16M\x17\
\xab0\xce\xb6sK\xec+\xa0\xb0g\x81\x0d\xc9\xa3\x95\
\x8e\xeet~\x93\x859\xcc\xbd\xcc\x1f\xf4\xbeV\xac\x8b\
\xbbf\x8a1\xc7\xf7\xbe\xc6\x8f,\xdb\x80{@#?\
\x9ce\x04X\xe56\xf5]_Iu \x84\x89q\x8f\
2n+q \xdc&)\xack\xb2M\xe2r\x05j\
\xbe`G4V\x1a\x01<\xb7|\xdf9\xa2\x81\xf1\xe2\
\x1f\x91=\x9f\x90m\xc2\xa7d\x93\xfc\xd0\xb05\x07\xab\
\x8e\x1e\xf2\x5c\xa7\xe5d\x1d>\xeb\xbc\x892\x83\x8fe\
\x07\x87\x05\x8a\xffiF\x97y\x98\x16\x80\xe5\x0d\xee5\
\x5c\xae\xc3R\xbfcWd\x22\xaaP~o\xd4\x8a\xf2\
y\x0d\xa1\xa4\xd3\xf0f\xad'7at\xb7\xcc\xb3\x87\
4\x9e\xa5zK\x18\xbcm.\xf0[!\xb5\xf3\xb7c\
\x7f\x13\x96y\xf2\xf4\x8eQ\xcfU\xfe\x15a\xf5\xa7G\
5\xce\xeay.\x951\xd677d\x10R\x8b\x12N\
c\xb0Ou\x06\x8dI\xd9\x9a\xdc5:<Of+\
\xb7\x9bgG\xf5\xcd\x1a\xc3\xa2gx\xdf\xb4Q\xe1;\
*\xa0t\x1f\x96\xab]=B@\xf1/\xe5xT:\
\xea\x8aH\xc7[t\x84\xcf\xa9pe\xd0c8\x94\xf9\
\x92(W\x80@\x5c\x11\xc5\x18\x10.0yE\x04\xca\
\xe3\xd4\xe7\xdcH<\x9bz\xdck\xc6\x89>\xa3\xb2\xbc\
\xe8\x18;~\x1d\xef\x87\xb5?\xcd\xdbd\xbd\x86\xe8\xfb\
Z\xbd\x06\xa5\x936\xce\xf9\x81<Z\x87\x05d\xc6\xcf\
k\x80\xd1\x81\x10\xf7\x0aw\x86\x1b\xe8\xb6\xdb5]\xf6\
\xee]G\xb4\x97\xe6\xa29\xf5\x10\xbf\xf4\x7f\x7f\xb0{\
\xe3\x83\xdd\xbd\x14\xd8\x9d\x9f\x83\xdd>\x1b\xecRRe\
\xdb=|w\x0c\x83o\xe9\x02\x12\xa5A\xb1\x12\x94{\
\xc2\xe0[\x01\xd8Y\x83|\x9bQ\x9f\xf9=|w\x0c\
\x83\xef\x96\x81\xf8\xae\xdc\xa8}\xa2V\xfd%\x80W#\
\x02\x9e\xab\xdf\x1f\xf1\x5c\x8e\x0fy..\x85y\xce\xcf\
\xc8\xf0\xec\x5c\xd4K\xdf\xa3\xb6\xea\xa1\xbe\xc70\xa8g\
\x02 \xd9\xa0\x9e\xb9m\x8a\x0f\x14\x17\x88o#\xc1N\
\xc6\xef\xa3\xbec\x18\xd4\xb7\x0c\x00z\xedF\xed\x13\xbf\
\x10\xf5\xfe\x98\xa8\xff\x03\xf2<\xbf@\xa2\xe7\x17\xcb\xf4\
\xfc\x8cT\xcf\x0fr}\xae\xa3r\xff~C\xc3+\x84\
\x83\xf9\xf7\x00\x0a\x00\x1e\xa9\x14u\x85{ 2\xad\xb6\
\xeda\xd2?\x906m6\xe7\x0e\xf6*\x07\xf2\x1c\x9c\
\xb2C\xee\xf3\x10\xf7\xc2P\xc7-\xe1cfx!\x7f\
\x7f\xac\x0b1>\xd6\x05\xbfX\x0b\xbf\x9b\xbd\x07r7\
fn\xd8\xa2*{\x06\xf5\x85\xab\xa8\x226s\xa8[\
\xf5\xca\xaeO\x1d\xe9\x00\x83\x99\xe6\xb9f,8\xc7S\
K\x076\x15=\x12gT[buf\x86\x93-\xb1\
\x17\x0f\xe0\x0a\x9a\x1c\xc5=b\x86\xd4\xfd\x0fi\x0c\xd6\
\xe4\xa2v(\x1b:\xa8g\xd4\xd2pcy]\x04\x1a\
c\x0d]\xbbY\xb4\xf4@\xb7\x7f*2N\xc7\xc5\x89\
\xa8h\xbb\xfc\xdd\xfc\xff\xd2 p/\x13\x04\x1fp]\
\xb3\xb7\x9e\xf4\xed(\xfe\xd0_\xe4\x8c\x8f\x1a NK\
\x9b\xa9\xfd\xdc\xf1\x98\xb1d\xf78/\x98\xc0\xd8\x81\xb7\
\x9b\xb9_4\x91\xc1j\xf3\x84\x05e\xa0\xd4\x00D\xeb\
\xc7\xe3=\xbe\xa92\xe6\xd9bO\xd8\x14\x19\xe1\xb8\x18\
r{\xd2\xa1\x123T`^\x1dD\xdfWI\xa9\x07\
\x82\x08W\xdf\xd6\x82\x17l\xe1+\xa2N\xfe\x01\xbf\x1d\
Iv\x81p\xf1/\x16\x01\xde9\xa5\x07\xee\xa3I\xfa\
\x8e_em\xd3\xf7\xb4\x8c\x80C\x1a\xaf:z\xc3 \
\x9c!h]d\xc0S\x00\xef\xd3\x1c\x03!\xe8\x18\xb6\
\x03\xcf\x00\xa0\xd1\x9a\xb0\x05\x1a'\x9d\x93\x9a\xb1\xa8\xa7\
\xe1\xb6\x8c\x00\x9eC\xe0Q\xa5c\xc0\x83\x89j\x86\xa0\
Q\xd1c\x18\xb7=\x06\xce\x8b\x93\xdaF\xb76\xb2\xbf\
\xd8\xff\xb5*A]yM|\x9cl\xcd\x1cD\x99\xe3\
\x8b\xf3\xc3\xa3\xfa7\xc5\x94\xa4\xdb\xea\xf5_J\x92\xdd\
a\xd1\x1e\x0e\x191\x5c\x8cN\xb9\xdc\x8d\x034\xf3\xbd\
\xfa\x9d\xfaX]9mk\x00\xf9\x15\xee10\xd9\x02\
Ov\x80GEm\x22|\x5c\x86\x823\x1c\x17\xd8\xe9\
\x04\xc2p\x8c\x02h/D;\x92\xb3]\x04\x1d\xc7\xcf\
Q|4\xe8\x90\xfcx\xbd\x1a^`\x07\xa6\xb3\xf0\xe3\
\xfc\x99\xf8\xb1\xc7\xc0\xcfR\xaaQ\xc1#\xbc\x0a\x02x\
\x12\xceB5Gd5G\xe1\x06\xd5\x11A\x83k\x13\
\x90}\xf0\xb8@l\x09/\xa8\xa1\x86\x5cf\xd4\xea\x0b\
\x83\xabE\xedb<x\xc9\x91\xe1u\x8d\x7f!~|\
\xf3/e\xbd\xe3l\
\x00\x00\x054\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg1\
\x22\x0a   sodipodi:do\
cname=\x22rpi_send.\
svg\x22\x0a   inkscape\
:version=\x221.4 (8\
6a8ad7, 2024-10-\
11)\x22\x0a   xmlns:in\
kscape=\x22http://w\
ww.inkscape.org/\
namespaces/inksc\
ape\x22\x0a   xmlns:so\
dipodi=\x22http://s\
odipodi.sourcefo\
rge.net/DTD/sodi\
podi-0.dtd\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22>\x0a  <\
defs\x0a     id=\x22de\
fs1\x22 />\x0a  <sodip\
odi:namedview\x0a  \
   id=\x22namedview\
1\x22\x0a     pagecolo\
r=\x22#000000\x22\x0a    \
 bordercolor=\x22#0\
00000\x22\x0a     bord\
eropacity=\x220.25\x22\
\x0a     inkscape:s\
howpageshadow=\x222\
\x22\x0a     inkscape:\
pageopacity=\x220.0\
\x22\x0a     inkscape:\
pagecheckerboard\
=\x220\x22\x0a     inksca\
pe:deskcolor=\x22#d\
1d1d1\x22\x0a     inks\
cape:zoom=\x2224.31\
25\x22\x0a     inkscap\
e:cx=\x2215.979434\x22\
\x0a     inkscape:c\
y=\x2216\x22\x0a     inks\
cape:window-widt\
h=\x221920\x22\x0a     in\
kscape:window-he\
ight=\x22996\x22\x0a     \
inkscape:window-\
x=\x22-9\x22\x0a     inks\
cape:window-y=\x22-\
9\x22\x0a     inkscape\
:window-maximize\
d=\x221\x22\x0a     inksc\
ape:current-laye\
r=\x22Layer_1\x22 />\x0a \
 <g\x0a     id=\x22Lay\
er_1\x22\x0a     trans\
form=\x22translate(\
-2, -2)\x22\x0a     st\
yle=\x22enable-back\
ground:new 0 0 3\
2 32\x22>\x0a    <g\x0a  \
     id=\x22Send\x22>\x0a\
      <polygon\x0a \
        points=\x22\
2,20 8,22.4 24,1\
0 12,24 12,30 16\
.3,25.7 22,28 30\
,2  \x22\x0a         f\
ill=\x22#FFFFFF\x22\x0a  \
       class=\x22Bl\
ack\x22\x0a         id\
=\x22polygon1\x22\x0a    \
     style=\x22fill\
:#ffffff;fill-op\
acity:1\x22 />\x0a    \
</g>\x0a  </g>\x0a</sv\
g>\x0a\
\x00\x00\x08V\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2.015 -\
2 32 32\x22 xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22 >\x0d\x0a \
 <g id=\x22Capa_1\x22 \
transform=\x22trans\
late(-0.01510038\
14697264, -5.340\
5761768488E-07)\x22\
 style=\x22enable-b\
ackground:new 0 \
0 297 297\x22>\x0d\x0a   \
 <g transform=\x22m\
atrix(0.09427609\
29465294, 0, 0, \
0.09427609294652\
94, 0, 0)\x22>\x0d\x0a   \
   <g>\x0d\x0a        \
<path d=\x22M150.08\
, 100.079C150.07\
8, 100.079 150.0\
77, 100.079 150.\
075, 100.079L70.\
044, 100.12C64.5\
43, 100.122 60.0\
86, 104.583 60.0\
89, 110.083C60.0\
92, 115.582 64.5\
5, 120.038 70.04\
8, 120.038C70.05\
, 120.038 70.052\
, 120.038 70.054\
, 120.038L150.08\
5, 119.998C155.5\
85, 119.995 160.\
042, 115.534 160\
.039, 110.034C16\
0.036, 104.535 1\
55.578, 100.079 \
150.08, 100.079z\
\x22 fill=\x22#FFFFFF\x22\
 class=\x22Black\x22 /\
>\x0d\x0a      </g>\x0d\x0a \
   </g>\x0d\x0a  </g>\x0d\
\x0a  <g id=\x22Capa_1\
\x22 transform=\x22tra\
nslate(-0.0151, \
0)\x22 style=\x22enabl\
e-background:new\
 0 0 297 297\x22>\x0d\x0a\
    <g transform\
=\x22matrix(0.09427\
60929465294, 0, \
0, 0.09427609294\
65294, 0, 0)\x22>\x0d\x0a\
      <g>\x0d\x0a     \
   <path d=\x22M288\
.985, 246.75L206\
.059, 163.745C22\
9.428, 121.854 2\
23.347, 67.804 1\
87.814, 32.237C1\
67.048, 11.449 1\
39.436, 0 110.06\
4, 0C80.691, 0 5\
3.076, 11.449 32\
.306, 32.237C-10\
.558, 75.151 -10\
.557, 144.967 32\
.306, 187.871C53\
.076, 208.664 80\
.692, 220.114 11\
0.064, 220.114C1\
29.161, 220.114 \
147.51, 215.269 \
163.721, 206.17L\
246.611, 289.139\
C251.674, 294.20\
8 258.426, 297 2\
65.622, 297C272.\
818, 297 279.57,\
 294.208 284.635\
, 289.139L288.98\
7, 284.784C299.4\
61, 274.298 299.\
461, 257.236 288\
.985, 246.75zM46\
.398, 173.794C11\
.289, 138.651 11\
.289, 81.465 46.\
398, 46.315C63.4\
04, 29.294 86.01\
5, 19.918 110.06\
4, 19.918C134.11\
3, 19.918 156.72\
, 29.294 173.723\
, 46.314C208.839\
, 81.463 208.839\
, 138.65 173.723\
, 173.794C156.71\
9, 190.818 134.1\
13, 200.194 110.\
064, 200.194C86.\
015, 200.195 63.\
404, 190.819 46.\
398, 173.794zM27\
4.894, 270.704L2\
70.541, 275.06C2\
69.24, 276.363 2\
67.493, 277.081 \
265.621, 277.081\
C263.75, 277.081\
 262.004, 276.36\
3 260.702, 275.0\
61L180.382, 194.\
666C182.944, 192\
.525 185.427, 19\
0.263 187.814, 1\
87.872C190.207, \
185.478 192.459,\
 182.995 194.585\
, 180.441L274.89\
5, 260.827C277.5\
67, 263.506 277.\
568, 268.027 274\
.894, 270.704z\x22 \
fill=\x22#FFFFFF\x22 c\
lass=\x22Black\x22 />\x0d\
\x0a      </g>\x0d\x0a   \
 </g>\x0d\x0a  </g>\x0d\x0a<\
/svg>\
\x00\x00\x07\x02\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x2224\x22\x0a   heig\
ht=\x2224\x22\x0a   viewB\
ox=\x220 0 24 24\x22\x0a \
  fill=\x22none\x22\x0a  \
 stroke=\x22current\
Color\x22\x0a   stroke\
-width=\x222\x22\x0a   st\
roke-linecap=\x22ro\
und\x22\x0a   stroke-l\
inejoin=\x22round\x22\x0a\
   version=\x221.1\x22\
\x0a   id=\x22svg6\x22\x0a  \
 sodipodi:docnam\
e=\x22flip-horizont\
al-2.svg\x22\x0a   ink\
scape:export-fil\
ename=\x22flip-hori\
zontal-2.png\x22\x0a  \
 inkscape:export\
-xdpi=\x22128\x22\x0a   i\
nkscape:export-y\
dpi=\x22128\x22\x0a   ink\
scape:version=\x221\
.4 (86a8ad7, 202\
4-10-11)\x22\x0a   xml\
ns:inkscape=\x22htt\
p://www.inkscape\
.org/namespaces/\
inkscape\x22\x0a   xml\
ns:sodipodi=\x22htt\
p://sodipodi.sou\
rceforge.net/DTD\
/sodipodi-0.dtd\x22\
\x0a   xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
>\x0a  <defs\x0a     i\
d=\x22defs6\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     id=\x22name\
dview6\x22\x0a     pag\
ecolor=\x22#000000\x22\
\x0a     bordercolo\
r=\x22#FFFFFF\x22\x0a    \
 borderopacity=\x22\
0.25\x22\x0a     inksc\
ape:showpageshad\
ow=\x222\x22\x0a     inks\
cape:pageopacity\
=\x220.0\x22\x0a     inks\
cape:pagechecker\
board=\x220\x22\x0a     i\
nkscape:deskcolo\
r=\x22#d1d1d1\x22\x0a    \
 inkscape:zoom=\x22\
32.416667\x22\x0a     \
inkscape:cx=\x2211.\
984576\x22\x0a     ink\
scape:cy=\x2212\x22\x0a  \
   inkscape:wind\
ow-width=\x221920\x22\x0a\
     inkscape:wi\
ndow-height=\x22996\
\x22\x0a     inkscape:\
window-x=\x22-9\x22\x0a  \
   inkscape:wind\
ow-y=\x22-9\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg6\x22 \
/>\x0a  <path\x0a     \
d=\x22m3 7 5 5-5 5V\
7\x22\x0a     style=\x22s\
troke:#FFFFFF;st\
roke-opacity:1\x22\x0a\
     id=\x22path1\x22 \
/>\x0a  <path\x0a     \
d=\x22m21 7-5 5 5 5\
V7\x22\x0a     style=\x22\
stroke:#FFFFFF;s\
troke-opacity:1\x22\
\x0a     id=\x22path2\x22\
 />\x0a  <path\x0a    \
 d=\x22M12 20v2\x22\x0a  \
   style=\x22stroke\
:#FFFFFF;stroke-\
opacity:1\x22\x0a     \
id=\x22path3\x22 />\x0a  \
<path\x0a     d=\x22M1\
2 14v2\x22\x0a     sty\
le=\x22stroke:#FFFF\
FF;stroke-opacit\
y:1\x22\x0a     id=\x22pa\
th4\x22 />\x0a  <path\x0a\
     d=\x22M12 8v2\x22\
\x0a     style=\x22str\
oke:#FFFFFF;stro\
ke-opacity:1\x22\x0a  \
   id=\x22path5\x22 />\
\x0a  <path\x0a     d=\
\x22M12 2v2\x22\x0a     s\
tyle=\x22stroke:#FF\
FFFF;stroke-opac\
ity:1\x22\x0a     id=\x22\
path6\x22 />\x0a</svg>\
\x0a\
\x00\x00\x07\x87\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   he\
ight=\x2232\x22\x0a   vie\
wBox=\x220 0 32 32\x22\
\x0a   width=\x2232\x22\x0a \
  version=\x221.1\x22\x0a\
   id=\x22svg2\x22\x0a   \
sodipodi:docname\
=\x22invert-colors.\
svg\x22\x0a   inkscape\
:version=\x221.4 (8\
6a8ad7, 2024-10-\
11)\x22\x0a   xmlns:in\
kscape=\x22http://w\
ww.inkscape.org/\
namespaces/inksc\
ape\x22\x0a   xmlns:so\
dipodi=\x22http://s\
odipodi.sourcefo\
rge.net/DTD/sodi\
podi-0.dtd\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22>\x0a  <\
defs\x0a     id=\x22de\
fs2\x22 />\x0a  <sodip\
odi:namedview\x0a  \
   id=\x22namedview\
2\x22\x0a     pagecolo\
r=\x22#000000\x22\x0a    \
 bordercolor=\x22#F\
FFFFF\x22\x0a     bord\
eropacity=\x220.247\
05882\x22\x0a     inks\
cape:showpagesha\
dow=\x22true\x22\x0a     \
inkscape:pageopa\
city=\x220.0\x22\x0a     \
inkscape:pageche\
ckerboard=\x22false\
\x22\x0a     inkscape:\
deskcolor=\x22#d1d1\
d1\x22\x0a     showgri\
d=\x22true\x22\x0a     in\
kscape:zoom=\x2215.\
291667\x22\x0a     ink\
scape:cx=\x2216.446\
866\x22\x0a     inksca\
pe:cy=\x2213.144414\
\x22\x0a     inkscape:\
window-width=\x2219\
20\x22\x0a     inkscap\
e:window-height=\
\x22996\x22\x0a     inksc\
ape:window-x=\x22-9\
\x22\x0a     inkscape:\
window-y=\x22-9\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g2\x22\x0a     showbor\
der=\x22true\x22\x0a     \
inkscape:antiali\
as-rendering=\x22tr\
ue\x22>\x0a    <inksca\
pe:grid\x0a       i\
d=\x22grid2\x22\x0a      \
 units=\x22px\x22\x0a    \
   originx=\x220\x22\x0a \
      originy=\x220\
\x22\x0a       spacing\
x=\x221\x22\x0a       spa\
cingy=\x221\x22\x0a      \
 empcolor=\x22#0099\
e5\x22\x0a       empop\
acity=\x220.3019607\
8\x22\x0a       color=\
\x22#0099e5\x22\x0a      \
 opacity=\x220.1490\
1961\x22\x0a       emp\
spacing=\x225\x22\x0a    \
   enabled=\x22true\
\x22\x0a       visible\
=\x22true\x22 />\x0a  </s\
odipodi:namedvie\
w>\x0a  <path\x0a     \
d=\x22M 23.546667,1\
0.573333 16,3.02\
66667 8.4533333,\
10.573333 c -4.1\
6,4.16 -4.16,10.\
92 0,15.08 2.079\
9997,2.08 4.8133\
337,3.12 7.54666\
67,3.12 2.733333\
,0 5.466667,-1.0\
4 7.546667,-3.12\
 4.16,-4.16 4.16\
,-10.92 0,-15.08\
 z M 16,26.12 c \
-2.133333,0 -4.1\
46667,-0.826667 \
-5.653333,-2.346\
667 C 8.8266667,\
22.253333 8,20.2\
53333 8,18.12 8,\
15.986667 8.8266\
667,13.973333 10\
.346667,12.46666\
7 L 16,6.8 Z\x22\x0a  \
   id=\x22path2\x22\x0a  \
   style=\x22stroke\
-width:1.33333;f\
ill:#ffffff;fill\
-opacity:1\x22 />\x0a<\
/svg>\x0a\
\x00\x00\x06\xb2\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   width=\x22\
32\x22\x0a   height=\x223\
2\x22\x0a   viewBox=\x220\
 0 32 32\x22\x0a   ver\
sion=\x221.1\x22\x0a   id\
=\x22svg1\x22\x0a   inksc\
ape:version=\x221.4\
 (86a8ad7, 2024-\
10-11)\x22\x0a   sodip\
odi:docname=\x22squ\
are.svg\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0a\
   xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22\x0a   xmlns:s\
vg=\x22http://www.w\
3.org/2000/svg\x22>\
\x0a  <sodipodi:nam\
edview\x0a     id=\x22\
namedview1\x22\x0a    \
 pagecolor=\x22#000\
000\x22\x0a     border\
color=\x22#FFFFFF\x22\x0a\
     borderopaci\
ty=\x220.25\x22\x0a     i\
nkscape:showpage\
shadow=\x222\x22\x0a     \
inkscape:pageopa\
city=\x220.0\x22\x0a     \
inkscape:pageche\
ckerboard=\x220\x22\x0a  \
   inkscape:desk\
color=\x22#d1d1d1\x22\x0a\
     inkscape:do\
cument-units=\x22px\
\x22\x0a     showgrid=\
\x22true\x22\x0a     inks\
cape:zoom=\x2223.78\
125\x22\x0a     inksca\
pe:cx=\x2216\x22\x0a     \
inkscape:cy=\x2215.\
978975\x22\x0a     ink\
scape:window-wid\
th=\x221920\x22\x0a     i\
nkscape:window-h\
eight=\x22996\x22\x0a    \
 inkscape:window\
-x=\x22-9\x22\x0a     ink\
scape:window-y=\x22\
-9\x22\x0a     inkscap\
e:window-maximiz\
ed=\x221\x22\x0a     inks\
cape:current-lay\
er=\x22layer1\x22>\x0a   \
 <inkscape:grid\x0a\
       id=\x22grid1\
\x22\x0a       units=\x22\
px\x22\x0a       origi\
nx=\x220\x22\x0a       or\
iginy=\x220\x22\x0a      \
 spacingx=\x221\x22\x0a  \
     spacingy=\x221\
\x22\x0a       empcolo\
r=\x22#0099e5\x22\x0a    \
   empopacity=\x220\
.30196078\x22\x0a     \
  color=\x22#0099e5\
\x22\x0a       opacity\
=\x220.14901961\x22\x0a  \
     empspacing=\
\x225\x22\x0a       enabl\
ed=\x22true\x22\x0a      \
 visible=\x22true\x22 \
/>\x0a  </sodipodi:\
namedview>\x0a  <de\
fs\x0a     id=\x22defs\
1\x22 />\x0a  <g\x0a     \
inkscape:label=\x22\
Layer 1\x22\x0a     in\
kscape:groupmode\
=\x22layer\x22\x0a     id\
=\x22layer1\x22>\x0a    <\
path\x0a       d=\x22M\
 5,5 V 27 H 27 V\
 5 Z M 8,8 H 24 \
V 24 H 8 Z\x22\x0a    \
   style=\x22fill:#\
FFFFFF;fill-opac\
ity:1\x22\x0a       id\
=\x22path2\x22\x0a       \
sodipodi:nodetyp\
es=\x22cccccccccc\x22 \
/>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x06y\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -8.912\
7 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg2\x22\x0a   sodipo\
di:docname=\x22elli\
pse.svg\x22\x0a   inks\
cape:version=\x221.\
4 (86a8ad7, 2024\
-10-11)\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0a\
   xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22\x0a   xmlns:s\
vg=\x22http://www.w\
3.org/2000/svg\x22>\
\x0a  <defs\x0a     id\
=\x22defs2\x22 />\x0a  <s\
odipodi:namedvie\
w\x0a     id=\x22named\
view2\x22\x0a     page\
color=\x22#020202\x22\x0a\
     bordercolor\
=\x22#000000\x22\x0a     \
borderopacity=\x220\
.25\x22\x0a     inksca\
pe:showpageshado\
w=\x222\x22\x0a     inksc\
ape:pageopacity=\
\x220.0\x22\x0a     inksc\
ape:pagecheckerb\
oard=\x22true\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   inkscape:zoom\
=\x2224.3125\x22\x0a     \
inkscape:cx=\x2215.\
979434\x22\x0a     ink\
scape:cy=\x2216\x22\x0a  \
   inkscape:wind\
ow-width=\x221920\x22\x0a\
     inkscape:wi\
ndow-height=\x22996\
\x22\x0a     inkscape:\
window-x=\x22-9\x22\x0a  \
   inkscape:wind\
ow-y=\x22-9\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg2\x22 \
/>\x0a  <g\x0a     tra\
nsform=\x22translat\
e(-1.95268128414\
154, -8.74558092\
651367)\x22\x0a     id\
=\x22g2\x22\x0a     style\
=\x22fill:#ffffff;f\
ill-opacity:0;st\
roke:#ffffff;str\
oke-opacity:1\x22>\x0a\
    <g\x0a       tr\
ansform=\x22matrix(\
0.06535751372575\
76, 0, 0, 0.0653\
575137257576, 0,\
 0)\x22\x0a       id=\x22\
g1\x22\x0a       style\
=\x22fill:#ffffff;f\
ill-opacity:0;st\
roke:#ffffff;str\
oke-opacity:1\x22>\x0a\
      <ellipse\x0a \
        cx=\x22244.\
068\x22\x0a         cy\
=\x22242.153\x22\x0a     \
    rx=\x22194.068\x22\
\x0a         ry=\x2288\
.418\x22\x0a         f\
ill=\x22rgb(255, 25\
5, 255)\x22\x0a       \
  fill-opacity=\x22\
0\x22\x0a         stro\
ke=\x22#FFFFFF\x22\x0a   \
      stroke-wid\
th=\x2240px\x22\x0a      \
   id=\x22ellipse1\x22\
\x0a         style=\
\x22fill:#ffffff;fi\
ll-opacity:0;str\
oke:#ffffff;stro\
ke-opacity:1\x22 />\
\x0a    </g>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x09<\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2.005 -2\
.005 32 32\x22\x0a   v\
ersion=\x221.1\x22\x0a   \
id=\x22svg2\x22\x0a   sod\
ipodi:docname=\x22d\
ropper.svg\x22\x0a   i\
nkscape:version=\
\x221.4 (86a8ad7, 2\
024-10-11)\x22\x0a   x\
mlns:inkscape=\x22h\
ttp://www.inksca\
pe.org/namespace\
s/inkscape\x22\x0a   x\
mlns:sodipodi=\x22h\
ttp://sodipodi.s\
ourceforge.net/D\
TD/sodipodi-0.dt\
d\x22\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0a   xmln\
s:svg=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a  <defs\x0a    \
 id=\x22defs2\x22 />\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview2\x22\x0a     p\
agecolor=\x22#00000\
0\x22\x0a     borderco\
lor=\x22#FFFFFF\x22\x0a  \
   borderopacity\
=\x220.25\x22\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0a     in\
kscape:pageopaci\
ty=\x220.0\x22\x0a     in\
kscape:pagecheck\
erboard=\x220\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   inkscape:zoom\
=\x2225.21875\x22\x0a    \
 inkscape:cx=\x2216\
\x22\x0a     inkscape:\
cy=\x2215.980173\x22\x0a \
    inkscape:win\
dow-width=\x221920\x22\
\x0a     inkscape:w\
indow-height=\x2299\
6\x22\x0a     inkscape\
:window-x=\x22-9\x22\x0a \
    inkscape:win\
dow-y=\x22-9\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
\x0a     showgrid=\x22\
true\x22>\x0a    <inks\
cape:grid\x0a      \
 id=\x22grid1\x22\x0a    \
   units=\x22px\x22\x0a  \
     originx=\x220\x22\
\x0a       originy=\
\x220\x22\x0a       spaci\
ngx=\x221\x22\x0a       s\
pacingy=\x221\x22\x0a    \
   empcolor=\x22#00\
99e5\x22\x0a       emp\
opacity=\x220.30196\
078\x22\x0a       colo\
r=\x22#0099e5\x22\x0a    \
   opacity=\x220.14\
901961\x22\x0a       e\
mpspacing=\x225\x22\x0a  \
     enabled=\x22tr\
ue\x22\x0a       visib\
le=\x22true\x22 />\x0a  <\
/sodipodi:namedv\
iew>\x0a  <g\x0a     t\
ransform=\x22transl\
ate(-0.0054, -0.\
006)\x22\x0a     id=\x22g\
2\x22\x0a     style=\x22f\
ill:#FFFFFF;fill\
-opacity:1\x22>\x0a   \
 <g\x0a       trans\
form=\x22matrix(0.0\
546829737722874,\
 0, 0, 0.0546829\
737722874, 0, 0)\
\x22\x0a       id=\x22g1\x22\
\x0a       style=\x22f\
ill:#FFFFFF;fill\
-opacity:1\x22>\x0a   \
   <path\x0a       \
  d=\x22M341.6, 29.\
2L240.1, 130.8L2\
30.7, 121.4C218.\
2, 108.9 197.9, \
108.9 185.4, 121\
.4C172.9, 133.9 \
172.9, 154.2 185\
.4, 166.7L345.4,\
 326.7C357.9, 33\
9.2 378.2, 339.2\
 390.7, 326.7C40\
3.2, 314.2 403.2\
, 293.9 390.7, 2\
81.4L381.3, 272L\
482.8, 170.4C521\
.8, 131.4 521.8,\
 68.2 482.8, 29.\
3C443.8, -9.6 38\
0.6, -9.7 341.7,\
 29.3zM55.4, 323\
.3C40.4, 338.3 3\
2, 358.7 32, 379\
.9L32, 422.3L5.4\
, 462.2C-3.1, 47\
4.9 -1.4, 491.8 \
9.4, 502.6C20.2,\
 513.4 37.1, 515\
.1 49.8, 506.6L8\
9.7, 480L132.1, \
480C153.3, 480 1\
73.7, 471.6 188.\
7, 456.6L309.4, \
335.9L264.1, 290\
.6L143.4, 411.3C\
140.4, 414.3 136\
.3, 416 132.1, 4\
16L96, 416L96, 3\
79.9C96, 375.7 9\
7.7, 371.6 100.7\
, 368.6L221.4, 2\
47.9L176.1, 202.\
6L55.4, 323.3z\x22\x0a\
         id=\x22pat\
h1\x22\x0a         sty\
le=\x22fill:#FFFFFF\
;fill-opacity:1\x22\
 />\x0a    </g>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x08\x11\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   he\
ight=\x2232\x22\x0a   vie\
wBox=\x220 0 32 32\x22\
\x0a   width=\x2232\x22\x0a \
  version=\x221.1\x22\x0a\
   id=\x22svg1\x22\x0a   \
sodipodi:docname\
=\x22selection-drag\
.svg\x22\x0a   inkscap\
e:version=\x221.4 (\
e7c3feb100, 2024\
-10-09)\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0a\
   xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22\x0a   xmlns:s\
vg=\x22http://www.w\
3.org/2000/svg\x22>\
\x0a  <defs\x0a     id\
=\x22defs1\x22 />\x0a  <s\
odipodi:namedvie\
w\x0a     id=\x22named\
view1\x22\x0a     page\
color=\x22#000000\x22\x0a\
     bordercolor\
=\x22#FFFFFF\x22\x0a     \
borderopacity=\x220\
.25\x22\x0a     inksca\
pe:showpageshado\
w=\x222\x22\x0a     inksc\
ape:pageopacity=\
\x220.0\x22\x0a     inksc\
ape:pagecheckerb\
oard=\x220\x22\x0a     in\
kscape:deskcolor\
=\x22#d1d1d1\x22\x0a     \
showgrid=\x22true\x22\x0a\
     inkscape:zo\
om=\x2215.291667\x22\x0a \
    inkscape:cx=\
\x22-0.55585831\x22\x0a  \
   inkscape:cy=\x22\
9.6457766\x22\x0a     \
inkscape:window-\
width=\x221920\x22\x0a   \
  inkscape:windo\
w-height=\x22969\x22\x0a \
    inkscape:win\
dow-x=\x220\x22\x0a     i\
nkscape:window-y\
=\x220\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22svg1\x22>\x0a    \
<inkscape:grid\x0a \
      id=\x22grid1\x22\
\x0a       units=\x22p\
x\x22\x0a       origin\
x=\x220\x22\x0a       ori\
giny=\x220\x22\x0a       \
spacingx=\x221\x22\x0a   \
    spacingy=\x221\x22\
\x0a       empcolor\
=\x22#0099e5\x22\x0a     \
  empopacity=\x220.\
30196078\x22\x0a      \
 color=\x22#0099e5\x22\
\x0a       opacity=\
\x220.14901961\x22\x0a   \
    empspacing=\x22\
5\x22\x0a       enable\
d=\x22true\x22\x0a       \
visible=\x22true\x22 /\
>\x0a  </sodipodi:n\
amedview>\x0a  <pat\
h\x0a     d=\x22m 19.6\
54321,22.086421 \
h 4.148148 v -4.\
14815 h 2.765433\
 v 4.14815 h 4.1\
48147 v 2.76543 \
H 26.567902 V 29\
 h -2.765433 v -\
4.148149 h -4.14\
8148 z m -2.7654\
31,0 v 2.76543 h\
 -4.148149 v -2.\
76543 z m -6.913\
5811,0 v 2.76543\
 H 4.4444444 v -\
5.530864 h 2.765\
4323 v 2.765434 \
z M 4.4444444,16\
.555556 v -4.148\
149 h 2.7654323 \
v 4.148149 z m 0\
,-6.9135815 V 4.\
1111104 H 9.9753\
089 V 6.8765427 \
H 7.2098767 V 9.\
6419745 Z M 12.7\
40741,4.1111104 \
h 4.148149 v 2.7\
654323 h -4.1481\
49 z m 8.296296,\
0 h 5.530865 V 9\
.6419745 H 23.80\
2469 V 6.8765427\
 h -2.765432 z m\
 5.530865,8.2962\
966 v 2.765432 h\
 -2.765433 v -2.\
765432 z\x22\x0a     i\
d=\x22path1\x22\x0a\x09  sty\
le=\x22stroke-width\
:1.33333;fill:#f\
fffff;fill-opaci\
ty:1\x22 />\x0a</svg>\x0a\
\
\x00\x00\x06A\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-4 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg1\
\x22\x0a   sodipodi:do\
cname=\x22copy.svg\x22\
\x0a   inkscape:ver\
sion=\x221.4 (86a8a\
d7, 2024-10-11)\x22\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0a   xmlns:sodipo\
di=\x22http://sodip\
odi.sourceforge.\
net/DTD/sodipodi\
-0.dtd\x22\x0a   xmlns\
=\x22http://www.w3.\
org/2000/svg\x22\x0a  \
 xmlns:svg=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a  <defs\
\x0a     id=\x22defs1\x22\
 />\x0a  <sodipodi:\
namedview\x0a     i\
d=\x22namedview1\x22\x0a \
    pagecolor=\x22#\
000000\x22\x0a     bor\
dercolor=\x22#FFFFF\
F\x22\x0a     borderop\
acity=\x220.25\x22\x0a   \
  inkscape:showp\
ageshadow=\x222\x22\x0a  \
   inkscape:page\
opacity=\x220.0\x22\x0a  \
   inkscape:page\
checkerboard=\x220\x22\
\x0a     inkscape:d\
eskcolor=\x22#d1d1d\
1\x22\x0a     inkscape\
:zoom=\x2224.3125\x22\x0a\
     inkscape:cx\
=\x2215.979434\x22\x0a   \
  inkscape:cy=\x221\
6\x22\x0a     inkscape\
:window-width=\x221\
920\x22\x0a     inksca\
pe:window-height\
=\x22996\x22\x0a     inks\
cape:window-x=\x22-\
9\x22\x0a     inkscape\
:window-y=\x22-9\x22\x0a \
    inkscape:win\
dow-maximized=\x221\
\x22\x0a     inkscape:\
current-layer=\x22s\
vg1\x22 />\x0a  <g\x0a   \
  id=\x22Layer_1\x22\x0a \
    transform=\x22t\
ranslate(-4, -2)\
\x22\x0a     style=\x22en\
able-background:\
new 0 0 32 32\x22>\x0a\
    <g\x0a       id\
=\x22Copy\x22>\x0a      <\
path\x0a         d=\
\x22M21, 2L11, 2C10\
.5, 2 10, 2.5 10\
, 3L10, 8L5, 8C4\
.5, 8 4, 8.5 4, \
9L4, 29C4, 29.5 \
4.5, 30 5, 30L21\
, 30C21.5, 30 22\
, 29.5 22, 29L22\
, 24L27, 24C27.5\
, 24 28, 23.5 28\
, 23L28, 9L21, 2\
zM20, 28L6, 28L6\
, 10L14, 10L14, \
15C14, 15.5 14.5\
, 16 15, 16L20, \
16L20, 28zM26, 2\
2L22, 22L22, 15L\
15, 8L12, 8L12, \
4L20, 4L20, 9C20\
, 9.5 20.5, 10 2\
1, 10L26, 10L26,\
 22z\x22\x0a         f\
ill=\x22#FFFFFF\x22\x0a  \
       class=\x22Bl\
ack\x22\x0a         id\
=\x22path1\x22\x0a       \
  style=\x22fill:#F\
FFFFF;fill-opaci\
ty:1\x22 />\x0a    </g\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x03\x82\
\x00\
\x00\x12Qx\xda\xedX\xcdn\xdb8\x10\xbe/\xd0w\
\x18\xb0\x87\xb4@L\xf3\x9fR\x10\xb5@\xb4\xc8I{\
k\xd1\xe3B\xb1U[\xa8#\x07\xb2\x1a'}\xb5=\
\xec#\xf5\x15v(R\x12\x9d\xdd,\xd2n\x0e\xc1\xc2\
\x89Mr>qf\xa4\x99\x8f\xa3I\xbe\xff\xf1\xe7\xf9\
\xfb\xbb\xeb\x0d\xdcV\xed\xae\xde6\xd9\x09\xa7\xec\x04\xaa\
f\xb1]\xd6\xcd*;\xf9\xf8\xe1r\x96\x9c\xbc\x7f\xf7\
\xea\x97\xf3\xdd\xed\x0an\xebj\x7f\xb1\xbd\xcb\xc8L\xc0\
LQ\xc9\xac\x06)\xf0C\x00\xad4\xbb\x8c\xac\xbb\xee\
\xe6l>\xdf\xef\xf7t/\xe9\xb6]\xcd\x05cl\x8e\
\xca\x04\xd0\x0a\xc0\xf9\x0a\xeaeF\x8a\xf2\xbej\x7f\xe7\
\x04\xba\xb6lv\x9f\xb7\xeduF\xfa\xe5\xa6\xec\xaa7\
\xec\x14f\xa27\xff\x96\xc0\xae\xbb\xdfT\x19\xa9\x9a\xf2\
jS\xcd\xae\xca\xc5\x97U\xbb\xfd\xda,\xcf\x9aj\x0f\
\x0c\x7f5\x17\xeeKz\xfb\xbd\x87\xc8\xe8u\xd9\xb5\xf5\
\xdd\x1bF\x13\xab\xd2S`\xfe\x13Io\x07\xbdG4\
9\xe5J\x98A3\x96\x22\xcdG\xbd2\xad\xec\xe4u\
\x92\x0et\x9d\xf6\x81\x88\xc0M\xd9\xad\x01\x03\xf5\x9b2\
\x09\x95F\x9d\x824I1\x09)\xa7\xc2\xca<\x02\x0c\
e\xa9\x04e\x05^\x10\xa7\xa0\x18C\xc1\x22\xc8{!\
W\x09\xa7)\xe7\xe1J\xa2i\xc2\x93AO\xc4@o\
\xb9\x98\x80\x03\xbf&\xf9F\xe0s\xbd\xd9d\xe4\xf5e\
\xff\xe3\xc5\xd9\xf6\xa6\x5c\xd4\xdd}F0\xa9\x8bM\xb9\
C2\x5cl0Y\x04\xe6\x87\x8f:\x8f\x9f5\x96\xa6\
\xf5\xb0\x1a\xe7#i~\x904RR\xa5u\xc4\x93\x09\
\x08<\x91\x163*\x03\x1b\x94\xa0<\x11\x81'\x0aI\
\xc3\x06\x06iFS\x96F<\x99\x80\xc0\x93\x11p<\
\xe9\xdd\xa8\x87\x82\xdfz$\xce\xcb'\x8eL\x13\xaaU\
D\x9c\x08\x08\xc4a\x02\xb3:\x10\x87\xd9\xb1\xda\xe4\x8a\
\x0bG\x91p\x85k\x9a\xa61q& \x10g\x04\x90\
+\xde\x8dz(\x1c\x89\xf3\xc2\x89\xd3V\x8b\x0e\xb0!\
\x10\xc2\xb8*@\x00\xd3!\x95\xa2VX\x02\xfbz\xd9\
\xad3\xa2\x13W\x5c\x08\xac\xabz\xb5\xee0]\xdc\xb8\
\x97\x09\x81\x16\x15\x19N\xf7\xfdtL\xf1\x8bH\xf1X\
\x0a\xf0A\xfa\xe3\x98\xfb\x85UT\x81f\x86\xda\xbe\x0f\
\xb0)5\xd2 \xc0Bc\xe0\x81\x82s7\x8dr\xae\
\xa9\x88D\xe7\xd1[b\xfe\xa8\xe3\xa4\xa5\xeb3r\x5c\
\xe1\x8bG\xf1\x04\x82\x8a\x7f'\xc1`\xd0\x8b\x85w(\
\x079\xf7w4\xca\x18~\xee\xab\xca`l\x90\xbd\x9b\
b\x94\x9f\xd6\xc9\x84\x94;\xfcl\xdc5?r\xedy\
\xb86T\x0f\xa9\xc6\xe2\xe1;\xd6\xb1v\x84\xced*\
\x1e\xc2X\xc7\x87\x9f,\x1e\x9f\xd6uW\x1d\x13\xf8\xfc\
\xc5B\xa6:\x1cS\x93\xf6\xe7,\x14\xf9\x11\xc89\x1e\
\xbc\xfe\xa5\x1e\x00\xe0\xcce\xd2:\x00\x1b\x01\x1e\xcb\xdc\
q \x9f\x00m\xb0\x0d\xc0\x1d\xa3\x09-\x9cq\x98\x9c\
x\xa0\xf0\xb7aG \xc7V\x04\xbb\x95\x09\xc0\xdeD\
\x0d*\xce\xa8\x88\x80\xe06\x02\xdc}q\xf06\xa6g\
\x83\x87\x0f\xfb\x9f\xfa\x93g\xe4\x9fq\x896\xa9x\x12\
\xfd\xfc\xdf\xed\xffN>=q@\xff\x13\xed\xdc-}\
\xaa\x9b\xe5v\x7f\xc0\xa9\x89\x15\x8ez\xacp\x93\xce\xdd\
\xa8\xa8\x06\x91:c\x0ag\x1c\x0bW\xb9s\x11\x90\xb0\
\x01w\x17b\xd4\xe4l\x8a/\xe7\xd6\xfej\xa3p~\
=8\xcd\xff\xb7\xf8\x89\xa4\x8f\x82\x9b\x84)\xd40:\
h\x18\x85\xcd\xfb\xd1\xc5\xcd9\x11HO7\x16.\xbc\
\x22\xc9}\xb4\x1d\xca\xc26\xbf\x08\xa1-\xbc\x8b\xbf3\
\xf81\xc2>\x16\xe2s\xf7?\x9ew\x7f\x01\xa1\xd8S\
\xd6\
\x00\x00\x03#\
\x00\
\x00\x0a{x\xda\xddV]o\x9b0\x14}\xef\xaf@\
\xee\xcb&\x0db\x08\xf9\x80\x96V\x9a\xaa\xfe\x82\xee\xad\
/\x0e\xbe!^\x88\x8dl\x12\x92\xfe\xfa\xd9\x80\x81|\
u\xab\xa6j\xd2B\x22\xc5\xe7~\xfa\xf8\x5c'\xf7\x8f\
\xfbM\xee\xec@*&x\x82|\x0f#\x07x*(\
\xe3Y\x82~\xbc<\xbbs\xe4\xa8\x92pJr\xc1!\
A\x5c\xa0\xc7\x87\x9b{\xb5\xcbn\x1c\xc7\xd91\xa8\xbe\
\x8b}\x82\xdc\xd0qC\x0f\x07\x13g\x1c\xe87\xaa\x8d\
}V\xbf\x06\x18M\x90\x0e\x0c\xeb\x85\xd25\x0a\xfd\x89\
\xa9H9\xd9\xe8\xd4\xe9\x0a\xd25HO\xbb4\xee|\
\xadRR@<H\x14:_\xe6S2't\xf6\xcd\
\x09p\x10\xba>v}\xff\xeb\xb1?\xec\x0b!Kw\
\xc9rh2{\xdek\xc13\x96\x0a\xae^\xdb*\xe3\
\xc0\xd3\xd0\xc5\xb8=-X\x82\xa2\xe9E\xe3ah\xd4\
\xdcq\x15[\x97\x04\xad\xca\xb2\x88G\xa3\xaa\xaa<\x0b\
zBf#\xd3\x85*H\x0ajd\xf1A\xbce\xa2\
\x8b\xb7\x80\xa7\xc4V\xa6\xb0\xd4)\xc0\xe3P\x8e\x9e^\
\x9e:\xa3\x8b=Z\xd2>\xcdQ\xf5j\x5c\xd7\x0d0\
\xc6#Kg[l\x97\xbd\xeb\xf9\xa0]\xef),\x95\
\x09i\x8e\xcc\xacB\xe4\x8cjSwlfO\xd4\x9c\
\x7f\xef\xd8A\xcd\x09;NA2HE.d\x82n\
q\xfdj\x0d\x0b!)Hkz\xae_G&\xa1\xd9\
b\xe5!A\xd8\x0b&\xad\xa5;\x0a\xb5\x12\x95I\xad\
V\x84\x8a*A\xc1\xa9\x831\x0e2\xe0K\xf6V\x07\
\x0bA\xa4n\xbd\x94[8\xf5\xa2\xa0\xd6\xb6E\xea\x9b\
\xa7\xf50\xf53\xc9\xae\x84\xbd\x09\xb1\xd1=\x85\xde\xd8\
?o=\xd5\xb3\xe2O\xbch\x16\x85\xe3\xf0\xcc\xa8\xbb\
\xf5\xa7\xa7h\xc5\xb8\xde\xa5[1Z\xae\xb4=\x0a\xf0\
\x15\x8f\x15\xb0lUjqF\xd7r\x98A\x8d\xae\xd8\
\x0e\xef\xd86d\xcf6\xec\x0d\xf4\x8e\xfd\xb3\xa6\xb7R\
\x02/\xdd\x9c\x1c@\x0e\xe6\xbb\xa1\xa99\xcd#\xa2r\
\xb2\x80\x5c\x95\x87\x1cji\x91m^\xd6\xaa\xd3\xe2\xea\
\x92\x1av\x1b\xefFYfm\xd3:\xce\x96\xb3R\xeb\
\xbd\xd8w\x88\x90,c\x5co\x0f\x9f@\x87!dF\
P\xdfk\xfb~\x17\x1dv\x18b\xb0)z\xd5F\x11\
L\x86\x96\x81\xae\xc6\xd8\x8f\xa6x6\xef\xccW\xa2\x06\
!~\x18\x99\xa0\xa3Zm\x0b\x09\x1a\xd4\xe1d\x91\xc3\
\xb1\xc0\xccm\xab\xd8\xc2\xd0V\xa3\xed@\x8e\xce'\xb2\
\xc6%\xa4e{\x0e\x0d\xd7;\x0d\x08\xe9\xc2r\xa9\xbf\
\xc4\x5cpWs\x9d\xeb\xc2\xae*\xa5X\xc3\x9d\xbe/\
\xf3\xf8\x16\xb0y\xea\x85\xdb6\x1e\xfbw\x8dK\xdc\x8e\
j\xbbl4\x19\xfb^`\x01\x9d\x0e\xf4\x01\xc6Rl\
9\x1d\x82?\x05\xe3\xc7(%z|\xa5$\x07\xd3\x0a\
\xdc\xb9\xf6\xec\xdbn\xe2\x15a\xd2D\xa2\xfe~1[\
\xb2*\xb0\xe3`g\xdf\x8a\xdf\x0f\xbc\xfa\xa2\xb1\x0c\x0f\
4a\x14\x8e\xcdo\x941\xcf\x22K\xe0\x7fJ\xd4\xe4\
\xb7D\xf5\x0cu\xdf\xcd\x18\xf8\xfav\x9a\xfc-9s\
l\x9ek\xe4\xcc\xc0<\x9f@N\x8b\xf6\x15\xff\x94\xad\
\xe9\xc7e5$\xad\xd3\xd5x2\xff\x5c\xea\xfe\xb9\xae\
f\x1f\xd0\x15\xbe(\xab{\xf3G\xe3\xe1\xe6\x17\x1d\xdf\
3\xdf\
\x00\x00\x08\xc4\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-3.1665 -\
1.9998 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg8\x22\x0a   s\
odipodi:docname=\
\x22text.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (86a8ad7, 20\
24-10-11)\x22\x0a   xm\
lns:inkscape=\x22ht\
tp://www.inkscap\
e.org/namespaces\
/inkscape\x22\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:svg=\x22http://www\
.w3.org/2000/svg\
\x22>\x0a  <defs\x0a     \
id=\x22defs8\x22 />\x0a  \
<sodipodi:namedv\
iew\x0a     id=\x22nam\
edview8\x22\x0a     pa\
gecolor=\x22#000000\
\x22\x0a     bordercol\
or=\x22#FFFFFF\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x220\x22\x0a     \
inkscape:deskcol\
or=\x22#d1d1d1\x22\x0a   \
  showgrid=\x22true\
\x22\x0a     inkscape:\
zoom=\x2224.3125\x22\x0a \
    inkscape:cx=\
\x2215.979434\x22\x0a    \
 inkscape:cy=\x2216\
\x22\x0a     inkscape:\
window-width=\x2219\
20\x22\x0a     inkscap\
e:window-height=\
\x22996\x22\x0a     inksc\
ape:window-x=\x22-9\
\x22\x0a     inkscape:\
window-y=\x22-9\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g8\x22>\x0a    <inksca\
pe:grid\x0a       i\
d=\x22grid8\x22\x0a      \
 units=\x22px\x22\x0a    \
   originx=\x220\x22\x0a \
      originy=\x220\
\x22\x0a       spacing\
x=\x221\x22\x0a       spa\
cingy=\x221\x22\x0a      \
 empcolor=\x22#0099\
e5\x22\x0a       empop\
acity=\x220.3019607\
8\x22\x0a       color=\
\x22#0099e5\x22\x0a      \
 opacity=\x220.1490\
1961\x22\x0a       emp\
spacing=\x225\x22\x0a    \
   enabled=\x22true\
\x22\x0a       visible\
=\x22true\x22 />\x0a  </s\
odipodi:namedvie\
w>\x0a  <g\x0a     tra\
nsform=\x22matrix(0\
.96643453,0,0,0.\
92591904,-4.8039\
544,-2.3206938)\x22\
\x0a     style=\x22str\
oke:#FFFFFF;stro\
ke-opacity:1\x22\x0a  \
   id=\x22g8\x22>\x0a    \
<g\x0a       transf\
orm=\x22scale(2.333\
3)\x22\x0a       id=\x22g\
7\x22\x0a       style=\
\x22stroke:#FFFFFF;\
stroke-opacity:1\
\x22>\x0a      <g\x0a    \
     class=\x22Blac\
k\x22\x0a         tran\
sform=\x22translate\
(1.5,-1)\x22\x0a      \
   id=\x22g6\x22\x0a     \
    style=\x22strok\
e:#FFFFFF;stroke\
-opacity:1\x22>\x0a   \
     <g\x0a        \
   id=\x22g5\x22\x0a     \
      style=\x22str\
oke:#FFFFFF;stro\
ke-opacity:1\x22>\x0a \
         <path\x0a \
            d=\x22M\
 11.643102,14.57\
168 H 9.9015035 \
L 8.5469269,11.2\
93037 H 4.096175\
1 L 2.838354,14.\
57168 H 1 L 5.45\
07518,3 H 7.1923\
503 Z M 8.063149\
5,10.135869 6.32\
1551,4.7357519 4\
.5799525,10.1358\
69 Z\x22\x0a          \
   id=\x22path4\x22\x0a  \
           style\
=\x22fill:#FFFFFF;f\
ill-opacity:1;st\
roke:none;stroke\
-width:0;stroke-\
opacity:1;stroke\
-dasharray:none\x22\
\x0a             so\
dipodi:nodetypes\
=\x22ccccccccccccc\x22\
 />\x0a        </g>\
\x0a      </g>\x0a    \
</g>\x0a  </g>\x0a</sv\
g>\x0a\
\x00\x00\x07\x05\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x2224\x22\x0a   heig\
ht=\x2224\x22\x0a   viewB\
ox=\x220 0 24 24\x22\x0a \
  fill=\x22none\x22\x0a  \
 stroke=\x22current\
Color\x22\x0a   stroke\
-width=\x222\x22\x0a   st\
roke-linecap=\x22ro\
und\x22\x0a   stroke-l\
inejoin=\x22round\x22\x0a\
   version=\x221.1\x22\
\x0a   id=\x22svg6\x22\x0a  \
 sodipodi:docnam\
e=\x22flip-vertical\
-2.svg\x22\x0a   inksc\
ape:export-filen\
ame=\x22flip-vertic\
al-2.png\x22\x0a   ink\
scape:export-xdp\
i=\x22128\x22\x0a   inksc\
ape:export-ydpi=\
\x22128\x22\x0a   inkscap\
e:version=\x221.4 (\
86a8ad7, 2024-10\
-11)\x22\x0a   xmlns:i\
nkscape=\x22http://\
www.inkscape.org\
/namespaces/inks\
cape\x22\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0a   \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22\x0a   xmlns:svg=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a  \
<defs\x0a     id=\x22d\
efs6\x22 />\x0a  <sodi\
podi:namedview\x0a \
    id=\x22namedvie\
w6\x22\x0a     pagecol\
or=\x22#000000\x22\x0a   \
  bordercolor=\x22#\
FFFFFF\x22\x0a     bor\
deropacity=\x220.25\
\x22\x0a     inkscape:\
showpageshadow=\x22\
2\x22\x0a     inkscape\
:pageopacity=\x220.\
0\x22\x0a     inkscape\
:pagecheckerboar\
d=\x220\x22\x0a     inksc\
ape:deskcolor=\x22#\
d1d1d1\x22\x0a     ink\
scape:zoom=\x2232.4\
16667\x22\x0a     inks\
cape:cx=\x2211.9845\
76\x22\x0a     inkscap\
e:cy=\x2212\x22\x0a     i\
nkscape:window-w\
idth=\x221920\x22\x0a    \
 inkscape:window\
-height=\x22996\x22\x0a  \
   inkscape:wind\
ow-x=\x22-9\x22\x0a     i\
nkscape:window-y\
=\x22-9\x22\x0a     inksc\
ape:window-maxim\
ized=\x221\x22\x0a     in\
kscape:current-l\
ayer=\x22svg6\x22 />\x0a \
 <path\x0a     d=\x22m\
17 3-5 5-5-5h10\x22\
\x0a     style=\x22str\
oke:#FFFFFF;stro\
ke-opacity:1\x22\x0a  \
   id=\x22path1\x22 />\
\x0a  <path\x0a     d=\
\x22m17 21-5-5-5 5h\
10\x22\x0a     style=\x22\
stroke:#FFFFFF;s\
troke-opacity:1\x22\
\x0a     id=\x22path2\x22\
 />\x0a  <path\x0a    \
 d=\x22M4 12H2\x22\x0a   \
  style=\x22stroke:\
#FFFFFF;stroke-o\
pacity:1\x22\x0a     i\
d=\x22path3\x22 />\x0a  <\
path\x0a     d=\x22M10\
 12H8\x22\x0a     styl\
e=\x22stroke:#FFFFF\
F;stroke-opacity\
:1\x22\x0a     id=\x22pat\
h4\x22 />\x0a  <path\x0a \
    d=\x22M16 12h-2\
\x22\x0a     style=\x22st\
roke:#FFFFFF;str\
oke-opacity:1\x22\x0a \
    id=\x22path5\x22 /\
>\x0a  <path\x0a     d\
=\x22M22 12h-2\x22\x0a   \
  style=\x22stroke:\
#FFFFFF;stroke-o\
pacity:1\x22\x0a     i\
d=\x22path6\x22 />\x0a</s\
vg>\x0a\
\x00\x00\x06X\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -5.400\
9 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg2\x22\x0a   sodipo\
di:docname=\x22rect\
angle.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (86a8ad7, 20\
24-10-11)\x22\x0a   xm\
lns:inkscape=\x22ht\
tp://www.inkscap\
e.org/namespaces\
/inkscape\x22\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:svg=\x22http://www\
.w3.org/2000/svg\
\x22>\x0a  <defs\x0a     \
id=\x22defs2\x22 />\x0a  \
<sodipodi:namedv\
iew\x0a     id=\x22nam\
edview2\x22\x0a     pa\
gecolor=\x22#000000\
\x22\x0a     bordercol\
or=\x22#FFFFFF\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x22true\x22\x0a  \
   inkscape:desk\
color=\x22#d1d1d1\x22\x0a\
     inkscape:zo\
om=\x2224.3125\x22\x0a   \
  inkscape:cx=\x221\
5.979434\x22\x0a     i\
nkscape:cy=\x2216\x22\x0a\
     inkscape:wi\
ndow-width=\x221920\
\x22\x0a     inkscape:\
window-height=\x229\
96\x22\x0a     inkscap\
e:window-x=\x22-9\x22\x0a\
     inkscape:wi\
ndow-y=\x22-9\x22\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0a \
    inkscape:cur\
rent-layer=\x22svg2\
\x22 />\x0a  <g\x0a     t\
ransform=\x22transl\
ate(-1.504897735\
0235, -4.9878532\
699585)\x22\x0a     id\
=\x22g2\x22\x0a     style\
=\x22stroke:#FFFFFF\
;stroke-opacity:\
1\x22>\x0a    <g\x0a     \
  transform=\x22mat\
rix(0.0623481683\
433056, 0, 0, 0.\
0623481683433056\
, 0, 0)\x22\x0a       \
id=\x22g1\x22\x0a       s\
tyle=\x22stroke:#FF\
FFFF;stroke-opac\
ity:1\x22>\x0a      <r\
ect\x0a         x=\x22\
44.137\x22\x0a        \
 y=\x22100\x22\x0a       \
  width=\x22409.091\
\x22\x0a         heigh\
t=\x22300\x22\x0a        \
 rx=\x220\x22\x0a        \
 ry=\x220\x22\x0a        \
 fill=\x22rgb(216, \
216, 216)\x22\x0a     \
    fill-opacity\
=\x220\x22\x0a         st\
roke=\x22#FFFFFF\x22\x0a \
        stroke-w\
idth=\x2240px\x22\x0a    \
     id=\x22rect1\x22\x0a\
         style=\x22\
stroke:#FFFFFF;s\
troke-opacity:1;\
fill:#ffffff;fil\
l-opacity:0\x22 />\x0a\
    </g>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x09\x5c\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -6.55 \
32 32\x22\x0a   versio\
n=\x221.1\x22\x0a   id=\x22s\
vg3\x22\x0a   sodipodi\
:docname=\x22undo-g\
ray.svg\x22\x0a   inks\
cape:version=\x221.\
4 (e7c3feb100, 2\
024-10-09)\x22\x0a   x\
mlns:inkscape=\x22h\
ttp://www.inksca\
pe.org/namespace\
s/inkscape\x22\x0a   x\
mlns:sodipodi=\x22h\
ttp://sodipodi.s\
ourceforge.net/D\
TD/sodipodi-0.dt\
d\x22\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0a   xmln\
s:svg=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a  <defs\x0a    \
 id=\x22defs3\x22 />\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview3\x22\x0a     p\
agecolor=\x22#00000\
0\x22\x0a     borderco\
lor=\x22#FFFFFF\x22\x0a  \
   borderopacity\
=\x220.25\x22\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0a     in\
kscape:pageopaci\
ty=\x220.0\x22\x0a     in\
kscape:pagecheck\
erboard=\x220\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   inkscape:zoom\
=\x2225.21875\x22\x0a    \
 inkscape:cx=\x2216\
\x22\x0a     inkscape:\
cy=\x2216\x22\x0a     ink\
scape:window-wid\
th=\x221920\x22\x0a     i\
nkscape:window-h\
eight=\x22969\x22\x0a    \
 inkscape:window\
-x=\x220\x22\x0a     inks\
cape:window-y=\x220\
\x22\x0a     inkscape:\
window-maximized\
=\x221\x22\x0a     inksca\
pe:current-layer\
=\x22svg3\x22 />\x0a  <g\x0a\
     transform=\x22\
translate(-11.97\
1, -16.521)\x22\x0a   \
  id=\x22g3\x22\x0a     s\
tyle=\x22fill:#FFFF\
FF;fill-opacity:\
1\x22>\x0a    <g\x0a     \
  transform=\x22mat\
rix(0.2028985321\
52176, 0, 0, 0.2\
02898532152176, \
0, 0)\x22\x0a       id\
=\x22g2\x22\x0a       sty\
le=\x22fill:#FFFFFF\
;fill-opacity:1\x22\
>\x0a      <g\x0a     \
    id=\x22g1\x22\x0a    \
     style=\x22fill\
:#FFFFFF;fill-op\
acity:1\x22>\x0a      \
  <path\x0a        \
   d=\x22M18.100006\
, 0C21.799988, 0\
.0000002 25.2999\
88, 1.2999886 27\
.899994, 3.59999\
28C30.600006, 5.\
8999971 32, 9.00\
00046 32, 12.299\
993C32, 15.59999\
8 30.600006, 18.\
700005 27.899994\
, 20.999995C27.5\
, 21.399989 26.8\
99994, 21.600001\
 26.399994, 21.6\
00001C25.899994,\
 21.600001 25.29\
9988, 21.399989 \
24.899994, 20.99\
9995C24.100006, \
20.300013 24.100\
006, 19.099999 2\
4.899994, 18.300\
011C26.699982, 1\
6.700005 27.6999\
82, 14.599998 27\
.699982, 12.2999\
93C27.699982, 10\
.000005 26.69998\
2, 7.899998 24.8\
99994, 6.299991C\
23.100006, 4.699\
9992 20.699982, \
3.7999898 18.100\
006, 3.7999898C1\
5.5, 3.7999898 1\
3.100006, 4.6999\
992 11.299988, 6\
.299991C10, 7.39\
99976 9.1000061,\
 8.8999985 8.699\
9817, 10.500006L\
13.299988, 15.09\
9998L0, 15.09999\
8L1.1000061, 2.8\
999954L5.5, 7.29\
99915C6.1999817,\
 5.8999971 7.100\
0061, 4.6999992 \
8.3999939, 3.599\
9928C10.899994, \
1.2999886 14.399\
994, 0.0000002 1\
8.100006, 0z\x22\x0a  \
         fill=\x22#\
FFFFFF\x22\x0a        \
   id=\x22path1\x22\x0a  \
         transfo\
rm=\x22rotate(0, 12\
8, 128) translat\
e(59, 81.4249991\
774559) scale(4.\
3125)\x22\x0a         \
  style=\x22fill:#F\
FFFFF;fill-opaci\
ty:1\x22 />\x0a      <\
/g>\x0a    </g>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x06\xf7\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2.0025 -\
2.0025 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg2\x22\x0a   s\
odipodi:docname=\
\x22crop.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (86a8ad7, 20\
24-10-11)\x22\x0a   xm\
lns:inkscape=\x22ht\
tp://www.inkscap\
e.org/namespaces\
/inkscape\x22\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:svg=\x22http://www\
.w3.org/2000/svg\
\x22>\x0a  <defs\x0a     \
id=\x22defs2\x22 />\x0a  \
<sodipodi:namedv\
iew\x0a     id=\x22nam\
edview2\x22\x0a     pa\
gecolor=\x22#000000\
\x22\x0a     bordercol\
or=\x22#000000\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x22true\x22\x0a  \
   inkscape:desk\
color=\x22#d1d1d1\x22\x0a\
     inkscape:zo\
om=\x2224.3125\x22\x0a   \
  inkscape:cx=\x221\
5.979434\x22\x0a     i\
nkscape:cy=\x2216\x22\x0a\
     inkscape:wi\
ndow-width=\x221920\
\x22\x0a     inkscape:\
window-height=\x229\
96\x22\x0a     inkscap\
e:window-x=\x22-9\x22\x0a\
     inkscape:wi\
ndow-y=\x22-9\x22\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0a \
    inkscape:cur\
rent-layer=\x22svg2\
\x22 />\x0a  <g\x0a     t\
ransform=\x22transl\
ate(-0.0021, -0.\
0021)\x22\x0a     id=\x22\
g2\x22\x0a     style=\x22\
fill:#ffffff;fil\
l-opacity:1\x22>\x0a  \
  <g\x0a       tran\
sform=\x22matrix(0.\
0546875037252903\
, 0, 0, 0.054687\
5037252903, 0, 0\
)\x22\x0a       id=\x22g1\
\x22\x0a       style=\x22\
fill:#ffffff;fil\
l-opacity:1\x22>\x0a  \
    <path\x0a      \
   d=\x22M128, 32C1\
28, 14.3 113.7, \
0 96, 0C78.3, 0 \
64, 14.3 64, 32L\
64, 64L32, 64C14\
.3, 64 0, 78.3 0\
, 96C0, 113.7 14\
.3, 128 32, 128L\
64, 128L64, 384C\
64, 419.3 92.7, \
448 128, 448L352\
, 448L352, 384L1\
28, 384L128, 32z\
M384, 480C384, 4\
97.7 398.3, 512 \
416, 512C433.7, \
512 448, 497.7 4\
48, 480L448, 448\
L480, 448C497.7,\
 448 512, 433.7 \
512, 416C512, 39\
8.3 497.7, 384 4\
80, 384L448, 384\
L448, 128C448, 9\
2.7 419.3, 64 38\
4, 64L160, 64L16\
0, 128L384, 128L\
384, 480z\x22\x0a     \
    id=\x22path1\x22\x0a \
        style=\x22f\
ill:#ffffff;fill\
-opacity:1\x22 />\x0a \
   </g>\x0a  </g>\x0a<\
/svg>\x0a\
\x00\x00\x0a\x1a\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -6 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg5\
\x22\x0a   sodipodi:do\
cname=\x22hide.svg\x22\
\x0a   inkscape:ver\
sion=\x221.4 (86a8a\
d7, 2024-10-11)\x22\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0a   xmlns:sodipo\
di=\x22http://sodip\
odi.sourceforge.\
net/DTD/sodipodi\
-0.dtd\x22\x0a   xmlns\
=\x22http://www.w3.\
org/2000/svg\x22\x0a  \
 xmlns:svg=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a  <defs\
\x0a     id=\x22defs5\x22\
 />\x0a  <sodipodi:\
namedview\x0a     i\
d=\x22namedview5\x22\x0a \
    pagecolor=\x22#\
000000\x22\x0a     bor\
dercolor=\x22#00000\
0\x22\x0a     borderop\
acity=\x220.25\x22\x0a   \
  inkscape:showp\
ageshadow=\x222\x22\x0a  \
   inkscape:page\
opacity=\x220.0\x22\x0a  \
   inkscape:page\
checkerboard=\x22tr\
ue\x22\x0a     inkscap\
e:deskcolor=\x22#d1\
d1d1\x22\x0a     inksc\
ape:zoom=\x2224.312\
5\x22\x0a     inkscape\
:cx=\x2215.979434\x22\x0a\
     inkscape:cy\
=\x2216\x22\x0a     inksc\
ape:window-width\
=\x221920\x22\x0a     ink\
scape:window-hei\
ght=\x22996\x22\x0a     i\
nkscape:window-x\
=\x22-9\x22\x0a     inksc\
ape:window-y=\x22-9\
\x22\x0a     inkscape:\
window-maximized\
=\x221\x22\x0a     inksca\
pe:current-layer\
=\x22svg5\x22 />\x0a  <g\x0a\
     id=\x22Layer_1\
\x22\x0a     transform\
=\x22translate(-2, \
-6)\x22\x0a     style=\
\x22enable-backgrou\
nd:new 0 0 32 32\
;fill:#ffffff;fi\
ll-opacity:1\x22>\x0a \
   <g\x0a       id=\
\x22VisibilityOff\x22\x0a\
       style=\x22fi\
ll:#ffffff;fill-\
opacity:1\x22>\x0a    \
  <path\x0a        \
 d=\x22M6, 8L8.4, 1\
0.4C4.5, 12.7 2,\
 16 2, 16C2, 16 \
8, 24 16, 24C17.\
8, 24 19.4, 23.6\
 21, 23L24, 26L2\
6, 24L8, 6L6, 8z\
M10.9, 12.9L12.4\
, 14.4C12.1, 14.\
9 12, 15.4 12, 1\
6C12, 18.2 13.8,\
 20 16, 20C16.6,\
 20 17.1, 19.9 1\
7.6, 19.6L19.1, \
21.1C18.2, 21.7 \
17.1, 22 16, 22C\
12.7, 22 10, 19.\
3 10, 16C10, 14.\
9 10.3, 13.8 10.\
9, 12.9z\x22\x0a      \
   fill=\x22#FFFFFF\
\x22\x0a         class\
=\x22Black\x22\x0a       \
  id=\x22path1\x22\x0a   \
      style=\x22fil\
l:#ffffff;fill-o\
pacity:1\x22 />\x0a   \
 </g>\x0a  </g>\x0a  <\
g\x0a     id=\x22g3\x22\x0a \
    transform=\x22t\
ranslate(-2, -6)\
\x22\x0a     style=\x22en\
able-background:\
new 0 0 32 32;fi\
ll:#ffffff;fill-\
opacity:1\x22>\x0a    \
<g\x0a       id=\x22g2\
\x22\x0a       style=\x22\
fill:#ffffff;fil\
l-opacity:1\x22>\x0a  \
    <path\x0a      \
   d=\x22M16, 12L20\
, 16C20, 13.8 18\
.2, 12 16, 12z\x22\x0a\
         fill=\x22#\
FFFFFF\x22\x0a        \
 class=\x22Black\x22\x0a \
        id=\x22path\
2\x22\x0a         styl\
e=\x22fill:#ffffff;\
fill-opacity:1\x22 \
/>\x0a    </g>\x0a  </\
g>\x0a  <g\x0a     id=\
\x22g5\x22\x0a     transf\
orm=\x22translate(-\
2, -6)\x22\x0a     sty\
le=\x22enable-backg\
round:new 0 0 32\
 32;fill:#ffffff\
;fill-opacity:1\x22\
>\x0a    <g\x0a       \
id=\x22g4\x22\x0a       s\
tyle=\x22fill:#ffff\
ff;fill-opacity:\
1\x22>\x0a      <path\x0a\
         d=\x22M16,\
 8C14.8, 8 13.6,\
 8.2 12.5, 8.5L1\
4.2, 10.2C14.8, \
10 15.3, 9.9 15.\
9, 9.9C19.2, 9.9\
 21.9, 12.6 21.9\
, 15.9C21.9, 16.\
5 21.8, 17.1 21.\
6, 17.6L24.7, 20\
.7C28, 18.6 30, \
16 30, 16C30, 16\
 24, 8 16, 8z\x22\x0a \
        fill=\x22#F\
FFFFF\x22\x0a         \
class=\x22Black\x22\x0a  \
       id=\x22path3\
\x22\x0a         style\
=\x22fill:#ffffff;f\
ill-opacity:1\x22 /\
>\x0a    </g>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00K\x8f\
\x89\
PNG\x0d\x0a\x1a\x0a\x00\x00\x00\x0dIHDR\x00\
\x00\x01\xf4\x00\x00\x01\xf4\x08\x06\x00\x00\x00\xcb\xd6\xdf\x8a\
\x00\x00\x00\x09pHYs\x00\x00\x0e\xc3\x00\x00\x0e\xc3\
\x01\xc7o\xa8d\x00\x00\x00\x19tEXtSof\
tware\x00www.inksca\
pe.org\x9b\xee<\x1a\x00\x00 \x00ID\
ATx\x9c\xed\xddw\x80\x5cg}\xef\xff\xcfs\xa6\
n\x91\xb6\xa8w\xad\x9a{\x91\xe4\x86\x1b\xb6\xdc+\xae\
k\xa4\xd9\xd9\xf5\x8a\x80\x92K\xe2@\xe8\x90\x9b\x84_\
\x027!\x01\x12\xc8\x0d\x18.\x9643+\xd9r\xef\
\xbda\x8a\x0d\xd8\x96+n\xb2$\x17\xf5\xae-S\xcf\
\xf3\xfbcvd\xd5\xd5\x96s\xbe\xa7}^\xffak\
\xcf\xf7Ac\xcd[\xa7+\xad5\x88\x88\x88\xc8\xdb\x0c\
\xa7\x17@DDDC\xc7\xa0\x13\x11\x11\xf9\x00\x83N\
DD\xe4\x03\x0c:\x11\x11\x91\x0f0\xe8DDD>\
\x10vz\x01DD$\xaf\xb5\xb5\xf5X\xad\xf5\x19J\
\xa9\x99\x00\x86k\xad\xb7\x01\xf8\xc80\x8c_/]\xba\
\xf4U\xa7\xd7G\x03\xa7x\xdb\x1a\x11Q0|\xf7\xbb\
\xdf5V\xadZ\x95\xd0Z\x7f\x13\xc0\xd1}\xfc\xd2\xf7\
\x01|\xf7\xa3\x8f>Z\xf6\xf4\xd3O\x17\x85\x96GC\
\xc4\xa0\x13\x11\x05@\x22\x91\x98f\x18F\x1a\xc0\xe9\x03\
\xf8\xb1\x95\xa6i6wtt\xbck\xd7\xba\xc8:\x0c\
:\x11\x91\xcf\xb5\xb4\xb4\x9c\xac\x94\xba\x07\xc0\xf8A\xfc\
\xf8\x0e\xa5\xd4\xb5\xa9T\xea)\xab\xd7E\xd6b\xd0\x89\
\x88|,\x91H\xcc5\x0c\xe3q\x00\x0dC\xd8L\x0e\
\xc0\xb5\xe9t\xfaA\x8b\x96E6\xe0U\xeeDD>\
eQ\xcc\x01 \x06\xe0\xf6\xb6\xb6\xb6\xf3-X\x16\xd9\
\x84A'\x22\xf2\xa1\xb6\xb6\xb6O\x19\x86\xf1\x14\x86\x1e\
\xf3\x8a*\xd34\xefc\xd4\xdd\x8bA'\x22\xf2\x99\xb6\
\xb6\xb6O\x99\xa6\xf9\x08\x80\xe1\x16o\x9aQw1\x06\
\x9d\x88\xc8Gl\x8cy\x05\xa3\xeeR\x0c:\x11\x91O\
\x08\xc4\xbc\x82Qw!^\xe5ND\xe4\x03\xc9d\xf2\
t\x00\x0f\xc3\xfe\x98\xef\xad[)u\x05ois\x07\
\xee\xa1\x13\x11y\x9cC1\x07\x80j\xad\xf5\xfd--\
-\xe7\x09\xcf\xa5\x83`\xd0\x89\x88<\xcc\xc1\x98WT\
+\xa5\xeec\xd4\x9d\xc7\xa0\x13\x11yTo\xcc%\xce\
\x99\x1f\x0e\xa3\xee\x02\x8e\x9fConnn\x8cF\xa3\
\x09\xc30.\xd4Z\x1f\x8d\xf2=\x93Y\x00\xefj\xad\
\x7fm\x9af\xc7\xb2e\xcb\xdert\x91DD.\xb3\
W\xcc\x879\xbd\x96\xbd\xf0\x9c\xba\x83\x1c\x0b\xfaM7\
\xdd\x14\xdb\xbe}\xfb\xb7\x00|\x0d@u\x1f\xbfT\x03\
\xb8\xd30\x8c/-]\xba\xf4c\x99\xd5\x11\x11\xb9\x97\
Kc^\xc1\xa8;\xc4\x91\xa0\xb7\xb7\xb7\x8f-\x95J\
\xf7j\xadO\x19\xc0\x8fm\xd2Z_\x93\xc9d~k\
\xdb\xc2\x88\x88\x5c\xae\xa5\xa5\xe5\x0c\xa5\xd4\xc3pg\xcc\
+\x18u\x07\x88\x07\xbd\xbd\xbd\xbd\xbeX,>\x07\xe0\
\xd8A\xfcx\x0f\x80\xcf\xa4\xd3\xe9\xc7-^\x16\x11\x91\
\xeb\xb5\xb5\xb5\x9di\x9a\xe6Cpw\xcc+\xba\x00\x5c\
\x9eN\xa7\x9fqz!A!~Q\x5c\xb1X\xfc\x19\
\x06\x17s\x00\xa8\x02po2\x99\xbc\xc0\xc2%\x11\x11\
\xb9^KK\xcb\x19\x1e\x8a9\x00\xd4\x00x\xb0\xb5\xb5\
u\x9e\xd3\x0b\x09\x0a\xd1=\xf4\xde\xbf]>g\xc1\xa6\
\xf8*?\x22\x0a\x8cd2y\x16\x80\x87\x00\xd4:\xbd\
\x96A\xe8RJ]\x96J\xa5\x9euz!~'\xba\
\x87n\x9a\xe6W,\xdaT\x0c\xc0\xed\xdcS'\x22\xbf\
\xf3x\xcc\x01\xa0Fk\xfd`kk\xeb\xa7\x9d^\x88\
\xdf\x89\xed\xa1777W\xc5b\xb1\xed(\xc7\xd8*\
<\xa7ND\xbe\xe5\x91\x0b\xe0\xfa\xab\xdb4\xcd\xcb;\
::\x9evz!~%\xb6\x87\x1e\x8dFO\x80\xb5\
1\x07xN\x9d\x88|\xcag1\x07\x80j\xc30\x1e\
H$\x12\xe7:\xbd\x10\xbf\x12\x0b\xbaRj\x82M\x9b\
\xae\x02p\x7f2\x99\xbc\xcc\xa6\xed\x13\x11\x89jkk\
;\xd3g1\xaf`\xd4m$\x16t\xadu\x95\x8d\x9b\
\xe79u\x22\xf2\x85D\x22qv\xef+PEb>\
,\xac\xf17\x93s\xa8\x0f\x8b] ]m\x18\xc6}\
\xbd\xd7\x06\x90\x85\xfc\xf4,w\xee\xa9\x13\x91\xa7\xb5\xb5\
\xb5\x9di\x18\xc6\x03(\xdf\xf2e\xbb\x9a\x90\xc6\xd7\xa6\
dq\xca\xf0\x22\xbe3-\x8b\x86\x88X\xd4k\x01<\
\xc2=uk\xf9)\xe8@yO\xfdNF\x9d\x88\xbc\
\xa6\xf7\xb6^\xb1\xc3\xec5!\x8doL\xcd\xa2\xa9\xca\
\x04\x00\x8c\x8d\x9a\xf8v\x93h\xd4y\xf8\xddb~\x0b\
:\xc0\xa8\x13\x91\xc7\xec\x15s\x91[\xd3\xf6\x8fy\xc5\
\xd8\xa8\x89oM\x95\x8fz2\x99<Gj\xa0\x9f\xf9\
1\xe8\x00\xa3ND\x1e!\x1d\xf3a!\x8d\xef4\x1d\
\x18\xf3\x8aq1\xf9\xa8\x03`\xd4-\xe0\xd7\xa0\x03\x8c\
:\x11\xb9\x5c2\x99<K:\xe6\xdfj\xcabR\xfc\
\xe01\xafp \xea5`\xd4\x87\xcc\xcfA\x07\x18u\
\x22r)\xe9'\xc0\xf57\xe6\x15\x8c\xba\xf7\xf8=\xe8\
\x00oi#\x22\x97q{\xcc+*Q\x17\xbc\xa5\x8d\
Q\x1f\x82 \x04\x1d\xe0-mD\xe4\x12^\x89y\xc5\
\xb8X\xf9\xeawF\xdd\xfd\x82\x12t\x80\x87\xdf\x89\xc8\
a^\x8by\x85SQ\xe7\x0b]\x06&HA\x07\x18\
u\x22r\x88Wc^\xe1D\xd4\xf9\x96\xb6\x81\x09Z\
\xd0\x01F\x9d\x88\x84%\x12\x89\xb3\xe1\xe1\x98W0\xea\
\xee\x16\xc4\xa0\x03\x8c:\x11\x09I$\x12g\x1b\x86\xf1\
 <\x1e\xf3\x8aq1\x13\xdfj\xeaa\xd4](\xa8\
A\x07\x18u\x22\xb2\x99t\xcc\x87\x87\xed\x8dy\xc5\xf8\
\x98v$\xea\xbdG:\xe8\x10\x82\x1ct\x80Q'\x22\
\x9b\xf4\xc6\x5c\xec0\xbbT\xcc+\x9c\x88\xbaa\x18\x0f\
1\xea\x87\x16\xf4\xa0\x03\x8c:\x11Yl\xaf\x98\x8b\xbc\
5\xad\x12\xf3\x891\x99\x98WT\xa2^\xc7\xa8\xbb\x02\
\x83^\xc6\xa8\x13\x91%\x82\x12\xf3\x8a\xf11\x8do\xcb\
G\xfd\xfe\x96\x96\x96\xd3\xa4\x06z\x05\x83\xfe\x09F\x9d\
\x88\x86$\x99L^`\x18\xc6#\x08H\xcc+\x1c\x88\
\xfap\xa5\xd4\xa3\x8c\xfa\xbe\x18\xf4}1\xeaD4(\
\xbd\x8f\x97\xbe\x17\xe5'S\xda\xce-1\xaf`\xd4\x9d\
\xc7\xa0\x1f\x88Q'\xa2\x01\x09z\xcc+\x18ug1\
\xe8\x07\xc7\xa8\x13Q\xbf8\x11\xf3o\xbb0\xe6\x15\xe5\
\xa8g\xa5\xa3\xfe\x08\xa3\xce\xa0\xf7\x85Q'\xa2>\xb5\
\xb4\xb4\x5c\x08\x07b>\xc1\xa51\xaf\x18\xdf\xfbD9\
\xc1\xa8\xd7)\xa5\x1eimm=Uj\xa0\x1b1\xe8\
}c\xd4\x89\xe8\xa0ZZZ.TJ\xdd\x03\xc6\xfc\
\xa0\x9c\x88\xba\xd6\xfa\xd1 G\x9dA?<F\x9d\x88\
\xf6!\x1d\xf3:\x8f\xc5\xbcb|\xcc\xc47\xa6f1\
\x8cQ\x17\xe1\xd9\xa0W\x8d\x9d\x89pM\x83\xd4\xb8\x18\
\x80\xdb{\xcf\x95\x11Q\x80\xf5\xc6\x5c\xec0{]\xef\
\x05p^\x8by\xc5\xa4\xb8\x89o1\xea\x22<\x1b\xf4\
H\xddhL\xbc\xea\xdb\x92Q\xaf\x02p?\xf7\xd4\x89\
\x82\xab\xad\xad\xed3\x00\x1e\x04\x10\x97\x98\xe7\xf5\x98W\
0\xea2<\x1bt\x00\x88\xd6\x8f\x95\x8e:\x0f\xbf\x13\
\x05\x90RJ\xb5\xb6\xb6\xfe\xc84\xcd\xbb\x95Ra\x89\
\x99\xf5\xe1\xf2-`^\x8fy\xc5\xa4\xb8\x89oN\xcd\
\xa26$\x1a\xf5GZZZN\x96\x1a\xe84O\x07\
\x1d`\xd4\x89\xc8^\xcd\xcd\xcd\xd1D\x22q\x9f\xd6\xfa\
\xcb\x00\x94\xc4\xcc\xba\xb0\xc67\x9b\xb2\x18\x1f\x13\x8b\x9f\
\x88\xc9q\x13\xdfj\x12\xddS\xafWJ=\x9eH$\
N\x91\x1a\xe8$\xcf\x07\x1d`\xd4\x89\xc8\x1e7\xddt\
S,\x1e\x8f\xdf\xa7\x94\xba\x5cjf}X\xe3;>\
8\xcc~(\x93\xe3&\xbe1EvO\xdd0\x8cG\
[[[O\x92\x1a\xe8\x14_\x04\x1d`\xd4\x89\xc8Z\
7\xddtSl\xfb\xf6\xedwj\xad/\x92\x9aY\xdf\
{5\xfb8\x9f\xc6\xbcbJ\x95\xf8\xe1\xf7z\xad\xf5\
\xe3~\x8f\xbao\x82\x0e0\xeaDd\x8dJ\xcc\x01\x88\
\xfd\xd9n\x88\x04#\xe6\x15\x0eE\xfd\xb1D\x221W\
j\xa04_\x05\x1d`\xd4\x89hh\x9a\x9b\x9b\xab\xb6\
m\xdb\xf6\x00\x84c\xfe\xad\xa9\xc1\x89y\xc5\x94*\x13\
\xdfl\x12\x8dz\x83a\x18\x8f\xfb5\xea\xbe\x0b:\xc0\
\xa8\x13\xd1\xe0477WE\xa3\xd1\xfb\x94R\xe7K\
\xcd\x0c\xda\x9e\xf9\xfe\xa6\xc4{\xa3.r\xef\x00\x00\x1f\
G\xdd\x97A\x07\x18u\x22\x1a\x18'c>6\x1a\xcc\
\x98WL\x89\x9b\xf8\xe6\xd4\x1eF}\x88|\x1bt\x80\
Q'\xa2\xfeq\x22\xe6a\xa5\xf1\xcd\xa9=\x81\x8fy\
\xc5\x94\xb8\x89oL\x91\x8fz2\x99\x9c#6\xd1f\
\xbe\x0e:\xc0\xa8\x13Q\xdf\x9c\x889\x00\x14\xb5\xc2\x83\
[\xa2\xf0\xd7\x9d\xe6C3\xb5J>\xea\x00\x9e\xf0K\
\xd4}\x1ft\x80Q'\xa2\x83[\xb4hQ\xb5\x131\
\xaf\xf8\xf5\xf60~\xf5q\x8cQ\xdfK%\xea5\x82\
\x17\xca)\xa5|\xb1\xa7\x1e\x88\xa0\x03\x8c:\x11\xedk\
\xd1\xa2E\xd5\xdd\xdd\xdd\x8e\xc5\xbc\xe2YF\xfd\x00S\
{oi\x93\x8a\xba\xd6\xba\xd1\x0fQ\x0fL\xd0\x01F\
\x9d\x88\xca*1\x07p\x9e\xd3k\x01\x18\xf5\x83\x99Z\
U~\xf5\xaat\xd4\xdb\xda\xdaf\x8b\x0c\xb4A\xa0\x82\
\x0e0\xeaDA\xe7\xb6\x98W\x94\xa3\xces\xea{k\
r \xeaZ\xeb'\xbc\x1a\xf5\xc0\x05\x1d`\xd4\x89\x82\
\xca\xad1\xafxv{\x84Q\xdf\x8f\x13Q7M\xd3\
\x93{\xea\x81\x0c:\xc0\xa8\x13\x05\xcd\xa2E\x8b\xaa{\
zz\x1e\x80Kc^\xf1\xec\xf6\x08n\xe1\xe1\xf7}\
HG\x1d\xc0\x08\xd34\x1fO$\x12'J\x0d\xb4B\
`\x83\x0e0\xeaDAQ\x89\xb9\xd6\xfa\x5c\xa7\xd7\xd2\
\x1f\xcfl\x0f3\xea\xfb\xa9D\xbdZ0\xea\x86a<\
\xe1\xa5\xa8\x07:\xe8\x00\xa3N\xe4w\xbd\x87\xd9\xef\xf7\
J\xcc+\x9e\xe1\x85r\x07h\xaa2\xf1m\xd9\xc7\xc4\
\x8e0\x0c\xe3i\xaf\xbc\xa5-\xf0A\x07\x18u\x22\xbf\
jmm\xad\xe9\xee\xee~\x10\xc0<\xa7\xd72\x18\xbc\
\xfa\xfd@\x0e<&\xd63\xaf^e\xd0{1\xeaD\
\xfe\xb2h\xd1\xa2j\xad\xf5}\x00\xceqz-C\xc1\
\xa8\x1f\xc8\xa1\xa8?\xe6\xf6\xa83\xe8{a\xd4\x89\xfc\
\xa1r\x98\x1d\x1e\xdd3\xdf\x1foi;\x90\x13/t\
q\xfb\xfb\xd4\x19\xf4\xfd0\xeaD\xde\xb6\xd7\xd5\xec\xbe\
\x88y\x05oi;\x90S/tqk\xd4\x19\xf4\x83\
`\xd4\x89\xbc\xa9\xf7\x9c\xf9C\x92\x17\xc05\xd4\xc9\xd5\
\x84Q?\x90\x13/tqk\xd4\x19\xf4C`\xd4\x89\
\xbce\xd1\xa2E\xd5\x00\xee\x07\xf0i\xa9\x99\x97\x9f\xdf\
\x80\xff\xfc\xee\x14L\x9f\x1a\x97\x1a\xc9\xa8\x1f\x04\xa3^\
\xc6\xa0\xf7\x81Q'\xf2\x86\xdes\xe6\x8fH\xee\x99_\
~~\x03n\xb8r\x04\x0cC\xe1\x1f\xbe4A<\xea\
\xbcO}_\x8c:\x83~X\x8c:\x91\xbb\xf5\x1ef\
\x7f\x05\xc0YR3\xaf\xbe\xa4\x117\x5c9b\xcf\xff\
\xaeD\xbdirLj\x09|\xf8\xccA8\x14\xf5\x87\
\xdb\xda\xda\x8e\x17\x9b\xd8\x07\x06\xbd\x1f\x18u\x22wj\
nn\xae\xd2Z\xbf\x09`\x86\xd4\xcc\xab/i\xc45\
\x974\x1e\xf0\xcf\x0dC\xe1\x9f\xfen\x22\xa3\xee0\x07\
\xde\xa7>\xca4\xcd'ZZZ\x8e\x93\x1ax(\x0c\
z?1\xeaD\xee\xd2\xdc\xdc\x5c\x15\x8b\xc5V\x02\x98\
,5\xf3P1\xaf`\xd4\xddA\xfa\xd5\xab\x00F)\
\xa5\x9et:\xea\x0c\xfa\x000\xeaD\xee\xb0h\xd1\xa2\
\xeaX,\xf60\x80YR3\xaf9L\xcc+\x18u\
wp\xe0\x85.\x8eG\x9dA\x1f F\x9d\xc8Y{\
\xbd\x02U\xecj\xf6k.i\xc4\xd5\xfd\x88y\xc5\x9e\
\xa8O\x92\x8d\xfa\xe2u\x8c\xfa\xde\x82\x16u\x06}\x10\
\x18u\x22g\xec\xf5\x048\xb1W\xa0\x0e4\xe6\x15\x86\
\xa1\xf0O_\x91\x8d\xfa\xd3\xdbz\xa3\xce\xaa\xef\x11\xa4\
\xa83\xe8\x83\xc4\xa8\x13\xc9r\xe2q\xae\x83\x8dy\x85\
cQ_\xcf\xa8\xef-(Qg\xd0\x87\x80Q'\x92\
\xe1\xc4\xe3\x5c\xaf\xbdth1\xaf\xd8\x13u\xc1s\xea\
\x8c\xfa\x81\x9a\xaaL|uj\x0eU\x86\x7f\xa3\xce\xa0\
\x0f\x11\xa3Nd\xaf\xd6\xd6\xd6\x9a\x9e\x9e\x9e\x07$\x1f\
\x1as\xda\x9cZ\x5cu\xf1\xd0c^Q9\xa7>\x95\
{\xea\x8e\x9aQU\xc2\xd7\x9b\xfc\x1bu\x06\xdd\x02\x8c\
:\x91=>\xf7\xb9\xcf\x0d\xd3Z\x8b>\x01\x0e\x00\xfe\
\xf8J\x17\xfe\xf4J\x97\xa5\xdb4\x0c\x85\xef~\x85Q\
w\x9aSQomm=\xd6\xeeA\x0c\xbaE\x18u\
\x22k\xb5\xb6\xb6\xd6\xe4\xf3\xf9\xfb\x01\x9c)=\xbbT\
\xd2\xf8\xef%\x1b\xfc\x13\xf5uQF}/ND]\
km{\xd4\x19t\x0b1\xeaD\xd6hmm\xad\xd1\
Z?\x08\xc1[\xd3\xf6\xf7I\xd4;-\xdd\xee\x9e\xa8\
O\x14\x8c\xfa\xf6\x08\xa3\xbe\x1f\x07\xa2>\xda\xee\xa83\
\xe8\x16c\xd4\x89\x86\xa6\xb9\xb9\xb9Nk\xfd\x04\x1c\x8c\
yE9\xea\x1b\xed\x89\xfaW\x19u\xa7\xcd\xa8*\xe1\
k\xb2\x17\xca\xd9\x1au\x06\xdd\x06\x8c:\xd1\xe047\
7\xd7\xc5b\xb1G\x00\x9c\xe6\xf4Z*\xec\x8ez\xd3\
$\xb9\xb7\xb41\xea\x07\x9aY]\x8ez\xdc\x07Qg\
\xd0m\xc2\xa8\x13\x0dLo\xcc\x1f\x85\x8bb^Q\x89\
\xfa\x8b\xafZ\x7fN\xfd\x1f\xffn\x02&\x8d\x8fZ\xba\
\xdd\xbe<\xbd=\x82\xcc\x06F}o\xe5\xa8g\xa5\xa3\
\xfe\xc4\x82\x05\x0b\x8e\xb4r\xa3\x0c\xba\x8d\x18u\xa2\xfe\
ioo\xaf\x8f\xc5b\x8f\x038\xd5\xe9\xb5\x1cJ\xe5\
\x9c\xba\xd5Q\x0f\x85\x14\xfe\xf9k\x930i\xbc\xdc\xe1\
\xf7\xc7\xb6F\xd0\xc1\xa8\xefcV\xb5)\xbd\xa7>\xc6\
0\x8c\x87\xdb\xdb\xdb\xc7Z\xb5A\x06\xddf\x8c:Q\
\xdf\x12\x89DC\xb1X|\x1c\xc0\xc9N\xaf\xe5p\x8a\
\xc5J\xd4\xad=\xfc^\x8e\xfaD\xd1\xa8?\xca\xa8\x1f\
`\xd6\x9e\xc3\xef2\xf3\x94RS\x0b\x85\xc2\x12\xab\xb6\
\xc7\xa0\x0b`\xd4\x89\x0e\xae\xbd\xbd\xbd>\x14\x0a=\x02\
\xe0$\xa7\xd7\xd2_\xc5\xa2\xc6O\x17[\x7f\xf8=\x14\
R\xf8\x97\xaf\xcb^(\xc7\xa8\x1fhVu\x09_\x17\
<\xfc\xae\x94\xba\xc8\xaa\xefj\x06]\x08\xa3N\xb4\xaf\
\xe6\xe6\xe6\xc6b\xb1\xf8\xa4\xd6\xfa\x14\xa7\xd72P\xa5\
\x92\xc6O\x17[\x7f\xf8\xbd\xf2\x98X\xc9s\xea\x8fn\
\x8d`\xd9F\xb9\xbfDx\xc1\xcc\xea\x12\xbe:Et\
O\xfd\x1f\xac\xd8\x0e\x83.\x88Q'*K$\x12\x0d\
\xbd\x17\xc0\xcdqz-\x83eW\xd4?9\xa7.\x17\
\xf5G\xb6\x84\xd1\xb1^n\x9e\x17\x1cQS\xc2W\xa7\
dE\xa2\xae\xb5>%\x99L\x1e1\xd4\xed0\xe8\xc2\
\x18u\x0a\xbaD\x22\xd1`\x18\xc6c\xf0\xd0a\xf6C\
\xb1\xfbB\xb9\x89\xe3\x04\xa3\xbe5\xc2\xa8\xefG8\xea\
g\x0cu\x1b\x0c\xba\x03\x18u\x0a\xaaD\x22\xd1\x10\x0a\
\x85\x1e\x87\x0fb^a\xe7\x85r\xff\xf2uF\xddi\
G\xd4\x94\xf0\x95)=\x12Qo\x1a\xea\x06\x18t\x87\
0\xea\x144\x0b\x17.\x1ce\x18\xc63Z\xeb\xb9R\
3UT&N\xe5\xa8o\xf4M\xd4\x97m`\xd4\xf7\
vd\x8d\x89\x85\x13r\xb6\xcePJ\x8d\x1a\xea6\x18\
t\x071\xea\x14\x14\x0b\x17.\x1cU(\x14\x9e\x04p\
\xbc\xd4\xcc\xc8\xb9g\xa3\xea\x8b_\x80\xaa\xae\x16\x99g\
{\xd4\x05\xcf\xa9?\xbc\x85Q\xdf\xdb\xd6\x82\xc2\x1d\x1b\
#\xb6\xcePJ\xf5\x0cu\x1b\x0c\xba\xc3\x18u\xf2\xbb\
\xd6\xd6\xd6\xd1\xbd1\x17y'4P\x8ey\xf4\xec3\
\xa0\x86\x0fC\xfc\x0b\xedP5>\x88\xfa\xd7&a\xa2\
\xe0}\xea\x0fo\xe1\xe1w\xa0\x1c\xf3\xef\xaf\x8ecS\
\xde\xf6\x5c\xae\x1e\xea\x06\x18t\x17`\xd4\xc9\xafZ[\
[Gk\xadEc\x1e\x9d\xf7iD\xcf\xfe\xe4\xfa\x22\
\xa3n8\xe2\x9fo\x17\xdfS\x7f\xe95\x1b\xeeS\xff\
\xdaD\xd1\xa8\x07\xfd\x9c\xba`\xccQ*\x95~;\xd4\
m0\xe8.\xc1\xa8\x93\xdf\xec\x15s[\xdf\x01\xbd\xb7\
\xe8y\xe7 r\xd6\xe9\x07\xfcs\xa3n8\xe2_h\
\x07\x04\xa3\xfe\xd3\xc5\x1b\xec\x8b\xba\xf09\xf5\xe5\x01<\
\xfc^\x8ey\x95H\xcc\xb5\xd6kf\xcd\x9a\xf5\xf2P\
\xb7\xc3\xa0\xbb\x08\xa3N~\xb1`\xc1\x821\xa6i>\
\x05\xe9\x98\x9f\xf9\xa9C\xfe{\xa3n8\xaa|\x12u\
\xe9[\xda\x1e\xda\x12\xac\xa8\x7f\x12s%2\xcf0\x8c\
\x1f\xff\xe3?\xfe\xa39\xe4\xedX\xb1\x18\xb2\x0e\xa3N\
^\xb7`\xc1\x821\x86a<\xa9\x94:Fd\xa0R\
\x88^|~\x9f1\xaf\xa8D]\xf2\xf0\xbb\x1dQ\x0f\
\x87\xcbQ\x9f0\xd6\xde\x0b\xb5\xf6\xf6\xd0\x96\x08n\x0d\
@\xd4\xb7\xe4\x15\xbe\xb7:.\x16s\xa5\xd4[\xa1P\
\xe8\x17Vl\x8bAw!F\x9d\xbcj\xc1\x82\x05c\
B\xa1\xd0S\x921\x8f]|>\x22\xa7\xf6\xff\xbd.\
\x95\xc3\xef~\x88\xfa\xbf|}\xb2h\xd4\x1f\xf4y\xd4\
\xb7\xe4\x15\xbe\xbf&\x8e\xcd\x02\x87\xd9{u\x95J\xa5\
\xf9\x8b\x17/\xceZ\xb11\x06\xdd\xa5\x18u\xf2\x9a\xf6\
\xf6\xf6\xb1\xa1P\xe8)\x00G\x8b\x0c\xec\x8dy\xf8\x94\
\x81?\xa3\xc6/\xe7\xd4?\x89\xba\x5cd\xcbQ\x97\xfb\
K\x84\x14\x07b^\xd4Z';::VZ\xb5A\
\x06\xdd\xc5\x18u\xf2\x8a\xf6\xf6\xf6\xb1\xc5bQ4\xe6\
\xd1\x8b\x06\x17\xf3\x0a?\x1d~\xff\xde7&a\x82\xe0\
9\xf5\x07\xb7D}u\x9f\xfa\xd6\x82\xc2\xffYS%\
\x19\xf3\x92\xd6\xba-\x93\xc9\xdcm\xe5F\x19t\x97c\
\xd4\xc9\xedZZZ&\x16\x8b\xc5\xe7\x00\x1c%2P\
)D/\xbe\x00\x91S\x87\xfe\xf4X\xa7\xa2\xfe\xf2\xeb\
v\x5c\xfd.\x1b\xf5\x87\xb7D\xb0|\x83\xf7\xdf\xd2&\
}\x01\x1c\x80\x12\x80d&\x93Yf\xf5\x86\x19t\x0f\
`\xd4\xc9\xad\xe6\xcf\x9f?I)\xf54\x80\x19\x22\x03\
\x95B\xec\x92\x0b\x119\xc5\xba\xa7\xc7*\x07\xa2\xfe\x93\
[\xac\x8fz8\xdc\x1bu\xc1\xc3\xef\x0fm\x09{:\
\xeaN\xc5<\x9dN/\xb7c\xe3\x0c\xbaG0\xea\xe4\
6\xf3\xe7\xcf\x9f\x14\x0e\x87Ec\x1e\xbd\xe4\x02\x84O\
\xb6\xfe\x8d\xab\x9fD\xbd\xca\xf2m\x1f\x8c\xadQ\xff:\
\xa3\xde\x1f~\x8b9\xc0\xa0{\x0a\xa3Nn\xb1W\xcc\
\xa7\x8b\x0c\xec\x8dy\xe4d\xfb\xde\xebR\x8e\xfaBF\
}\x10\xbc\x16\xf5\xad\x05\xd9[\xd3 \x10s\x80A\xf7\
\x1cF\x9d\x9c\xd6\xd6\xd66Y:\xe6\xb1K/\xb45\
\xe6{F\xf9,\xea\xe3E\xefS\x0f{\xe2\xe13\x95\
\x98K^\x00\xa7\x94j\xb1;\xe6\x00\x83\xeeI\x8c:\
9\xa5\xad\xadm\xb2i\x9a\xb21\xbf\xec\x22\x84O\xb2\
\xfe0\xfb!GV\xa2^\xe5\xfd\xa8\x7fO\xf8\x966\
\xb7?Q\xce\x81\x98\x17\x94R\xcd\xa9T\xeaV\x89a\
\x0c\xbaG1\xea$-\x91HL1M\xf3\x19\x00\xd3\
D\x06*\x85\xd8g.Cx\xeel\x91q\xfb\x8c\xae\
\x1b\x8e\xaaE\xfe\x88\xba\xfc\xe1wwF\xbd\xf2\x048\
\xc9\x98k\xadoH\xa5RwI\x0dd\xd0=\x8cQ\
')\x89Db\x8aa\x18O\x03h\x12\x19\xa8\x14b\
W^\x86\xf0\x09b/i;p\x09{\xa2\x1e\x17\x99\
gw\xd4\xc7\x8d\x0en\xd4\x1dxhLAk}\x83\
\xd5\xf7\x99\x1f\x0e\x83\xeeq\x8c:\xd9M<\xe6\x86Q\
\x8e\xf9\x89\xce\xc5\xbc\xa2\x1c\xf5\xcf\xf9\x22\xea\xdf\xff\xa6\
|\xd4\xdd\xf0\x98\xd8\xa0\xc4\x1c`\xd0}\x81Q'\xbb\
\xb4\xb7\xb7OUJ=\x03\xd1\x98_\xea\x8a\x98W0\
\xea\x83\xe7\xf4\xb3\xdf\x83\x14s\x80A\xf7\x0dF\x9d\xac\
\x96H$f\x16\x8b\xc5\xe7\x94RSE\x06\x1aF\xf9\
\x9c\xb9\x83\x87\xd9\x0f\xc5\xa9\xa8\xaf|\x83Q\x1f,'\
b\x0e\xa0\xd9\xa9\x98\x03\x0c\xba\xaf0\xead\x95D\x22\
1\xb3\xf70\xfbD\x91\x81\x95\x98\x1f/\xf6\xfa\xf4\x01\
Su\xc3\x11\xff\x82\xec9\xf5\xff\xfa\x95}Q\x1f;\
\xda\xbfois\xe2\x028\x00\xcd\xe9t\xfa\x1e\xa9\x81\
\x07\xc3\xa0\xfb\x0c\xa3NC\xd5\xd6\xd66\xab7\xe6\x13\
D\x06z \xe6\x15F}]9\xeaq\xefG\xfd\xff\
|s\xb2/\xa3^\x89\xf9\x96B\xb0b\x0e0\xe8\xbe\
\xc4\xa8\xd3`\xb5\xb5\xb5\xcd\xea\xbd\xcf\x5c.\xe6W]\
\xee\x89\x98W\x18\xf5u\x88/b\xd4\x07\xc3\xeeW\xaf\
:\x10\xf3<\x5c\x12s\x80A\xf7-F\x9d\x06*\x99\
L\x1e\xd1\x1b\xf3\xf1\x22\x03+1?\xee\x18\x91qV\
\xaaD\x1d1\x99\xc7\x9d\xfa+\xeaQ[\xa2\xbe\xa5`\
8\x11\xf3\x1b\xdc\x12s\x80A\xf75F\x9d\xfa+\x99\
L\x1e\x01\xe0)H\xc6\xfc\xea+<\x19\xf3\x0a\xa3\xbe\
\x0eU\x7f\xf99\xd1\xa8\xff\xf4\x96\x8dx\xe3\x9d\x1eK\
\xb7\xfbI\xd4e\xdf\xa7ne\xd4\xb7\x14\x0c|\xef\xfd\
X\xa0c\x0e0\xe8\xbe\xc7\xa8\xd3\xe1\xf4\xc6\x5ct\xcf\
<~\xfd\xd5\x08\x1f{\xb4\xc88;IG=_0\
\xf1\xa3\x9b\xd7\xdb\x14\xf5I\x9e\x8c\xba\x1317M\xd3\
5\x87\xd9\xf7\xc6\xa0\x07\x00\xa3N\x87\xb2`\xc1\x82#\
Q\x8e\xf98\x91\x81\x86\x81\xd8uW!t\xe4,\x91\
q\x12\x18\xf5\xc1{pK\x14\xb7\x0d\xe1B9\xa7b\
\xde\xd1\xd1q\xaf\xd4\xc0\x81`\xd0\x03\x82Q\xa7\xfd-\
X\xb0\xe0\xc8P(\xf4\x14\xa4b\x1e\x0a\x95\xf7\xcc\x8f\
:Bd\x9c$F}\xf0\x1e\xd8\x12\x19T\xd47\xe4\
\x14\xfe\xf9}\xd9s\xe6n\x8e9\xc0\xa0\x07\x0a\xa3N\
\x15\xad\xad\xadG\x85B!\xb9=\xf3P\x08q\x9f\xed\
\x99\xef\xcf\xa8\xafC\xf5_\xf9)\xear\x17\xca\x0d4\
\xea\x1br\x0a\xdf_]\x85m\x05\xb1\xf7\x99\xbb>\xe6\
\x00\x83\x1e8\x8c:\xb5\xb5\xb5\x1d\xaf\xb5~\x16\xc0X\
\x91\x81\xa1\x90\xef\x0e\xb3\x1f\x8a\xaas(\xeaow[\
\xba]'\xae~\x7f`K\x04wo:|\xd4+1\
\xdf^\x94\x8b9\x80\xeb\xdd\x1es\x80A\x0f$F=\
\xb8\x92\xc9\xe4\x09\xa6i>\x09`\x94\xc8\xc0P\x08\xb1\
\xeb\xafF8\x001\xafPuu\xa8\xfaB;TL\
\xe6\xb0u\xbe`\xe2G\xbf\xf0G\xd4\xef\xda\xd4w\xd4\
\x9d\x8ay:\x9d\xbeOj\xe0P0\xe8\x01\xc5\xa8\x07\
O\x22\x918\x11\xc0\x13\x00F\x8a\x0c\xac\xc4\xfc\x88\x99\
\x22\xe3\xdc\xc4hl@\xfc\x0b\x0b\x81\xa8T\xd4\xb5\xad\
Q\x1f3\xca\xf9\xa83\xe6\x87\xc7\xa0\x07\x18\xa3\x1e\x1c\
\x89D\xe2D\xc30Dc\x1eo\xbe&\x901\xaf0\
\x1a\x1bP\xf5\xf9\x1b\x81\x88L\x0c\xed\x8c\xfa\xbf~\xcb\
\xd9\xa83\xe6\xfd\xc3\xa0\x07\x1c\xa3\xee\x7f{\xc5|\x84\
\xc8\xc0\xde\x98\x87f\xcd\x10\x19\xe7f\xc6\xc8\x11\xa8\xfa\
B;\x10\x95\x8d\xfa\x9b6\x5c(\xe7L\xd4#\x8c\xf9\
\x000\xe8\xc4\xa8\xfbX[[\xdbl\xe9\x98\xc7\x18\xf3\
}\x18#G\xa0\xea\xf3\xed\xa2{\xea?\xbcy\x9d-\
Q\xff\xfe7'a\xd4\x08\xc9\xa8G\xf1\x0f\xabDc\
\x9eSJ]\xed\xc5\x98\x03\x0c:\xf5b\xd4\xfd\xa7\xad\
\xadm\xb6\xd6Z,\xe6*\x12A|\xc1\xf5\x083\xe6\
\x07\xd8\xb3\xa7\xee\xf1\xa8G#\x06~\xf0\x1d\xd9=\xf5\
\x1eSn\xcf\x5c)u}*\x95zHj\xa0\xd5\x18\
t\xda\x83Q\xf7\x8fd29Gk\xfd\x84\xd6\xbaQ\
b\x9e\x8aD\x10\x9f\x7f\x1dB\xd3\x9a$\xc6y\x92_\
\xa2\xbegO\xbd1l\xe9v\x1d\x96WJ]\x97J\
\xa5\xeewz!C\xc1\xa0\xd3>\x18u\xefK$\x12\
s\x95R\x8fK\xc5\x1c\x910\xe2\xf3\xaf\x83\xd14U\
d\x9c\x97\xf9%\xea\xd1\x88\x81\x7f\xfd\xced\xd1\xc3\xef\
6\xcaj\xad\xaf\xf2z\xcc\x01\x06\x9d\x0e\x82Q\xf7\xae\
D\x221\xd70\x0c\xd9\x98\x7f\xf6z\xc6|\x00|\x15\
\xf5o\xcb\x9eS\xb7AVk}M&\x93y\xd8\xe9\
\x85X\x81A\xa7\x83b\xd4\xbd\xa7\x12s\x002\x1fZ\
$\x8c\xf8\xfcf\x84\xa6M\x15\x19\xe7'\x95\xa8+\xc1\
\xab\xdf\xcbQ\xb7\xf6\x96\xb6J\xd4Gz\xf3\xf0{^\
)\xd5\xec\x97\x98\x03\x0c:\xf5\x81Q\xf7\x8ed2y\
\xbaa\x18OA:\xe6MSD\xc6\xf9\x911r\x04\
\xe2\x9fo\x87\x12\xbdO}\x03\xdez\xcf\xfa=\xf5\x7f\
\xfb\xce\x14\x8ch\xf0T\xd4\xb3\x00>\xe3\x87\xc3\xec{\
c\xd0\xa9O\x8c\xba\xfb%\x93\xc9\xd3\x01<\x0c`\xb8\
\xc8@\xc6\xdc2\xc6\xc8\x11\x88\x7fA.\xea\xb9\xbc\x89\
\xff\xf8\xf9z\x1b\xa2\xae\xf0\x83\xbf\x9f\x8c\x91\x8d\x9e8\
\xfc\x9e\xd3Z_\x9fN\xa7\x1fqz!Vc\xd0\xe9\
\xb0\x18u\xf7jii9\x03\xc0#\x10\x8by\x841\
\xb7\x981r\x04\xaa\x16\xc9F\xfd\xdf\x7ff\xcf\xe1\xf7\
\x7f\xfb\x8e\xeb\xa3\x9e\xd3Z_\x97\xc9d\x1epz!\
v`\xd0\xa9_\x18u\xf7iii9C)\xf50\
\x80a\x22\x03#\x11\xc4\x170\xe6vP#d\xa3^\
>\xa7\xbe\xde\x86\xa8+7G\xdd\xd71\x07\x18t\x1a\
\x00F\xdd=\xda\xda\xda\xce\x94\x8eyU\xa2\x19\xa1\xa9\
\x93E\xc6\x05\x91\x1a1\x02\xf1\xbfh\x03\xc22\xe7\xa2\
\xf3\x05\x8d\x1f\xffr\x03\xde^e\xfd\xe1\xf7\x7f\xfb\xce\
d\xb7\x9dS\xcf\x01\xb8\xd6\xcf1\x07\x18t\x1a F\
\xddymmmg\x9a\xa6\xf9\x10$\xf7\xcc\x13\xcd0\
\xa60\xe6v3F\x8f*\xbf\xd0E(\xea\xd9\x5c\xf9\
\x9c\xba\x1dQ\xff\xc1\xdfOAc\xbd+\xa2\x9e\x03p\
m:\x9d~\xd0\xe9\x85\xd8\x8dA\xa7\x01c\xd4\x9d\x93\
L&\xcf2MSl\xcf\x5c\xc5\xe3\x88\xb7\xceG\x88\
1\x17\xe3T\xd4\xdfy?k\xe9v\xa3\x11\x85\x7f\xff\
\xdf\x8eG=01\x07\x18t\x1a$F]^2\x99\
<\x0b\xc0C\x00j%\xe6\xa9x\x1c\xb1D3B\x13\
'H\x8c\xa3\xbd8\x11\xf5\x7f\xff\xd9:[\xa2\xfe\x83\
\xbf\x9f\xecT\xd4{\x00\x5c\x11\x94\x98\x03\x0c:\x0d\x01\
\xa3.'\x91H\x9c\x0d\xe1\x98\xc7[n`\xcc\x1dT\
\x89\xba\xf2x\xd4cQ\x03\x7f1\x7f\xb4\xa5\xdb\xec\x87\
\x1e\xc30\xaeL\xa7\xd3\x8fK\x0fv\x12\x83NC\xc2\
\xa8\xdb\xaf\xb5\xb5\xf5\xd3\x86a\x88\xc7\xdc\x980^b\
\x1c\xf5\xc1\x18=\x0aqG\xa2n\xdd9\xf5?\xbf\xdb\
\x83\xff\xfa\xd5\x06\xcb\xb6\xd7\x0f=\x86a\x5c\xb9t\xe9\
\xd2'$\x87\xba\x01\x83NC\xc6\xa8\xdb\xa7\xa5\xa5\xe5\
B\xad\xf5\xc3\x00jD\x06\xc6c\x881\xe6\xaeb\x8c\
\x1e\x85\xf8_\xb4\x09G}\xbd%Q\xff\xf3\xbb=\xf8\
\xe1\xcd\xeb\x91\xcb\x9b\x16\xac\xac_\x02\x1bs\x80A'\
\x8b0\xea\xd6kii\xb9P)u\x0f\x80*\x91\x81\
\xf1\x18\xaaZ\xe6#\xc4\x98\xbb\x8e1f\xb4\xe7\xa2\xfe\
\xe6;\xdd\xf8\x8f\x9f\xafc\xcc\x051\xe8d\x19F\xdd\
:\xad\xad\xad\x17)\xa5\xee\x85p\xcc\x8d\x09\xe3D\xc6\
\xd1\xc09\x15\xf5wW\x0f\xfc\x9c\xfa\x9b\xeft\xe3\x87\
7\xafG\xbe\xa0mX\xd9A\x05>\xe6\x00\x83N\x16\
c\xd4\x87.\x99L^\xac\xb5\xbe\x07@\x5cb\x9e\xaa\
\x8a\xa3*\xb9\x801\xf7\x00'\xa2\xfe\x83\xffY7\xa0\
\xa8;\x10\xf3<c^\xc6\xa0\x93\xe5\x18\xf5\xc1K&\
\x93\x17\x03\xb8\x1b\x821\x8f\xb7\xcc\x871~\xac\xc48\
\xb2\x801f4\xaa\xfe\xa2\x0d\x08\x85D\xe6U.\x94\
\xebO\xd4\xdf|\xa7G:\xe6%\x00\x973\xe6e\x0c\
:\xd9\x82Q\x1f\xb8\x96\x96\x96K \x1c\xf3X\xcbg\
\x19s\x0fRcF\x8b\xde\xa7\xde\x935\xf1o\xffw\
]\x9foi{\xeb\xbd\x1e\xfc\xf8\x97\xb217M\xf3\
\xe2\xa0\xdd\x9a\xd6\x17\x06\x9dl\xc3\xa8\xf7_KK\xcb\
%J\xa9\xbb \x14sTW#\xde\xd6\x82\xd0x\x1e\
f\xf7\xaa={\xeaBQ\xef\xeb\xd5\xabo\xbdW\xde\
3\xcf\xe6\xc4.\x80\xeb\xd6Z\x9f\xd9\xd1\xd1\xc1=\xf3\
\xbd0\xe8d+F\xfd\xf0Z[[/UJ\x89\xed\
\x99\xa3\xba\x1aU\xad\xf3a\x8c\x19%2\x8e\xec\xe3\x86\
\xa8;\x10\xf3\xadZ\xeb\xd32\x99\xcc\xf3R\x03\xbd\x82\
A'\xdb1\xea\x87\x96L&/\xd3Z\xdf\x85\xf2\x9a\
m\xa7j*1\x17\x7fr\x17\xd9D\xfa\x9c\xfa\xdeQ\
w \xe6\x9b\xb5\xd6\xe7f2\x99\xd7\xa4\x06z\x09\x83\
N\x22\x18\xf5\x03\xf5\xae\xedN\x08\xc6<\xde\xba\x801\
\xf7!'\xa2\xfe\xa3_\xac\xc7\xbf\xffL4\xe6\x9b\x94\
R\xf3\x18\xf3Cc\xd0I\x0c\xa3\xfe\x89\xd6\xd6\xd6k\
P\xbe\x00N6\xe6\xa3y\x98\xdd\xaf\x8c\xb1c\xca\x17\
\xca\x09E\xbd'k\x22_\x10\xdd3??\x95J\xbd\
.5\xd0\x8b\x18t\x12\xc5\xa8\x03\xc9d\xf2Z\xad\xf5\
\xad\x00\x22\x12\xf3Tm\x0d\xaa\xda\x12\x8cy\x00\x18\x95\
\xab\xdf\x85\xa2.d\x93\xd6\xfa<\xee\x99\x1f\x1e\x83N\
\xe2\x82\x1c\xf5\x96\x96\x96\xeb\x00,\x87d\xcc[\x17@\
\x8d\x1a)1\x8e\x5c\xc0\x183\x1a\xf1\xf6\x16\xc0\xf0\xc5\
\xd7\xfb\xa6P(\xc4\xc3\xec\xfd\xe4\x8bO\x9c\xbc'\x88\
Qoii\xb9N)%\x1a\xf38c\x1eH\xa1\x09\
\xe3\x11_\x98\xf4z\xd47\x86B\xa1yK\x96,y\
\xc3\xe9\x85x\x85\xa7?m\xf2\xb6 E\xbd\xb5\xb5\xf5\
\xfa\xde\x98\x8b\xdc_T\x89\xb9\xc1\x98\x07Vh\xc2x\
/\x1f~\xdf\xa4\x94:\x9f1\x1f\x18\x06\x9d\x1c\x15\x84\
\xa8'\x93\xc9\xf9Zk\xb9\x98\x0f\x1b\x86\xf8\x8d-\x8c\
9\x95/\x94kOz-\xea\x1b\xb5\xd6\xe7\xf2\x02\xb8\
\x81c\xd0\xc9q~\x8ez2\x99L\x00H\x03\x10\xf9\
FU\xc3\x87!~c\x02\xc6\x88F\x89q\xe4\x01\xc6\
\x84q\xa8jo\xf1J\xd47)\xa5\xce\xcfd2o\
:\xbd\x10/b\xd0\xc9\x15\xfc\x18\xf5\x96\x96\x96\x16\x00\
K!\x14s\xa3n8\xaanl\x81\xd1(\xf6{H\
\x1eaL\x18\xef\x85\xa8oRJ\x9d\xc7=\xf3\xc1c\
\xd0\xc95\xfc\x14\xf5\xd6\xd6\xd6\xcf*\xa5\x16C0\xe6\
\xf1\xb6\x04TC\xbd\xc48\xf2\xa0r\xd4]{\xf8}\
S(\x14\x9a\xc7\x98\x0f\x0d\x83N\xae\xe2\x87\xa8\xb7\xb4\
\xb4\xb4i\xad3\x90:g^7\x1c1\xc6\x9c\xfa\xc1\
\x980\x0e\xf1\x1b\x13@\xc8U_\xfd\x9bx5\xbb5\
\x5c\xf5\xa9\x12\x01\xde\x8ezkk\xeb\x8dJ\xa9[ \
\xb5g^_\x87\xaa\x1b\x130\x18s\xea\xa7\xd0\xc4\x09\
\xa8\xba\xb1\xc5-Qg\xcc-\xe4\x8aO\x94h\x7f^\
\x8czKK\xcbB\xad\xf5\xaf \xf4\xe7J\xd5\xd5!\
~c\x02\xaa\x9e1\xa7\x811&N@\xbc-\xe1\xf4\
}\xea\x8c\xb9\xc5\x18tr-/E\xbd\xb5\xb5\xf5s\
J\xa9_B*\xe6\xf5\xf5\xe5\x98\xd7\xd5I\x8c#\x1f\
\x0aM\x9a\x88x\xdb\x02\xa7\xa2\xbeA)u\x0ecn\
-\x06\x9d\x5c\xcd\x0bQoii\xf9\xbc\xd6\xfa\x17\x10\
\xfa\xf3d4\xd4\x97\x0f\xb3\xd73\xe644\xa1\xc9\x93\
P\x95\x9c\x0f(%9vc(\x14:?\x95J\xfd\
Yrh\x100\xe8\xe4zn\x8ezkk\xeb\x17\x94\
R7Cj\xcf\xbc\xa1\xbe|\x01\x5c\xddp\x89q\xe4\
w\xa5\x12\xf2\xbf{\x01\xd0Zj\xe2\xc6P(t\x1e\
\xf7\xcc\xed\xc1\xa0\x93'\xb81\xea\xbd{\xe6?\x03 \
\xb2{\xa3\xea\xeaP\xd5\xb6\x00\x06cNV(\x95\x90\
]q\x17J\xef\xbe'5q\xa3\xd6\x9a\xe7\xccm\xc4\
\xa0\x93g\xb8)\xea---\x9fWJ\xfd\x1cR\x87\
\xd9G4\xa2ja\x92\xe7\xcc\xc9\x1a\xa5\x12r+\xee\
B\xe9\x1d\xd9\x98\xf3\x09p\xf6b\xd0\xc9S\xdc\x10\xf5\
\xd6\xd6\xd6/J\x1ef7F4\x22\xde\xb6\x00j\xf8\
0\x89q\xe4w\xc5\x22\xb2\xcboGQ.\xe6[\x19\
s\x19\x22\x0f\xbe \xb2R%\xea\x1f\xdd\xf3}\x14\xbb\
\xb6K\x8c\xacD\xfdZ\x00M\x00~\x02\xa9\xc3\xec#\
\x1a\x11k[\x005\x8c1\xa7\xa1\xd3\x85\x02r\xb7\xdd\
\x89\xd2\xaa\xd5R#\xf3Z\xeb\xb3\x19s\x19\xdcC'\
OrhO\xfd\x1e\x08\xc6\xdc\x181\x02\xf1\xb6\x050\
\x18s\xb2\x80.\x14\x90]~\x87d\xcc\xb5i\x9a\xcd\
\x8c\xb9\x1c\x06\x9d<\xcb\x81\xa8\x87!\x15\xf3\x91#\x10\
\xbf\x911'\x8b\x14\x8a\xc8\xddz\x07\xcc\xd5k\xc4F\
*\xa5\xfewGG\xc7\xbdb\x03\x89A'os \
\xea\xb63F\x8e(\xbfh\xa5\xb6\xd6\xe9\xa5\x90\x1f\x14\
\x8a\xc8._\x81\xd2\xfbk$\xa7\xfeO*\x95\xfa\x9e\
\xe4@b\xd0\xc9\x07\xfc\x14\xf5r\xcc\x17@\xd5\xd68\
\xbd\x14\xf2\x83J\xccW\xaf\xb5u\x8c\xde\xf7>\xf6_\
d2\x99\xbf\xb6u \x1d\x14\x83N\xbe\xe0\x87\xa8\x7f\
\x12s\xee\x99\x93\x05\x84b\x0e\x00\xea\x93'\xcd\xfd\x22\
\x93\xc9\xfc\xa5\xd6rO\xaa\xa1O0\xe8.\xa1\xcd\x12\
z6\xae\xc2\xeew~\x87\x9do<\x8d\xce\xf7\xff\x84\
\xfc\x8e\xf5N/\xcbS\xa2\xf5c1\xc9\xa3Qg\xcc\
\xc9R\x821\xdf\xcb\xcd\x8c\xb9\xb3x\xdb\x9a\xc3\xf2;\
\xd6c\xfb\xcb\x0fa\xf7\xbb\xcf\xc3,d\x0f\xf8\xf7\x91\
a#Qw\xcc\xb9\xa8?\xee\x02\x18\xd1*\x07V\xe8\
-\x91\xde\xa8\x7f(wK\xdb\x90}r\xce\x9c\x87\xd9\
\xc9\x02\x85\x02\xb2\xcbo\x17\x8d\xb9\xd6\xfa\xe7\x1d\x1d\x1d\
\xff\x8b1w\x16\xf7\xd0\x1d\xa2\xb5\xc6\xb6?\xdd\x8b\xb5\
\xb7~\x1b;\xdf|\xe6\xa01\x07\x80\xc2\xee-\xd8\xf2\
\xfc\xedX\xb3\xec\x1b\xe8\xfa\xe05\xe1UzS\xc4C\
{\xea\xc6\x98Q\x88\xb7\xb70\xe6d\x8dB\x01\xd9e\
\xb2{\xe6J\xa9\xff\xccd2\x7f\xc5\x98;\x8fAw\
\x80\xd6&6<\xfe3ly\xe1\x0e\xe8R\xb1_?\
S\xec\xda\x8eu\x0f\xfc\x07v\xbe\xf1\xb4\xcd\xab\xf3\x07\
/D\xdd\x183\x1a\xf1\xd6\x05P\xd5\xd5N/\x85\xfc\
\xa0\x12\xf35\x1fHN\xfdq*\x95\xfa\xb2\xe4@:\
4\x06\xdd\x01[\x7f\x7f\x1bv\xbf\xfb\xfb\x01\xff\x9c\xd6\
&6=\xbb\x18;\xdex\xca\x86U\xf9\x8f\x9b\xa3n\
\x8c\x1d\x83x\xeb|\xc6\x9c\xacQ(\xa0\xa7C<\xe6\
?J\xa7\xd3\x7f'9\x90\xfa\xc6\xa0\x0b\xebY\xff\x0e\
\xb6\xaf|x\xd0?\xaf\xb5\xc6\xe6g\x970\xea\xfd\xe4\
\xc6\xa83\xe6d%\x9d\xcd\x22\x9bZ\x0es\xad\x5c\xcc\
\x95R?L\xa7\xd3_\x11\x1bH\xfd\xc2\xa0\x0b\xdb\xfa\
\xc2\x1d\xfb\xdf\xb39`\x8c\xfa\xc0\xb8)\xea{b^\
\xc5\x0b\x99\xcb\x15\xcc\x00\x00 \x00IDAT\x1ci\
\xe8t6\x8b\x5c\xc7\x0a\x94>\xfaXr\xec\x7f\xa4R\
\xa9\xafJ\x0e\xa4\xfea\xd0\x05\x15vmB\xcf\xba\xb7\
,\xd9\x16\xa3>0n\x88:cNV\xd2\xd9,\xb2\
\x99\xdb\xa4c\xfe\xef\xe9t\xfak\x92\x03\xa9\xff\x18t\
A\xdd\x1f\xbe>\xe4\xbd\xf3\xbd\xed\x89\xfakOX\xb6\
M?\x8b8\xf8\xf0\x19\xc6\x9c\xacT\x89\xb9\xf9\xf1:\
\xb9\x99Z\xff \x9dN\x7f]l \x0d\x18\x83.(\
\xb7\xcd\xfa\xbfIk\xad\xb1\xf9\xb9\x14\xf7\xd4\xfb)Z\
?\x16\xb5\xd3\xe6\x8a\xce4\xc6\x8de\xcc\xc9:\xd9\x1c\
r\x0e\xc4<\x93\xc9|Cl \x0d\x0a\x1f,#\xa8\
\x94\xeb\xb2e\xbb\x95=u\x00\xa8?f\x9e-3\xfc\
b\xcb\x0bw\x88\x1e\xd1\x08\x8d\x1f\x87X\xcb\x0d\x8c9\
Y#\x9bC6s+J\x821\x07\xf0o\x99L\xe6\
\x9b\x92\x03ip\xb8\x87.H\xd9\xf8\xdc\x05\x1e~?\
\xbc\xad/\xdc\x81m\x7f\x92{\x9bc9\xe6\x9fe\xcc\
\xc9\x1a\xd9\x1cz2\xcb\xc5c\x9eN\xa7\x19s\x8f`\
\xd0}d\xcf\xe1wF\xfd\x00[_\xb8\x03[\x1d\x89\
y\x5cl&\xf9X6\x87\x9e\xf42\x98\x1f\x8b\xbe\xdf\
\xe1\x9f\x18so\xe1!w\x9f\xa9D\x1d\x00\xea\x8f;\
\xdf\xe1\xd5\xb8\xc3\x96\xe7o\xc7\xb6\x17\xef\x13\x9bgL\
\x9a\x80X\xe2\x06\xa8XLl&\xf9\x97\xee\xc9\x22\x9b\
Y\x0es\xdd\x06\xb9\x99Z\xffc&\x93\xf9\xff\xc4\x06\
\x92%\x18t\x1fb\xd4?\xb1\xe5\xf7+\xb0\xed\xa5\xfb\
\xc5\xe6\x19\x93& \xce\x98\x93EtO\x16\xb9\xcc\xad\
\xa21\x07\xf0\x0f\x99L\xe6\x9f%\x07\x925\x18t\x9f\
b\xd4\x81-\xcf\xcb\xc6<4y\x22\xe2\x89\x1b\x80h\
Tl&\xf9Xw7\xb2\xa9e07n\x16\x1b\xa9\
\x94\xfa\xdf\xa9T\xea_\xc4\x06\x92\xa5\x18t\x1f\x0bj\
\xd4\xb5\xd6\xd8\xf2\xdb\x0el\x7f\xe5Q\xb1\x99\x8c9Y\
\xaa\xbb\x1b=\xa9\xe5\x8c9\x0d\x08\x83\xees{\xa2n\
\x18\x81\xb8\xa5Mk\x8d\xcd\xbf\xc9`\xc7\xab\x8f\x89\xcd\
4\x18s\xb2\x90\xee\xeaF6\xbd\x1c\xe6\xc6Mr3\
\xb5\xfe\xfbt:\xfd=\xb1\x81d\x0b^\xe5\x1e\x00A\
\xb9\xa5Mk\x8d-\x8c9y\x98\xee\xaa\x1cf\x97\x8b\
9\x80\xefd2\x19\xc6\xdc\x07\x18\xf4\x80\xf0\xfb-m\
\x95\x98o\x17\x8cyh\xf2\xa4\xf2\x05p\x8c9Y`\
O\xcc7\x89\x1ef\xffv:\x9d\xfe\xbe\xd8@\xb2\x15\
\x0f\xb9\x07\x88_\xcf\xa9\x97\xff\x7f\xa5\xb1\xe3\xb5\xc7\xc5\
f\x86\xa6LFl\xc1\xf5\x8c9YBwv\xa1'\
\xb5\x0cz\xf3\x16\xb9\x99Z\x7f+\x9dN\xff\xab\xd8@\
\xb2\x1d\x83\x1e0~\x8b\xba\xd6\x1a\x9b\x7f\x9d\xc2\x8e\xd7\
\x05\x1f\xe7\xca\x98\x93\x85\x1c\x88\xb9\x06\xf0\xe5L&\xf3\
_R\x03I\x06\x83\x1e@~\x89\xfa\x9e\xd3\x08\x821\
7\xa6LF<\xd1\x0cD\x22b3\xc9\xbftg\x17\
\xb2\xc21WJ})\x95J\xfdDj \xc9a\xd0\
\x03\xca\xebQw\xe2\x9a\x80\xd0\xf4&\xc4n\xb8\x961\
'KTbn2\xe6d\x11\x06=\xc0\xbc\x1a\xf5\xf2\
a\xf6\xa5\xd8\xf1\xfa\x93b3+1W\x8c9Y@\
wv!\xbb\xb4\x03\xe6\x96\xadb#\xb5\xd6\x7f\x9bN\
\xa7\x7f*5\x90\xe41\xe8\x01\xe7\xb5\xa8k\xad\xb1\xe9\
\xd9%\xd8)\xf8\xfew\xc6\x9c\xac\xa4w\xed.\xc7|\
\xdbv\xb1\x91\x00n\xcad2\xff-5\x90\x9c\xc1\xa0\
\x93w\xa2\xae56>\xf5K\xecz\xeb9\xb1\x91\xa1\
\x19\xd3\x10\xbf\xe1Z \xcc?*4t\xe6\xce]\xc8\
\xa5\x96\x89\xc6\x5c)\xf57\xa9T\xea\xffJ\x0d$\xe7\
\xf0[\x8a\x00x \xeaZc\x03cN\x1ef\xee\xdc\
\x85\xec\xd2\x0e\xe8\xed;\xa4Fj\xad\xf5_\xa7\xd3\xe9\
\xff\x91\x1aH\xce\xe27\x15\xed\xe1\xd6\xa8kmb\xe3\
S\xffO6\xe63\xa7#\xde|\x0dcN\x96p*\
\xe6\x99L\x861\x0f\x10~[\xd1>\xdc\x16u\xadM\
l|\xf2\x97\xd8\xf5\xf6o\xc4f2\xe6d%\xed@\
\xcc\x01|1\x93\xc9\xfcLj \xb9\x03\xbf\xb1\xe8\x00\
n\x89\xba\xd6&6<\xf9\x0b\xec~\xfb\xb7b3C\
3\xa7\x97\x0f\xb3\x87Bb3\xc9\xbf\x9c\x88\xb9R\xea\
\x7f\xa5R\xa9\x9fK\x0d$\xf7`\xd0\xe9\xa0\x9c\x8ez\
y\xcf\x5c:\xe63\x10\xbf\xe1\x1a\xc6\x9c,\xa1w\xee\
B\xcf\x92\x0e\xe8\x1db17\x95R\x9fK\xa5RK\
\xa4\x06\x92\xbb0\xe8tHNE\xbd\x12\xf3]\x8c9\
y\x94\xb9c'\xb2K\x97\x89\xc6\x5ck\xbd0\x9dN\
/\x95\x1aH\xee\xc3\xa0S\x9f\xa4\xa3\xae\xb5\x89\x0dO\
\xdc\x8c\xdd\xef\xfc\xce\xf6Y\x15\xe1\xa3\x8e@\xec\xba\xab\
\x00\x83/\x1f\xa4\xa1s \xe6%\xad\xf5\xe72\x99\x0c\
c\x1ep\xfc\x06\xf3\xb6\x1e\x89!{\x1e\xb3j\xf3\xc3\
\x5c\xb46\xb1\x911'\x0f\xd3;w\x22+{\x98\xbd\
\x04`!cN\x00\x83\xeeiZ\xeb\xaf\x02\xf8\x93\xd0\
,l~v\x89m\xcfN\xd7\xda\xc4\x86\xc7\x7f\x8e]\
\x921?\xfaH\xc6\x9c,cn\xdd\x86\x9e[\xd2\xd0\
;wJ\x8d,)\xa5\xda\xd3\xe9tJj \xb9\x1b\
\xbf\xc9\xbcmG8\x1c\xbe\x00\x92Q\xb7\xe1\x85(\xda\
,a\xfd#?\xc5\xeew\x7fo\xe9v\xfb\x12:\xfa\
HD\xaf\xfd\x0ccN\x960\xb7n+\x1ff\xdf\xb5\
[jdIk}c*\x95JK\x0d$\xf7\xe3\xb7\
\x99\xc7-^\xbc\xd8\xd3Q\xd7f\x09\xeb\x1f\xfdot\
\xbe/\xb2|\x00\xe5\x98\xc7\xae\xfd\x0c\x14cN\x16\xd0\
\x95\x98\xef\x96\x8dy&\x93\xc9H\x0d$o\xe07\x9a\
\x0fx5\xea\xbaT\xc4\xfaG~*\x1a\xf3\xf01G\
1\xe6d\x19\xbdu\x1bz\x84c\x0e\xa0\x8d1\xa7\x83\
\xe1\xb7\x9aOx-\xea\xbaT,\xef\x99\xaf~\xd1\xe2\
\x95\x1dZ\xf8\xd8\xa3\x11\xbd\xe6J\xc6\x9c,an\xdd\
*\x1es\xaduk:\x9d\xee\x90\x1aH\xde\xc2o6\
\x1f\xf1J\xd4u\xa9\x88u\x8f\xfeT>\xe6W_\xc1\
\x98\x93%\xcc\xad[\x91]\xba\x5cz\xcf<\x99\xc9d\
\x96I\x0d$\xef\xe1\xb7\x9b\xcf\xb8=\xea\xe5=\xf3\x9f\
\xa2k\xf5K6\xaf\xec\x13\x8c9Y\xc9\xdc\xba\x15\xd9\
%\xa2{\xe6\x05\xa5Ts:\x9d^.5\x90\xbc\x89\
\xdfp>\xe4\xd6\xa8Wb\xde)\x1c\xf3\x18cN\x16\
1\xb7\xf4\xc6\xbc\xb3SjdAk}C*\x95\xba\
Kj y\x17\xbf\xe5|\xcamQ\xd7\xa5\x22\xd6=\
\xf2\x13\xd9\x98\x9fx<b\xd7\x5c\xc9[\xd3\xc8\x12\xe6\
\x96\xad\xe5\xab\xd9\xe5b\x9e\x07\xd0\x9c\xc9d\xee\x96\x1a\
H\xde\xc6o:\x1fsK\xd4\xb5Y\xc4\xfaG~\x82\
\xae5/K,\x03\x00\x10\x99}\x02bW^\x0a(\
%6\x93\xfc\xab\x1c\xf3\x0e\xe9\x98\xdf\x90N\xa7\xef\x91\
\x1aH\xde\xc7\xa0\xfb\x9c\xd3Q\xd7f\x11\xeb\x1f\xfe\x09\
:\x85c\x1e\xbd\xe2\x12\xc6\x9c,an\xdc\x8c\x9e\xc5\
\x19\xe8\xce.\xa9\x91y\xd34\x9b\x19s\x1a(\x06=\
\x00\x9c\x8a\xfa\xf6W\x1e\xc1\xc7\x0f\xfcP4\xe6a\xc6\
\x9c,dn\xdc\x84lj\x19\xd0\xdd-52\x0f\xe0\
\xfa\x8e\x8e\x8e{\xa5\x06\x92\x7f0\xe8\x01\xe1H\xd4\x7f\
\xd3\x81\xee\x0f_\x97\x18\x07\x00\x08\xcf9\x111\xc6\x9c\
,bn\xd8\x88lj9\xb4p\xcc\xd3\xe9\xf4}R\
\x03\xc9_\x18\xf4\x00\x91\x8e\xba\xa4\xc8\xdc\x13\x11\xbb\xfc\
b\xc6\x9c,\xe1D\xcc\x95R\xd71\xe64\x14\x0cz\
\xc0\xf81\xea\x91\xb9'\x22z\x19cN\xd6\xd8\x13\xf3\
\x1e\x91\xb7\x13\x03@N)u]*\x95\xba_j \
\xf9\x13\x83\x1e@~\x8az\x981'\x0b9\x11s\xad\
5cN\x96`\xd0\x03\xca\x0fQ\x8f\xcc\x9d\x8d\x18c\
N\x16q \xe6=\x00\xae\xc8d2\x0fH\x0d$\x7f\
c\xd0\x03\xcc\xcbQ\x0f\xcf\x9d\x8d\xe8e\x171\xe6d\
\x09s\xfd\x06\xf1\x98\x1b\x86qe:\x9d~\x5cj \
\xf9\x1f\x83\x1ep^\x8cz\xe4\xb4S\x10c\xcc\xc9\x22\
\xa5u\xeb\x91M\xdf*\x19\xf3n\xc30\xae\x5c\xbat\
\xe9\xd0\xde?L\xb4\x1f\x06\x9d<\x15\xf5\xc8i'#\
z\xd1y\x8c9Y\xa2\xb4n=r\x19\xd9\x98k\xad\
\x19s\xb2\x05\x83N\x00\xbc\x11\xf5\xc8\xa7NA\xf4\xa2\
\xf3\x9d^\x06\xf9\xc4'1\xcfJ\x8d\xecVJ]\x91\
\xc9d\x9e\x94\x1aH\xc1\xc2\xa0\xd3\x1en\x8ez\xe4S\
\xa7 z\xe1yN/\x83|\xc2\xfc\xf0c\xe4R\xcb\
\xc5c\x9eJ\xa5\x9e\x92\x1aH\xc1\xc3\xa0\xd3>\xdc\x18\
\xf5\xc8\xe9\xa72\xe6d\x19\xf3\xc3\x8f\x91\xed\xb8\x0d:\
\x97\x93\x1a\xd9m\x9a\xe6\xe5\x8c9\xd9\x8dA\xa7\x03\xb8\
)\xea\x91\xd3OE\xf4\x82yN/\x83|\xa2\xf4\xc1\
G\xe8\xc9\xdc*\x19\xf3.\xd34/\xef\xe8\xe8xZ\
j \x05\x17\x83N\x07\xe5\x86\xa8GN?\x8d1'\
\xcb\x94>\xf8\x08\xd9\x8e\xdb\x80|^jd\x17\x00\xc6\
\x9c\xc40\xe8tH{E]\xeeui\xbd\xca1?\
Wz,\xf9\x94\xe9@\xcc\x95R\x97\xa5\xd3\xe9g\xa4\
\x06\x121\xe8tXJ)Sr^\xe4\x0c\xc6\x9c\xac\
c~\xf0\x11z\x1c\x88y*\x95zVj \x11\x00\
\x84\x9d^\x00\xb9W{{{}\xb1X|\x0c\xc0\x5c\
\xa9\x99\x913NC\xf4|\xc6\x9c\xacQ\xfa\xe0C\xe4\
:VH\xc6|\xa7\xd6\xfa\xe2t:\xfd\xbc\xd4@\xa2\
\x0a\x06\x9d\x0ej\xaf\x98\x9f,5\x931'+\x95\xd6\
~\x80\xdc\xb2\xdb\xa1\x85c\x9e\xc9d\x18sr\x04\x83\
N\x07H$\x12\x0d\x86a<\x06\xe0$\xa9\x99\xd1s\
\xceB\xe4\xd3gJ\x8d#\x9fs\x22\xe6J\xa9\x8b\xd2\
\xe9\xf4\x0bR\x03\x89\xf6\xc7\xa0\xd3>\x9c\x88y\x841\
'\x0b\x99k?@\xb6c\x05P(H\x8d\xdc\xa9\x94\
\xba(\x95J1\xe6\xe4(\x06\x9d\xf6H$\x12\x0d\xa1\
P\xe8q\xad\xb5\xd89\xf3\xe8\xb9g#r\xf6\x19R\
\xe3\xc8\xe7J\xabV#w\xdb\x9d\x921\xdfa\x9a\xe6\
E\x1d\x1d\x1d\x7f\x90\x1aHt(\x0c:\x01\x00\x16.\
\x5c8\xca0\x8c'\xb4\xd6\xc7K\xcd\x8c\xce;\x1b\x91\
\xb3\x18s\xb2F%\xe6Z0\xe6Z\xeb\x0b;::\
\xfe(5\x90\xa8/\x0c:a\xe1\xc2\x85\xa3\x0a\x85\xc2\
\x93\x00\x8e\x93\x9a\x199\x971'\xeb\x94V\xadF\xf6\
\xd6;\x80bQj\xe4\x0e\xad\xf5\x85\x99L\x861'\
\xd7`\xd0\x03\xae\xb5\xb5u\xb4\xd6\xfa\x09\x08\xc6<:\
\xef\xd3\x88\x9cu\xba\xd48\xf2\xb9\xd2{\xef#{\xdb\
\x9d\x921\xdf\xae\x94\xba0\x9dN;\xfehd\xa2\xbd\
1\xe8\x01\xd6\x1b\xf3'\x01\x1c+5\x931'+9\
\x15\xf3T*\xc5\x98\x93\xeb0\xe8\x01\xe5H\xcc\xcf;\
\x07\x913?%5\x8e|\xae\xf4\xee*dW\xdc%\
\x1as\xd34/\xe8\xe8\xe8xQj \xd1@\xf0\xd1\
\xaf\x01\xb4`\xc1\x821\xa6i>\x05\xc6\x9c<\xca\x81\
\x98o6\x0c\xe3\x1c\xc6\x9c\xdc\x8c{\xe8\x01\xb3`\xc1\
\x821\x86a<\xa9\x94:Fd\xa0R\x88^t\x1e\
\x22\xa7\x8a=p\x8e|\xae\xf4\xee\xaa\xf2a\xf6RI\
j\xe4f\xad\xf5yK\x97.}Mj \xd1`0\
\xe8\x01\xb2`\xc1\x821\xa1P\xe8)\x00G\x8b\x0cT\
\x0a\xb1\x8b\xcfG\xf8\x14\xb1g\xd4\x90\xcf\x95\xde}\x0f\
\xd9\xdb\xee\x92\x8c\xf9&\xad\xf5\xf9\x99L\x861'\xd7\
\xe3!\xf7\x80hoo\x1f+\x1d\xf3\xe8E\x8c9Y\
\xc7\x89\x98+\xa5\xcec\xcc\xc9+\xb8\x87\x1e\x00\xed\xed\
\xedc\x8b\xc5\xe2S\x00\x8e\x12\x19\xd8\x1b\xf3\xc8\xa9\x8c\
9Y\xa3\xf8\xe7\xb7\x91\xbb\xe3\x1e\xc0\x14{\x93\xef&\
\xa5\xd4y\xa9T\xeau\xa9\x81DC\xc5\xa0\xfb\x5cK\
K\xcbD\xa5\xd4\xd3\x00f\x88\x0cT\x0a\xd1\x8b/@\
\xe4\x14\xb1\xa7\xc7\x92\xcf9\x10\xf3\x8d\xa1P\xe8\xbc%\
K\x96\xbc!5\x90\xc8\x0a<\xe4\xeec\xf3\xe7\xcf\x9f\
$\x1d\xf3\xd8%\x172\xe6d\x99\xe2\x9bo1\xe6D\
\xfd\xc4=t\x9f\x9a?\x7f\xfe\xa4p8\xfc4\x80\xe9\
\x22\x03\x95B\xf4\x92\x0b\x10>y\x8e\xc88\xf2\xbf\xd2\
\x9bo!\x7f\xe7\xbd\xa21\xd7Z\xcf[\xb2d\xc9\x9b\
R\x03\x89\xac\xc4=t\x1fjkk\x9b\xecD\xcc#\
's\xcf\x9c\xacQz\xf3-\xe4\xee\xbc\x17Z.\xe6\
\x1b\xb4\xd6\xf32\x99\x0ccN\x9e\xc5=t\x9fik\
k\x9bl\x9a\xe6\xd3\x00\xa6\x89\x0cT\x0a\xb1K/D\
\xf8$\xee\x99\x935\x8ao\xfc\x19\xf9\xbb\xee\x13\x8d\xb9\
Rj^:\x9d\xfe\xb3\xd4@\x22;0\xe8>\xe2H\
\xcc/\xbb\x08\xe1\xb9\xb3E\xc6\x91\xff\x15_\x7f\x13\xf9\
\xbb\xef\x97\x8c\xf9G\x00\xceM\xa5R\xefI\x0d$\xb2\
\x0b\x83\xee\x13\x89Db\x8aa\x18O\x03h\x12\x19\xa8\
\x14b\x9f\xb9\x0c\xe1\x13\xc4^\xd2F>'\x1ds\xa5\
\xd4\x87Z\xeby\xe9t\x9a1'_\xe09t\x1f\x10\
\x8f\xb9a v%cN\xd6q\x22\xe6\x86a\x9c\xcb\
\x98\x93\x9fp\x0f\xdd\xe3\x9c\x89\xf9\xa5\x8c9Y\xa6\xf8\
\xfa\x9b\xc8\xdd}\xbf\xe4\xd5\xec\x1f\x18\x861o\xc9\x92\
%\xab\xa4\x06\x12I`\xd0=L)5\x0a\xc03\x00\
\xa6\x8a\x0cd\xcc\xc9b\xc5\x95\xaf\x22w\xdfC\x80\xd6\
R#?0M\xf3\xdct:\xfd\xbe\xd4@\x22)\x0c\
\xba\x87)\xa5\xfe\x01@\xa3\xc80\xc3(\x9f3?^\
\xec\x8d\xab\xe4s\x85\x97_A\xfe\xfe\x87\xc5c\xde\xd1\
\xd1\xc1\x98\x93/\xf1\x1c\xba\x87i\xad\x19s\xf2$\x07\
b\xbeV)u\x0ecN~\xc6\xa0S\xdf\x18s\xb2\
X\xd1\x99\x98\x9f\x9bJ\xa5VK\x0d$r\x02\x83N\
\x87f\x18\x88]u9cN\x96)\xbe\xb4\x129\xe1\
\x98\x87\xc3\xe1s\x18s\x0a\x02\x06\x9d\x0e\xae\x12\xf3\xe3\
\x8eqz%\xe4\x13\x85\x17W\x22\xf7\xc0#b1\xd7\
Z\xaf\x09\x87\xc3\xe7,^\xbcx\x8d\xc8@\x22\x87\xf1\
\xa28:\x90a v\xf5\x15\x08\x1f{\xb4\xd3+!\
\x9f(\xbc\xb8\x12\xf9\x07\xe5b\x0e\xe0]\x00\xf3\x16/\
^\xfc\x91\xd4@\x22\xa71\xe8\xb4/\xc3@\xfc\xfa\xab\
\x11:r\x96\xd3+!\x9f(:\x10s\xc30\xce]\
\xbat\xe9\xc7R\x03\x89\xdc\x80A\xa7O\x18\x06b\xd7\
]\xc5\x98\x93e\x0a/\xbe\x8c\xfc\x83\x8fJ\xc6\xfc\x1d\
\xc30\xe61\xe6\x14D\x0c:\x95\x85B\x883\xe6d\
\xa1\xa2\x031/\x16\x8b\xe7._\xbe|\x9d\xd4@\x22\
7a\xd0\x891'\xcb\x15\x9e\xff\x03\xf2\x8f=%\x19\
\xf3\xb7\x8b\xc5\xe2<\xc6\x9c\x82\x8cA\x0f\xbaP\x88\x87\
\xd9\xc9R\x85\xe7\xff\x88\xfc\xa3OJ\x8e\xd4\xa6i~\
\x8f1\xa7\xa0\xe3mkA\x16\x0a!v\xfd\xd5\x083\
\xe6d\x91\xc2\xef\xff\x80\xfc\xa3OH\x8fU\x86a\xfc\
2\x99L^&=\x98\xc8M\x18\xf4\xa0\xaa\xc4\xfc\x88\
\x99N\xaf\x84|\xa2\xf0\xfb? \xff\x98\xe8\x9e\xf9\xde\
b\x00\xeed\xd4)\xc8\x18\xf4 \x0a\x85\x10o\xbe\x86\
1'\xcb\x14~\xf7\x82\x931\xaf`\xd4)\xd0\x18\xf4\
\xa0\x09\x85\x10k\xbe\x06\xa1Y3\x9c^\x09\xf9D\xe1\
w/ \xff\xf8SN/\xa3\x82Q\xa7\xc0b\xd0\x83\
\xa47\xe6a\xc6\x9c,R\xf8\xdd\xf3n\x8ay\x05\xa3\
N\x81\xc4\xa0\x07\x84\x8aD\x10_p=cN\x96)\
\xc7\xfci\xa7\x97q(\x8c:\x05\x0e\x83\x1e\x00*\x12\
A|\xfeu\x08Mkrz)\xe4\x13\x85\xdf\xba:\
\xe6\x15\x8c:\x05\x0a\x83\xeew\x910\xe2\xf3\xaf\x83\xd1\
4\xd5\xe9\x95\x90O\x14~\xfb<\xf2O\xb8>\xe6\x15\
\x8c:\x05\x06\x83.\xc8\xcc\xf7\xc8\x0e\x8c\x84\x11\x9f\xdf\
\xcc\x98\x93e\xf2\xcf<\xe7\xa5\x98W0\xea\x14\x08\x0c\
\xba\x10\xb3\x90C\xf7\xba\xb7\xe4\x06F\x22\x88/\xb8\x01\
\xa1\xa6)r3\xc9\xd7\xf2O\xff\x1a\x85g\x7f\xe3\xf4\
2\x06\x8bQ'\xdfc\xd0\x85l\xfb\xc3\x9dr{\xe8\
\x91\x08\xaa\x12\xcd\x08M\x9d,3\x8f|/\xff\xd4\xaf\
Q\xf8\xf5o\x9d^\xc6P1\xea\xe4k\x0c\xba\x80R\
v7\xb6\xbd\xfa\x98\xc8,\x15\x8d\x22\x9eh\x861\x85\
1'k\xe4\x9fz\x16\x85\xe7<\x1f\xf3\x0aF\x9d|\
\x8bA\x17\xb0\xe3\x95G\x01\xb3d\xfb\x1c\x15\x8d\x22\x96\
hF\x881'\x8b\xe4\x9f|\x06\x85\xe7~\xe7\xf42\
\xac\xc6\xa8\x93/1\xe8\x02v\xbe\xf5\x9c\xfdC\xa2Q\
\xc4\x137 4y\x92\xfd\xb3(\x10\xf2O<\x8d\xc2\
o~/6/6r\x0aB\xd5\xf5b\xe3\xc0\xa8\x93\
\xcf0\xe86\xd3\xc5<\x8a\x9d\xdbl\x9d\xa1b1T\
\xb5|\x16\xc6\xe4\x89\xb6\xce\xa1\xe0\xc8?\xfe4\x0a\xbf\
}^l^|\xcc\x0cL\xba\xfa;\x98t\xf5w\x10\
\xaei\x90\x1a\xcb\xa8\x93\xaf0\xe86\xeb\xfa\xe0U{\
\x07D\xa3\x88\xb7\xdc\x00c\xd2\x04{\xe7P`\xe4\x1f\
\x7f\x0a\x85\xdf\xc9\xc5\xbcj\xecLL\xbc\xf2\xeb0\xa2\
U\x88\xd6\x8f\xc5\xc4\xab\xbe\xcd\xa8\x13\x0d\x02\x83n\xb3\
\xce\xd5/\xd9;\xa0P\x80\xee\xec\xb2w\x06\x05F\xfe\
\xb1'Q\xf8\xdd\x0bb\xf3\xaa\xc6\xcd\xc2\x84\xde\x98W\
0\xeaD\x83\xc3\xa0\xdbHk\x13]kW\xda=\x04\
\xd9\xdb\xefF\xf1\xadw\xec\x9dC\xfe\xa65\xf2\x8f>\
\x89\xc2\xef\xff 6\xb2j\xdc,L\xb8\xe2k0\x22\
\xf1\x03\xfe\x1d\xa3N4p\x0c\xba\x8dz\xd6\xbd\x8dR\
\xcfn\xfb\x07\x99&r\x8c:\x0dV%\xe6\xcf\xbb#\
\xe6\x15\x8c:\xd1\xc00\xe86\xea\xb2\xfbp\xfb\xde*\
Q\x7f\xe7=\xb9\x99\xe4}Z#\xff\xe8\x13(\xbc\xf0\
G\xb1\x91\xd5\xe3\x8f<l\xcc+\x18u\xa2\xfec\xd0\
m\xd4\xb9F0\xe8@9\xea\xb7\xdd\x89\xd2\xbb\x8c:\
\xf5\x83\xd6\xc8?\xf28\x0a/\xfcIld\xf5\x84\xa3\
0\xfe\xf2\xaf\xf6+\xe6\x15\x8c:Q\xff0\xe86\xc9\
o\xfd\x10\x85\x9d\x9b\xe4\x07\x9b&\xb2\xb7\xde\x89\x12\xf7\
\xd4\xa9/\x95\x98\xff\xe1E\xb1\x91U\xe3\x8f\xc0\xf8\xcb\
\xfe\x0eF$6\xe0\x9fe\xd4\x89\x0e\x8fA\xb7\xc9\xee\
\xf7\xe5\xf6z\x0e`\x9a\xc8\xdev'J\xef\xbd\xef\xdc\
\x1a\xc8\xbd\xb4F\xee\xa1\xc7Dc^=\xf1hL\xbc\
\xe2\xeb\x03\xda3\xdf\x1f\xa3N\xd47\x06\xdd&\xb6\xdf\
\xaev8\xa6\x89\xec\xadw\xa0\xb4j\xb5\xb3\xeb w\
\xd1\x1a\xf9\x07\x1fE\xf1Or\xff}VO<\x06\x13\
.\xfb\x0aT8:\xe4m1\xeaD\x87\xc6\xa0\xdb\xa0\
\xb0{+\xf2[\xd6:\xbd\x0c\xa0TBv\xf9\xed<\
\xa7NeZ#\xff\xf0\xe3(\xbc\xf8\xb2\xd8\xc8\xaa\xf1\
Gb\xfc\xa5_\xb6$\xe6\x15\x8c:\xd1\xc11\xe86\
\xe8Z\xf3\x12\xb4\xd6N/\xa3\xacT*\x9fSg\xd4\
\x83\xad\x12\xf3?\xca\x1df\xaf\x99|\x5c\xef\xd5\xec\x03\
?g~8\x8c:\xd1\x81\x18t\x1bt\xbe/\xf7\xa5\
\xd9/\xa6\x89\xdc\x8a\xbba\xae^\xe3\xf4J\xc8\x09\x95\
s\xe6\xc21\x1fw\xc9\x97`X\xb8g\xbe?F\x9d\
h_\x0c\xba\xc5J\xb9n\xf4\xac\x7f\xdb\xe9e\x1c@\
\x17\x8b\xc8.\xbb\x1d\xa5\xf7\xd78\xbd\x14\x92\xa45r\
\xd2\xe7\xcc'\x1d\x87\xf1\x97~\xd9\xd6\x98W0\xeaD\
\x9f`\xd0-\xd6\xbdv%t\xa9\xe8\xf42\x0eJ\x17\
\x8b\xc8._\x81\xd2j\x17\x9c\xdf'\xfbi\x8d\xdc\xbd\
\x0f\xa2(x\xce\xbcf\xf2\xf1\x98p\xd9\x97\xa1B\x11\
\xb1\x99\x8c:Q\x19\x83n\xb1\xddn;\xdc\xbe\xbfb\
\x09\xd9e\xb71\xea~g\x9a\xc8\xdd\xf7 \x8a\xaf\xbc\
&6\xb2f\xf2\xf1\x18\x7f\xe9\x97Dc^\xc1\xa8\x13\
1\xe8\x96\xd2f\x11\xdd\x1f\xca}\x81\x0e\x1a\xa3\xeeo\
\xa6\x89\xdc}\x0f\xa1\xb8R0\xe6SNp,\xe6\x15\
\x8c:\x05\x1d\x83n\xa1\xee\x0f\xdf\x80\x99\xefqz\x19\
\xfd\xc3\xa8\xfbS%\xe6\x92{\xe6SN\xc0\xf8K\xfe\
\xd6\xd1\x98W0\xea\x14d\x0c\xba\x85D_\xc6b\x85\
J\xd4\xd7|\xe0\xf4J\xc8\x0a\xa6Y>g.\x1ds\
\x87\xf7\xcc\xf7\xc7\xa8SP1\xe8\x16\xd1Z\xa3s\x8d\
\xdc\xc5G\x96)\x96\x90\xed\xb8\x0d\xe6ZF\xdd\xd3*\
1\x7f\xf5u\xb1\x915SO,\xc7\xdc\x08\x8b\xcd\xec\
/F\x9d\x82\x88A\xb7Hv\xe3*\x14\xbb\xb6;\xbd\
\x8c\xc1)\x16\xd1\x93a\xd4=\xcb4\x91\xbb\xe7\x01\xf9\
\x98_\xf2\xb7\xae\x8cy\x05\xa3NA\xc3\xa0[\xc4\x8e\
\xc3\xedJY\xbe\xc9C\xeb\x8dz\x89Q\xf7\x96J\xcc\
_{Cld\xed\xf4\x931\xfe\x12w\xee\x99\xef\x8f\
Q\xa7 QCyD\xe9\x8d7\xde8\xbdX,\xce\
\x060E)\xd5\xe7\x9fn\xa5\xd4l\xad\xf5\x0d\x83\x1e\
\xb6\x9f\xf8\xa8\xa9\xa8\x9dq\xaaU\x9b\x1b\xb2\xed+\x1f\
F\xa9g\x97e\xdbS\x0a\xf8\xe2i\xc3\xb1\xf8\xc5N\
t\xe5M\xcb\xb6{\xd8\xb9\xd1(b\xc9\xcf\x224q\
\x82\xd8L\x1a$\x07b\x1e\x1b1\x09\xc3f\x9e\x06(\
\xb9}\x013\xd7\x8db\xd76\x94\xb2]\x00\x80P\xbc\
\x06\xe1\x9aF\x18\xb1\xea~o\xa3\x94\xdd\x8d\x9do<\
-v\xd1\xaa\xd6\xba\x08 \xa3\x94zKd\xa0 \xa5\
T\xbd\xd6z\x22\x80\xca\xdf\x92\xb6+\xa5>\xd2Z\xef\
pr]n\xd6\xfb\xdf\xc3Z\xad\xf5K\x1d\x1d\x1d\xb6\
\xbd\x06s\xc0A?\xf7\xdcs\xc3\x93&MZh\x9a\
\xe6MJ\xa9clZW\xe055\x86\xf1\xf7\xf3\x1a\
\xb0f{\x01?zn\x97h\xd4\x11\x8d\xa2\xaau>\
\x8c\x09\xe3\xe5f\xd2\xc0\x98&rw\xdf\x8f\xe2\xebo\
:\xbd\x12\x22\x1a\x98\xd7\x00\xfc$\x97\xcb-^\xb1b\
E\xc9\xca\x0d\x0f(\xe8mmm\xb3L\xd3\xbc\x0d\xc0\
\x89V.\x82\x0et\xf51\xd5\xb8\xfc\xa8\x1a\x00`\xd4\
i_\xa6\x89\xec\xedw\xa3\xf4\xd6;N\xaf\x84\x88\x06\
\xef%\x007\xa4\xd3i\xcb\xde\x9c\xd5\xef\xe3f\x89D\
b\xaei\x9a/\x801\x171{\xc2'o\xa8\x9a\xda\
\x10\xc1\xdf\x9d5\x1c5Q\xc1K\x1e\xf2y\xf4\xa4\x96\
\xa3\xf4\xf1:\xb9\x99tx\xa6\x89\xdc\x1d\xf70\xe6D\
\xde7G)\xf5B\x22\x91\xb0\xac\xa9\xfd*D{{\
\xfbX\xc30\x1e\x02Po\xd5`:\xb4Q5!L\
\x18\xbe\xef%\x09NE=\xcb\xa8\xbbG\xa9\x84\xec\xed\
w\xa3\xf8g\xf7\xbd\xfc\x87\x88\x06Nk\xddh\x18\xc6\
\xc3\xad\xad\xad\xa3\xad\xd8^\xbf\xeaP,\x16\xff\x07\x80\
%\x03\xe9\xf0\xe6L8\xf8\xfb\xa3\x9d\x8b\xfa2\x98\x1f\
\xaf\x97\x9bI\x07*\x95\x90\xe5\x9e9\x91\x1f\x8d\xd5Z\
\xff\xb7\x15\x1b:l\x19\x92\xc9\xe4\x1c\x00WY1\x8c\
\xfa\xe7\xc4\xf1\x87~\xed\xa43Q/\xa0'\xd5\x01s\
\xdd\x06\xb9\x99\xf4\x89\xde=s\xc6\x9c\xc8\xb7\xaeK&\
\x93'\x0cu#\xfd\xa9B;\x00\xc9;\xa2\x03\xad6\
\xaa0\xbd\xb1\xef\xfb{\x1d\x8b\xfa\xd2\x0c\xa3.\xadT\
B\xee\xf6\xbbQz\xfb]\xa7WBD\xf6QJ\xa9\
\x1b\x87\xba\x91\xfe\x14\xe1\xbc\xa1\x0e\xa1\xfe;q|\x0c\
!\xe3\xf0\x7f\x7fr2\xea\xa5u<\xfc.\xa27\xe6\
E\xc6\x9c\xc8\xf7\xb4\xd6\xf3\x86\xba\x8d>k\xf0\xdd\xef\
~\xd7\x000k\xa8C\xa8\xffN\x1cw\xe8\xc3\xed\xfb\
s*\xea\xd9\xd42F\xddn\xa5\x12\xb2+\xeeb\xcc\
\x89\x82\xe3H\xa5\x86\xf6|\xd0>K\xf0\xc6\x1bo\x0c\
\x03\x10\x1a\xca\x00\xea\xbfhH\xe1\x98\xb1\x07\xbf \xee\
P\xa66D\xf0\xb7g\xd6\xa1*\x22xV$\x97G\
6s\x1b\xcc\x8d\x9b\xe4f\x06I\xa9\x84\xdc\x8a\xbbP\
z\xc7\xb2\xdbS\x89\xc8\xfd\xa2\xc9d\xb2\xff\x8f?<\
\x88\xc3\xed\xda1\xe6\x82\x8e\x19\x13At\x10\xbf\xe3\xd3\
\x1b\xc3\xf8\xf2Y\xf5\xb2Q\xef\xe9A\xcf\xd2e\x8c\xba\
\xd5zc^d\xcc\x89\x02\xc74\xcd!5\x97/g\
q\x91\xd9\x87\xb8]\xad?\x1c\x8b\xfa\x92\x0e\x98\x9b6\
\xcb\xcd\xf41]( \xbb\xecv\xc6\x9c\x88\x06\x85A\
w\x09C\x01\xc7\x8f\x1b|\xd0\x01\x87\xa2\x9e\xcd\x22\xbb\
$\xc3\xa8\x0fU\xa1\x88\xec\xf2;Pz\x7f\xb5\xd3+\
!\x22\x8fb\xd0]b\xe6\xc8\x08\x86E\x87\x1eb'\
\xa2\xae{\xcaQ\xd7\x9b\xb7\x88\xcd\xf4\x95B\x11\xd9[\
o\x87\xb9z\x8d\xd3+!\x22\x0fc\xd0]b W\
\xb7\x1f\x8eSQ\xefY\x9cf\xd4\x07\xaa7\xe6\xa5\xf7\
\xd78\xbd\x12\x22\xf28\x06\xdd%N\x18\xe2\xe1\xf6\xfd\
9\x16\xf5%\x19\x98\x8cz\xff\x14\x8a\xc8._\xc1\x98\
\x13\x91%\x18t\x17\x98X\x17\xc6\x98a\xd6\xdfP\xe0\
H\xd4\xbb{\xca\xe7\xd4\x19\xf5\xbeUb\xbez\xad\xd3\
+!\x22\x9f`\xd0]\xa0\xafg\xb7\x0f\x95\xa3Q\xdf\
\xb2Ul\xa6\xa7\x14\x0a\x8c9\x11Y\x8eAw\x81\xd9\
\xe3\xad=\xdc\xbe?\xc7\xa2\xbe8\xcd\xa8\xef\xafP@\
v\x19cND\xd6\xeb\xfb- \x16S\xa1\x08\x1aN\
\xb8Hr\xa4\xa5t\xa9\x80\xed\xaf>\x06hm\xd96\
\xeb\xab\x0cL\xa9\xb7\xffc\x98\xde\x18\xc6\x97\xce\xac\xc3\
\x7f\xfef'z\x0a\xd6\xad\xbf/\x95=\xf5\xf8\xc2V\
\x18\x8d\x0d\x223]\xad\x12\xf35\x1f\x88\x8d\x8c\x8fn\
B\xf5\xc4c\xc4\xe6\x0d\xd6\xb6\x97\x1e\xb0t{\x8ds\
.\xb7t{A\xc3\xcf\xa3\x7f\xb6\xaf|\x04\xda,:\
\xbd\x8c=D\x83nDb\x18\xf9\xa9\x1b$GZj\
\xd7\xdb\xbf\xb54\xe6\x000{|\x14C{zo\xff\
\xcd\x18\x11\x91\x8fzW7\xb2\xb7\xa4P\xf5\xb96\xa8\
\x86z\x91\x99\xaeT(\xa0\xa7c\x05\xcc\xb5r1o\
8\xf1\x12\x8c:c\x81\xd8\xbc\xa1\xb0: ^\xfe\x9e\
q\x03~\x1e\xfd\xb3\xe3\xf5'\xa1\xf3\xee\x09:\x0f\xb9\
\x0f@\xd7\x9a\x97,\xdf\xe6\x1c\x9b\x0f\xb7\xef\xaf\x12\xf5\
xX\xf0\xf0{W7znIAo\xdf!6\xd3\
Mt.\x87\x9e\xd4r\xd1\x987\xce\xbe\xd431'\
\x22k0\xe8\xfd\xa4\xcd\x22\xba\xd6\xbej\xe96\xab#\
\x06f\x8d\x8aX\xba\xcd\xfe\x981\x22\x82/\x9f%\x1c\
\xf5\xce\xae@F]g\xb3\xc8en\x83\xf9\xd1\xc7b\
3\x1bg_\x8a\x91\xa7\xcf\x17\x9bGD\xee\xc0\xa0\xf7\
S\xf7\x87o\xc0,d-\xdd\xe6qc#\x08\xf7\xe3\
\xdd\xe7vp2\xeaf@\xa2\xae\xb3Y\xe4:V\xa0\
$\x18\xf3\x06\xc6\x9c(\xb0\x18\xf4~\xea\x5c\xfd\xa2\xe5\
\xdb\xb4\xf3v\xb5\xfep*\xea\xd9[R\xd0;\xfc\x1d\
u\x9d\xcd\x22\x9b\xb9M4\xe6\x8d\xb3/\xc3(\xc6\x9c\
(\xb0\x18\xf4\xfe\xd0\x1a]k^\xb6t\x93!\x05\x1c\
;\xc0w\x9f\xdb\xc1\xb9=\xf5\xb4\x7f\xa3\x9e\xcd\x95\x0f\
\xb3\x7f\xbcNld\xc3\xec\xcb0\xf2\xf4\xcf\x8a\xcd#\
\x22\xf7a\xd0\xfb!\xbbi\x15\x8a]\xd6\xc6\xe7\xa81\
QTK\xbe\x15\xad\x0f\x8eD}w\xa7?\xa3\x9e\xcd\
!\x9b\xb9\x15%\xc1\x987\xce\xb9\x1c\xa3\x18s\xa2\xc0\
c\xd0\xfb\xa1\xf3}\xeb\x0f\xb7\xdb\xfd0\x99\x81r*\
\xea\xd9[2\xd0;w\x8a\xcd\xb4U6\x87\x9e\xccr\
\xf1\x98\xfb\xf5\x96 \x22\x1a\x18\x06\xbd\x1f:W[{\
\xbb\x9aR\xc0\x09\x16\xbe]\xcd*ND\xdd\xdc\xbd\x1b\
\xd9_\xa5\xbd\x1f\xf5\xde\x98\x9b\x1f\xaf\x17\x1b9\xe2\x94\
k\x18s\x22\xda\x83A?\x8c\xfc\x8e\x0d\xc8o\xb7v\
\x8f\xab\xa9!\x82\x86*w\xfe\xd6;\x16\xf5\xc5\x19\xe8\
\xdd\xbb\xc5fZI\xf7d\xd1\x93^&\x1e\xf3\x11'\
_-6\x8f\x88\xdc\xcf\x9dUq\x91\xce\xf7\xffd\xf9\
6\x9d\xbe\xba\xfdp\x9cx\xf8\x8c\xb9s\x17\xb2\xb7\xa4\
=\x17u\xdd\x93E6\xb3\x1c\xe6\xba\x0db3\x19s\
\x22:\x18\x06\xfd0\xec9\x7f\xee\xee\xa0\x03\xc0\xcc\x91\
\x0eD}\xc7NoE\xbd\xbb\x1b\xd9\xa5\x19\xe1\x98_\
\xcb\x98\x13\xd1A1\xe8}(v\xefDv\xd3*K\
\xb79\xaa&\x84\xf1\xc3E\x1f\xa1?hNF\xddt\
{\xd4\xbb\xbb\xcb\x8fs\xdd\xb8Yl\xe4\xc8S\xaf\xc3\
\x88\x93\xaf\x12\x9bGD\xde\xc2\xa0\xf7\xa1k\xf5K\x96\
\xbf\x8ce\xce\x04\xf7\xef\x9d\xef\x8dQ?\x88=1\xdf\
$6r\xc4\xa9\xd7\xa1\xf1\xa4\xcf\x88\xcd#\x22\xefa\
\xd0\xfb\xd0i\xc3\xcbXfOp\xd7\xedj\xfd\xe1D\
\xd4\xf5\x8e\x9d\xc8\xdd\x92q]\xd4u\x97|\xccG\x9e\
v=F0\xe6Dt\x18\x0c\xfa!\x98\x85,\xba?\
|\xc3\xd2m\x0e\x8b\x19\x98\xde(\xff2\x16+8\xb3\
\xa7\xbe\x03\xb9[2\xd0\x9d\x9db3\xfb\xa2\xbb\xba\x91\
M-\x93\x8d\xf9\xa7\x9a\xd18\xf7J\xb1yD\xe4]\
\x0c\xfa!t\xad}\x15\xbaT\xb0t\x9b'\x8e\x8f\xc2\
\xa1w\xb1X\xc2\xa9\xa8g\x7f\x95v<\xea{b\xbe\
I\xf0\x9c\xf9\xa7\x9a\xd18\xe7\x0a\xb1yD\xe4m\x0c\
\xfa!\xd8\xf1\xee\xf3\x13]\xf80\x99\x81r,\xea\xb7\
\xa4\xa1;\xbb\xc4f\xeeMwv\xa1gi\x87X\xcc\
\x95R\x18uf\x821'\xa2\x01a\xd0\x0fB\x9b%\
t\xad}\xc5\xd2mFC\xc0\xd1c\xbcw\xfe\xfc`\
\x1c\x89\xfa\xf6\x1d\xe5\xb7\xb4\x09G]wv!\x9bZ\
\x06\xbdy\x8b\xc8<\xa5\x14F\x9e\x91@\xc3\x09\x17\x8b\
\xcc#\x22\xff`\xd0\x0f\xa2g\xdd\xdb(e\xad=\xc4\
{\xec\xd8\x18\xa2!K7\xe9(\xc7\xa2\xbe4\x03\xdd\
\xdd-2\xaf\x12sS0\xe6\xa3\xcelA\xc3\x09\x17\
\x89\xcc#\x22\x7fa\xd0\x0f\xc2\x96w\x9f\xfb\xe0p\xfb\
\xfef\x8e\x8c\xe0K\xd2\x8f\x89\xdd\xb2\x0d\xd9\xc5i\xdb\
\xa3\xeeD\xccG\x9e\xd9\x82\xfa\xe3/\x14\x99GD\xfe\
\xc3\xa0\x1f\x84\xd5\xef>7\x14p\xbc\x0f\x83\x0e\x003\
G8\x15u\xfb\xf6\xd4ug\x17\xb2K;d\xf7\xcc\
\xcfJ\xa2\x811'\xa2!`\xd0\xf7\x93\xdb\xb2\x16\x85\
]\xd6^\xfc4sD\x04\xc3b\xfe\xfd\xadv&\xea\
[\xcbQ\xef\xe9\xb1t\xbbz\xd7nd\x17\xa7an\
\xd9j\xe9v\x0f\xa5\x1c\xf3V\xd4\x1fw\x81\xc8<\x22\
\xf2/\xffVf\x90lyv\xbb\x07\x1f&3P\x8e\
E\xfd\x16\xeb\xa2n\xee\xdcU\xde3\xdf\xb6\xdd\x92\xed\
\x1d\xce'1?_d\x1e\x11\xf9\x1b\x83\xbe\x1f\xab\xdf\
}\x0e\xb8\xff\xedjVq&\xea[,\x89:cN\
D^\xc7\xa0\xef\xa5\xb0{\x0b\xf2[?\xb0t\x9b\x13\
\xebB\x18U\xe3\xa3\xcb\xdb\x0f\xc3\x8bQ\xd7\xbd1\xd7\
\xdbwX\xbc\xb2\x83SJa\xd4\xd9m\x8c9\x11Y\
\x8aA\xdfK\xe7\xfb/B[\xfc2\x96\xd9\xe3\xfd\x7f\
\xb8}\x7f^\x8a\xbac1?\xf6<\x91yD\x14\x1c\
\x0c\xfa^ly:\x5c@\x0e\xb7\xef\xcf\xb1\xa8\x0f\xe0\
B\xb9J\xccM\xc1\x98\x8f\xfe\xf4\x8d\x8c9\x11\xd9\x82\
A\xefU\xcav\xa2g\xdd\xdb\x96n\xb3\xbe\xca\xc0\x94\
zo\xbe\x8c\xc5\x0a\x8eD}s%\xea\xd9\xbe\x7f\xdd\
\x8e\x9d\xe8Y\x22\x17s(\x851\xf3>\x8f\xbac\xe6\
\xc9\xcc#\xa2\xc0a\xd0{u\xaf}\x05\xda,Y\xba\
\xcd9\x13bP\x1e~\x19\x8b\x15\x1c\x8b\xfa\x92CG\
\xdd\xdc\xb1\x13\xd9\xa5\xcb\xa0wH\xed\x99\x1b\x18;\xef\
\xf3\x18~\xe4Y\x22\xf3\x88(\x98\x18\xf4^\xbbmx\
:\xdc\x9c\x00\x9e??\x18G\xa2\xbeis\xf9\xdcx\
.\xb7\xcf?\xd7;w\x22\xbb\xa4C4\xe6c\xcec\
\xcc\x89\xc8~\x0c:\x00m\x16\xd1\xfd\xc1k\x96n\xb3\
:b`\xe6\xc8\xb0\xa5\xdb\xf4\xb2\x99#\x22\xf8[\xe9\
g\xbfo\xdc\x84\xec\xe2\x0c\x90\xcf\x03(\xc7\xbcgq\
\x07\xf4\xce\x9d\x22\xf3\x9520\xf6\xbc/`\xf8\x11g\
\x8a\xcc#\xa2`c\xd0\x01t}\xf0\x1a\xccB\xdf\xe7\
\x5c\x07\xea\xf8qQ\x84\xbd\xfc\xf2s\x1b\xcc\x1a\xe9L\
\xd4{\x16\xa7a\xae\xdf\x80\x9e[\xd2\xe21\x1fv\xc4\
\x19\x22\xf3\x88\x88\x18t\x00]|\x98\x8c\x18G\xa2\xbe\
a\x13z~\xb9\x04z\xd7n\x91y\xca\x08a\xec\x05\
\x7f\xc5\x98\x13\x91(\x06]ktZ\xfc2\x96\xb0\x01\
\x1c;\x86A?\x14'\xa2\x0e\x8b\x9f/p({\xf6\
\xccg\x9e&2\x8f\x88\xa8\x22\xf0A\xef\xd9\xf8\x1eJ\
\xdd\xd6\x1e\x86=jt\x14U\x11\x1en\xef\x8b#Q\
\xb7\x99R\x06\xc6\x9c\xbf\x08\xc3f\x9d\xee\xf4R\x88(\
\x80\x02\x1ft;^\xc6\xc2\xc3\xed\xfd\xe3\xa7\xa8+#\
\x84\xb1\x17~\x11\xc3\x19s\x22rH\xe0\x83n\xf5\xbb\
\xcf\x95\x02N\xf4\xe9\xbb\xcf\xed0kd\x04\x7fsz\
\x1d\xa2\x1e\x7f\xdc\xfd\xb8\x0b\xbf\x88a3Nqz\x19\
D\x14`\x81\x0ez~\xfb:\xe4\xb7\xaf\xb3t\x9bM\
\x0da\xd4Wy\xbcN\xc2\x8e\x1c\x1d\xc1\x97\xcf\xaa\xf7\
\xf4\x9ez\xed\xf4\x93\x9d^\x02\x11\x05\x5c\xa0\x83n\xcb\
\xbb\xcf\xf90\x99A\xf1\xd3\xe1w\x22\x22'\x04;\xe8\
\xbc]\xcdUf\x8d\x8c\xe0\xafO\x1f\xee\xf9\xc3\xefD\
DN\x08l\xd0K\xdd;\x91\xdd\xb4\xca\xd2m\xc6#\
\x0a\xe3\x86\xf1\xe9pCq\xd4\xe8(n:\xc3\xfd\xe7\
\xd4\xad~\xcd.\x11\xd1P\x056\xe8\x9d\xab_\xb2\xfc\
\xde\xe4lA\xe3\xae7\xba,\xddf\x10\x1d5:\x8a\
\x1bN\x18\xe6\xf42\x0eIk\x0d\x15\xf4\xb7\xee\x10\x91\
\xeb\x04vw\xb2\xd3\x86w\x9f\x03\xc0Cou\xa36\
j\xe0\xa2YU\xb6l\xdf\xaf4\x80\xd5\xdb\x8axy\
]\x0e+\xd7\xe5\xb1nW\xd1\xe9%\x1d\x12cND\
n\x14\xc8\xa0\x9b\x85,\xba?|\xc3\xb6\xed\xdf\xfeZ\
'\xaa#\x0ag5\xc5m\x9b\xe1\x07\x85\x92\xc6[\x9b\
\x0bx\xf9\xe3\x1cV\xae\xcfcg\xd6tzIDD\
\x9e\x15\xc8\xa0w\xad}\x15\xbaT\xb0m\xfbZ\x03\xa9\
\x97v\xa3&j`\xce\x04^$\xb7\xb7\xce\xbc\x89\xd7\
\xd6\xe7\xb1r}\x1e\xafo\xc8#[\xe4\xb9h\x22\x22\
+\x042\xe8\x9d6\xbc\xfb|\x7f\xa6\x06~\xf9\x87]\
\xf8\xd2\x99u8bT\xc4\xf6yn\xb6\xb5\xbb\x84\xd7\
7\x16\xf0\xca\xba<\xde\xd8\x98G\xd1d\xc4\x89\x88\xac\
\x16\xb8\xa0k\xb3\x84\xee\xb5\xaf\x88\xcc\xca\x974~\xfa\
\xbb\x9d\xf8\xfa\xa7\xeb1\xb9>X\xbf\xd5k\xb7fL\
\x1f\xae\x00\x00\x0b\x04IDAT\x17\xb1r}\x1e/\
\x7f\x9c\xc3\x87;\xdd{>\x9c\x88\xc8/\x82U\x19\x00\
=\xeb\xdeB)'w%zOA\xe3G\xcf\xed\xc4\
\xb7\xce\xad\xc7\x98Z\x97\xdf\x8b5\x04%\x0d\xbc\xb3\xb9\
\x80\x17?\xce\xe2\x95\xf5\x05l\xeb.9\xbd$\x22\xa2\
@\x09\x5c\xd0\xedx\xf7\xf9\xe1\xec\xce\x99\xf8qo\xd4\
\xeb\xe2\xfe\xb9S\xb0\xa7\xa0\xf1\xda\x86\xf2U\xe9\xafm\
\xc8\xa3\xbb\xc0C\xe9DDN\x09\x5c\xd0w;\x10t\
\x00\xd8\xdcU\xc2\x8f\x9e\xdb\x89\xaf\x7f\xba\x0e5Q\xef\
F}w^\xe3\xb5\xf59\xfc\xe9\xa3<\xde\xd8\x98C\
\x91\x17\xa6\x13\x11\xb9B\xa0\x82\x9e\xdb\xb2\x16\xc5\xdd[\
\x1c\x9b\xff\xd1\xce\x22\xfe\xeb7;\xf1\x95\xb3\xeb\x11\xf3\
\xd03\xcb?\xdaY\xc4\xcau9\xbc\xbc.\x8f\xb5;\
\x8aV?\x8f\x87\x88\x88,\x10\xa8\xa0\xdb\xf12\x96\x81\
Z\xb5\xad\x88\x9b_\xd8\x8d/~j\x18B\x86;\xa3\
nj\xe0\xdd\xad\xbd\xf7\x87\xaf\xcbcs\x17\xcf\x87\x13\
\x11\xb9]\xb0\x82\xee\xd0\xe1\xf6\xfd\xbd\xb2>\x87\xc5\x7f\
R\xf8\xdc\xc9\xc3\xe0\x96\x87\x8e\xe5\x8a\x1aol,`\
\xe5\xfa\x1c^Y\x97Cg\x9e\xbb\xe1DD^\x12\x98\
\xa0\x17woAn\xcbZ\xa7\x97\xb1\xc7\xef?\xc8\xa2\
:\xaa\xb0\xe0\xc4Z\xc7\xd6\xb0+kb\xe5\xfa<V\
\xae\xcb\xe3\xcf\x9b\xf2\xc8\x97\x18q\x22\x22\xaf\x0aL\xd0\
w\xbb\xe0p\xfb\xfe\x9e|\xaf\x07\x8d\xd5!\x5c,\xf8\
\xdc\xf7\x0d\xbbK{\xee\x0f_\xb5\xb5\x00&\x9c\x88\xc8\
\x1f\x02\x13\xf4.\x9b^\xc62Tw\xf4>\xf7\xfdl\
\x9b\x9e\xfb\xae\x01\xac\xdaZ\xc0\xcauy\xbc\xbc.\x87\
\x0d\xbb\x83}>\x5c\x85\xc2\xa8\x1a\x7f$\xba?|\xdd\
\xe9\xa5\x10\x11Y*\x10A/e;\xd1\xb3\xeem\xa7\
\x97qPZ\x03\xe9\x97v\xa3:\xa2p\xd2\xc4\x98%\
\xdb,\x944\xde\xdbZ~s\xd9\x8b\x1f\xe7\xb1\xa3'\
\xd8\x11\x0fU\x0dC\xf5\xe4\xe31\xaci\x0e\xaa'\x9f\
\x00#\x12\xc3{7\x7f\x0ef1o\xc9\xf6U\x98\xcf\
\xeb\x1f*#\x1c\xe5\xe7\xe1\x22\xfc<\xbc)\x10A\xef\
Z\xbb\x12\xdato\xd4\xca\xcf}/G\xfd\xe81\x83\
\xfb\x8f\xbf3o\xe2\xadM\x05\xac\x5cW~sYO\
\xc0\x1f\xf2\x12\xa9\x1b\x8d\x9a)'\xa2\xb6i\x0e\xaa\xc6\
\x1f\x09e\xec\xfb\x94\xbePu\x1d\xcc]\x9b-\x99\x15\
\xae\xae\xb3d;A\xc6\xcf\xc3]\xf8yxS \x82\
\xee\x86\xdb\xd5\x0e\xa7hj\xfc\xcf\xf3\xbb\xf0\xb5\xb3\xeb\
1\xa5\xa1\x7f\x1f\xcb\xd6n\x13\xafo\xcc\xe3\x95uy\
\xbc\xbe!\x87@_\xd3\xa6\x14\xe2\xa3\xa6\xa2f\xca\x89\
\x186\xe3TD\x1b'\xf4\xf9\xcb\xe3\xa3\xa7\xa1`\xd1\
\x17V|\xf44K\xb6\x13d\xfc<\xdc\x85\x9f\x877\
\xf9>\xe8\xda,z\xe6|iOA\xe3\xc7\xcf\xed\xc0\
7\xcfm\xc0\xd8a\x07\x7f\xee\xfb\xba]%\xfc\xf1\xa3\
,^]_\xc0\xda\x1d\x85@?\xe4E\x85\x22\xa8\x1a\
7\x0b5Sgc\xd8\x8cS\x10\xaei\xe8\xf7\xcf\xd6\
N;\x09\xbb\xdf{\xc1\x92u\xd4N;\xc9\x92\xed\x04\
\x19?\x0fw\xe1\xe7\xe1M\xbe\x0fz\xf7\x07\xaf\xc1,\
d\x9d^F\xbf\xed\xcek\xfc\xf0\xb9\x9d\xf8\xd69u\
h\xac\x0e\xc1\xd4\xc0\xaam\x05\xfc\xf1\xc3\x1c^\xfa8\
\x87\xed=\xc1~\xd6j(^\x8b\xaa\x09G\xa3\xb6i\
6j\xa7\x9d\x04#2\xb8\x8b\x09k\xa7\x9d\x84\xc8\xf0\
QC\xde\x0b\x89\x0c\x1b\x89\xda\xe9\xfc\xc2\x1a*~\x1e\
\xee\xc2\xcf\xc3\x9b|\x1ft7\xde\xaev8\xdb\xbaK\
\xf8\xd7gv\xa0\xa9!\x8c77\x15\xd1]\x08v\xc4\
\xc3\xc3F\xa2\xb6i\xce!\xcf\x87\x0f\x86\x0a\x851\xea\
\xf4\xf9X\xf7\xc8O\x86\xb4\x9dQg,\x802|\xff\
\xc7\xc8v\xfc<\xdc\x85\x9f\x877\xf9\xfbwZkt\
\xad]\xe9\xf4*\x06ek\xb7\x89\xad\xdd\xd6\x5ce\xea\
E\xd1\xc6\x09\x186\xfd\x14\xd4L\x9d\x8d\xf8\xe8&[\
f\xd4N?\x19\xf5\xc7_\x88\x1d\xaf>6\xa8\x9f\xaf\
?\xfeB\xd4N?\xd9\xe2U\x05\x17?\x0fw\xe1\xe7\
\xe1=\xbe\x0ez\xcf\x86wQ\xea\xde\xe9\xf42\xa8\x1f\
\x94\x11B|\xcct\xd4N?\x05\xc3\xa6\x9f\x8cpm\
\xa3\xc8\xdc\xd1g\xb6\x00\xc0\x80\xbf\xb4\xea\x8f\xbfp\xcf\
\xcf\x92u\xf8y\xb8\x0b?\x0fo\xf1u\xd0\x9dx\xf7\
9\xf5\x9f\x11\x89\xa1z\xc2\xd1\xa8\x9dq\x0aj\xa6\xce\
A(V-\xbf\x08\xa50\xfa\xac$\xaa\xc7\x1f\x89\xcd\
\xbf\xed@a\xf7\xd6>\x7fyd\xd8\x08\x8c:#\xc1\
=\x0f\xbb\xf0\xf3p\x17~\x1e\x9e\xe2\xeb\xa0\xef^\xed\
\xbd\xf3\xe7~\x17\xae\x1d\x81\x9a)\xc7\xa3v\xealT\
O:\x0e*\xe4\x8e\xff\x04k\xa7\x9f\x8c\x9a\xa9\xb3\xd1\
\xf9\xfe\x9f\xd0\xb9\xfaEd7\xbe\x8fbg\xf9\xcb+\
\x5c;\x02\xf11\xd3P\xdb4\x17\xb5\xd3Nr\xcd\x9a\
\xfd\x8c\x9f\x87\xbb\xf0\xf3\xf0\x06\xdf\xfe\xce\xe7\xb7}\x8c\
\xc2\x8e\x0dN/\x83P>\x1f^;uv\xf9|\xf8\
\xd8\x99Pny\xc5\xdc~T(\x8ca3O\xc3\xb0\
\x99\xa79\xbd\x14\x02?\x0f\xb7\xe1\xe7\xe1~\xbe\x0dz\
\xa7K\x9f\xdd\x1e\x04J\x19\x88\x8f\x9dQ\xbe?|\xda\
I\x88\xd4\x8fuzIDD\xbe\xe7\xdf\xa0{\xf0v\
5/S\xe1(j&\x1e\x83\x9a\xa9\xb3Q;m.\
BU\xc3\x9d^\x12\x11Q\xa0\xf82\xe8\xc5\xae\xed\xc8\
mz\xdf\xe9e\xf8^(>\x0c\xd5S\x8e\xc7\xf0\x19\
\xa7\xa2z\xf2q\xbc\xdf\x94\x88\xc8A\xbe\xfc\x06\xee\x5c\
\xf32t\x90\x9f\x89j\xa3\xf2\xf9\xf09\xa8\x996\x17\
\xf1\xd1\xd3\x5c{>\x9c\x88(h|\x19\xf4.\x1en\
\xb7\xce\xde/=\x99y\x1a\xa2\x0d\xe3\x9d^\x11\x11\x11\
\x1d\x84\xef\x82n\x16\xb2\xe8\xfe\xf8\xcfN/\xc3\xd3\x8c\
p\x14\xf1\xb13{_zr*\xc25\xf5N/\x89\
\x88\x88\x0e\xc3wA\xefZ\xfb\x0at\xa9\xe0\xf42<\
'\x14\xafE\xf5\x94\x130\xaci\x0e\xaa'\x1f?\xe8\
\x97\x9e\x10\x11\x913\xfc\x17t>\x1d\xae\xdf\x22\xc3G\
\x95\xafJ\xb7\xf0\xa5'DD\xe4\x0c_\x05]\x9b%\
t\xae\xf1\xe6\xcbXD(\x85\xf8\xe8\xde':5\xcd\
A\xb4q\x82\xd3+\x22\x22\x22\x8b\xf8*\xe8=\x1f\xff\
\x19f\xbe\xdb\xe9e\xb8\x8a\x0aEP5nV\xef\xf9\
\xf0S\x10\xaeipzIDDd\x03_\x05\x9d\x0f\
\x93)\x0b\xc5jP5\xf1\x18\xd46\xcdFm\xd3\x5c\
\x18\xd1*\xa7\x97DDD6\xf3M\xd0\xb5\xd6\xe8Z\
\xfb\xb2\xd3\xcbpLd\xd8HTO>\xceu/=\
!\x22\x22\x19\xbe\xf9\xd6\xcfm^s\xd8W\xfb\xf9\x8d\
W^zBDD\xf6\xf3M\xd0\xbb\x02\xf02\x96\xca\
KOj\xa7\x9f\x82\xdai'!2l\x84\xd3K\x22\
\x22\x22\x97\xf0M\xd0\xfdz\xfe\xbc\xf2\xd2\x93\xda\x19\xa7\
\xa0\xb6i\x0e\x8ch\xb5\xd3K\x22\x22\x22\x17\xf2E\xd0\
\x0b\xbb\xb7\x22\xb7\xf5C\xa7\x97a\x99pM\x03j\x9b\
\xe6\xa0\xa6i.\xaa'\x1c\xc5\xf3\xe1DDtX\xbe\
(En\xd3*\xa7\x970d\x91\xba\xd1\xe5\xe7\xa5\xcf\
8\x95\xe7\xc3\x89\x88h\xc0\xfc\x11\xf4\xad\x1f9\xbd\x84\
\x01S\xca@|\xdc,\xd4N\x9b\x8b\xda\xa9s\x10\xa9\
\x1b\xed\xf4\x92\x88\x88\xc8\xc3|\x11t\xb3\x90uz\x09\
\xfdbDb\xa8\x9et\x5c\xf9p\xfa\xd4\xd9\x08\xc5k\
\x9d^\x12\x11\x11\xf9\x84/\x82\xee\xe6\x07\xa7\x84\xaa\x86\
\xa1z\xf2\xf1|\xe9\x09\x11\x11\xd9\xca\x17Aw\xdb;\
\xba\xa3\xf5\xe3P\xd34\x07\xb5\xd3\xe6\xa2j\xcc\x0c\x80\
\xe7\xc3\x89\x88\xc8f\xbe\x08z\xf5\x84\xa3\xa0\x8c\x10\xb4\
Yrf\x01J\xa1j\xcc\x0c\xd4N\x9b\x8b\x9a\xa69\
\x88\xd6\x8fsf\x1dDD\x14X\xbe\x08z\xa8j8\
j\xa6\x9c\x88\xce\xd5r\xf7\xa2\xabP\x045\x93\x8eE\
M\xef\xf9\xf0pu\x9d\xd8l\x22\x22\xa2\xfd\xf9\x22\xe8\
\x000\xf2\xd4k\xd1\xb5\xe6ehm\xda6#\x14\xaf\
\xdd\xf3\xfe\xf0\xeaI\xc7\xc1\x88\xc4l\x9bEDD4\
\x10\xbe\x09zt\xc4$4\x9e|\x15\xb6\xfe\xe1.K\
\xb7\x1b\x1e6\x125\x95\x97\x9eL>\x1e\xca\x08Y\xba\
}\x22\x22\x22+\xf8&\xe8\x00\xd0x\xd2U(v\xed\
\xc0\xce7\x9e\x1a\xd2v\xa2\x8d\x130l\xfa)\xa8\x99\
:\x1b\xb1QS\xf9\x90\x17\x22\x22r=_\x05])\
\x85\xd1\x9f\xbe\x11\xd1\xba\xd1\xd8\xf2\xc2\x1d\xd0\xa5b\xff\
~.\x14F\xf5\x84\xa3P\xd34\x17\xb5Ms\x10\xae\
i\xb0y\xa5DDD\xd6\xf2U\xd0\x81r\xd4\x1bf\
_\x86\xdai'a\xdb\x8b\xf7c\xf7{\xcf\xc3,\xe4\
\x0e\xf8uF\xb4\x1a5SN(?\xe4e\xca\x09\xae\
\xbe\x97\x9d\x88\x88\xe8p|\x17\xf4\x8aH\xdd\x18\x8c\x99\
\xf7\x17\x18}\xce\x8d\xc8nX\x85\xc2\xaeM\xd0\xa5\x22\
\x8cp\x14\xd1\x91\x93\x11m\x9c\x00\xa5\x0c\xa7\x97ID\
Dd\x09\xdf\x06\xbdB\x19aT\x8d?\x02U\xe3\x8f\
pz)DDD\xb6\xe1.*\x11\x11\x91\x0f0\xe8\
DDD>\xc0\xa0\x13\x11\x11\xf9\x00\x83NDD\xe4\
\x03\x0c:\x11\x11\x91\x0f0\xe8DDD>\xc0\xa0\x13\
\x11\x11\xf9\x00\x83NDD\xe4\x03\x0c:\x11\x11\x91\x0f\
0\xe8DDD>\xc0\xa0\x13\x11\x11\xf9\x00\x83ND\
D\xe4\x03\x0c:\x11\x11\x91\x0f0\xe8DDD> \
\xfa\xfaT3\xd7\x85U\xff\xef/%G\x12\x11\x11\xd9\
B\x17\xb2N/a\x1f\xa2A\xd7Z\xa3\x94\xeb\x92\x1c\
IDD\x14\x08<\xe4NDD\xe4\x03\x0c:\x11\x11\
\x91\x0f0\xe8DDD>\xc0\xa0\x13\x11\x11\xf9\x00\x83\
NDD\xe4\x03\x0c:\x11\x11\x91\x0f0\xe8DDD\
>\xc0\xa0\x13\x11\x11\xf9@\x9fA\x8f\xc7\xe39\xa9\x85\
\x10\x11\x11\x05Ycc\xe3\x90\x9a\xab\xb4\xd6}\xfe\x82\
d2\xb9\x1b@\xedP\x86\x10\x11\x11Q\x9fv\xa4\xd3\
\xe9\x86\xa1l\xa0?\x87\xdc_\x1a\xca\x00\x22\x22\x22:\
\xac!\xb7\xb6?A\xbfw\xa8C\x88\x88\x88\xe8\xd0\xb4\
\xd6\xf7\x0cu\x1b\x87\x0d\xbaa\x18K\x01\xec\x1a\xea \
\x22\x22\x22:\xa8\x1dZ\xeb\xccP7r\xd8\xa0/]\
\xbat+\x80\x7f\x1e\xea \x22\x22\x22:\x90\xd6\xfa\xbb\
\x1d\x1d\x1d\xdb\x87\xba\x9d~\xdd\xb66c\xc6\x8c\x1f\x01\
xp\xa8\xc3\x88\x88\x88h\x1f\xf7\xcd\x9c9\xf3'V\
l\xe8\xb0W\xb9W,Z\xb4\xa8\xba\xbb\xbb{\x05\x80\
\xcb\xac\x18LDD\x14p\xf7\xe5r\xb9\xcf\xaeX\xb1\
\xa2\xc7\x8a\x8d\xf5\xfb\xc127\xdf|s\xf7\x8c\x193\
\xae\x04\xf05\x00]V\x0c'\x22\x22\x0a\xa0N\x00_\
\x991c\xc6\xd5V\xc5\x1c\x18\xc0\x1e\xfa\xde\xda\xda\xda\
F\x98\xa6\xb9\x10\xc0\x95\x00f\x03\xa8\xb1jADD\
D>\xd4\x85\xf2\xadi\xf7\xe5r\xb9[V\xacX\xb1\
\xcd\xea\x01\x83\x0a\xfa\xfe\xda\xdb\xdb\xeb\xf3\xf9\xbc\xb2`\
=DDD\xbe\x12\x8dF\xf5\xe2\xc5\x8bw\xd8=\xc7\
\x92\xa0\x13\x11\x11\x91\xb3\xf8r\x16\x22\x22\x22\x1f`\xd0\
\x89\x88\x88|\x80A'\x22\x22\xf2\x01\x06\x9d\x88\x88\xc8\
\x07\x18t\x22\x22\x22\x1f`\xd0\x89\x88\x88|\x80A'\
\x22\x22\xf2\x01\x06\x9d\x88\x88\xc8\x07\x18t\x22\x22\x22\x1f\
`\xd0\x89\x88\x88|\x80A'\x22\x22\xf2\x01\x06\x9d\x88\
\x88\xc8\x07\x18t\x22\x22\x22\x1f`\xd0\x89\x88\x88|\x80\
A'\x22\x22\xf2\x01\x06\x9d\x88\x88\xc8\x07\x18t\x22\x22\
\x22\x1f`\xd0\x89\x88\x88|\x80A'\x22\x22\xf2\x01\x06\
\x9d\x88\x88\xc8\x07\x18t\x22\x22\x22\x1f`\xd0\x89\x88\x88\
|\x80A'\x22\x22\xf2\x81\xff\x1f\x9d\xd5\x9e\x06\x1d.\
\x1dW\x00\x00\x00\x00IEND\xaeB`\x82\
\x00\x00\x07\xbc\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -5.400\
9 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg2\x22\x0a   sodipo\
di:docname=\x22roun\
drectangle.svg\x22\x0a\
   inkscape:vers\
ion=\x221.4 (86a8ad\
7, 2024-10-11)\x22\x0a\
   xmlns:inkscap\
e=\x22http://www.in\
kscape.org/names\
paces/inkscape\x22\x0a\
   xmlns:sodipod\
i=\x22http://sodipo\
di.sourceforge.n\
et/DTD/sodipodi-\
0.dtd\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22>\x0a  <defs\x0a\
     id=\x22defs2\x22 \
/>\x0a  <sodipodi:n\
amedview\x0a     id\
=\x22namedview2\x22\x0a  \
   pagecolor=\x22#0\
00000\x22\x0a     bord\
ercolor=\x22#FFFFFF\
\x22\x0a     borderopa\
city=\x220.25\x22\x0a    \
 inkscape:showpa\
geshadow=\x222\x22\x0a   \
  inkscape:pageo\
pacity=\x220.0\x22\x0a   \
  inkscape:pagec\
heckerboard=\x22tru\
e\x22\x0a     inkscape\
:deskcolor=\x22#d1d\
1d1\x22\x0a     inksca\
pe:zoom=\x2224.3125\
\x22\x0a     inkscape:\
cx=\x2215.979434\x22\x0a \
    inkscape:cy=\
\x2216\x22\x0a     inksca\
pe:window-width=\
\x221920\x22\x0a     inks\
cape:window-heig\
ht=\x22996\x22\x0a     in\
kscape:window-x=\
\x22-9\x22\x0a     inksca\
pe:window-y=\x22-9\x22\
\x0a     inkscape:w\
indow-maximized=\
\x221\x22\x0a     inkscap\
e:current-layer=\
\x22svg2\x22 />\x0a  <g\x0a \
    transform=\x22t\
ranslate(-1.5048\
977350235, -4.98\
78532699585)\x22\x0a  \
   id=\x22g2\x22\x0a     \
style=\x22stroke:no\
ne;stroke-opacit\
y:1;fill:#ffffff\
;fill-opacity:1\x22\
>\x0a    <g\x0a       \
transform=\x22matri\
x(0.062348168343\
3056, 0, 0, 0.06\
23481683433056, \
0, 0)\x22\x0a       id\
=\x22g1\x22\x0a       sty\
le=\x22stroke:none;\
stroke-opacity:1\
;fill:#ffffff;fi\
ll-opacity:1\x22>\x0a \
     <path\x0a     \
    d=\x22m 118.021\
32,79.991827 c -\
51.66714,0 -93.8\
8432,42.217183 -\
93.88432,93.8843\
23 V 326.121 c 0\
,51.66714 42.217\
18,93.88432 93.8\
8432,93.88432 h \
261.32234 c 51.6\
6714,0 93.88432,\
-42.21718 93.884\
32,-93.88432 V 1\
73.87615 c 0,-51\
.66714 -42.21718\
,-93.884323 -93.\
88432,-93.884323\
 z m 0,40.003433\
 h 261.32234 c 3\
0.19903,0 53.880\
89,23.68186 53.8\
8089,53.88089 V \
326.121 c 0,30.1\
9903 -23.68186,5\
3.88089 -53.8808\
9,53.88089 H 118\
.02132 c -30.199\
029,0 -53.880889\
,-23.68186 -53.8\
80889,-53.88089 \
V 173.87615 c 0,\
-30.19903 23.681\
86,-53.88089 53.\
880889,-53.88089\
 z\x22\x0a         sty\
le=\x22fill:#ffffff\
;stroke:none;fil\
l-opacity:1\x22\x0a   \
      id=\x22path5\x22\
 />\x0a    </g>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x08)\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2.855\
 32 32\x22\x0a   versi\
on=\x221.1\x22\x0a   id=\x22\
svg1\x22\x0a   sodipod\
i:docname=\x22pan.s\
vg\x22\x0a   inkscape:\
version=\x221.4 (86\
a8ad7, 2024-10-1\
1)\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   xmlns:sod\
ipodi=\x22http://so\
dipodi.sourcefor\
ge.net/DTD/sodip\
odi-0.dtd\x22\x0a   xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
\x0a   xmlns:svg=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a  <d\
efs\x0a     id=\x22def\
s1\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  id=\x22namedview1\
\x22\x0a     pagecolor\
=\x22#000000\x22\x0a     \
bordercolor=\x22#00\
0000\x22\x0a     borde\
ropacity=\x220.25\x22\x0a\
     inkscape:sh\
owpageshadow=\x222\x22\
\x0a     inkscape:p\
ageopacity=\x220.0\x22\
\x0a     inkscape:p\
agecheckerboard=\
\x22true\x22\x0a     inks\
cape:deskcolor=\x22\
#d1d1d1\x22\x0a     in\
kscape:zoom=\x2224.\
3125\x22\x0a     inksc\
ape:cx=\x2215.97943\
4\x22\x0a     inkscape\
:cy=\x2216\x22\x0a     in\
kscape:window-wi\
dth=\x221920\x22\x0a     \
inkscape:window-\
height=\x22996\x22\x0a   \
  inkscape:windo\
w-x=\x22-9\x22\x0a     in\
kscape:window-y=\
\x22-9\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22svg1\x22 />\x0a  \
<g\x0a     id=\x22Laye\
r_1\x22\x0a     transf\
orm=\x22translate(0\
, 0.0196)\x22\x0a     \
style=\x22enable-ba\
ckground:new 0 0\
 32 32;fill:#fff\
fff;fill-opacity\
:1\x22>\x0a    <g\x0a    \
   transform=\x22ma\
trix(0.875683128\
833771, 0, 0, 0.\
875683128833771,\
 0, 0)\x22\x0a       i\
d=\x22g1\x22\x0a       st\
yle=\x22fill:#fffff\
f;fill-opacity:1\
\x22>\x0a      <path\x0a \
        d=\x22M31.1\
, 8.3C30, 7.6 28\
.6, 8.1 28.2, 9.\
2L26.3, 13.3C26.\
1, 13.7 25.7, 13\
.9 25.3, 13.9L25\
.3, 13.9C24.6, 1\
3.9 24.1, 13.3 2\
4.3, 12.6L26, 4.\
4C26.2, 3.3 25.6\
, 2.3 24.5, 2C23\
.4, 1.8 22.4, 2.\
4 22.1, 3.5L20.2\
, 11.1C20.1, 11.\
6 19.7, 11.9 19.\
2, 11.9L19.1, 11\
.9C18.5, 11.9 18\
, 11.4 18, 10.8L\
18, 2.1C18, 1.1 \
17.3, 0.2 16.4, \
0C15.1, -0.2 14,\
 0.8 14, 2L14, 1\
0.9C14, 11.5 13.\
5, 12 12.9, 12L1\
2.8, 12C12.3, 12\
 11.9, 11.7 11.8\
, 11.2L10, 3.6C9\
.7, 2.4 8.4, 1.7\
 7.3, 2.2C6.3, 2\
.5 5.9, 3.6 6.1,\
 4.6L8.6, 15.9C8\
.8, 16.7 7.9, 17\
.4 7.1, 17L3.1, \
14.4C2.3, 13.9 1\
.3, 14 0.6, 14.7\
C-0.2, 15.5 -0.2\
, 16.8 0.6, 17.6\
L10.9, 28C12.1, \
29.3 13.9, 30 15\
.8, 30L20, 30C22\
.9, 30 24.7, 28 \
25.9, 25.2L31.8,\
 10.9C32.2, 10 3\
1.9, 8.9 31.1, 8\
.3z\x22\x0a         fi\
ll=\x22#FFFFFF\x22\x0a   \
      id=\x22path1\x22\
\x0a         style=\
\x22fill:#ffffff;fi\
ll-opacity:1\x22 />\
\x0a    </g>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x08\xc1\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg4\
\x22\x0a   sodipodi:do\
cname=\x22print.svg\
\x22\x0a   inkscape:ve\
rsion=\x221.4 (86a8\
ad7, 2024-10-11)\
\x22\x0a   xmlns:inksc\
ape=\x22http://www.\
inkscape.org/nam\
espaces/inkscape\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s=\x22http://www.w3\
.org/2000/svg\x22\x0a \
  xmlns:svg=\x22htt\
p://www.w3.org/2\
000/svg\x22>\x0a  <def\
s\x0a     id=\x22defs4\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
id=\x22namedview4\x22\x0a\
     pagecolor=\x22\
#000000\x22\x0a     bo\
rdercolor=\x22#0000\
00\x22\x0a     bordero\
pacity=\x220.25\x22\x0a  \
   inkscape:show\
pageshadow=\x222\x22\x0a \
    inkscape:pag\
eopacity=\x220.0\x22\x0a \
    inkscape:pag\
echeckerboard=\x22t\
rue\x22\x0a     inksca\
pe:deskcolor=\x22#d\
1d1d1\x22\x0a     inks\
cape:zoom=\x2224.31\
25\x22\x0a     inkscap\
e:cx=\x2215.979434\x22\
\x0a     inkscape:c\
y=\x2216\x22\x0a     inks\
cape:window-widt\
h=\x221920\x22\x0a     in\
kscape:window-he\
ight=\x22996\x22\x0a     \
inkscape:window-\
x=\x22-9\x22\x0a     inks\
cape:window-y=\x22-\
9\x22\x0a     inkscape\
:window-maximize\
d=\x221\x22\x0a     inksc\
ape:current-laye\
r=\x22svg4\x22 />\x0a  <g\
\x0a     id=\x22Layer_\
1\x22\x0a     transfor\
m=\x22translate(-2,\
 -2)\x22\x0a     style\
=\x22enable-backgro\
und:new 0 0 32 3\
2;fill:#ffffff;f\
ill-opacity:1\x22>\x0a\
    <g\x0a       id\
=\x22Printer\x22\x0a     \
  style=\x22fill:#f\
fffff;fill-opaci\
ty:1\x22>\x0a      <g\x0a\
         id=\x22g1\x22\
\x0a         style=\
\x22fill:#ffffff;fi\
ll-opacity:1\x22>\x0a \
       <polygon\x0a\
           point\
s=\x2210,4 22,4 22,\
12 24,12 24,2 8,\
2 8,12 10,12   \x22\
\x0a           fill\
=\x22#FFFFFF\x22\x0a     \
      class=\x22Bla\
ck\x22\x0a           i\
d=\x22polygon1\x22\x0a   \
        style=\x22f\
ill:#ffffff;fill\
-opacity:1\x22 />\x0a \
     </g>\x0a    </\
g>\x0a  </g>\x0a  <g\x0a \
    id=\x22g4\x22\x0a    \
 transform=\x22tran\
slate(-2, -2.000\
00095367432)\x22\x0a  \
   style=\x22enable\
-background:new \
0 0 32 32;fill:#\
ffffff;fill-opac\
ity:1\x22>\x0a    <g\x0a \
      id=\x22g3\x22\x0a  \
     style=\x22fill\
:#ffffff;fill-op\
acity:1\x22>\x0a      \
<g\x0a         id=\x22\
g2\x22\x0a         sty\
le=\x22fill:#ffffff\
;fill-opacity:1\x22\
>\x0a        <path\x0a\
           d=\x22M2\
8, 10L26, 10L26,\
 13C26, 13.6 25.\
6, 14 25, 14L7, \
14C6.4, 14 6, 13\
.6 6, 13L6, 10L4\
, 10C2.9, 10 2, \
10.9 2, 12L2, 24\
C2, 25.1 2.9, 26\
 4, 26L8, 26L8, \
30L24, 30L24, 26\
L28, 26C29.1, 26\
 30, 25.1 30, 24\
L30, 12C30, 10.9\
 29.1, 10 28, 10\
zM22, 24L22, 26L\
22, 28L10, 28L10\
, 26L10, 24L10, \
20L22, 20L22, 24\
z\x22\x0a           fi\
ll=\x22#FFFFFF\x22\x0a   \
        class=\x22B\
lack\x22\x0a          \
 id=\x22path1\x22\x0a    \
       style=\x22fi\
ll:#ffffff;fill-\
opacity:1\x22 />\x0a  \
    </g>\x0a    </g\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x08\x97\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-4 -4 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg4\
\x22\x0a   sodipodi:do\
cname=\x22cut.svg\x22\x0a\
   inkscape:vers\
ion=\x221.4 (86a8ad\
7, 2024-10-11)\x22\x0a\
   xmlns:inkscap\
e=\x22http://www.in\
kscape.org/names\
paces/inkscape\x22\x0a\
   xmlns:sodipod\
i=\x22http://sodipo\
di.sourceforge.n\
et/DTD/sodipodi-\
0.dtd\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22>\x0a  <defs\x0a\
     id=\x22defs4\x22 \
/>\x0a  <sodipodi:n\
amedview\x0a     id\
=\x22namedview4\x22\x0a  \
   pagecolor=\x22#0\
00000\x22\x0a     bord\
ercolor=\x22#000000\
\x22\x0a     borderopa\
city=\x220.25\x22\x0a    \
 inkscape:showpa\
geshadow=\x222\x22\x0a   \
  inkscape:pageo\
pacity=\x220.0\x22\x0a   \
  inkscape:pagec\
heckerboard=\x220\x22\x0a\
     inkscape:de\
skcolor=\x22#d1d1d1\
\x22\x0a     inkscape:\
zoom=\x2224.3125\x22\x0a \
    inkscape:cx=\
\x2215.979434\x22\x0a    \
 inkscape:cy=\x2216\
\x22\x0a     inkscape:\
window-width=\x2219\
20\x22\x0a     inkscap\
e:window-height=\
\x22996\x22\x0a     inksc\
ape:window-x=\x22-9\
\x22\x0a     inkscape:\
window-y=\x22-9\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g4\x22 />\x0a  <g\x0a    \
 id=\x22Layer_1\x22\x0a  \
   transform=\x22tr\
anslate(-4, -4)\x22\
\x0a     style=\x22ena\
ble-background:n\
ew 0 0 32 32\x22>\x0a \
   <g\x0a       id=\
\x22Cut\x22>\x0a      <pa\
th\x0a         d=\x22M\
9, 18C6.2, 18 4,\
 20.2 4, 23C4, 2\
5.8 6.2, 28 9, 2\
8C11.8, 28 14, 2\
5.8 14, 23C14, 2\
0.2 11.8, 18 9, \
18zM9, 26C7.3, 2\
6 6, 24.7 6, 23C\
6, 21.3 7.3, 20 \
9, 20C10.7, 20 1\
2, 21.3 12, 23C1\
2, 24.7 10.7, 26\
 9, 26z\x22\x0a       \
  fill=\x22#FFFFFF\x22\
\x0a         class=\
\x22Black\x22\x0a        \
 id=\x22path1\x22 />\x0a \
   </g>\x0a  </g>\x0a \
 <g\x0a     id=\x22g2\x22\
\x0a     transform=\
\x22translate(-4, -\
4)\x22\x0a     style=\x22\
enable-backgroun\
d:new 0 0 32 32\x22\
>\x0a    <g\x0a       \
id=\x22g1\x22>\x0a      <\
polygon\x0a        \
 points=\x2220.7,14\
.8 26,4 17.4,11.\
6  \x22\x0a         fi\
ll=\x22#FFFFFF\x22\x0a   \
      class=\x22Bla\
ck\x22\x0a         id=\
\x22polygon1\x22 />\x0a  \
  </g>\x0a  </g>\x0a  \
<g\x0a     id=\x22g4\x22\x0a\
     transform=\x22\
translate(-4, -4\
)\x22\x0a     style=\x22e\
nable-background\
:new 0 0 32 32\x22>\
\x0a    <g\x0a       i\
d=\x22g3\x22>\x0a      <p\
ath\x0a         d=\x22\
M23, 18C22.4, 18\
 21.8, 18.1 21.3\
, 18.3L6, 4L13, \
18L16, 18L18.6, \
20.6C18.2, 21.3 \
18, 22.1 18, 23C\
18, 25.8 20.2, 2\
8 23, 28C25.8, 2\
8 28, 25.8 28, 2\
3C28, 20.2 25.8,\
 18 23, 18zM23, \
26C21.3, 26 20, \
24.7 20, 23C20, \
21.3 21.3, 20 23\
, 20C24.7, 20 26\
, 21.3 26, 23C26\
, 24.7 24.7, 26 \
23, 26z\x22\x0a       \
  fill=\x22#FFFFFF\x22\
\x0a         class=\
\x22Black\x22\x0a        \
 id=\x22path2\x22 />\x0a \
   </g>\x0a  </g>\x0a<\
/svg>\x0a\
\x00\x00\x06\xe9\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-1.9999 -\
2.7367 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg2\x22\x0a   s\
odipodi:docname=\
\x22select-rectangl\
e-gray.svg\x22\x0a   i\
nkscape:version=\
\x221.4 (e7c3feb100\
, 2024-10-09)\x22\x0a \
  xmlns:inkscape\
=\x22http://www.ink\
scape.org/namesp\
aces/inkscape\x22\x0a \
  xmlns:sodipodi\
=\x22http://sodipod\
i.sourceforge.ne\
t/DTD/sodipodi-0\
.dtd\x22\x0a   xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns:svg=\x22http:/\
/www.w3.org/2000\
/svg\x22>\x0a  <defs\x0a \
    id=\x22defs2\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     id=\
\x22namedview2\x22\x0a   \
  pagecolor=\x22#00\
0000\x22\x0a     borde\
rcolor=\x22#FFFFFF\x22\
\x0a     borderopac\
ity=\x220.25\x22\x0a     \
inkscape:showpag\
eshadow=\x222\x22\x0a    \
 inkscape:pageop\
acity=\x220.0\x22\x0a    \
 inkscape:pagech\
eckerboard=\x220\x22\x0a \
    inkscape:des\
kcolor=\x22#d1d1d1\x22\
\x0a     inkscape:z\
oom=\x2212.609375\x22\x0a\
     inkscape:cx\
=\x2211.697646\x22\x0a   \
  inkscape:cy=\x221\
8.042131\x22\x0a     i\
nkscape:window-w\
idth=\x221920\x22\x0a    \
 inkscape:window\
-height=\x22969\x22\x0a  \
   inkscape:wind\
ow-x=\x220\x22\x0a     in\
kscape:window-y=\
\x220\x22\x0a     inkscap\
e:window-maximiz\
ed=\x221\x22\x0a     inks\
cape:current-lay\
er=\x22svg2\x22 />\x0a  <\
g\x0a     transform\
=\x22translate(-4.4\
2104959106445, -\
5.89473290176392\
)\x22\x0a     id=\x22g2\x22\x0a\
     style=\x22fill\
:#FFFFFF;fill-op\
acity:1;stroke:n\
one;stroke-opaci\
ty:1\x22>\x0a    <g\x0a  \
     transform=\x22\
matrix(1.4736832\
3802948, 0, 0, 1\
.47368323802948,\
 0, 0)\x22\x0a       i\
d=\x22g1\x22\x0a       st\
yle=\x22fill:#FFFFF\
F;fill-opacity:1\
;stroke:none;str\
oke-opacity:1\x22>\x0a\
      <path\x0a    \
     d=\x22M14, 17L\
17, 17L17, 14L19\
, 14L19, 17L22, \
17L22, 19L19, 19\
L19, 22L17, 22L1\
7, 19L14, 19zM12\
, 17L12, 19L9, 1\
9L9, 17zM7, 17L7\
, 19L3, 19L3, 15\
L5, 15L5, 17zM3,\
 13L3, 10L5, 10L\
5, 13zM3, 8L3, 4\
L7, 4L7, 6L5, 6L\
5, 8zM9, 4L12, 4\
L12, 6L9, 6zM15,\
 4L19, 4L19, 8L1\
7, 8L17, 6L15, 6\
zM19, 10L19, 12L\
17, 12L17, 10z\x22\x0a\
         id=\x22pat\
h1\x22\x0a         sty\
le=\x22fill:#FFFFFF\
;fill-opacity:1;\
stroke:none;stro\
ke-opacity:1\x22 />\
\x0a    </g>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x0fn\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x2232\x22\x0a   heig\
ht=\x2232\x22\x0a   viewB\
ox=\x220 0 32 32\x22\x0a \
  fill=\x22none\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg2\x22\x0a   s\
odipodi:docname=\
\x22mirror.svg\x22\x0a   \
inkscape:version\
=\x221.4 (86a8ad7, \
2024-10-11)\x22\x0a   \
xmlns:inkscape=\x22\
http://www.inksc\
ape.org/namespac\
es/inkscape\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns=\x22ht\
tp://www.w3.org/\
2000/svg\x22\x0a   xml\
ns:svg=\x22http://w\
ww.w3.org/2000/s\
vg\x22>\x0a  <defs\x0a   \
  id=\x22defs2\x22 />\x0a\
  <sodipodi:name\
dview\x0a     id=\x22n\
amedview2\x22\x0a     \
pagecolor=\x22#0000\
00\x22\x0a     borderc\
olor=\x22#FFFFFF\x22\x0a \
    borderopacit\
y=\x220.25\x22\x0a     in\
kscape:showpages\
hadow=\x222\x22\x0a     i\
nkscape:pageopac\
ity=\x220.0\x22\x0a     i\
nkscape:pagechec\
kerboard=\x22true\x22\x0a\
     inkscape:de\
skcolor=\x22#d1d1d1\
\x22\x0a     inkscape:\
zoom=\x2224.3125\x22\x0a \
    inkscape:cx=\
\x2215.979434\x22\x0a    \
 inkscape:cy=\x2216\
\x22\x0a     inkscape:\
window-width=\x2219\
20\x22\x0a     inkscap\
e:window-height=\
\x22996\x22\x0a     inksc\
ape:window-x=\x22-9\
\x22\x0a     inkscape:\
window-y=\x22-9\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g2\x22 />\x0a  <path\x0a \
    id=\x22path4\x22\x0a \
    style=\x22basel\
ine-shift:baseli\
ne;display:inlin\
e;overflow:visib\
le;vector-effect\
:none;fill:#ffff\
ff;enable-backgr\
ound:accumulate;\
stop-color:#0000\
00;stop-opacity:\
1;fill-opacity:1\
\x22\x0a     d=\x22M 16 1\
 C 14.1038 1 12.\
33305 1.9476406 \
11.28125 3.52539\
06 L 10.257812 5\
.0605469 C 9.968\
202 5.4949469 9.\
5704756 5.846598\
1 9.1035156 6.08\
00781 L 7.519531\
2 6.8710938 C 5.\
1040312 8.078843\
8 4.0850769 10.9\
87353 5.2167969 \
13.439453 L 5.81\
83594 14.742188 \
C 6.1865194 15.5\
39886 6.1865194 \
16.460113 5.8183\
594 17.257812 L \
5.2167969 18.560\
547 C 4.0850769 \
21.012647 5.1040\
214 23.921106 7.\
5195312 25.12890\
6 L 9.1035156 25\
.919922 C 9.5704\
856 26.153422 9.\
968202 26.505053\
 10.257812 26.93\
9453 L 11.28125 \
28.474609 C 12.3\
3305 30.052309 1\
4.1038 31 16 31 \
C 17.8962 31 19.\
66695 30.052309 \
20.71875 28.4746\
09 L 21.742188 2\
6.939453 C 22.03\
1788 26.505053 2\
2.429584 26.1534\
22 22.896484 25.\
919922 L 24.4804\
69 25.128906 C 2\
6.895969 23.9211\
06 27.914903 21.\
012647 26.783203\
 18.560547 L 26.\
181641 17.257812\
 C 25.813441 16.\
460113 25.813441\
 15.539887 26.18\
1641 14.742188 L\
 26.783203 13.43\
9453 C 27.914903\
 10.987353 26.89\
5969 8.0788439 2\
4.480469 6.87109\
38 L 22.896484 6\
.0800781 C 22.42\
9584 5.8465981 2\
2.031788 5.49493\
69 21.742188 5.0\
605469 L 20.7187\
5 3.5253906 C 19\
.66695 1.9476406\
 17.8962 1 16 1 \
z M 16 3 C 17.22\
75 3 18.373788 3\
.6134156 19.0546\
88 4.6347656 L 2\
0.078125 6.16992\
19 C 20.560825 6\
.8939119 21.2236\
53 7.4800106 22.\
001953 7.8691406\
 L 23.585938 8.6\
601562 C 25.0352\
38 9.3848061 25.\
645797 11.130262\
 24.966797 12.60\
1562 L 24.365234\
 13.904297 C 23.\
751634 15.233797\
 23.751634 16.76\
6203 24.365234 1\
8.095703 L 24.96\
6797 19.398438 C\
 25.645797 20.86\
9737 25.035238 2\
2.615144 23.5859\
38 23.339844 L 2\
2.001953 24.1308\
59 C 21.223653 2\
4.520059 20.5608\
25 25.106078 20.\
078125 25.830078\
 L 19.054688 27.\
365234 C 18.3737\
87 28.386534 17.\
2275 29 16 29 C \
14.7725 29 13.62\
6212 28.386534 1\
2.945312 27.3652\
34 L 11.921875 2\
5.830078 C 11.43\
9175 25.106078 1\
0.774384 24.5200\
59 9.9960938 24.\
130859 L 8.41406\
25 23.339844 C 6\
.9647625 22.6151\
44 6.3541631 20.\
869737 7.0332031\
 19.398438 L 7.6\
347656 18.095703\
 C 8.2483656 16.\
766203 8.2483656\
 15.233797 7.634\
7656 13.904297 L\
 7.0332031 12.60\
1562 C 6.3541731\
 11.130261 6.964\
7625 9.3848062 8\
.4140625 8.66015\
62 L 9.9960938 7\
.8691406 C 10.77\
4384 7.4800106 1\
1.439175 6.89391\
19 11.921875 6.1\
699219 L 12.9453\
12 4.6347656 C 1\
3.626212 3.61341\
56 14.7725 3 16 \
3 z M 16 5.41015\
62 C 12.2665 5.4\
101562 9.2402344\
 10.275997 9.240\
2344 16.279297 C\
 9.2402344 22.28\
2697 12.2665 27.\
150391 16 27.150\
391 C 19.7334 27\
.150391 22.75976\
6 22.282697 22.7\
59766 16.279297 \
C 22.759766 10.2\
75997 19.7334 5.\
4101562 16 5.410\
1562 z M 20.8964\
84 11.132812 C 2\
1.439884 12.6229\
12 21.759766 14.\
379797 21.759766\
 16.279297 C 21.\
759766 19.124497\
 21.041641 21.65\
27 19.931641 23.\
4375 C 18.812541\
 25.237 17.395 2\
6.150391 16 26.1\
50391 C 14.6049 \
26.150391 13.187\
459 25.237 12.06\
8359 23.4375 C 1\
1.672759 22.8014\
 11.328275 22.07\
1225 11.046875 2\
1.265625 L 20.89\
6484 11.132812 z\
 \x22 />\x0a</svg>\x0a\
\x00\x00\x08F\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg7\
\x22\x0a   sodipodi:do\
cname=\x22fullscree\
nexit.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (86a8ad7, 20\
24-10-11)\x22\x0a   xm\
lns:inkscape=\x22ht\
tp://www.inkscap\
e.org/namespaces\
/inkscape\x22\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:svg=\x22http://www\
.w3.org/2000/svg\
\x22>\x0a  <defs\x0a     \
id=\x22defs7\x22 />\x0a  \
<sodipodi:namedv\
iew\x0a     id=\x22nam\
edview7\x22\x0a     pa\
gecolor=\x22#000000\
\x22\x0a     bordercol\
or=\x22#000000\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x22true\x22\x0a  \
   inkscape:desk\
color=\x22#d1d1d1\x22\x0a\
     inkscape:zo\
om=\x2224.3125\x22\x0a   \
  inkscape:cx=\x221\
5.979434\x22\x0a     i\
nkscape:cy=\x2216\x22\x0a\
     inkscape:wi\
ndow-width=\x221920\
\x22\x0a     inkscape:\
window-height=\x229\
96\x22\x0a     inkscap\
e:window-x=\x22-9\x22\x0a\
     inkscape:wi\
ndow-y=\x22-9\x22\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0a \
    inkscape:cur\
rent-layer=\x22svg7\
\x22 />\x0a  <g\x0a     i\
d=\x22Layer_1\x22\x0a    \
 transform=\x22tran\
slate(-2, -2)\x22\x0a \
    style=\x22enabl\
e-background:new\
 0 0 32 32\x22>\x0a   \
 <g\x0a       id=\x22F\
ullScreenExit\x22>\x0a\
      <polygon\x0a \
        points=\x22\
24,8 24,2 20,2 2\
0,12 30,12 30,8 \
 \x22\x0a         fill\
=\x22#FFFFFF\x22\x0a     \
    class=\x22Black\
\x22\x0a         id=\x22p\
olygon1\x22 />\x0a    \
</g>\x0a  </g>\x0a  <g\
\x0a     id=\x22g3\x22\x0a  \
   transform=\x22tr\
anslate(-2, -2)\x22\
\x0a     style=\x22ena\
ble-background:n\
ew 0 0 32 32\x22>\x0a \
   <g\x0a       id=\
\x22g2\x22>\x0a      <pol\
ygon\x0a         po\
ints=\x222,24 8,24 \
8,30 12,30 12,20\
 2,20  \x22\x0a       \
  fill=\x22#FFFFFF\x22\
\x0a         class=\
\x22Black\x22\x0a        \
 id=\x22polygon2\x22 /\
>\x0a    </g>\x0a  </g\
>\x0a  <g\x0a     id=\x22\
g5\x22\x0a     transfo\
rm=\x22translate(-2\
, -2)\x22\x0a     styl\
e=\x22enable-backgr\
ound:new 0 0 32 \
32\x22>\x0a    <g\x0a    \
   id=\x22g4\x22>\x0a    \
  <polygon\x0a     \
    points=\x228,8 \
2,8 2,12 12,12 1\
2,2 8,2  \x22\x0a     \
    fill=\x22#FFFFF\
F\x22\x0a         clas\
s=\x22Black\x22\x0a      \
   id=\x22polygon3\x22\
 />\x0a    </g>\x0a  <\
/g>\x0a  <g\x0a     id\
=\x22g7\x22\x0a     trans\
form=\x22translate(\
-2, -2)\x22\x0a     st\
yle=\x22enable-back\
ground:new 0 0 3\
2 32\x22>\x0a    <g\x0a  \
     id=\x22g6\x22>\x0a  \
    <polygon\x0a   \
      points=\x2220\
,30 24,30 24,24 \
30,24 30,20 20,2\
0  \x22\x0a         fi\
ll=\x22#FFFFFF\x22\x0a   \
      class=\x22Bla\
ck\x22\x0a         id=\
\x22polygon5\x22 />\x0a  \
  </g>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x08\xb8\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -6.605\
 32 32\x22\x0a   versi\
on=\x221.1\x22\x0a   id=\x22\
svg3\x22\x0a   sodipod\
i:docname=\x22redo-\
gray.svg\x22\x0a   ink\
scape:version=\x221\
.4 (e7c3feb100, \
2024-10-09)\x22\x0a   \
xmlns:inkscape=\x22\
http://www.inksc\
ape.org/namespac\
es/inkscape\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns=\x22ht\
tp://www.w3.org/\
2000/svg\x22\x0a   xml\
ns:svg=\x22http://w\
ww.w3.org/2000/s\
vg\x22>\x0a  <defs\x0a   \
  id=\x22defs3\x22 />\x0a\
  <sodipodi:name\
dview\x0a     id=\x22n\
amedview3\x22\x0a     \
pagecolor=\x22#0000\
00\x22\x0a     borderc\
olor=\x22#FFFFFF\x22\x0a \
    borderopacit\
y=\x220.25\x22\x0a     in\
kscape:showpages\
hadow=\x222\x22\x0a     i\
nkscape:pageopac\
ity=\x220.0\x22\x0a     i\
nkscape:pagechec\
kerboard=\x220\x22\x0a   \
  inkscape:deskc\
olor=\x22#d1d1d1\x22\x0a \
    inkscape:zoo\
m=\x2225.21875\x22\x0a   \
  inkscape:cx=\x221\
6\x22\x0a     inkscape\
:cy=\x2216\x22\x0a     in\
kscape:window-wi\
dth=\x221920\x22\x0a     \
inkscape:window-\
height=\x22969\x22\x0a   \
  inkscape:windo\
w-x=\x220\x22\x0a     ink\
scape:window-y=\x22\
0\x22\x0a     inkscape\
:window-maximize\
d=\x221\x22\x0a     inksc\
ape:current-laye\
r=\x22svg3\x22 />\x0a  <g\
\x0a     transform=\
\x22translate(-11.9\
71, -16.5763)\x22\x0a \
    id=\x22g3\x22\x0a    \
 style=\x22fill:#FF\
FFFF;fill-opacit\
y:1\x22>\x0a    <g\x0a   \
    transform=\x22m\
atrix(0.20289853\
2152176, 0, 0, 0\
.202898532152176\
, 0, 0)\x22\x0a       \
id=\x22g2\x22\x0a       s\
tyle=\x22fill:#FFFF\
FF;fill-opacity:\
1\x22>\x0a      <g\x0a   \
      id=\x22g1\x22\x0a  \
       style=\x22fi\
ll:#FFFFFF;fill-\
opacity:1\x22>\x0a    \
    <path\x0a      \
     d=\x22M13.8659\
97, 0C17.570007,\
 0.0000001 21.05\
3009, 1.7499998 \
23.67099, 4.9230\
035C24.899994, 6\
.4070119 25.8559\
88, 8.126006 26.\
537994, 9.990995\
3L30.934998, 4.0\
270075L32, 20.67\
3L18.665985, 20.\
673L23.264008, 1\
4.436003C22.8890\
08, 12.231993 21\
.997986, 10.2030\
01 20.653992, 8.\
574004C18.841003\
, 6.376006 16.43\
1, 5.1650079 13.\
865997, 5.165007\
9C11.302002, 5.1\
650079 8.8919983\
, 6.376006 7.080\
9937, 8.574004C5\
.2640076, 10.766\
996 4.2659912, 1\
3.691007 4.26599\
12, 16.798002C4.\
2659912, 18.4389\
91 4.553009, 20.\
019009 5.0830078\
, 21.479L0.55700\
68, 21.479C0.195\
0073, 19.976986 \
0, 18.402004 0, \
16.798002C0, 12.\
311003 1.4440002\
, 8.0899953 4.06\
20117, 4.9230035\
C6.6789856, 1.74\
99998 10.158997,\
 0.0000001 13.86\
5997, 0z\x22\x0a      \
     fill=\x22#FFFF\
FF\x22\x0a           i\
d=\x22path1\x22\x0a      \
     transform=\x22\
rotate(0, 128, 1\
28) translate(59\
, 81.68590605258\
94) scale(4.3125\
)\x22\x0a           st\
yle=\x22fill:#FFFFF\
F;fill-opacity:1\
\x22 />\x0a      </g>\x0a\
    </g>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x09\xe3\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2.0175 \
-2 32 32\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22 >\x0d\x0a\
  <g id=\x22Capa_1\x22\
 transform=\x22tran\
slate(-0.0176003\
814697268, -5.14\
984130894902E-07\
)\x22 style=\x22enable\
-background:new \
0 0 297 297\x22>\x0d\x0a \
   <g transform=\
\x22matrix(0.094276\
0929465294, 0, 0\
, 0.094276092946\
5294, 0, 0)\x22>\x0d\x0a \
     <g>\x0d\x0a      \
  <path d=\x22M150.\
079, 100.075C150\
.077, 100.075 15\
0.075, 100.075 1\
50.073, 100.075L\
120.034, 100.093\
L120.048, 70.048\
C120.051, 64.549\
 115.594, 60.087\
 110.095, 60.085\
C110.093, 60.085\
 110.092, 60.085\
 110.09, 60.085C\
104.592, 60.085 \
100.136, 64.539 \
100.133, 70.038L\
100.118, 100.103\
L70.051, 100.121\
C64.552, 100.124\
 60.095, 104.584\
 60.098, 110.084\
C60.101, 115.584\
 64.559, 120.037\
 70.057, 120.037\
C70.059, 120.037\
 70.061, 120.037\
 70.063, 120.037\
L100.109, 120.01\
9L100.094, 150.0\
69C100.091, 155.\
568 104.548, 160\
.028 110.047, 16\
0.031C110.049, 1\
60.031 110.05, 1\
60.031 110.052, \
160.031C115.55, \
160.031 120.007,\
 155.577 120.01,\
 150.079L120.025\
, 120.009L150.08\
6, 119.991C155.5\
85, 119.988 160.\
04, 115.527 160.\
037, 110.027C160\
.034, 104.529 15\
5.576, 100.075 1\
50.079, 100.075z\
\x22 fill=\x22#FFFFFF\x22\
 class=\x22Black\x22 /\
>\x0d\x0a      </g>\x0d\x0a \
   </g>\x0d\x0a  </g>\x0d\
\x0a  <g id=\x22Capa_1\
\x22 transform=\x22tra\
nslate(-0.0176, \
0)\x22 style=\x22enabl\
e-background:new\
 0 0 297 297\x22>\x0d\x0a\
    <g transform\
=\x22matrix(0.09427\
60929465294, 0, \
0, 0.09427609294\
65294, 0, 0)\x22>\x0d\x0a\
      <g>\x0d\x0a     \
   <path d=\x22M288\
.969, 246.75L206\
.053, 163.745C22\
9.421, 121.855 2\
23.342, 67.803 1\
87.811, 32.237C1\
67.048, 11.449 1\
39.438, 0 110.06\
9, 0C80.701, 0 5\
3.091, 11.449 32\
.323, 32.237C-10\
.54, 75.148 -10.\
54, 144.966 32.3\
23, 187.868C53.0\
9, 208.661 80.70\
1, 220.111 110.0\
69, 220.111C129.\
164, 220.111 147\
.51, 215.266 163\
.719, 206.167L24\
6.598, 289.138C2\
51.662, 294.209 \
258.412, 297 265\
.607, 297C272.8,\
 297 279.552, 29\
4.209 284.617, 2\
89.138L288.971, \
284.778C299.443,\
 274.293 299.442\
, 257.232 288.96\
9, 246.75zM46.41\
2, 173.794C11.30\
4, 138.651 11.30\
5, 81.462 46.412\
, 46.311C63.418,\
 29.291 86.024, \
19.916 110.069, \
19.916C134.114, \
19.916 156.719, \
29.291 173.722, \
46.311C208.834, \
81.46 208.834, 1\
38.649 173.72, 1\
73.795C156.719, \
190.819 134.114,\
 200.195 110.069\
, 200.195C86.024\
, 200.195 63.418\
, 190.819 46.412\
, 173.794zM274.8\
79, 270.704L270.\
524, 275.064C269\
.225, 276.366 26\
7.478, 277.084 2\
65.607, 277.084C\
263.737, 277.084\
 261.991, 276.36\
5 260.689, 275.0\
64L180.378, 194.\
664C182.94, 192.\
522 185.424, 190\
.261 187.81, 187\
.87C190.203, 185\
.476 192.453, 18\
2.992 194.578, 1\
80.441L274.879, \
260.825C277.553,\
 263.502 277.553\
, 268.025 274.87\
9, 270.704z\x22 fil\
l=\x22#FFFFFF\x22 clas\
s=\x22Black\x22 />\x0d\x0a  \
    </g>\x0d\x0a    </\
g>\x0d\x0a  </g>\x0d\x0a</sv\
g>\
\x00\x00\x0e\xbf\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Uploa\
ded to: SVG Repo\
, www.svgrepo.co\
m, Generator: SV\
G Repo Mixer Too\
ls -->\x0a\x0a<svg\x0a   \
width=\x22800px\x22\x0a  \
 height=\x22800px\x22\x0a\
   viewBox=\x220 0 \
24 24\x22\x0a   fill=\x22\
none\x22\x0a   version\
=\x221.1\x22\x0a   id=\x22sv\
g10\x22\x0a   sodipodi\
:docname=\x22serial\
-port-svgrepo-co\
m.svg\x22\x0a   inksca\
pe:export-filena\
me=\x22serial-port-\
svgrepo-com.png\x22\
\x0a   inkscape:exp\
ort-xdpi=\x223.8399\
999\x22\x0a   inkscape\
:export-ydpi=\x223.\
8399999\x22\x0a   inks\
cape:version=\x221.\
4 (86a8ad7, 2024\
-10-11)\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0a\
   xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22\x0a   xmlns:s\
vg=\x22http://www.w\
3.org/2000/svg\x22>\
\x0a  <defs\x0a     id\
=\x22defs10\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     id=\x22name\
dview10\x22\x0a     pa\
gecolor=\x22#000000\
\x22\x0a     bordercol\
or=\x22#FFFFFF\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x220\x22\x0a     \
inkscape:deskcol\
or=\x22#d1d1d1\x22\x0a   \
  inkscape:zoom=\
\x220.97875\x22\x0a     i\
nkscape:cx=\x22400\x22\
\x0a     inkscape:c\
y=\x22400\x22\x0a     ink\
scape:window-wid\
th=\x221920\x22\x0a     i\
nkscape:window-h\
eight=\x221001\x22\x0a   \
  inkscape:windo\
w-x=\x22-9\x22\x0a     in\
kscape:window-y=\
\x22-9\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22svg10\x22 />\x0a \
 <path\x0a     d=\x22M\
6.99998 11.5C7.4\
142 11.5 7.74998\
 11.1642 7.74998\
 10.75C7.74998 1\
0.3358 7.4142 10\
 6.99998 10C6.58\
577 10 6.24998 1\
0.3358 6.24998 1\
0.75C6.24998 11.\
1642 6.58577 11.\
5 6.99998 11.5Z\x22\
\x0a     fill=\x22#FFF\
FFF\x22\x0a     id=\x22pa\
th1\x22 />\x0a  <path\x0a\
     d=\x22M10.25 1\
0.75C10.25 11.16\
42 9.9142 11.5 9\
.49998 11.5C9.08\
577 11.5 8.74998\
 11.1642 8.74998\
 10.75C8.74998 1\
0.3358 9.08577 1\
0 9.49998 10C9.9\
142 10 10.25 10.\
3358 10.25 10.75\
Z\x22\x0a     fill=\x22#F\
FFFFF\x22\x0a     id=\x22\
path2\x22 />\x0a  <pat\
h\x0a     d=\x22M8.249\
98 14C8.6642 14 \
8.99998 13.6642 \
8.99998 13.25C8.\
99998 12.8358 8.\
6642 12.5 8.2499\
8 12.5C7.83577 1\
2.5 7.49998 12.8\
358 7.49998 13.2\
5C7.49998 13.664\
2 7.83577 14 8.2\
4998 14Z\x22\x0a     f\
ill=\x22#FFFFFF\x22\x0a  \
   id=\x22path3\x22 />\
\x0a  <path\x0a     d=\
\x22M11.5 13.25C11.\
5 13.6642 11.164\
2 14 10.75 14C10\
.3358 14 9.99998\
 13.6642 9.99998\
 13.25C9.99998 1\
2.8358 10.3358 1\
2.5 10.75 12.5C1\
1.1642 12.5 11.5\
 12.8358 11.5 13\
.25Z\x22\x0a     fill=\
\x22#FFFFFF\x22\x0a     i\
d=\x22path4\x22 />\x0a  <\
path\x0a     d=\x22M13\
.25 14C13.6642 1\
4 14 13.6642 14 \
13.25C14 12.8358\
 13.6642 12.5 13\
.25 12.5C12.8358\
 12.5 12.5 12.83\
58 12.5 13.25C12\
.5 13.6642 12.83\
58 14 13.25 14Z\x22\
\x0a     fill=\x22#FFF\
FFF\x22\x0a     id=\x22pa\
th5\x22 />\x0a  <path\x0a\
     d=\x22M16.5 13\
.25C16.5 13.6642\
 16.1642 14 15.7\
5 14C15.3358 14 \
15 13.6642 15 13\
.25C15 12.8358 1\
5.3358 12.5 15.7\
5 12.5C16.1642 1\
2.5 16.5 12.8358\
 16.5 13.25Z\x22\x0a  \
   fill=\x22#FFFFFF\
\x22\x0a     id=\x22path6\
\x22 />\x0a  <path\x0a   \
  d=\x22M12 11.5C12\
.4142 11.5 12.75\
 11.1642 12.75 1\
0.75C12.75 10.33\
58 12.4142 10 12\
 10C11.5858 10 1\
1.25 10.3358 11.\
25 10.75C11.25 1\
1.1642 11.5858 1\
1.5 12 11.5Z\x22\x0a  \
   fill=\x22#FFFFFF\
\x22\x0a     id=\x22path7\
\x22 />\x0a  <path\x0a   \
  d=\x22M15.25 10.7\
5C15.25 11.1642 \
14.9142 11.5 14.\
5 11.5C14.0858 1\
1.5 13.75 11.164\
2 13.75 10.75C13\
.75 10.3358 14.0\
858 10 14.5 10C1\
4.9142 10 15.25 \
10.3358 15.25 10\
.75Z\x22\x0a     fill=\
\x22#FFFFFF\x22\x0a     i\
d=\x22path8\x22 />\x0a  <\
path\x0a     d=\x22M17\
 11.5C17.4142 11\
.5 17.75 11.1642\
 17.75 10.75C17.\
75 10.3358 17.41\
42 10 17 10C16.5\
858 10 16.25 10.\
3358 16.25 10.75\
C16.25 11.1642 1\
6.5858 11.5 17 1\
1.5Z\x22\x0a     fill=\
\x22#FFFFFF\x22\x0a     i\
d=\x22path9\x22 />\x0a  <\
path\x0a     d=\x22M4.\
90701 6.99933C3.\
13073 6.99933 1.\
82042 8.65816 2.\
23177 10.3862L3.\
30329 14.8875C3.\
5982 16.1263 4.7\
0507 17.0007 5.9\
7854 17.0007H18.\
0172C19.2901 17.\
0007 20.3966 16.\
1271 20.6921 14.\
889L21.7664 10.3\
877C22.1789 8.65\
932 20.8685 6.99\
933 19.0915 6.99\
933H4.90701ZM3.6\
9099 10.0388C3.5\
0402 9.25334 4.0\
9961 8.49933 4.9\
0701 8.49933H19.\
0915C19.8992 8.4\
9933 20.4949 9.2\
5387 20.3074 10.\
0395L19.2331 14.\
5408C19.0988 15.\
1036 18.5958 15.\
5007 18.0172 15.\
5007H5.97854C5.3\
9969 15.5007 4.8\
9657 15.1032 4.7\
6252 14.5401L3.6\
9099 10.0388Z\x22\x0a \
    fill=\x22#FFFFF\
F\x22\x0a     id=\x22path\
10\x22 />\x0a</svg>\x0a\
\x00\x00\x02\xc1\
<\
?xml version=\x221.\
0\x22 encoding=\x22iso\
-8859-1\x22?>\x0d\x0a<!--\
 Uploaded to: SV\
G Repo, www.svgr\
epo.com, Generat\
or: SVG Repo Mix\
er Tools -->\x0d\x0a<!\
DOCTYPE svg PUBL\
IC \x22-//W3C//DTD \
SVG 1.1//EN\x22 \x22ht\
tp://www.w3.org/\
Graphics/SVG/1.1\
/DTD/svg11.dtd\x22>\
\x0d\x0a<svg fill=\x22#FF\
FFFF\x22 version=\x221\
.1\x22 id=\x22Capa_1\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22  \x0d\x0a\x09 width=\x228\
00px\x22 height=\x2280\
0px\x22 viewBox=\x220 \
0 498.78 498.781\
\x22\x0d\x0a\x09 xml:space=\x22\
preserve\x22>\x0d\x0a<g>\x0d\
\x0a\x09<g>\x0d\x0a\x09\x09<polygo\
n points=\x22452.88\
,439.875 45.9,43\
9.875 45.9,367.9\
65 0,367.965 0,4\
85.775 498.78,48\
5.775 498.78,366\
.435 452.88,366.\
435 \x09\x09\x0d\x0a\x09\x09\x09\x22/>\x0d\x0a\
\x09\x09<polygon point\
s=\x22134.086,241.5\
57 134.086,406.2\
15 374.333,406.2\
15 374.333,241.5\
57 438.082,241.5\
57 254.209,13.00\
5 \x0d\x0a\x09\x09\x0970.334,24\
1.557 \x09\x09\x22/>\x0d\x0a\x09</\
g>\x0d\x0a</g>\x0d\x0a</svg>\
\
\x00\x00\x0a\xb9\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   fi\
ll=\x22none\x22\x0a   hei\
ght=\x2214\x22\x0a   view\
Box=\x220 0 14 14\x22\x0a\
   width=\x2214\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg9\x22\x0a   s\
odipodi:docname=\
\x22edit-select-are\
a-rectangle-dash\
.svg\x22\x0a   inkscap\
e:version=\x221.4 (\
86a8ad7, 2024-10\
-11)\x22\x0a   xmlns:i\
nkscape=\x22http://\
www.inkscape.org\
/namespaces/inks\
cape\x22\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0a   \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22\x0a   xmlns:svg=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a  \
<defs\x0a     id=\x22d\
efs9\x22 />\x0a  <sodi\
podi:namedview\x0a \
    id=\x22namedvie\
w9\x22\x0a     pagecol\
or=\x22#000000\x22\x0a   \
  bordercolor=\x22#\
000000\x22\x0a     bor\
deropacity=\x220.25\
\x22\x0a     inkscape:\
showpageshadow=\x22\
2\x22\x0a     inkscape\
:pageopacity=\x220.\
0\x22\x0a     inkscape\
:pagecheckerboar\
d=\x22true\x22\x0a     in\
kscape:deskcolor\
=\x22#d1d1d1\x22\x0a     \
inkscape:zoom=\x225\
5.571429\x22\x0a     i\
nkscape:cx=\x227.00\
89974\x22\x0a     inks\
cape:cy=\x227\x22\x0a    \
 inkscape:window\
-width=\x221920\x22\x0a  \
   inkscape:wind\
ow-height=\x22996\x22\x0a\
     inkscape:wi\
ndow-x=\x22-9\x22\x0a    \
 inkscape:window\
-y=\x22-9\x22\x0a     ink\
scape:window-max\
imized=\x221\x22\x0a     \
inkscape:current\
-layer=\x22svg9\x22 />\
\x0a  <clipPath\x0a   \
  id=\x22a\x22>\x0a    <p\
ath\x0a       d=\x22m0\
 0h14v14h-14z\x22\x0a \
      id=\x22path1\x22\
 />\x0a  </clipPath\
>\x0a  <g\x0a     clip\
-path=\x22url(#a)\x22\x0a\
     stroke=\x22#00\
0001\x22\x0a     strok\
e-linecap=\x22round\
\x22\x0a     stroke-li\
nejoin=\x22round\x22\x0a \
    id=\x22g9\x22\x0a    \
 style=\x22fill:non\
e;fill-opacity:1\
;stroke:#ffffff;\
stroke-opacity:1\
\x22>\x0a    <path\x0a   \
    d=\x22m 11.5,0.\
5 h 1 c 0.2652,0\
 0.5196,0.105357\
 0.7071,0.292893\
 C 13.3946,0.980\
43 13.5,1.23478 \
13.5,1.5 v 1\x22\x0a  \
     id=\x22path2\x22\x0a\
       style=\x22di\
splay:inline;fil\
l:none;fill-opac\
ity:1;stroke-lin\
ejoin:round;stro\
ke-linecap:round\
;paint-order:nor\
mal;fill-rule:ev\
enodd;stroke:#ff\
ffff;stroke-opac\
ity:1\x22 />\x0a    <p\
ath\x0a       d=\x22m.\
5 2.5v-1c0-.2652\
2.105357-.51957.\
292893-.707107.1\
87537-.187536.44\
1887-.292893.707\
107-.292893h1\x22\x0a \
      id=\x22path3\x22\
\x0a       style=\x22f\
ill:none;fill-op\
acity:1;stroke:#\
ffffff;stroke-op\
acity:1\x22 />\x0a    \
<path\x0a       d=\x22\
m5.5.5h3\x22\x0a      \
 id=\x22path4\x22\x0a    \
   style=\x22fill:n\
one;fill-opacity\
:1;stroke:#fffff\
f;stroke-opacity\
:1\x22 />\x0a    <path\
\x0a       d=\x22m13.5\
 5.5v3\x22\x0a       i\
d=\x22path5\x22\x0a      \
 style=\x22fill:non\
e;fill-opacity:1\
;stroke:#ffffff;\
stroke-opacity:1\
\x22 />\x0a    <path\x0a \
      d=\x22m.5 5.5\
v3\x22\x0a       id=\x22p\
ath6\x22\x0a       sty\
le=\x22fill:none;fi\
ll-opacity:1;str\
oke:#ffffff;stro\
ke-opacity:1\x22 />\
\x0a    <path\x0a     \
  d=\x22m11.5 13.5h\
1c.2652 0 .5196-\
.1054.7071-.2929\
s.2929-.4419.292\
9-.7071v-1\x22\x0a    \
   id=\x22path7\x22\x0a  \
     style=\x22fill\
:none;fill-opaci\
ty:1;stroke:#fff\
fff;stroke-opaci\
ty:1\x22 />\x0a    <pa\
th\x0a       d=\x22m.5\
 11.5v1c0 .2652.\
105357.5196.2928\
93.7071.187537.1\
875.441887.2929.\
707107.2929h1\x22\x0a \
      id=\x22path8\x22\
\x0a       style=\x22f\
ill:none;fill-op\
acity:1;stroke:#\
ffffff;stroke-op\
acity:1\x22 />\x0a    \
<path\x0a       d=\x22\
m5.5 13.5h3\x22\x0a   \
    id=\x22path9\x22\x0a \
      style=\x22fil\
l:none;fill-opac\
ity:1;stroke:#ff\
ffff;stroke-opac\
ity:1\x22 />\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x0c,\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2.052\
5 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg5\x22\x0a   sodipo\
di:docname=\x22sett\
ings.svg\x22\x0a   ink\
scape:version=\x221\
.4 (86a8ad7, 202\
4-10-11)\x22\x0a   xml\
ns:inkscape=\x22htt\
p://www.inkscape\
.org/namespaces/\
inkscape\x22\x0a   xml\
ns:sodipodi=\x22htt\
p://sodipodi.sou\
rceforge.net/DTD\
/sodipodi-0.dtd\x22\
\x0a   xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
>\x0a  <defs\x0a     i\
d=\x22defs5\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     id=\x22name\
dview5\x22\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#000000\x22\x0a    \
 borderopacity=\x22\
0.25\x22\x0a     inksc\
ape:showpageshad\
ow=\x222\x22\x0a     inks\
cape:pageopacity\
=\x220.0\x22\x0a     inks\
cape:pagechecker\
board=\x22true\x22\x0a   \
  inkscape:deskc\
olor=\x22#d1d1d1\x22\x0a \
    inkscape:zoo\
m=\x2224.3125\x22\x0a    \
 inkscape:cx=\x2215\
.979434\x22\x0a     in\
kscape:cy=\x2216\x22\x0a \
    inkscape:win\
dow-width=\x221920\x22\
\x0a     inkscape:w\
indow-height=\x2299\
6\x22\x0a     inkscape\
:window-x=\x22-9\x22\x0a \
    inkscape:win\
dow-y=\x22-9\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg5\x22\
 />\x0a  <g\x0a     id\
=\x22Layer_1\x22\x0a     \
transform=\x22trans\
late(-3.0107, -1\
.0059)\x22\x0a     sty\
le=\x22fill:#ffffff\
;fill-opacity:1\x22\
>\x0a    <g\x0a       \
transform=\x22matri\
x(1.003584623336\
79, 0, 0, 1.0035\
8462333679, 0, 0\
)\x22\x0a       id=\x22g2\
\x22\x0a       style=\x22\
fill:#ffffff;fil\
l-opacity:1\x22>\x0a  \
    <g\x0a         \
id=\x22g1\x22\x0a        \
 style=\x22fill:#ff\
ffff;fill-opacit\
y:1\x22>\x0a        <p\
ath\x0a           d\
=\x22M27.1, 19.2C27\
.2, 19 27.3, 18.\
8 27.3, 18.5C27.\
4, 18.3 27.4, 18\
.1 27.5, 18L30.9\
, 17L30.9, 13L27\
.5, 12C27.4, 11.\
8 27.4, 11.6 27.\
3, 11.5C27.2, 11\
.3 27.2, 11 27.1\
, 10.8C27, 10.6 \
26.9, 10.4 26.8,\
 10.2C26.7, 10 2\
6.6, 9.9 26.6, 9\
.7L28.3, 6.6L25.\
5, 3.8L22.4, 5.5\
C22.2, 5.4 22.1,\
 5.3 21.9, 5.3C2\
1.7, 5.2 21.5, 5\
.1 21.3, 5C21.1,\
 4.9 20.9, 4.8 2\
0.6, 4.8C20.4, 4\
.7 20.3, 4.7 20.\
1, 4.6L19, 1L15,\
 1L14, 4.4C13.8,\
 4.5 13.6, 4.5 1\
3.5, 4.6C13.3, 4\
.7 13, 4.7 12.8,\
 4.8C12.6, 4.9 1\
2.4, 5 12.2, 5.1\
C12, 5.2 11.9, 5\
.3 11.7, 5.3L8.5\
, 3.7L5.7, 6.5L7\
.4, 9.6C7.3, 9.8\
 7.2, 10 7.2, 10\
.2C7.1, 10.4 7, \
10.6 6.9, 10.8C6\
.8, 11 6.7, 11.2\
 6.7, 11.5C6.6, \
11.7 6.6, 11.8 6\
.5, 12L3, 13L3, \
17L6.4, 18C6.5, \
18.2 6.5, 18.4 6\
.6, 18.5C6.7, 18\
.7 6.7, 18.9 6.8\
, 19.2C6.9, 19.4\
 7, 19.6 7.1, 19\
.8C7.2, 20 7.3, \
20.1 7.3, 20.3L5\
.6, 23.4L8.4, 26\
.2L11.5, 24.5C11\
.7, 24.6 11.8, 2\
4.7 12, 24.7C12.\
2, 24.8 12.4, 24\
.9 12.6, 25C12.8\
, 25.1 13, 25.2 \
13.3, 25.2C13.5,\
 25.3 13.6, 25.3\
 13.8, 25.4L14.8\
, 28.8L18.8, 28.\
8L19.8, 25.4C20,\
 25.3 20.2, 25.3\
 20.3, 25.2C20.5\
, 25.1 20.8, 25.\
1 21, 25C21.2, 2\
4.9 21.4, 24.8 2\
1.6, 24.7C21.8, \
24.6 21.9, 24.5 \
22.1, 24.5L25.2,\
 26.2L28, 23.4L2\
6.3, 20.3C26.4, \
20.1 26.5, 20 26\
.5, 19.8C26.9, 1\
9.6 27.1, 19.4 2\
7.1, 19.2zM17, 2\
2C13.1, 22 10, 1\
8.9 10, 15C10, 1\
1.1 13.1, 8 17, \
8C20.9, 8 24, 11\
.1 24, 15C24, 18\
.9 20.9, 22 17, \
22z\x22\x0a           \
id=\x22path1\x22\x0a     \
      style=\x22fil\
l:#ffffff;fill-o\
pacity:1\x22 />\x0a   \
   </g>\x0a    </g>\
\x0a  </g>\x0a  <g\x0a   \
  id=\x22g5\x22\x0a     t\
ransform=\x22transl\
ate(-3.010700572\
20459, -1.005900\
15258789)\x22>\x0a    \
<g\x0a       transf\
orm=\x22matrix(1.00\
358462333679, 0,\
 0, 1.0035846233\
3679, 0, 0)\x22\x0a   \
    id=\x22g4\x22>\x0a   \
   <g\x0a         i\
d=\x22g3\x22>\x0a        \
<circle\x0a        \
   cx=\x2217\x22\x0a     \
      cy=\x2215\x22\x0a  \
         r=\x224\x22\x0a \
          id=\x22ci\
rcle2\x22\x0a         \
  style=\x22fill:#f\
fffff;fill-opaci\
ty:1\x22 />\x0a      <\
/g>\x0a    </g>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x08\x03\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2.037\
5 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg2\x22\x0a   sodipo\
di:docname=\x22zoom\
reset.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (86a8ad7, 20\
24-10-11)\x22\x0a   xm\
lns:inkscape=\x22ht\
tp://www.inkscap\
e.org/namespaces\
/inkscape\x22\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:svg=\x22http://www\
.w3.org/2000/svg\
\x22>\x0a  <defs\x0a     \
id=\x22defs2\x22 />\x0a  \
<sodipodi:namedv\
iew\x0a     id=\x22nam\
edview2\x22\x0a     pa\
gecolor=\x22#000000\
\x22\x0a     bordercol\
or=\x22#FFFFFF\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x220\x22\x0a     \
inkscape:deskcol\
or=\x22#d1d1d1\x22\x0a   \
  inkscape:zoom=\
\x2224.3125\x22\x0a     i\
nkscape:cx=\x2215.9\
79434\x22\x0a     inks\
cape:cy=\x2216\x22\x0a   \
  inkscape:windo\
w-width=\x221920\x22\x0a \
    inkscape:win\
dow-height=\x22996\x22\
\x0a     inkscape:w\
indow-x=\x22-9\x22\x0a   \
  inkscape:windo\
w-y=\x22-9\x22\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22 /\
>\x0a  <g\x0a     id=\x22\
Layer_1\x22\x0a     tr\
ansform=\x22transla\
te(-2, -2)\x22\x0a    \
 style=\x22enable-b\
ackground:new 0 \
0 32 32\x22>\x0a    <p\
ath\x0a       d=\x22M2\
9.7, 27.3L22, 19\
.6L21.9, 19.5C23\
.2, 17.7 24, 15.\
4 24, 13C24, 6.9\
 19.1, 2 13, 2C6\
.9, 2 2, 6.9 2, \
13C2, 19.1 6.9, \
24 13, 24C15.4, \
24 17.7, 23.2 19\
.5, 21.9C19.5, 2\
1.9 19.5, 22 19.\
6, 22L27.3, 29.7\
C27.6, 30 28.2, \
30 28.5, 29.7L29\
.7, 28.5C30.1, 2\
8.2 30.1, 27.6 2\
9.7, 27.3zM4, 13\
C4, 8 8, 4 13, 4\
C18, 4 22, 8 22,\
 13C22, 18 18, 2\
2 13, 22C8, 22 4\
, 18 4, 13z\x22\x0a   \
    fill=\x22#FFFFF\
F\x22\x0a       class=\
\x22Black\x22\x0a       i\
d=\x22path1\x22\x0a      \
 style=\x22fill:#FF\
FFFF;fill-opacit\
y:1\x22 />\x0a  </g>\x0a \
 <g\x0a     id=\x22g2\x22\
\x0a     transform=\
\x22translate(4, 3.\
96250009536743)\x22\
\x0a     style=\x22ena\
ble-background:n\
ew 0 0 16 16\x22>\x0a \
   <g\x0a       id=\
\x22Check_2_\x22>\x0a    \
  <path\x0a        \
 d=\x22M 1.9742931,\
7.3830334 3.3161\
954,6.0411311 6,\
8.7249358 11.367\
609,3.3573265 12\
.709512,4.699228\
8 6,11.40874 c 0\
,0 -4.0257069,-4\
.0928017 -4.0257\
069,-4.0257066 z\
\x22\x0a         fill=\
\x22#FFFFFF\x22\x0a      \
   class=\x22Black\x22\
\x0a         id=\x22pa\
th2\x22\x0a         st\
yle=\x22stroke-widt\
h:0.670951;fill:\
#FFFFFF;fill-opa\
city:1\x22 />\x0a    <\
/g>\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x06h\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg1\
\x22\x0a   sodipodi:do\
cname=\x22cancel.sv\
g\x22\x0a   inkscape:v\
ersion=\x221.4 (86a\
8ad7, 2024-10-11\
)\x22\x0a   xmlns:inks\
cape=\x22http://www\
.inkscape.org/na\
mespaces/inkscap\
e\x22\x0a   xmlns:sodi\
podi=\x22http://sod\
ipodi.sourceforg\
e.net/DTD/sodipo\
di-0.dtd\x22\x0a   xml\
ns=\x22http://www.w\
3.org/2000/svg\x22\x0a\
   xmlns:svg=\x22ht\
tp://www.w3.org/\
2000/svg\x22>\x0a  <de\
fs\x0a     id=\x22defs\
1\x22 />\x0a  <sodipod\
i:namedview\x0a    \
 id=\x22namedview1\x22\
\x0a     pagecolor=\
\x22#000000\x22\x0a     b\
ordercolor=\x22#000\
000\x22\x0a     border\
opacity=\x220.25\x22\x0a \
    inkscape:sho\
wpageshadow=\x222\x22\x0a\
     inkscape:pa\
geopacity=\x220.0\x22\x0a\
     inkscape:pa\
gecheckerboard=\x22\
0\x22\x0a     inkscape\
:deskcolor=\x22#d1d\
1d1\x22\x0a     inksca\
pe:zoom=\x2224.3125\
\x22\x0a     inkscape:\
cx=\x2215.979434\x22\x0a \
    inkscape:cy=\
\x2216\x22\x0a     inksca\
pe:window-width=\
\x221920\x22\x0a     inks\
cape:window-heig\
ht=\x22996\x22\x0a     in\
kscape:window-x=\
\x22-9\x22\x0a     inksca\
pe:window-y=\x22-9\x22\
\x0a     inkscape:w\
indow-maximized=\
\x221\x22\x0a     inkscap\
e:current-layer=\
\x22svg1\x22 />\x0a  <g\x0a \
    id=\x22Layer_1\x22\
\x0a     transform=\
\x22translate(-8.4,\
 -8.4)\x22\x0a     sty\
le=\x22fill:#ffffff\
;fill-opacity:1\x22\
>\x0a    <g\x0a       \
transform=\x22matri\
x(1.4, 0, 0, 1.4\
, 0, 0)\x22\x0a       \
id=\x22g1\x22\x0a       s\
tyle=\x22fill:#ffff\
ff;fill-opacity:\
1\x22>\x0a      <path\x0a\
         d=\x22M19.\
1, 16L25.7, 9.4C\
26.1, 9 26.1, 8.\
4 25.7, 8L24, 6.\
3C23.6, 5.9 23, \
5.9 22.6, 6.3L16\
, 12.9L9.4, 6.3C\
9, 5.9 8.4, 5.9 \
8, 6.3L6.3, 8C5.\
9, 8.4 5.9, 9 6.\
3, 9.4L12.9, 16L\
6.3, 22.6C5.9, 2\
3 5.9, 23.6 6.3,\
 24L8, 25.7C8.4,\
 26.1 9, 26.1 9.\
4, 25.7L16, 19.1\
L22.6, 25.7C23, \
26.1 23.6, 26.1 \
24, 25.7L25.7, 2\
4C26.1, 23.6 26.\
1, 23 25.7, 22.6\
L19.1, 16z\x22\x0a    \
     id=\x22path1\x22\x0a\
         style=\x22\
fill:#ffffff;fil\
l-opacity:1\x22 />\x0a\
    </g>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x02p\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!--\x0d\x0a // 1\
6pxls (c) by Pau\
l mackenzie <pau\
l@whatspauldoing\
.com>\x0d\x0a //\x0d\x0a // \
16pxls is licens\
ed under a\x0d\x0a // \
Creative Commons\
 Attribution-Sha\
reAlike 4.0 Inte\
rnational Licens\
e.\x0d\x0a //\x0d\x0a // You\
 should have rec\
eived a copy of \
the license alon\
g with this\x0d\x0a //\
 work. If not, s\
ee <http://creat\
ivecommons.org/l\
icenses/by-sa/4.\
0/>.\x0d\x0a-->\x0d\x0a\x0d\x0a<sv\
g fill=\x22#FFFFFF\x22\
 width=\x22800px\x22 h\
eight=\x22800px\x22 vi\
ewBox=\x220 0 16 16\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22>\x0d\x0a    <path\
 d=\x22M7 5.222V0h2\
v5.193l1.107-1.1\
07L11.52 5.5 7.9\
86 9.036 4.45 5.\
5l1.414-1.414L7 \
5.222zM16 11v5H0\
v-5h2v3h12v-3h2z\
\x22 fill-rule=\x22eve\
nodd\x22/>\x0d\x0a</svg>\
\x00\x00\x04\x02\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -2)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
FullScreenExit\x22>\
\x0d\x0a      <polygon\
 points=\x2224,8 24\
,2 20,2 20,12 30\
,12 30,8  \x22 fill\
=\x22#FFFFFF\x22 class\
=\x22Black\x22 />\x0d\x0a   \
 </g>\x0d\x0a  </g>\x0d\x0a \
 <g id=\x22Layer_1\x22\
 transform=\x22tran\
slate(-2, -2)\x22 s\
tyle=\x22enable-bac\
kground:new 0 0 \
32 32\x22>\x0d\x0a    <g \
id=\x22FullScreenEx\
it\x22>\x0d\x0a      <pol\
ygon points=\x222,2\
4 8,24 8,30 12,3\
0 12,20 2,20  \x22 \
fill=\x22#FFFFFF\x22 c\
lass=\x22Black\x22 />\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a  <g id=\x22Laye\
r_1\x22 transform=\x22\
translate(-2, -2\
)\x22 style=\x22enable\
-background:new \
0 0 32 32\x22>\x0d\x0a   \
 <g id=\x22FullScre\
enExit\x22>\x0d\x0a      \
<polygon points=\
\x228,8 2,8 2,12 12\
,12 12,2 8,2  \x22 \
fill=\x22#FFFFFF\x22 c\
lass=\x22Black\x22 />\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a  <g id=\x22Laye\
r_1\x22 transform=\x22\
translate(-2, -2\
)\x22 style=\x22enable\
-background:new \
0 0 32 32\x22>\x0d\x0a   \
 <g id=\x22FullScre\
enExit\x22>\x0d\x0a      \
<polygon points=\
\x2220,30 24,30 24,\
24 30,24 30,20 2\
0,20  \x22 fill=\x22#F\
FFFFF\x22 class=\x22Bl\
ack\x22 />\x0d\x0a    </g\
>\x0d\x0a  </g>\x0d\x0a</svg\
>\
\x00\x00\x08\x10\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-3.0775 -\
2 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg3\x22\x0a   sodipo\
di:docname=\x22exit\
-black.svg\x22\x0a   i\
nkscape:version=\
\x221.4 (e7c3feb100\
, 2024-10-09)\x22\x0a \
  xmlns:inkscape\
=\x22http://www.ink\
scape.org/namesp\
aces/inkscape\x22\x0a \
  xmlns:sodipodi\
=\x22http://sodipod\
i.sourceforge.ne\
t/DTD/sodipodi-0\
.dtd\x22\x0a   xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns:svg=\x22http:/\
/www.w3.org/2000\
/svg\x22>\x0a  <defs\x0a \
    id=\x22defs3\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     id=\
\x22namedview3\x22\x0a   \
  pagecolor=\x22#00\
0000\x22\x0a     borde\
rcolor=\x22#FFFFFF\x22\
\x0a     borderopac\
ity=\x220.25\x22\x0a     \
inkscape:showpag\
eshadow=\x222\x22\x0a    \
 inkscape:pageop\
acity=\x220.0\x22\x0a    \
 inkscape:pagech\
eckerboard=\x220\x22\x0a \
    inkscape:des\
kcolor=\x22#d1d1d1\x22\
\x0a     inkscape:z\
oom=\x2225.21875\x22\x0a \
    inkscape:cx=\
\x2216\x22\x0a     inksca\
pe:cy=\x2216\x22\x0a     \
inkscape:window-\
width=\x221920\x22\x0a   \
  inkscape:windo\
w-height=\x22969\x22\x0a \
    inkscape:win\
dow-x=\x220\x22\x0a     i\
nkscape:window-y\
=\x220\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22svg3\x22 />\x0a  \
<g\x0a     id=\x22Laye\
r_1\x22\x0a     transf\
orm=\x22translate(-\
4.3083, -2.15390\
015258789)\x22\x0a    \
 style=\x22enable-b\
ackground:new 0 \
0 32 32\x22>\x0a    <g\
\x0a       transfor\
m=\x22matrix(1.0769\
225358963, 0, 0,\
 1.0769225358963\
, 0, 0)\x22\x0a       \
id=\x22g1\x22>\x0a      <\
path\x0a         d=\
\x22M20, 4.7L20, 9.\
1C22.4, 10.5 24,\
 13.1 24, 16C24,\
 20.4 20.4, 24 1\
6, 24C11.6, 24 8\
, 20.4 8, 16C8, \
13 9.6, 10.5 12,\
 9.1L12, 4.7C7.3\
, 6.3 4, 10.8 4,\
 16C4, 22.6 9.4,\
 28 16, 28C22.6,\
 28 28, 22.6 28,\
 16C28, 10.8 24.\
7, 6.3 20, 4.7z\x22\
\x0a         fill=\x22\
#FFFFFF\x22\x0a       \
  class=\x22Black\x22\x0a\
         id=\x22pat\
h1\x22\x0a         sty\
le=\x22fill:#FFFFFF\
;fill-opacity:1\x22\
 />\x0a    </g>\x0a  <\
/g>\x0a  <g\x0a     id\
=\x22g3\x22\x0a     trans\
form=\x22translate(\
-4.3083014495849\
6, -2.1539)\x22\x0a   \
  style=\x22enable-\
background:new 0\
 0 32 32\x22>\x0a    <\
g\x0a       transfo\
rm=\x22matrix(1.076\
9225358963, 0, 0\
, 1.076922535896\
3, 0, 0)\x22\x0a      \
 id=\x22g2\x22>\x0a      \
<path\x0a         d\
=\x22M17, 14L15, 14\
C14.4, 14 14, 13\
.6 14, 13L14, 3C\
14, 2.4 14.4, 2 \
15, 2L17, 2C17.6\
, 2 18, 2.4 18, \
3L18, 13C18, 13.\
6 17.6, 14 17, 1\
4z\x22\x0a         fil\
l=\x22#FFFFFF\x22\x0a    \
     class=\x22Blac\
k\x22\x0a         id=\x22\
path2\x22\x0a         \
style=\x22fill:#FFF\
FFF\x22 />\x0a    </g>\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x07\xdc\
\x00\
\x00(\xcex\xda\xd5Z[s\xdb\xb8\x0e~\xef\xaf\xe0\
\xf8\xbctgj\x85\xe0\x9d\x99\xba;\xb3\xda\xb3O\xea\
[\xf7yG\xb5U\xc7S\xc7\xca\xd8n\xdd\xe6\xd7\x1f\
\x80\x22)9\xb7u\xf6X\x93lz\x13\x04\x10\x04)\
}\x1f@\xa8\xef\x7f\xfdq\xbdf\xdf\x9b\xedn\xd5n\
f\x13(\xf8\x845\x9by\xbbXm\x96\xb3\xc9\x9f\x9f\
\xfe\x98\xba\x09\xdb\xed\xeb\xcd\xa2^\xb7\x9bf6\xd9\xb4\
\x93_?\xbcy\xbf\xfb\xbe|\xc3\x18\xfb\xbej\x0e\xbf\
\xb5?f\x93\xa9)\xb8\xb2\x9aM\x05\x93\xf4{\x12\xb4\
\xbd[\x087V\x8b\xd9\x04G\xeaN\xbd\xc3Yn\xf0\
\xcf\xe5\xa2\x9do\xeakt~\xb3\xda\x14\xa8\xefl7\
_w\xf3\xfa\xa6\xb9\x1cxQ\xec\xad3\xb5\xab\x17\xf6\
\x1d\x13\x5c\xa8)\xf0)\xc0/\xc1\x1e\xd7\xb1\xd9]\xa6\
Q\xb3\xc9\xd5~\x7fsyqq8\x1c\x8at\xb3h\
\xb7\xcb\x0b\x9aiwS\xcf\x9b\xddE\xba?\x18\x9fb\
\xca\xe3\xd3\x8db\xd7~\xdb\xce\x9b/\xe8\xa2)6\xcd\
\xfe\xe2\xf7O\xbfg\xe5\x94\x17\x8b\xfd\xa2ws4\xfb\
A\x86y\x05\xe7\xfc\x22-.N\xf6}\xf9\xa4\xe5\x07\
4}\xbfh\xbe\xechH\xb7{$\xe1\xf6\xb1\x8b\xa0\
\xcb;H\x8bZ\xd0\xc3\xe8-\xf3\xad\xb8\xdb\x8c\xdd\xd4\
\xcbf\xde\xae\xdb\xedl\xf2\x9f/\xe1'*>\xb7\xdb\
E\xb3M*\x1e~\x8eT-\xee\xd7j\xffs6\xe1\
\x85\xd0Q\x93\x9f\xcf\xee\xaa=\x90\xeb\xddU\xbdh\x0f\
\xb3\x89\xb8k@\xca\x81\x07\xfe\x90~~\xd5\xcc\xbf6\
\xdb\xcfm\xbd\xc5\xd8\xf7\xdbo\xcd]\xabE\xb3\xfb\x9a\
B\x5c\x00\xfd\xbakq\xdb\xb6\xd78\xbd*$\xdc\x8f\
r\x8e/)\xe8\xc2[\xaf\xa4\xba\xa7\xc4\xc0\xc0\xdc\xbd\
{XmpA\xd3\xc3j\xb1\xbfB\xbd\x17\xfc\x11\x8b\
\xabf\xb5\xbc\xda\xcf&\xde?\xe6\x83\x10\xe2\x1f\xd1\xfd\
|Bw]\xffX]\xafn\x1b\xdc\x93{\xcb\x9d\x7f\
\xdbn\x9b\xcd~\xba\xae\x7f6\xdb\x84\xab\xf8b,\xfb\
\xf7\xa0\x22\xf5_i\xf4~[ov\xf8\x12_\xd3&\
\xe3\xe5\xba\xde7o\xa7\x0a\xc1k4\xe7\xc6\x19\xa3\xb4\
\x86wl\xea\x0b\xef\xa5\xe3\x00`<\x02\xdb\xffw\xca\
\xf5/\xd1\xc9n\xffs\x8d\x08k6\xf5\xe7u3\xfd\
\x5c\xcf\xbf.\xb7\xed\xb7\xcd\xe2r\xd3\x1c\x18\xc7_\x8a\
Ca\xba\xbf\xc3K\xdcGt\x14\xc1u\xbd\xdf\xae~\
\xbc\xe5\x85\xb3\xca+\xee%Xo\xb9p\xef\x18\xef~\
?\xacHat\xeb[\xea8\xc5p\x92\x87\xa6A\x12\
RR$\xdfC\xa9w\x18]\xaa\xec\xf2\xd8\xe9\xc3\xd1\
s\xe3m\x1fr/\x0d\xddF\xc7r\xe0\xf8\xae\xebG\
\x1e\x8e\xa4`\xf5\xb1\xaf\xe8M\x1cy\xbb\xef/\x9a\xc1\
\x1d34\xbc\xa9\xf7Wwm\x19C\xe3\x8f^\x17\xdc\
\xe2\xbe(\xa8\x1c/\x0c]N\xa1p\xa5\xf5\xf80H\
P\x85`\x0e\xa2`\x99S\xd1\xc8VB\xdbBu\xd7\
\xa50H\x15\xd1D\x18\x11\xafi\xac0\xd0\xcd@n\
+\xa1l\x9aor?\xa0/\xab\xf5\x1a\xe1\xfeG\xf8\
yD?\xcd\xd4\xf2\x90\x87\xf9\xba\xde!\x1d\xff\xb6\xc6\
\x97\xf4\x015\xed\x0f\xed\x05D\xe0\x0c\xb6\xe8by\xf4\
\xa8\x86\xe2@\xc8\x97\xf1\x22\xfd3\x00\xe0\x12N\x00\x9f\
\xf2\xde\x09'\xa53\xb43\xf8\x16q\x0e\x9c\x0bCo\
\xbd\xe3\xcep\xff:\xc1\x07\xfc\xfc\xe8\xf3c\xa1\xcf\x9d\
\x15}\xf64\xf4\x99\xe7\xa0\xcfF\x04!\xe9V\x03$\
\x0ePR\x09\x13\x11\x876\x083\xd3A\x0b\x9f\x11V\
G\xc2D\x94\x82\x0b\xa2\x8d.\xc0\xbb\xc2T\x92\xcbN\
+\x94)L)\xb9\xeb\x1c\x09\x8d\x1e\x19i\x83q\x98\
\x80\x09/\xbbP\x82X)\xd7\xcd\x13\xa4R\xfa\xa1\xa9\
L\x03;?v0I\x85\xf1\x99\x1cAi#\x11P\
x\x8eat.\xc5\x8e\xd2`\xe9\x83\xeb\xdb\x97\xa4\x05\
=*-\x98\x93r2\xe6`\xc4\xbf\x92\xff\xaa\x9c\x0c\
#$e\x18-+\xc3y\xd32\xdc\xcb\xcb\x0f\x01\x9e\
\xe0.x\x02\x19\x87\x12\xcb\xfe\x84\x0e\x04\x1b\x22&\x02\
\x09\x8c\x1d\x08\x1a1\x5ce\x91\xf8\x80\xa7\xcc\x8c\x19\xd8\
@\x7f\xad\x22O\x90\x8d\xce\xbet\xa1J\xa1}\xc4\x17\
A\x10Q\x1c\x01\x0c\xae\x13#\xd6\xc1\xebJ\xf8\xc8<\
BId\x8c\xe8^h@\x820\x89\x12Pp\x11\xe7\
(\xe0\xcc\xc9\xcc\xe0\xaa\x84\xcb\x1a&\xb0\x02\xef\xd6\xab\
9q\x0cD>\x10D\x1a\xd5p7\x8e\x84\xfb\x1c\xf0\
4\x03\xfc\x1d\xfe\x9fD\x7f.\x09\xee\xd6\x04\xff\x0f\xd6\
\x858\xa9\x04P\xd2x\x8dU\xf8\xa0\x04\xf0\xdcH+\
\xf0\x9e\x15\xf0:\xb1.\xe0\xfcX\x17|4\xac\xfb\xf3\
b\xdd\x9dX\x83\xdb\xe7\x94\x01\xa0tB\x90\xae %\
u\xe9P\xf02k^\xb4`6c\xa6F\xe1NJ\
\x8d\x1e\xb4\x16V\xaa\x1e.XfH\xa3\x90\xee\xbc\x95\
\xaf\xb4b\x16v\x04\xb8\x98\xb1\xe0\x22\xf4yO\xac\xea\
4\xb8\x08\xf9,\xb8X\x9b\x10B5'\xa4,\x18\xc5\
\x5c\x91R1Z\x92\x18\x8bWAiV\xfa\x94\xd3B\
\xd6\xc5\xac\xd9\xa5$mKP\xb9B6\xa4\xd3\x22\x89\
\xbeK\xc4\x9d\x1bLT\x03\x90\x92\x83*d\xd2\xac-\
!\xa7G\x1a\xe9!\xd5\xcb\xc1\xab\xcf9\x11g\xf49\
\x1aK\xa9\x98\xa7\x19C\xac\x22\xe7_\x13\x16v\xb4\xec\
\x17-\x94\x85\x18\x93\x0er\xc3\xeei:\xe0\xd2\x81\x0a\
/s\xa4\x83\xd7I\x00R\x9e\x9f\x00\xa4\x18\xadc\x05\
g%\x00\xc9O$\x00\xff\x8f\x9aV\xbe\xf4\x11\x22\xca\
3\x17\xd1\xab,s\xf1@\xa9\x08\xab6\x96\xbb\x9cN\
\xa4\xa9`\x96\xccF\xacM\x11L\xcc\xa6\xb6\x96\xa7\xde\
\x97M\x1d+\xc9\xfa\xa6\x98\xee{_\xa0\x07\xcd/\xd0\
%\xd5\xe1I\xa0L\x9d\x04\x89B\xc4,:\xc6B\xdc\
\xc4B|jBg,U\xf2\x01\xec&\x86O\xe5{\
*\xe5e\xa8\xdece\xac\x02E$\x8eR>H\xc9\
\x92\x8e\xdbB\xf1\xb4\x03\xd4\x0d\x90\xb1\xaeW\x82jo\
\x19\xa7\x96\xd4\x1a\xc0\x82>\x1e\x10*\x97Z\x08\x15\xf0\
X\x9e\x93I\x09\xa9{\x10\x86c\xaa\xcdA(\x96\x0e\
\x09aVoR@\xcc\xeb\xfc0\xfaG\xf4\xb2D\xe5\
\xc6$*\xc5O \xaaAq\x8f\x19E;\xeb<\xd7\
R\xbdR\xb2\xf2#\x90\x95\x1b\x8d\xac\xecy\xc9\xca\x9c\
FVR?\x87\xac\xfa\xce\x1a1N\xdfY#\xa9T\
\xa96 \x09\x8b\x89t\xc4v\xa1C7(\x06J\x91\
\xca\x18\x1d\x0e\xed\xf9\x98\x1e,\x93\x17\xc4\xaa\xa8tB\
\xb4Gw\xa5I=AG\x9c\x93\xcf\xfa\xd4rc\x89\
\x8e\x00YJU.\xea\xa4\xacD\xaav\xe8:w\xf1\
\x88\xcb0\x0e\x99\xdax\x16\xc3H\xfd\xbe\xae\x95\x90>\
\x14\xd0\xd4\xa6\x92\x90V@\x1cRJH\xcbC~ \
aPkI\x80\xbeJ\xa3^\xa5M\xddH4\xe5G\
\x9bt\xbc\x9f\xb7\x1f\x81\xe7\x14P\xb9\xb4X\xcbq\xe9\
.\x1a\x82#\x82\xb5>5G\xf16KIApY\
\xf55 \x94*9\xa7\xe2\x8f\x08\xd8\xa5V\xa7`\xbd\
\x1d5EU^\x00\xf2=\xcb'8M\xe9D\xd9\x81\
TQ\xc4\xb9\x02D\x9a\xee+@\x13\xd6\x93\x1a+\xc1\
\x91\xf0f\xd0\xa6-\xfb\x86\x0c=\x12F\xe2 \xbe\x81\
1\xa7\x89R\xb6\x09\x85d\x99\xdbC\xe0C\x86\xd1\xe9\
\xe1;\xfa\xb4\x1e6>oVE\xc9C\xc4m\x1cl\
\xe9\xed\xc7G\x1a\xb5\xaf\xa6i\x8b\xd5\xe2\x98\x14\x7fb\
\xd7Vz!\x8fN\xa6x\xb2@\xb2\x05\xc7\xb5x\x9d\
T\xaf\xc6\xf8\x90:Z\xcfV\x9d\xb7g\xabN\xfc\x96\
\xaa\x9e\xf51\x15d\xfe\x00#+\x102\x0b%@\xaa\
\xee\xbcd\x00\x99\x93\xe9\xb3\xcd@\xd4\xe5@\xa0\x96i\
?\x0e\xd9\xb6\xf7hm\xd5\xcfe\xf1\x1c)s\x87\x17\
\xcd\x94<r\xd1\x8b\xe8\xbe\x17\xc2\xd4y\x1c\x855\x88\
\xfeE\x11\x8de\xd5\x88\x88\xd6\xe2\x9f\x9d.\xff\x05\x90\
\xd6#\xb4f\xf5h\xadYu\xde\xd6\xac:\xb15\xab\
\x9e\xd5\x9a\xa5\x94\xdaC\xda\xc2\x00\xd2\xfd\xb7N\xc4\x8e\
9\xc6\x95\x19b\xce\x1c\xe31\x8f#\xacf\x8f\xd6V\
\xfd\x5c\x08ia\xa1\x87t\xffe7\xb8\x18\x88x\xf8\
\xb4Gl\xd2\x8f\xf3\xdd\xf1\xf3u@\xfa\xbc\xfd\xe3\xf7\
\xf4\xff\xe5>\xbc\xf9\x1f\x19\xe1\xc9\x1a\
\x00\x00\x07v\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -5.112\
5 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg2\x22\x0a   sodipo\
di:docname=\x22open\
-gray.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (e7c3feb100,\
 2024-10-09)\x22\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0a  \
 xmlns:sodipodi=\
\x22http://sodipodi\
.sourceforge.net\
/DTD/sodipodi-0.\
dtd\x22\x0a   xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22\x0a   xm\
lns:svg=\x22http://\
www.w3.org/2000/\
svg\x22>\x0a  <defs\x0a  \
   id=\x22defs2\x22 />\
\x0a  <sodipodi:nam\
edview\x0a     id=\x22\
namedview2\x22\x0a    \
 pagecolor=\x22#000\
000\x22\x0a     border\
color=\x22#FFFFFF\x22\x0a\
     borderopaci\
ty=\x220.25\x22\x0a     i\
nkscape:showpage\
shadow=\x222\x22\x0a     \
inkscape:pageopa\
city=\x220.0\x22\x0a     \
inkscape:pageche\
ckerboard=\x220\x22\x0a  \
   inkscape:desk\
color=\x22#d1d1d1\x22\x0a\
     inkscape:zo\
om=\x2225.21875\x22\x0a  \
   inkscape:cx=\x22\
16\x22\x0a     inkscap\
e:cy=\x2216\x22\x0a     i\
nkscape:window-w\
idth=\x221920\x22\x0a    \
 inkscape:window\
-height=\x22969\x22\x0a  \
   inkscape:wind\
ow-x=\x220\x22\x0a     in\
kscape:window-y=\
\x220\x22\x0a     inkscap\
e:window-maximiz\
ed=\x221\x22\x0a     inks\
cape:current-lay\
er=\x22svg2\x22 />\x0a  <\
g\x0a     transform\
=\x22translate(0, -\
1.5578)\x22\x0a     id\
=\x22g2\x22\x0a     style\
=\x22fill:#FFFFFF;f\
ill-opacity:1\x22>\x0a\
    <g\x0a       tr\
ansform=\x22matrix(\
0.04861427098512\
65, 0, 0, 0.0486\
142709851265, 0,\
 0)\x22\x0a       id=\x22\
g1\x22\x0a       style\
=\x22fill:#FFFFFF;f\
ill-opacity:1\x22>\x0a\
      <path\x0a    \
     d=\x22M384, 48\
0L432, 480C443.4\
, 480 453.9, 474\
 459.6, 464.1L57\
1.6, 272.1C577.4\
, 262.2 577.4, 2\
50 571.7, 240C56\
6, 230 555.5, 22\
4 544, 224L144, \
224C132.6, 224 1\
22.1, 230 116.4,\
 239.9L48, 357.1\
L48, 96C48, 87.2\
 55.2, 80 64, 80\
L181.5, 80C185.7\
, 80 189.8, 81.7\
 192.8, 84.7L219\
.3, 111.2C240.3,\
 132.2 268.8, 14\
4 298.5, 144L416\
, 144C424.8, 144\
 432, 151.2 432,\
 160L432, 192L48\
0, 192L480, 160C\
480, 124.7 451.3\
, 96 416, 96L298\
.5, 96C281.5, 96\
 265.2, 89.3 253\
.2, 77.3L226.7, \
50.7C214.7, 38.7\
 198.4, 32 181.4\
, 32L64, 32C28.7\
, 32 0, 60.7 0, \
96L0, 416C0, 451\
.3 28.7, 480 64,\
 480L87.7, 480L3\
84, 480z\x22\x0a      \
   id=\x22path1\x22\x0a  \
       style=\x22fi\
ll:#FFFFFF;fill-\
opacity:1\x22 />\x0a  \
  </g>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x0d\xe9\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x221em\x22\x0a   hei\
ght=\x221em\x22\x0a   vie\
wBox=\x220 0 32 32\x22\
\x0a   class=\x22bi bi\
-brush\x22\x0a   fill=\
\x22currentColor\x22\x0a \
  version=\x221.1\x22\x0a\
   id=\x22svg1\x22\x0a   \
sodipodi:docname\
=\x22brush.svg\x22\x0a   \
inkscape:version\
=\x221.4 (86a8ad7, \
2024-10-11)\x22\x0a   \
xmlns:inkscape=\x22\
http://www.inksc\
ape.org/namespac\
es/inkscape\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns=\x22ht\
tp://www.w3.org/\
2000/svg\x22\x0a   xml\
ns:svg=\x22http://w\
ww.w3.org/2000/s\
vg\x22>\x0a  <sodipodi\
:namedview\x0a     \
id=\x22namedview1\x22\x0a\
     pagecolor=\x22\
#000000\x22\x0a     bo\
rdercolor=\x22#FFFF\
FF\x22\x0a     bordero\
pacity=\x220.25\x22\x0a  \
   inkscape:show\
pageshadow=\x222\x22\x0a \
    inkscape:pag\
eopacity=\x220.0\x22\x0a \
    inkscape:pag\
echeckerboard=\x220\
\x22\x0a     inkscape:\
deskcolor=\x22#d1d1\
d1\x22\x0a     inkscap\
e:zoom=\x2217.19153\
4\x22\x0a     inkscape\
:cx=\x2211.022867\x22\x0a\
     inkscape:cy\
=\x2216.985104\x22\x0a   \
  inkscape:windo\
w-width=\x221920\x22\x0a \
    inkscape:win\
dow-height=\x22996\x22\
\x0a     inkscape:w\
indow-x=\x22-9\x22\x0a   \
  inkscape:windo\
w-y=\x22-9\x22\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0a    \
 inkscape:curren\
t-layer=\x22layer1\x22\
\x0a     showgrid=\x22\
true\x22>\x0a    <inks\
cape:grid\x0a      \
 id=\x22grid1\x22\x0a    \
   units=\x22px\x22\x0a  \
     originx=\x220\x22\
\x0a       originy=\
\x220\x22\x0a       spaci\
ngx=\x221\x22\x0a       s\
pacingy=\x221\x22\x0a    \
   empcolor=\x22#00\
99e5\x22\x0a       emp\
opacity=\x220.30196\
078\x22\x0a       colo\
r=\x22#0099e5\x22\x0a    \
   opacity=\x220.14\
901961\x22\x0a       e\
mpspacing=\x225\x22\x0a  \
     enabled=\x22tr\
ue\x22\x0a       visib\
le=\x22true\x22 />\x0a  <\
/sodipodi:namedv\
iew>\x0a  <defs\x0a   \
  id=\x22defs1\x22>\x0a  \
  <filter\x0a      \
 style=\x22color-in\
terpolation-filt\
ers:sRGB\x22\x0a      \
 id=\x22filter2\x22\x0a  \
     x=\x22-0.05859\
8499\x22\x0a       y=\x22\
-0.074647084\x22\x0a  \
     width=\x221.11\
71181\x22\x0a       he\
ight=\x221.1494136\x22\
>\x0a      <feGauss\
ianBlur\x0a        \
 stdDeviation=\x220\
.032040936\x22\x0a    \
     id=\x22feGauss\
ianBlur2\x22 />\x0a   \
 </filter>\x0a  </d\
efs>\x0a  <g\x0a     i\
nkscape:groupmod\
e=\x22layer\x22\x0a     i\
d=\x22layer1\x22\x0a     \
inkscape:label=\x22\
Layer 1\x22\x0a     tr\
ansform=\x22matrix(\
0.85769537,0,0,0\
.86353624,2.1241\
392,1.9256237)\x22>\
\x0a    <path\x0a     \
  style=\x22display\
:inline;fill:#ca\
5d5d;fill-opacit\
y:1;stroke:#FFFF\
FF;stroke-width:\
1.50321998;strok\
e-dasharray:none\
;stroke-opacity:\
1;paint-order:no\
rmal;filter:url(\
#filter2);stroke\
-linejoin:miter;\
stroke-linecap:r\
ound\x22\x0a       d=\x22\
M 9.9117002,21.4\
29319 C 9.989700\
2,21.083319 9.69\
5,20.016 9.828,1\
9.562 c 0.363,-1\
.233 0.964,-2.80\
8 1.907,-4.02 3.\
879,-4.979 11.49\
4,-11.209 17.316\
,-14.298 0.368,-\
0.195 0.908,-0.0\
82 1.327,0.278 0\
.421,0.361 0.621\
,0.885 0.491,1.2\
86 -2.197,6.806 \
-7.654,15.855 -1\
1.991,20.352 -1.\
217,1.257 -2.679\
247,1.413078 -4.\
408277,2.223973\x22\
\x0a       transfor\
m=\x22matrix(0.9173\
3221,0,0,0.92858\
849,0.0902633,2.\
1896622)\x22\x0a      \
 id=\x22path3\x22 />\x0a \
   <path\x0a       \
style=\x22display:i\
nline;fill:#92b6\
f0;fill-opacity:\
1;stroke:#FFFFFF\
;stroke-width:1.\
37732;stroke-lin\
ecap:round;strok\
e-dasharray:none\
;stroke-opacity:\
1;paint-order:no\
rmal;filter:url(\
#filter2)\x22\x0a     \
  d=\x22m 14.174,25\
.656 c -0.440868\
,0.206762 0.0524\
3,1.126067 -0.05\
6,1.796 -0.21657\
,1.338067 -0.961\
573,2.946306 -3.\
168,3.151 C 8.81\
23292,30.801315 \
6.52319,30.54673\
8 4.212,29.887 3\
.7801793,29.7637\
35 3.3523883,29.\
600932 2.926,29.\
417 2.5363642,29\
.248922 2.155944\
7,29.024383 1.81\
6,28.74 1.586923\
2,28.548365 1.39\
96288,28.313692 \
1.268,28.061 1.1\
006255,27.739686\
 1.0516667,27.40\
4166 1.125,27.12\
 1.251667,26.629\
165 1.6914367,26\
.414163 1.986,26\
.307 2.78544,26.\
016162 3.2079624\
,25.544434 3.614\
,24.829 3.770963\
8,24.552431 3.91\
8,24.257 4.085,2\
3.918 l 0.19,-0.\
384 C 4.52,23.04\
 4.808,22.49 5.1\
88,21.906 6.098,\
20.504 7.0344495\
,20.270595 8.248\
4495,20.509595 8\
.5284495,20.5655\
95 13.935,25.573\
 14.174,25.656\x22\x0a\
       transform\
=\x22matrix(0.91733\
221,0,0,0.928588\
49,0.0902633,2.1\
896622)\x22\x0a       \
id=\x22path1\x22\x0a     \
  sodipodi:nodet\
ypes=\x22csssssssss\
ccccc\x22 />\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x08>\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg7\
\x22\x0a   sodipodi:do\
cname=\x22fullscree\
n.svg\x22\x0a   inksca\
pe:version=\x221.4 \
(86a8ad7, 2024-1\
0-11)\x22\x0a   xmlns:\
inkscape=\x22http:/\
/www.inkscape.or\
g/namespaces/ink\
scape\x22\x0a   xmlns:\
sodipodi=\x22http:/\
/sodipodi.source\
forge.net/DTD/so\
dipodi-0.dtd\x22\x0a  \
 xmlns=\x22http://w\
ww.w3.org/2000/s\
vg\x22\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22>\x0a \
 <defs\x0a     id=\x22\
defs7\x22 />\x0a  <sod\
ipodi:namedview\x0a\
     id=\x22namedvi\
ew7\x22\x0a     pageco\
lor=\x22#050505\x22\x0a  \
   bordercolor=\x22\
#000000\x22\x0a     bo\
rderopacity=\x220.2\
5\x22\x0a     inkscape\
:showpageshadow=\
\x222\x22\x0a     inkscap\
e:pageopacity=\x220\
.0\x22\x0a     inkscap\
e:pagecheckerboa\
rd=\x22true\x22\x0a     i\
nkscape:deskcolo\
r=\x22#d1d1d1\x22\x0a    \
 inkscape:zoom=\x22\
24.3125\x22\x0a     in\
kscape:cx=\x2215.97\
9434\x22\x0a     inksc\
ape:cy=\x2216\x22\x0a    \
 inkscape:window\
-width=\x221920\x22\x0a  \
   inkscape:wind\
ow-height=\x22996\x22\x0a\
     inkscape:wi\
ndow-x=\x22-9\x22\x0a    \
 inkscape:window\
-y=\x22-9\x22\x0a     ink\
scape:window-max\
imized=\x221\x22\x0a     \
inkscape:current\
-layer=\x22svg7\x22 />\
\x0a  <g\x0a     id=\x22L\
ayer_1\x22\x0a     tra\
nsform=\x22translat\
e(-2, -2)\x22\x0a     \
style=\x22enable-ba\
ckground:new 0 0\
 32 32\x22>\x0a    <g\x0a\
       id=\x22FullS\
creen\x22>\x0a      <p\
olygon\x0a         \
points=\x222,12 6,1\
2 6,6 12,6 12,2 \
2,2  \x22\x0a         \
fill=\x22#FFFFFF\x22\x0a \
        class=\x22B\
lack\x22\x0a         i\
d=\x22polygon1\x22 />\x0a\
    </g>\x0a  </g>\x0a\
  <g\x0a     id=\x22g3\
\x22\x0a     transform\
=\x22translate(-2, \
-2)\x22\x0a     style=\
\x22enable-backgrou\
nd:new 0 0 32 32\
\x22>\x0a    <g\x0a      \
 id=\x22g2\x22>\x0a      \
<polygon\x0a       \
  points=\x226,20 2\
,20 2,30 12,30 1\
2,26 6,26  \x22\x0a   \
      fill=\x22#FFF\
FFF\x22\x0a         cl\
ass=\x22Black\x22\x0a    \
     id=\x22polygon\
2\x22 />\x0a    </g>\x0a \
 </g>\x0a  <g\x0a     \
id=\x22g5\x22\x0a     tra\
nsform=\x22translat\
e(-2, -2)\x22\x0a     \
style=\x22enable-ba\
ckground:new 0 0\
 32 32\x22>\x0a    <g\x0a\
       id=\x22g4\x22>\x0a\
      <polygon\x0a \
        points=\x22\
20,2 20,6 26,6 2\
6,12 30,12 30,2 \
 \x22\x0a         fill\
=\x22#FFFFFF\x22\x0a     \
    class=\x22Black\
\x22\x0a         id=\x22p\
olygon3\x22 />\x0a    \
</g>\x0a  </g>\x0a  <g\
\x0a     id=\x22g7\x22\x0a  \
   transform=\x22tr\
anslate(-2, -2)\x22\
\x0a     style=\x22ena\
ble-background:n\
ew 0 0 32 32\x22>\x0a \
   <g\x0a       id=\
\x22g6\x22>\x0a      <pol\
ygon\x0a         po\
ints=\x2226,26 20,2\
6 20,30 30,30 30\
,20 26,20  \x22\x0a   \
      fill=\x22#FFF\
FFF\x22\x0a         cl\
ass=\x22Black\x22\x0a    \
     id=\x22polygon\
5\x22 />\x0a    </g>\x0a \
 </g>\x0a</svg>\x0a\
\x00\x00\x05k\
\x00\
\x00\x12(x\xda\xcdXKs\x9bH\x10\xbe\xa7*\xff\
a\x8a\x5c\xa2*3\x9a7\x8cl%[[\xa9=\xed\
\xde\xb2\x97\xbd!\x18#\xd6\x88Q\x01\xb6\xa4\xfc\xfa\xed\
\x01\xf1\x12\x92\xd7\x87$\x159\xb2\xa1\xbb\xe9\x99\xfe\xbe\
\xee\xa6'\x0f\x9f\x8f\xbb\x1c\xbd\x98\xb2\xcal\xb1\xf6(\
&\x1e2El\x93\xacH\xd7\xde\xdf_\xff\xf0C\x0f\
UuT$Qn\x0b\xb3\xf6\x0a\xeb}\xfe\xf4\xfe\xdd\
C\xf5\x92\xbe\x7f\x87\x10z\xc9\xcc\xe1w{\x5c{\x04\
\x11$I\xf3\xf5Z\xcd\xe0\x94\xb6\x92,Y{\xf0\x9c\
j\xef*Xd\x0f\xdfUb\xe3\x22\xda\x81\xefm\x9c\
\x19\x0c\x06g\xeb\xe2\xa9\x8a\xa3\xbdY\x8d\x1c\x09\xf41\
TQ\x18%\xc1\x1db\x84\x09\x9f\x12\x9f\xd2\xc5\xc5\x03\
\xe6\xb8\xb7e\xed?f\xb9\x199\xde\x17\xe9u\xbbc\
\xb2\xcf\xd6\x9eV\xd7\xb5\xa7\x89\x16\xd0*\xaaUg\x03\
\x9e\xebz\xbfZ.\x0f\x87\x03\xee\x84\xd8\x96\xe9\xd2\xad\
[\xed\xa3\xd8T\xcbN>v\xd0\xc5\xde;\xe8\x04\xb8\
\xb2\xcfel\x1e\xc1\x87\xc1\x85\xa9\x97_\xbe~\xe9\x95\
>\xc1I\x9d\x8c\xfcL\xd6?\xf0feF\x08Y\xf6\
 \x9e\x97{I\xdfj\xba9\xb6\x96\x15\x98n\xec\xf1\
\xe4\x83\x1e\xc7v\xe7}rF\x0f\x89y\xac\x1a\xeb\x96\
Mw\xab<\xb4l\x95=\xa3.\xfa\xc4e\xc6\xc8\xb4\
\x97\x9d\x91Dh\x1f\xa5&\xb6\xb9-\xd7\xde\x07\xd2|\
:\xcd\xc6\x96\x89);\xdd\x1f\xcdg\xaa\xb3\x80mV\
\x9f \xed0\x93\x9d\xaa\xa7\xae\xda\xda\x83\xf3^m\xa3\
\xc4\x1e\xd6^]>\x9b\x99\x913\x18\xb9!W\x0d\xe2\
\xad\x89\x9fL\xb9\xb1Q\x99\xdc\xf0\x93\x98\xea\xa9\xdbj\
\x18\xbb\x9f\xce\xc4m#-]\xf0\x8fQ^\xf5O\xe6\
\xd1\xc6\xe4U}\xcaM\x03`\xf4\x9c\xd73\xa7q\x9e\
\xed\xfd\xda\xfan\x0f\x17\x8f;\xaf-\x0876\xf4\xcd\
\xda\x9d\x8bHJB\x99&\xe1\xdc9pL\xb9\xc6Z\
\x05t\x0e^\x0cp\xb0\x80a\xa58\x9b?{\xc8\x0a\
\x80\xd4?dI\xbd\x05/\x9a\x91[&[\x93\xa5\xdb\
\x1aJG\xab[&\xb0\x0f_\xdfR\x9e^S\xee\xa2\
c\xb6\xcb\xbe\x19\xc0\x96\xce#x.KS\xd4~\x1e\
\x9d\x1cHM\xcb\xe9rto\xf3Sj\x8b\x0e\xcb\x96\
\x85\xaa.\xed\x93\xf1\xf3\xac0\xff\xda\xacX\xa1\xd2>\
\x17\xc9=\x1a\xc9\xc1\xf1\xa5\xb8\xc1`\x05}h\x7f\xec\
d`\x92n>jv\x87\xda\xef\xe2\x1eA\x17\xca[\
1\xe5\xe4\x0eQ\xad\xa1uI\xb9\xb8\xef\xcb\x00V\xac\
\xa1\x94\xb9\xc2JP$8\xc3\x01\xe7\xe8|\xcb!3\
\x85\x04i\x88%\x0d\xe0/\xc5\x9a\x81\x98\x0b\xac\x82\xb0\
\xbf\xa7\x84b.\x19\xb8\x07;-\xfb{\xa7WDx\
\xa3B<#@{H\xd2\x912\xe5m\xa1\x83\xb84\
q}\xd6@s\x00\x9c\x03\xacy\x0f6B\xc0\x0f\x87\
\xbdJ\xc1\x07\xd99-\x84T\x9826\xc8\xbb\x5c\xa0\
\x97\x0fL\x09\xd8e\xb5)s \xb6^!5\x81\xff\
\x1a-\xdf\x09\xff6p\x17m\x0f\x09D\xef\x16\xbd\xb1\
\xcb\x1f\x9b\x0e\x805\x05\x04\x87f\x08H\xd3+P\x1f\
\xd9\xa5\xd5\xa5\xc0\x85\xe5\xf6\xfa\x0b\x85\xc5\xdf\x14\x16\x7f\
SX\xec\xd7\x09\x8b\xbd),\xf6\xa6\xb0x_\x97\xcb\
tZ\x9fu\x19\x15\x15L\x06\xd0\xdcwQ]f\xc7\
\x8f\xf4\x0e\x91\xe6\x1f\x5c\xf8T`\xc6\x99\x16\xa1\xbb\xc6\
!\x0d9\x0d\x17\xe3\xc2\x87.x\xab\xb6\x99\x80\xb6!\
\xd5\xa4\xb8\x15\x8c[\xf3\xd2\xa6L`94\x94\xa1\xb4\
9t\x1c\x15\xdc,\xed+x\xdf\xa2\xe6F\xbd\xbfN\
\x0f\xe1\xc0\x0cu\xf4P>\xa6g\x0e\x1a\xc1\x01\x11\x01\
\xa0\xe4.\xb4`\x12\xf0\x1a.{-\xd5\x123\xc1\x98\
s\xecS\x06\xf8\x00\xb8z1x.\x8f\xcd\xbcLG\
X\x94\xa7\x99\xa8\xeb-|\x94\xads\xf4\x03\x1c\x0a9\
A?\xc0\xc3\xcbw\x02>\x15\xc1\x15\xf0%\x0e\xc6\xf2\
\x9f\x8a=\x14\x04\xc0\xce\x1df,\x1cc\xff6\x84\xae\
3\xa4\x04\xe7-\x1b\x81c\xc3\xef\xaf\x06%\x0d!\xcd\
\xa5\x0a\x88c\x90B\xfa\x0b\x18G\x94Z\xcc\xc1\x17\xff\
\x03>\xa7\xd3\xd4\x07_D\x8a+\xf0s\x1c\x86t\x0e\
\xbf\xd2\x10\x12\x9d\xc1\xbf\x8f\xe0\xcd\xee7\xa3\xda\xaa\xc1\
\xeb\xb5\xee\xf3\xdd\x19\xa1\x5c\xdd\xa1\x90\xfeDB\x18\xcc\
,\x84\x04\x9chG\x88\x82\x14\xa6|\xdc\x84\x06B\xe4\
\x88\x90}To{\x03\xd0\xff\xe5\x9e\x853#\xd3\xc8\
\x17\x8aa\x0ac\xce\x9f\xc8\xd7\x1a\x0b\xcd\x90\xcf\x85\x04\
\x91v\x22\xc6`TR\xc1D6{\xf4\x9f\x19-#\
\x9c\x04\xec\x94\x06\x80\x13u]\xe3G\xb2\xf3\x1a\xbc\x0d\
\x96\xd0;U\x07k\xdf\x9e\xda\xab\x91\x9e\x85\x0aB\xd6\
L\xc2\x01\xd8\xd7\x98\x07L\xf0`\x04\xf0\xe6\x08\x87\x9f\
\xe6d\x0a\x9e\xa3\x22\xcd\xcd\x08\xa6\x0e\x12\x97\xc7,\x80\
!\x91*\xac\xb5\x86\x95$\x1c\xde\xe9oDR\xc3$\
\xd5S\xbe\x1c?\xaf\xf3\x05u(Y(!\x05\xa0_\
\xba\xc1\x8f\x86H\xc3|\x1a*x_\xf2P\xe0\x90s\
\xa2`9\xd8p(\x04\xbb\x13\x94\xc2\x8c+o\x92\xf3\
A\xc6\xee\xe7\xde\xdd\xf8\xe73\xda\x8a\xde\x9f\xb1\xed\xb4\
\x13\xb6\xe0\xbc\x02Sgp\x7fAW\xcb\xca%Y\x13\
i\x12\x01be\x19\x9dV\x85-\xcc\xebP\xba\xb1:\
\x80}\xfb\x8cJ\x173\x82A\x97S\x86$\xbc\x14\xe5\
\x00\xe4&\x10*\x84\x97\xf1\x1c\xc8Q\x9f\x19N\xcb6\
1\xf5io\xe0\x0c\x10\xc3g\xf6\xfe\xbfzd\x19%\
1uyq\xfe\xb5\x98f`;\x1d\x90\xf9a\x03\x0a\
\x13\xce\x07\x02Q\xc1\xf1\xd0\xfcF\xc7\x83\xf3\x89\xe9\xc1\
\xfd\xff\x00\xfc\xfd\x0f\x9e\x8b\xb9\x09\
\x00\x00\x15\x06\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#FFFFFF\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
0 0 14 14\x22 role=\
\x22img\x22 focusable=\
\x22false\x22 aria-hid\
den=\x22true\x22 xmlns\
=\x22http://www.w3.\
org/2000/svg\x22><p\
ath d=\x22m 1.69275\
,12.9793 c -0.15\
08,-0.051 -0.304\
9,-0.1433 -0.39,\
-0.2325 -0.085,-\
0.089 -0.1532,-0\
.2209 -0.1828,-0\
.3536 -0.011,-0.\
049 -0.011,-0.08\
8 -0.012,-0.8636\
 l -10e-5,-0.812\
6 0.2523,0 0.252\
4,0 10e-5,0.7584\
 c 10e-5,0.8342 \
0,0.7987 0.037,0\
.8706 0.037,0.06\
9 0.111,0.1211 0\
.1959,0.1382 0.1\
048,0.021 0.2355\
,-0.047 0.2813,-\
0.1473 0.033,-0.\
072 0.032,-0.053\
 0.032,-0.8675 l\
 10e-5,-0.7524 0\
.2546,0 0.2546,0\
 0.3717,0.6309 0\
.3718,0.6308 0,-\
0.2764 0,-0.2764\
 0.2643,0 0.2643\
,0 0,0.7871 0,0.\
787 -0.2576,0 -0\
.2577,0 -0.3748,\
-0.6135 -0.3746,\
-0.6135 0,0.3116\
 c 0,0.3559 0,0.\
3522 -0.059,0.46\
78 -0.09,0.1849 \
-0.2854,0.3473 -\
0.5117,0.4247 l \
-0.056,0.019 -0.\
1473,0 -0.1471,0\
 -0.061,-0.021 z\
 m 3.3481,-0.043\
 c -0.2434,-0.03\
8 -0.4585,-0.149\
5 -0.6315,-0.327\
6 -0.1594,-0.164\
5 -0.259,-0.3591\
 -0.2975,-0.5821\
 -0.084,-0.4869 \
0.1612,-0.9686 0\
.6044,-1.1867 0.\
3107,-0.1528 0.6\
612,-0.1541 0.97\
4,0 0.2262,0.109\
 0.4035,0.2852 0\
.5176,0.5142 0.0\
25,0.051 0.063,0\
.1495 0.07,0.181\
8 l 0,0.019 -0.2\
363,0 -0.2362,0 \
-0.018,-0.034 c \
-0.045,-0.086 -0\
.1288,-0.1763 -0\
.2174,-0.2341 -0\
.1239,-0.081 -0.\
2536,-0.1156 -0.\
4031,-0.1082 -0.\
1689,0.01 -0.323\
2,0.079 -0.441,0\
.2016 -0.1243,0.\
1293 -0.1852,0.2\
798 -0.1852,0.45\
73 0,0.1899 0.06\
9,0.3527 0.2033,\
0.4822 0.1019,0.\
098 0.2066,0.151\
7 0.3495,0.1791 \
0.048,0.01 0.175\
9,0.01 0.2288,0 \
0.1989,-0.039 0.\
3693,-0.1616 0.4\
651,-0.3361 l 0.\
022,-0.04 0.2337\
,0 c 0.1881,0 0.\
2337,0 0.2337,0.\
01 0,0.019 -0.04\
5,0.139 -0.075,0\
.2003 -0.161,0.3\
289 -0.4765,0.55\
89 -0.8391,0.611\
7 -0.079,0.012 -\
0.2515,0.011 -0.\
3265,-3e-4 z m 2\
.3129,0.01 c -0.\
2673,-0.039 -0.4\
807,-0.1442 -0.6\
601,-0.3244 -0.4\
915,-0.4937 -0.4\
079,-1.316 0.173\
4,-1.7057 0.3234\
,-0.2166 0.7406,\
-0.2475 1.0904,-\
0.08 0.4408,0.21\
04 0.6904,0.6682\
 0.6278,1.1511 -\
0.055,0.4257 -0.\
3594,0.7872 -0.7\
694,0.9147 -0.11\
52,0.036 -0.1672\
,0.043 -0.3119,0\
.045 -0.073,0 -0\
.1403,8e-4 -0.15\
02,-7e-4 z m 0.2\
643,-0.4526 c 0.\
3284,-0.066 0.56\
19,-0.3848 0.526\
,-0.7189 -0.031,\
-0.2841 -0.2241,\
-0.5064 -0.5043,\
-0.5799 -0.066,-\
0.017 -0.1911,-0\
.022 -0.265,-0.0\
1 -0.266,0.046 -\
0.4684,0.2318 -0\
.5392,0.4952 -0.\
014,0.051 -0.016\
,0.07 -0.016,0.1\
573 -2e-4,0.082 \
0,0.1079 0.013,0\
.152 0.044,0.174\
2 0.1438,0.3155 \
0.2917,0.4114 0.\
1442,0.093 0.320\
9,0.1262 0.4936,\
0.092 z m 4.0615\
,0.4526 c -0.132\
6,-0.019 -0.2566\
,-0.056 -0.3589,\
-0.1074 -0.6082,\
-0.3033 -0.8097,\
-1.0584 -0.432,-\
1.6197 0.1611,-0\
.2392 0.4079,-0.\
406 0.689,-0.465\
5 0.3449,-0.073 \
0.6879,0.016 0.9\
623,0.2512 0.137\
1,0.1172 0.2592,\
0.3018 0.3192,0.\
4822 0.022,0.067\
 0.048,0.1748 0.\
042,0.1797 0,0 -\
0.097,0.039 -0.2\
127,0.084 -0.115\
7,0.045 -0.2252,\
0.088 -0.2433,0.\
096 -0.018,0.01 \
-0.2778,0.1073 -\
0.5768,0.2203 -0\
.299,0.1128 -0.5\
473,0.2071 -0.55\
16,0.2095 -0.01,\
0 0.01,0.018 0.0\
39,0.049 0.093,0\
.089 0.199,0.143\
7 0.3292,0.1705 \
0.063,0.013 0.18\
2,0.013 0.2488,0\
 0.2166,-0.042 0\
.4049,-0.1972 0.\
4876,-0.4024 l 0\
.017,-0.042 0.23\
11,0 0.2311,0 -0\
.01,0.041 c -0.0\
82,0.3704 -0.370\
2,0.6871 -0.7342\
,0.8067 -0.1215,\
0.04 -0.1838,0.0\
5 -0.331,0.051 -\
0.071,9e-4 -0.13\
74,4e-4 -0.1473,\
0 z m 0.036,-1.3\
739 c 0.2875,-0.\
1075 0.5304,-0.1\
983 0.5397,-0.20\
19 l 0.017,-0.01\
 -0.032,-0.027 c\
 -0.1298,-0.1111\
 -0.2834,-0.164 \
-0.4556,-0.157 -\
0.1593,0.01 -0.2\
899,0.057 -0.409\
8,0.1577 -0.1172\
,0.099 -0.2096,0\
.268 -0.225,0.41\
27 l 0,0.035 0.0\
23,-0.01 c 0.013\
,0 0.2586,-0.096\
 0.546,-0.2037 z\
 m -2.983,0.2628\
 0,-1.1089 0.434\
2,0 c 0.4103,0 0\
.4376,0 0.5001,0\
.015 0.1764,0.03\
4 0.3195,0.093 0\
.4596,0.192 0.07\
3,0.051 0.2067,0\
.185 0.2599,0.25\
98 0.052,0.073 0\
.1224,0.2129 0.1\
503,0.2985 0.117\
9,0.3625 0.042,0\
.7627 -0.2003,1.\
051 -0.1873,0.22\
32 -0.4592,0.364\
9 -0.7536,0.3926\
 -0.038,0 -0.233\
9,0.01 -0.4581,0\
.01 l -0.3921,0 \
0,-1.1089 z m 0.\
871,0.6615 c 0.2\
579,-0.053 0.452\
6,-0.2379 0.5213\
,-0.4949 0.014,-\
0.052 0.016,-0.0\
69 0.016,-0.1602\
 0,-0.091 0,-0.1\
087 -0.015,-0.15\
97 -0.053,-0.199\
1 -0.1763,-0.350\
9 -0.3553,-0.438\
3 -0.034,-0.016 \
-0.088,-0.037 -0\
.121,-0.046 -0.0\
58,-0.015 -0.067\
,-0.016 -0.2477,\
-0.018 l -0.1878\
,0 0,0.6683 0,0.\
6682 0.1728,0 c \
0.119,0 0.1866,-\
0.01 0.2175,-0.0\
13 z m -6.1881,-\
1.4992 0,-0.2764\
 0.2644,0 0.2643\
,0 0,0.2764 0,0.\
2763 -0.2643,0 -\
0.2644,0 0,-0.27\
63 z m -2.3852,-\
5.4343 0,-4.5632\
 0.1502,0 0.1502\
,0 0,3.2301 c 0,\
3.5786 0,3.2528 \
0.039,3.4548 0.0\
88,0.4125 0.27,0\
.8253 0.5059,1.1\
487 0.1853,0.254\
 0.4189,0.4777 0\
.7011,0.6713 0.3\
804,0.2611 0.803\
3,0.457 1.3251,0\
.6138 0.015,0 -0\
.4035,0.01 -1.42\
55,0.01 l -1.446\
4,6e-4 0,-4.563 \
z m 4.0003,4.547\
9 c 0.5032,-0.10\
66 1.0421,-0.373\
5 1.4851,-0.7352\
 0.5723,-0.4676 \
0.9292,-1.017 1.\
048,-1.6139 0.03\
1,-0.1569 0.03,-\
0.091 0.033,-1.3\
68 l 0,-1.188 1.\
5006,2.4565 c 0.\
8253,1.3511 1.50\
05,2.4581 1.5005\
,2.4601 0,0 -1.2\
688,0 -2.8193,0 \
l -2.8194,-3e-4 \
0.068,-0.014 z m\
 7.6299,-3.1316 \
0,-3.1467 -1.054\
5,0 -1.0544,0 0,\
1.1036 0,1.1036 \
-1.4629,-2.4819 \
c -0.8047,-1.365\
 -1.4731,-2.499 \
-1.4853,-2.52 l \
-0.022,-0.038 1.\
4867,0 1.4868,0 \
0,1.1025 0,1.102\
5 1.0574,0 1.057\
5,0 0,-1.1025 0,\
-1.1025 0.1501,0\
 0.1503,0 0,4.56\
32 0,4.563 -0.15\
03,0 -0.1501,0 0\
,-3.1467 z m -8.\
3528,1.0859 c -0\
.2748,-0.05 -0.5\
144,-0.177 -0.67\
19,-0.3572 -0.15\
13,-0.173 -0.238\
1,-0.3775 -0.278\
3,-0.6551 -0.01,\
-0.068 -0.011,-0\
.2588 -0.012,-3.\
0626 l 0,-2.9905\
 1.0937,0 1.0936\
,0 0,3.0115 0,3.\
0116 -0.013,0.07\
7 c -0.057,0.339\
6 -0.1908,0.581 \
-0.4164,0.752 -0\
.2241,0.1699 -0.\
5476,0.2574 -0.7\
896,0.2137 z\x22/><\
/svg>\
\x00\x00\x01\xd4\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -4 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -4)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
TV\x22>\x0d\x0a      <pat\
h d=\x22M28, 4L4, 4\
C2.9, 4 2, 4.9 2\
, 6L2, 22C2, 23.\
1 2.9, 24 4, 24L\
10, 24L10, 28L22\
, 28L22, 24L28, \
24C29.1, 24 30, \
23.1 30, 22L30, \
6C30, 4.9 29.1, \
4 28, 4zM28, 22L\
4, 22L4, 6L28, 6\
L28, 22z\x22 fill=\x22\
#FFFFFF\x22 class=\x22\
Black\x22 />\x0d\x0a    <\
/g>\x0d\x0a  </g>\x0d\x0a</s\
vg>\
\x00\x00\x08*\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   sodipodi:do\
cname=\x22paste-gra\
y.svg\x22\x0a   inksca\
pe:version=\x221.4 \
(e7c3feb100, 202\
4-10-09)\x22\x0a   xml\
ns:inkscape=\x22htt\
p://www.inkscape\
.org/namespaces/\
inkscape\x22\x0a   xml\
ns:sodipodi=\x22htt\
p://sodipodi.sou\
rceforge.net/DTD\
/sodipodi-0.dtd\x22\
\x0a   xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
>\x0a  <defs\x0a     i\
d=\x22defs2\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     id=\x22name\
dview2\x22\x0a     pag\
ecolor=\x22#000000\x22\
\x0a     bordercolo\
r=\x22#FFFFFF\x22\x0a    \
 borderopacity=\x22\
0.25\x22\x0a     inksc\
ape:showpageshad\
ow=\x222\x22\x0a     inks\
cape:pageopacity\
=\x220.0\x22\x0a     inks\
cape:pagechecker\
board=\x220\x22\x0a     i\
nkscape:deskcolo\
r=\x22#d1d1d1\x22\x0a    \
 inkscape:zoom=\x22\
25.21875\x22\x0a     i\
nkscape:cx=\x2216\x22\x0a\
     inkscape:cy\
=\x2216\x22\x0a     inksc\
ape:window-width\
=\x221920\x22\x0a     ink\
scape:window-hei\
ght=\x22969\x22\x0a     i\
nkscape:window-x\
=\x220\x22\x0a     inksca\
pe:window-y=\x220\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
svg2\x22 />\x0a  <g\x0a  \
   transform=\x22tr\
anslate(0, 0)\x22\x0a \
    id=\x22g2\x22\x0a    \
 style=\x22fill:#FF\
FFFF;fill-opacit\
y:1\x22>\x0a    <g\x0a   \
    transform=\x22m\
atrix(0.05468749\
62747097, 0, 0, \
0.05468749627470\
97, 0, 0)\x22\x0a     \
  id=\x22g1\x22\x0a      \
 style=\x22fill:#FF\
FFFF;fill-opacit\
y:1\x22>\x0a      <pat\
h\x0a         d=\x22M1\
04.6, 48L64, 48C\
28.7, 48 0, 76.7\
 0, 112L0, 384C0\
, 419.3 28.7, 44\
8 64, 448L160, 4\
48L160, 400L64, \
400C55.2, 400 48\
, 392.8 48, 384L\
48, 112C48, 103.\
2 55.2, 96 64, 9\
6L80, 96C80, 113\
.7 94.3, 128 112\
, 128L184.4, 128\
C202, 108.4 227.\
6, 96 256, 96L31\
8, 96C310.9, 68.\
4 285.8, 48 256,\
 48L215.4, 48C21\
1.6, 20.9 188.2,\
 0 160, 0C131.8,\
 0 108.4, 20.9 1\
04.6, 48zM144, 5\
6A16 16 0 1 1 17\
6, 56A16 16 0 1 \
1 144, 56zM448, \
464L256, 464C247\
.2, 464 240, 456\
.8 240, 448L240,\
 192C240, 183.2 \
247.2, 176 256, \
176L396.1, 176L4\
64, 243.9L464, 4\
48C464, 456.8 45\
6.8, 464 448, 46\
4zM256, 512L448,\
 512C483.3, 512 \
512, 483.3 512, \
448L512, 243.9C5\
12, 231.2 506.9,\
 219 497.9, 210L\
430, 142.1C421, \
133.1 408.8, 128\
 396.1, 128L256,\
 128C220.7, 128 \
192, 156.7 192, \
192L192, 448C192\
, 483.3 220.7, 5\
12 256, 512z\x22\x0a  \
       id=\x22path1\
\x22\x0a         style\
=\x22fill:#FFFFFF;f\
ill-opacity:1\x22 /\
>\x0a    </g>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x07\x01\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   he\
ight=\x2256\x22\x0a   vie\
wBox=\x220 0 56 56\x22\
\x0a   width=\x2256\x22\x0a \
  version=\x221.1\x22\x0a\
   id=\x22svg1\x22\x0a   \
sodipodi:docname\
=\x22eyedropper.svg\
\x22\x0a   inkscape:ve\
rsion=\x221.4 (e7c3\
feb100, 2024-10-\
09)\x22\x0a   xmlns:in\
kscape=\x22http://w\
ww.inkscape.org/\
namespaces/inksc\
ape\x22\x0a   xmlns:so\
dipodi=\x22http://s\
odipodi.sourcefo\
rge.net/DTD/sodi\
podi-0.dtd\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22>\x0a  <\
defs\x0a     id=\x22de\
fs1\x22 />\x0a  <sodip\
odi:namedview\x0a  \
   id=\x22namedview\
1\x22\x0a     pagecolo\
r=\x22#000000\x22\x0a    \
 bordercolor=\x22#F\
FFFFF\x22\x0a     bord\
eropacity=\x220.25\x22\
\x0a     inkscape:s\
howpageshadow=\x222\
\x22\x0a     inkscape:\
pageopacity=\x220.0\
\x22\x0a     inkscape:\
pagecheckerboard\
=\x220\x22\x0a     inksca\
pe:deskcolor=\x22#d\
1d1d1\x22\x0a     inks\
cape:zoom=\x2213.10\
7143\x22\x0a     inksc\
ape:cx=\x2228.03814\
7\x22\x0a     inkscape\
:cy=\x2228\x22\x0a     in\
kscape:window-wi\
dth=\x221142\x22\x0a     \
inkscape:window-\
height=\x22942\x22\x0a   \
  inkscape:windo\
w-x=\x2245\x22\x0a     in\
kscape:window-y=\
\x2245\x22\x0a     inksca\
pe:window-maximi\
zed=\x220\x22\x0a     ink\
scape:current-la\
yer=\x22svg1\x22 />\x0a  \
<path\x0a     d=\x22m3\
9.6485 28.9024.6\
563-.7266c1.1484\
-1.1953 1.1953-2\
.6016-.0235-3.82\
03l-.7031-.6797c\
3.5859-3.2109 7.\
5703-3.6563 10.0\
313-6.1641 3.492\
-3.5156 2.3438-8\
.4375-.0936-10.8\
984-2.4379-2.484\
4-7.3127-3.5391-\
10.8987-.0938-2.\
5312 2.4376-2.95\
31 6.4454-6.164 \
10.0313l-.6797-.\
7032c-1.2187-1.2\
187-2.625-1.1718\
-3.8203-.0234l-.\
7266.6563c-1.429\
7 1.3828-1.1718 \
2.6015.0703 3.84\
37l.9844.9844-17\
.6953 17.7188c-7\
.2422 7.2421-3.7\
5 6.1171-7.6875 \
11.6718l2.086 2.\
2266c5.3905-3.91\
41 4.664-.0703 1\
2-7.4063l17.8124\
-17.6953 1.0079 \
1.0078c1.2421 1.\
2422 2.4609 1.5 \
3.8437.0704zm-29\
.5313 17.2265c-.\
8671-.9375-.7031\
-1.8281.2344-2.7\
656l19.9453-20.0\
391 2.5547 2.554\
7-20.039 20.0156\
c-.8203.8438-1.8\
985 1.1016-2.695\
4.2344z\x22\x0a     id\
=\x22path1\x22 \x0a\x09  sty\
le=\x22stroke-width\
:1.33333;fill:#f\
fffff;fill-opaci\
ty:1\x22 />\x0a</svg>\x0a\
\
\x00\x00\x08\xcc\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -4 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg7\
\x22\x0a   sodipodi:do\
cname=\x22image.svg\
\x22\x0a   inkscape:ve\
rsion=\x221.4 (86a8\
ad7, 2024-10-11)\
\x22\x0a   xmlns:inksc\
ape=\x22http://www.\
inkscape.org/nam\
espaces/inkscape\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s=\x22http://www.w3\
.org/2000/svg\x22\x0a \
  xmlns:svg=\x22htt\
p://www.w3.org/2\
000/svg\x22>\x0a  <def\
s\x0a     id=\x22defs7\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
id=\x22namedview7\x22\x0a\
     pagecolor=\x22\
#000000\x22\x0a     bo\
rdercolor=\x22#0000\
00\x22\x0a     bordero\
pacity=\x220.25\x22\x0a  \
   inkscape:show\
pageshadow=\x222\x22\x0a \
    inkscape:pag\
eopacity=\x220.0\x22\x0a \
    inkscape:pag\
echeckerboard=\x220\
\x22\x0a     inkscape:\
deskcolor=\x22#d1d1\
d1\x22\x0a     inkscap\
e:zoom=\x2224.3125\x22\
\x0a     inkscape:c\
x=\x2215.979434\x22\x0a  \
   inkscape:cy=\x22\
16\x22\x0a     inkscap\
e:window-width=\x22\
1920\x22\x0a     inksc\
ape:window-heigh\
t=\x22996\x22\x0a     ink\
scape:window-x=\x22\
-9\x22\x0a     inkscap\
e:window-y=\x22-9\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
svg7\x22 />\x0a  <g\x0a  \
   id=\x22Layer_1\x22\x0a\
     transform=\x22\
translate(-2, -4\
)\x22\x0a     style=\x22e\
nable-background\
:new 0 0 32 32\x22>\
\x0a    <g\x0a       i\
d=\x22Image\x22>\x0a     \
 <path\x0a         \
d=\x22M29, 4L3, 4C2\
.5, 4 2, 4.5 2, \
5L2, 27C2, 27.5 \
2.5, 28 3, 28L29\
, 28C29.5, 28 30\
, 27.5 30, 27L30\
, 5C30, 4.5 29.5\
, 4 29, 4zM28, 2\
6L4, 26L4, 6L28,\
 6L28, 26z\x22\x0a    \
     fill=\x22#FFFF\
FF\x22\x0a         cla\
ss=\x22Black\x22\x0a     \
    id=\x22path1\x22 /\
>\x0a    </g>\x0a  </g\
>\x0a  <g\x0a     id=\x22\
g2\x22\x0a     transfo\
rm=\x22translate(-2\
, -4)\x22\x0a     styl\
e=\x22enable-backgr\
ound:new 0 0 32 \
32\x22>\x0a    <g\x0a    \
   id=\x22g1\x22>\x0a    \
  <circle\x0a      \
   cx=\x2221\x22\x0a     \
    cy=\x2211\x22\x0a    \
     r=\x223\x22\x0a     \
    fill=\x22#FFB11\
5\x22\x0a         clas\
s=\x22Yellow\x22\x0a     \
    id=\x22circle1\x22\
 />\x0a    </g>\x0a  <\
/g>\x0a  <g\x0a     id\
=\x22g4\x22\x0a     trans\
form=\x22translate(\
-2, -4)\x22\x0a     st\
yle=\x22enable-back\
ground:new 0 0 3\
2 32\x22>\x0a    <g\x0a  \
     id=\x22g3\x22>\x0a  \
    <polygon\x0a   \
      points=\x2220\
,24 10,14 6,18 6\
,24  \x22\x0a         \
fill=\x22#039C23\x22\x0a \
        class=\x22G\
reen\x22\x0a         i\
d=\x22polygon2\x22 />\x0a\
    </g>\x0a  </g>\x0a\
  <g\x0a     id=\x22g7\
\x22\x0a     transform\
=\x22translate(-2, \
-4)\x22\x0a     style=\
\x22enable-backgrou\
nd:new 0 0 32 32\
\x22>\x0a    <g\x0a      \
 id=\x22g6\x22>\x0a      \
<g\x0a         clas\
s=\x22st1\x22\x0a        \
 id=\x22g5\x22>\x0a      \
  <polygon\x0a     \
      points=\x2222\
,24 18,20 20,18 \
26,24   \x22\x0a      \
     fill=\x22#039C\
23\x22\x0a           c\
lass=\x22Green\x22\x0a   \
        id=\x22poly\
gon4\x22 />\x0a      <\
/g>\x0a    </g>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x0bs\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -8.16 \
32 32\x22\x0a   versio\
n=\x221.1\x22\x0a   id=\x22s\
vg3\x22\x0a   sodipodi\
:docname=\x22visibl\
e.svg\x22\x0a   inksca\
pe:version=\x221.4 \
(86a8ad7, 2024-1\
0-11)\x22\x0a   xmlns:\
inkscape=\x22http:/\
/www.inkscape.or\
g/namespaces/ink\
scape\x22\x0a   xmlns:\
sodipodi=\x22http:/\
/sodipodi.source\
forge.net/DTD/so\
dipodi-0.dtd\x22\x0a  \
 xmlns=\x22http://w\
ww.w3.org/2000/s\
vg\x22\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22>\x0a \
 <defs\x0a     id=\x22\
defs3\x22 />\x0a  <sod\
ipodi:namedview\x0a\
     id=\x22namedvi\
ew3\x22\x0a     pageco\
lor=\x22#ffffff\x22\x0a  \
   bordercolor=\x22\
#000000\x22\x0a     bo\
rderopacity=\x220.2\
5\x22\x0a     inkscape\
:showpageshadow=\
\x222\x22\x0a     inkscap\
e:pageopacity=\x220\
.0\x22\x0a     inkscap\
e:pagecheckerboa\
rd=\x22true\x22\x0a     i\
nkscape:deskcolo\
r=\x22#d1d1d1\x22\x0a    \
 inkscape:zoom=\x22\
24.3125\x22\x0a     in\
kscape:cx=\x2215.97\
9434\x22\x0a     inksc\
ape:cy=\x2216\x22\x0a    \
 inkscape:window\
-width=\x221920\x22\x0a  \
   inkscape:wind\
ow-height=\x22996\x22\x0a\
     inkscape:wi\
ndow-x=\x22-9\x22\x0a    \
 inkscape:window\
-y=\x22-9\x22\x0a     ink\
scape:window-max\
imized=\x221\x22\x0a     \
inkscape:current\
-layer=\x22svg3\x22 />\
\x0a  <g\x0a     trans\
form=\x22translate(\
0, -6.16)\x22\x0a     \
id=\x22g3\x22>\x0a    <g\x0a\
       transform\
=\x22matrix(0.02800\
00045895576, 0, \
0, 0.02800000458\
95576, 0, 0)\x22\x0a  \
     id=\x22g2\x22>\x0a  \
    <g\x0a         \
id=\x22g1\x22>\x0a       \
 <path\x0a         \
  d=\x22M500, 220C5\
61.333, 220 620.\
333, 228.333 677\
, 245C733.667, 2\
61.667 780.667, \
282.333 818, 307\
C855.333, 331.66\
7 888.333, 357.3\
33 917, 384C945.\
667, 410.667 966\
.667, 434.333 98\
0, 455C993.333, \
475.667 1000, 49\
0.667 1000, 500C\
1000, 509.333 99\
3.333, 524 980, \
544C966.667, 564\
 945.667, 587.66\
7 917, 615C888.3\
33, 642.333 855.\
333, 668.333 818\
, 693C780.667, 7\
17.667 733.667, \
738.333 677, 755\
C620.333, 771.66\
7 561.333, 780 5\
00, 780C438.667,\
 780 379.667, 77\
1.667 323, 755C2\
66.333, 738.333 \
219.333, 717.667\
 182, 693C144.66\
7, 668.333 111.6\
67, 642.333 83, \
615C54.333, 587.\
667 33.333, 564 \
20, 544C6.667, 5\
24 0, 509.333 0,\
 500C0, 490.667 \
6.667, 475.667 2\
0, 455C33.333, 4\
34.333 54.333, 4\
10.667 83, 384C1\
11.667, 357.333 \
144.667, 331.667\
 182, 307C219.33\
3, 282.333 266.3\
33, 261.667 323,\
 245C379.667, 22\
8.333 438.667, 2\
20 500, 220C500,\
 220 500, 220 50\
0, 220M500, 714C\
561.333, 714 613\
.667, 693 657, 6\
51C700.333, 609 \
722, 558.667 722\
, 500C722, 440 7\
00.333, 389 657,\
 347C613.667, 30\
5 561.333, 284 5\
00, 284C438.667,\
 284 386.333, 30\
5 343, 347C299.6\
67, 389 278, 440\
 278, 500C278, 5\
58.667 299.667, \
609 343, 651C386\
.333, 693 438.66\
7, 714 500, 714C\
500, 714 500, 71\
4 500, 714M500, \
500C505.333, 505\
.333 517.667, 50\
6 537, 502C556.3\
33, 498 573, 494\
.333 587, 491C60\
1, 487.667 609.3\
33, 490.667 612,\
 500C612, 529.33\
3 601, 554.333 5\
79, 575C557, 595\
.667 530.667, 60\
6 500, 606C469.3\
33, 606 443.333,\
 595.667 422, 57\
5C400.667, 554.3\
33 390, 529.333 \
390, 500C390, 46\
9.333 400.667, 4\
43.667 422, 423C\
443.333, 402.333\
 469.333, 392 50\
0, 392C509.333, \
392 512.667, 399\
.667 510, 415C50\
7.333, 430.333 5\
03.333, 446 498,\
 462C492.667, 47\
8 493.333, 490.6\
67 500, 500C500,\
 500 500, 500 50\
0, 500\x22\x0a        \
   id=\x22path1\x22\x0a  \
         style=\x22\
fill:#ffffff;fil\
l-opacity:1\x22 />\x0a\
      </g>\x0a    <\
/g>\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x08\x15\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   sodipodi:do\
cname=\x22circle-gr\
ay.svg\x22\x0a   inksc\
ape:version=\x221.4\
 (86a8ad7, 2024-\
10-11)\x22\x0a   xmlns\
:inkscape=\x22http:\
//www.inkscape.o\
rg/namespaces/in\
kscape\x22\x0a   xmlns\
:sodipodi=\x22http:\
//sodipodi.sourc\
eforge.net/DTD/s\
odipodi-0.dtd\x22\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0a   xmlns:sv\
g=\x22http://www.w3\
.org/2000/svg\x22>\x0a\
  <defs\x0a     id=\
\x22defs2\x22 />\x0a  <so\
dipodi:namedview\
\x0a     id=\x22namedv\
iew2\x22\x0a     pagec\
olor=\x22#000000\x22\x0a \
    bordercolor=\
\x22#FFFFFF\x22\x0a     b\
orderopacity=\x220.\
25\x22\x0a     inkscap\
e:showpageshadow\
=\x222\x22\x0a     inksca\
pe:pageopacity=\x22\
0.0\x22\x0a     inksca\
pe:pagecheckerbo\
ard=\x220\x22\x0a     ink\
scape:deskcolor=\
\x22#d1d1d1\x22\x0a     i\
nkscape:zoom=\x2225\
.21875\x22\x0a     ink\
scape:cx=\x2216\x22\x0a  \
   inkscape:cy=\x22\
12.768278\x22\x0a     \
inkscape:window-\
width=\x221920\x22\x0a   \
  inkscape:windo\
w-height=\x22996\x22\x0a \
    inkscape:win\
dow-x=\x22-9\x22\x0a     \
inkscape:window-\
y=\x22-9\x22\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0a     i\
nkscape:current-\
layer=\x22g2\x22\x0a     \
showgrid=\x22true\x22>\
\x0a    <inkscape:g\
rid\x0a       id=\x22g\
rid1\x22\x0a       uni\
ts=\x22px\x22\x0a       o\
riginx=\x220\x22\x0a     \
  originy=\x220\x22\x0a  \
     spacingx=\x221\
\x22\x0a       spacing\
y=\x221\x22\x0a       emp\
color=\x22#0099e5\x22\x0a\
       empopacit\
y=\x220.30196078\x22\x0a \
      color=\x22#00\
99e5\x22\x0a       opa\
city=\x220.14901961\
\x22\x0a       empspac\
ing=\x225\x22\x0a       e\
nabled=\x22true\x22\x0a  \
     visible=\x22tr\
ue\x22 />\x0a  </sodip\
odi:namedview>\x0a \
 <g\x0a     id=\x22Cap\
a_1\x22\x0a     transf\
orm=\x22matrix(0.92\
887419,0,0,0.920\
12721,0.99195841\
,1.0770303)\x22\x0a   \
  style=\x22fill:#F\
FFFFF;fill-opaci\
ty:1;stroke:none\
;stroke-opacity:\
1;stroke-width:0\
.99946959;stroke\
-dasharray:none\x22\
>\x0a    <g\x0a       \
transform=\x22scale\
(0.96195179)\x22\x0a  \
     id=\x22g2\x22\x0a   \
    style=\x22fill:\
#FFFFFF;fill-opa\
city:1;stroke:no\
ne;stroke-opacit\
y:1;stroke-width\
:1.03900175;stro\
ke-dasharray:non\
e\x22>\x0a      <ellip\
se\x0a         styl\
e=\x22fill:none;fil\
l-rule:evenodd;s\
troke:#FFFFFF;st\
roke-width:3.335\
22;stroke-lineca\
p:round;stroke-l\
inejoin:bevel;st\
roke-dasharray:n\
one;stroke-opaci\
ty:1;paint-order\
:stroke fill mar\
kers\x22\x0a         i\
d=\x22path1\x22\x0a      \
   cx=\x2214.557998\
\x22\x0a         cy=\x221\
4.600277\x22\x0a      \
   rx=\x2212.881395\
\x22\x0a         ry=\x221\
3.019702\x22 />\x0a   \
 </g>\x0a  </g>\x0a</s\
vg>\x0a\
\x00\x00\x0a\x90\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg9\
\x22\x0a   sodipodi:do\
cname=\x22blur.svg\x22\
\x0a   inkscape:ver\
sion=\x221.4 (86a8a\
d7, 2024-10-11)\x22\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0a   xmlns:sodipo\
di=\x22http://sodip\
odi.sourceforge.\
net/DTD/sodipodi\
-0.dtd\x22\x0a   xmlns\
=\x22http://www.w3.\
org/2000/svg\x22\x0a  \
 xmlns:svg=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a  <defs\
\x0a     id=\x22defs9\x22\
 />\x0a  <sodipodi:\
namedview\x0a     i\
d=\x22namedview9\x22\x0a \
    pagecolor=\x22#\
000000\x22\x0a     bor\
dercolor=\x22#00000\
0\x22\x0a     borderop\
acity=\x220.25\x22\x0a   \
  inkscape:showp\
ageshadow=\x222\x22\x0a  \
   inkscape:page\
opacity=\x220.0\x22\x0a  \
   inkscape:page\
checkerboard=\x22tr\
ue\x22\x0a     inkscap\
e:deskcolor=\x22#d1\
d1d1\x22\x0a     inksc\
ape:zoom=\x2224.312\
5\x22\x0a     inkscape\
:cx=\x2215.979434\x22\x0a\
     inkscape:cy\
=\x2216\x22\x0a     inksc\
ape:window-width\
=\x221920\x22\x0a     ink\
scape:window-hei\
ght=\x22996\x22\x0a     i\
nkscape:window-x\
=\x22-9\x22\x0a     inksc\
ape:window-y=\x22-9\
\x22\x0a     inkscape:\
window-maximized\
=\x221\x22\x0a     inksca\
pe:current-layer\
=\x22svg9\x22 />\x0a  <pa\
th\x0a     d=\x22M 14,\
0 C 6.2680135,-3\
.313709e-8 -3.31\
37089e-8,6.26801\
35 0,14 -3.31370\
89e-8,21.731987 \
6.2680135,28 14,\
28 21.731987,28 \
28,21.731987 28,\
14 28,6.2680135 \
21.731987,-3.313\
7087e-8 14,0 Z m\
 0,5.203125 c 0,\
-0.066142 0.9265\
69,2.1384966 2.4\
25781,4.2109375 \
1.433071,2.16062\
95 3.417603,4.16\
64705 3.814453,5\
.9082035 0.08819\
,0.39685 0.15429\
7,0.816867 0.154\
297,1.257812 0.0\
6614,3.461417 -2\
.823739,6.238281\
 -6.285156,6.238\
281 h -0.21875 c\
 -3.461417,0 -6.\
3512982,-2.80030\
1 -6.2851563,-6.\
261718 0,-0.4409\
45 0.044061,-0.8\
59009 0.1542969,\
-1.25586 C 8.156\
616,13.603143 10\
.163195,11.57469\
2 11.574219,9.41\
40625 13.051384,\
7.3636688 13.977\
95,5.159031 14,5\
.203125 Z m -1.1\
91406,4.0117188 \
c -0.04409,0.066\
141 -0.08676,0.1\
336403 -0.13086,\
0.1777343 -1.455\
118,2.2267719 -3\
.5275402,4.34281\
49 -3.9023434,6.\
0624999 -0.08818\
8,0.396851 -0.13\
28125,0.838352 -\
0.1328125,1.2792\
97 0.022047,0.92\
5984 0.2646961,1\
.763503 0.683593\
8,2.535156 0.110\
2362,0.154333 0.\
2650283,0.242753\
 0.4414062,0.220\
703 0.3307049,-0\
.02205 0.5287669\
,-0.331136 0.396\
4849,-0.595703 -\
0.1763791,-0.396\
85 -0.3303429,-0\
.814914 -0.39648\
49,-1.255859 -0.\
08819,-0.440945 \
-0.1099376,-0.86\
0399 -0.087891,-\
1.279297 0.06614\
2,-1.76378 1.763\
4349,-4.144288 2\
.8437509,-6.5253\
906 0.110236,-0.\
1984252 0.196966\
,-0.4207155 0.28\
5156,-0.6191406 \
z m -2.44336,10.\
4960932 c -0.280\
458,0.01122 -0.4\
993209,0.228338 \
-0.4882809,0.484\
375 0.011815,0.2\
5449 0.2465999,0\
.450874 0.525390\
9,0.439454 0.279\
591,-0.01123 0.4\
98081,-0.227126 \
0.488281,-0.4824\
22 -0.01067,-0.2\
55269 -0.245799,\
-0.452806 -0.525\
391,-0.441407 z\x22\
\x0a     style=\x22bas\
eline-shift:base\
line;display:inl\
ine;overflow:vis\
ible;vector-effe\
ct:none;fill:#ff\
ffff;enable-back\
ground:accumulat\
e;stop-color:#00\
0000;stop-opacit\
y:1;fill-opacity\
:1\x22\x0a     id=\x22pat\
h15\x22 />\x0a</svg>\x0a\
\x00\x00\x0e\xdd\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   width=\x22\
31.994951\x22\x0a   he\
ight=\x2232.000015\x22\
\x0a   viewBox=\x2232 \
32 8.9386878 8.9\
401026\x22\x0a   versi\
on=\x221.1\x22\x0a   id=\x22\
svg1\x22\x0a   inkscap\
e:version=\x221.4 (\
86a8ad7, 2024-10\
-11)\x22\x0a   sodipod\
i:docname=\x22lasso\
_select.svg\x22\x0a   \
inkscape:export-\
filename=\x22lasso_\
select.png\x22\x0a   i\
nkscape:export-x\
dpi=\x221.6256\x22\x0a   \
inkscape:export-\
ydpi=\x221.6256\x22\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0a  \
 xmlns:sodipodi=\
\x22http://sodipodi\
.sourceforge.net\
/DTD/sodipodi-0.\
dtd\x22\x0a   xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22\x0a   xm\
lns:svg=\x22http://\
www.w3.org/2000/\
svg\x22>\x0a  <sodipod\
i:namedview\x0a    \
 id=\x22namedview1\x22\
\x0a     pagecolor=\
\x22#000000\x22\x0a     b\
ordercolor=\x22#FFF\
FFF\x22\x0a     border\
opacity=\x220.25\x22\x0a \
    inkscape:sho\
wpageshadow=\x222\x22\x0a\
     inkscape:pa\
geopacity=\x220.0\x22\x0a\
     inkscape:pa\
gecheckerboard=\x22\
true\x22\x0a     inksc\
ape:deskcolor=\x22#\
d1d1d1\x22\x0a     ink\
scape:document-u\
nits=\x22px\x22\x0a     i\
nkscape:zoom=\x2216\
\x22\x0a     inkscape:\
cx=\x2216.96875\x22\x0a  \
   inkscape:cy=\x22\
17.5\x22\x0a     inksc\
ape:window-width\
=\x221920\x22\x0a     ink\
scape:window-hei\
ght=\x22996\x22\x0a     i\
nkscape:window-x\
=\x22-9\x22\x0a     inksc\
ape:window-y=\x22-9\
\x22\x0a     inkscape:\
window-maximized\
=\x221\x22\x0a     inksca\
pe:current-layer\
=\x22layer1\x22\x0a     s\
howgrid=\x22true\x22>\x0a\
    <inkscape:gr\
id\x0a       id=\x22gr\
id1\x22\x0a       unit\
s=\x22mm\x22\x0a       or\
iginx=\x220\x22\x0a      \
 originy=\x220\x22\x0a   \
    spacingx=\x221.\
0000395\x22\x0a       \
spacingy=\x221.0000\
395\x22\x0a       empc\
olor=\x22#0099e5\x22\x0a \
      empopacity\
=\x220.30196078\x22\x0a  \
     color=\x22#009\
9e5\x22\x0a       opac\
ity=\x220.14901961\x22\
\x0a       empspaci\
ng=\x225\x22\x0a       en\
abled=\x22true\x22\x0a   \
    visible=\x22tru\
e\x22 />\x0a  </sodipo\
di:namedview>\x0a  \
<defs\x0a     id=\x22d\
efs1\x22 />\x0a  <g\x0a  \
   inkscape:labe\
l=\x22Katman 1\x22\x0a   \
  inkscape:group\
mode=\x22layer\x22\x0a   \
  id=\x22layer1\x22\x0a  \
   transform=\x22tr\
anslate(-201.519\
79,-235.5087)\x22>\x0a\
    <ellipse\x0a   \
    style=\x22fill:\
#4677ef;fill-opa\
city:0.34657;str\
oke:#FFFFFF;stro\
ke-width:0.58501\
992;stroke-linec\
ap:butt;stroke-d\
asharray:none;st\
roke-opacity:1;p\
aint-order:norma\
l\x22\x0a       id=\x22pa\
th1\x22\x0a       cx=\x22\
360.98166\x22\x0a     \
  cy=\x22-15.824715\
\x22\x0a       rx=\x222.0\
321822\x22\x0a       r\
y=\x223.0664492\x22\x0a  \
     transform=\x22\
matrix(0.6274904\
8,0.77862423,-0.\
77616391,0.63053\
119,0,0)\x22 />\x0a   \
 <ellipse\x0a      \
 id=\x22path5\x22\x0a    \
   style=\x22fill:#\
ef8946;stroke:#7\
07070;stroke-wid\
th:0.00478869\x22\x0a \
      cx=\x22236.77\
841\x22\x0a       cy=\x22\
272.81592\x22\x0a     \
  rx=\x220.00064945\
634\x22\x0a       ry=\x22\
0.00065205846\x22 /\
>\x0a    <path\x0a    \
   style=\x22fill:#\
707070;fill-opac\
ity:1;stroke:#FF\
FFFF;stroke-widt\
h:0.36375025;str\
oke-linecap:squa\
re;stroke-linejo\
in:round;stroke-\
dasharray:none;s\
troke-opacity:1;\
paint-order:mark\
ers fill stroke\x22\
\x0a       d=\x22m 237\
.41623,273.2039 \
c 0,0 0.11229,-0\
.0331 0.13475,-0\
.21916 0.0226,-0\
.18608 0.0315,-0\
.21502 -0.0628,-\
0.35563 -0.0943,\
-0.14059 -0.5748\
8,-0.0166 -0.574\
88,-0.0166 0,0 -\
0.38986,0.1396 -\
0.72759,0.43419 \
-0.17067,0.14887\
 -0.46709,0.459 \
-0.44014,0.6823 \
0.0269,0.22329 0\
.0943,0.33081 0.\
26499,0.34322 0.\
17066,0.0124 0.5\
1199,-0.0951 0.6\
4224,-0.20676 0.\
13024,-0.11165 0\
.0988,0.0413 0.0\
988,0.0413 0,0 -\
0.65075,0.5815 -\
1.00604,0.85597 \
-0.27894,0.21549\
 -0.86233,0.612 \
-0.8803,0.62441 \
-0.018,0.0124 0.\
0943,0.11992 0.0\
943,0.11992 0,0 \
0.70962,-0.49208\
 1.11382,-0.8311\
6 0.40423,-0.339\
08 0.91622,-0.82\
289 0.91622,-0.8\
2289 0,0 0.0359,\
-0.0413 0,-0.128\
19 -0.0359,-0.08\
69 -0.15269,-0.0\
827 -0.26049,-0.\
0413 -0.10778,0.\
0413 -0.18996,0.\
1093 -0.41319,0.\
17781 -0.12127,0\
.0372 -0.28744,0\
.0744 -0.3638,0.\
0208 -0.0564,-0.\
0397 -0.0982,-0.\
16547 -0.0495,-0\
.26466 0.0512,-0\
.10406 0.0907,-0\
.15983 0.14796,-\
0.23259 0.0478,-\
0.0607 0.16194,-\
0.1685 0.16194,-\
0.1685 0,0 0.251\
51,-0.26879 0.56\
589,-0.40111 0.3\
1439,-0.13233 0.\
47159,-0.11579 0\
.47159,-0.11579 \
0,0 0.13474,-0.0\
05 0.16617,0.099\
2 0.0278,0.0917 \
0.006,0.21063 -0\
.0359,0.27292 -0\
.0816,0.12233 -0\
.19726,0.15284 -\
0.13923,0.20675 \
0.0426,0.0396 0.\
17516,-0.0744 0.\
17516,-0.0744 z\x22\
\x0a       id=\x22path\
6\x22\x0a       sodipo\
di:nodetypes=\x22cs\
scsssscsscscssss\
sscscsssc\x22 />\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x06z\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2.0025 \
-4.8025 32 32\x22 x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22 >\x0d\x0a  <g transf\
orm=\x22translate(-\
0.0006, -0.0018)\
\x22>\x0d\x0a    <g trans\
form=\x22matrix(0.0\
437470972537994,\
 0, 0, 0.0437470\
972537994, 0, 0)\
\x22>\x0d\x0a      <path \
d=\x22M352, 124.5L3\
00.1, 111.5C293.\
6, 109.9 288.8, \
104.4 288.1, 97.\
7C287.4, 91 290.\
9, 84.6 296.8, 8\
1.6L337.6, 61.2L\
294.4, 28.8C288.\
9, 24.7 286.6, 1\
7.5 288.8, 10.9C\
291, 4.3 297.1, \
0 304, 0L416, 0L\
448, 0L464, 0C49\
4.2, 0 522.7, 14\
.2 540.8, 38.4L5\
98.4, 115.2C604.\
6, 123.5 608, 13\
3.6 608, 144C608\
, 170.5 586.5, 1\
92 560, 192L538.\
5, 192C521.5, 19\
2 505.2, 185.3 4\
93.2, 173.3L480,\
 160L448, 160L44\
8, 181.5C448, 20\
6.3 460.8, 229.4\
 481.8, 242.6L58\
8.4, 309.2C620.5\
, 329.3 640, 364\
.4 640, 402.3C64\
0, 462.9 590.9, \
512 530.2, 512L4\
96, 512L432, 512\
L32.3, 512C29, 5\
12 25.7, 511.6 2\
2.7, 510.6C13.5,\
 507.8 6, 501 2.\
4, 492.1C1, 488.\
7 0.2, 485.2 0, \
481.4C-0.2, 477.\
7 0.3, 474.1 1.3\
, 470.7C4.1, 461\
.5 10.9, 454 19.\
9, 450.3C22.9, 4\
49.1 26.1, 448.3\
 29.4, 448.1L433\
.3, 412C441.6, 4\
11.3 448, 404.3 \
448, 395.9C448, \
391.6 446.3, 387\
.5 443.3, 384.5L\
398.9, 340.1C368\
.9, 310.1 352, 2\
69.4 352, 227L35\
2, 181.5L352, 12\
4.5zM512, 72.3C5\
12, 72.2 512, 72\
.1 512, 72C512, \
71.9 512, 71.8 5\
12, 71.7L512, 72\
.3zM510.7, 79.7L\
464.3, 68.1C464.\
1, 69.4 464, 70.\
7 464, 72C464, 8\
5.3 474.7, 96 48\
8, 96C498.6, 96 \
507.5, 89.2 510.\
7, 79.7zM130.9, \
116.5C147.2, 102\
 171.3, 100.3 18\
9.4, 112.4L320, \
199.4L320, 226.9\
C320, 259.7 328.\
4, 291.7 344, 31\
9.9L112, 319.9C1\
05.3, 319.9 99.3\
, 315.7 97, 309.\
5C94.7, 303.3 96\
.5, 296.2 101.6,\
 291.8L171, 232.\
3L18.4, 255.8C11\
.4, 256.9 4.5, 2\
53.2 1.5, 246.8C\
-1.5, 240.4 0, 2\
32.7 5.3, 228L13\
0.9, 116.5z\x22 />\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a</svg>\
\x00\x00\x0b\x9b\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-4 -4.025\
 32 32\x22\x0a   versi\
on=\x221.1\x22\x0a   id=\x22\
svg4\x22\x0a   sodipod\
i:docname=\x22pen.s\
vg\x22\x0a   inkscape:\
version=\x221.4 (86\
a8ad7, 2024-10-1\
1)\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   xmlns:sod\
ipodi=\x22http://so\
dipodi.sourcefor\
ge.net/DTD/sodip\
odi-0.dtd\x22\x0a   xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
\x0a   xmlns:svg=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a  <d\
efs\x0a     id=\x22def\
s4\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  id=\x22namedview4\
\x22\x0a     pagecolor\
=\x22#000000\x22\x0a     \
bordercolor=\x22#FF\
FFFF\x22\x0a     borde\
ropacity=\x220.25\x22\x0a\
     inkscape:sh\
owpageshadow=\x222\x22\
\x0a     inkscape:p\
ageopacity=\x220.0\x22\
\x0a     inkscape:p\
agecheckerboard=\
\x220\x22\x0a     inkscap\
e:deskcolor=\x22#d1\
d1d1\x22\x0a     showg\
rid=\x22true\x22\x0a     \
inkscape:zoom=\x222\
4.3125\x22\x0a     ink\
scape:cx=\x229.4807\
198\x22\x0a     inksca\
pe:cy=\x2221.347044\
\x22\x0a     inkscape:\
window-width=\x2219\
20\x22\x0a     inkscap\
e:window-height=\
\x22996\x22\x0a     inksc\
ape:window-x=\x22-9\
\x22\x0a     inkscape:\
window-y=\x22-9\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22La\
yer_1\x22>\x0a    <ink\
scape:grid\x0a     \
  id=\x22grid4\x22\x0a   \
    units=\x22px\x22\x0a \
      originx=\x220\
\x22\x0a       originy\
=\x220\x22\x0a       spac\
ingx=\x221\x22\x0a       \
spacingy=\x221\x22\x0a   \
    empcolor=\x22#0\
099e5\x22\x0a       em\
popacity=\x220.3019\
6078\x22\x0a       col\
or=\x22#0099e5\x22\x0a   \
    opacity=\x220.1\
4901961\x22\x0a       \
empspacing=\x225\x22\x0a \
      enabled=\x22t\
rue\x22\x0a       visi\
ble=\x22true\x22 />\x0a  \
</sodipodi:named\
view>\x0a  <g\x0a     \
id=\x22Layer_1\x22\x0a   \
  transform=\x22tra\
nslate(-4.000002\
28881836, -4.025\
)\x22\x0a     style=\x22e\
nable-background\
:new 0 0 32 32\x22>\
\x0a    <g\x0a       i\
d=\x22Edit\x22>\x0a      \
<path\x0a         d\
=\x22M27.6, 8.2L23.\
8, 4.4C23.3, 3.9\
 22.4, 3.9 21.9,\
 4.4L19.4, 6.9L2\
5.2, 12.7L27.7, \
10.2C28.1, 9.6 2\
8.1, 8.8 27.6, 8\
.2z\x22\x0a         fi\
ll=\x22#D11C1C\x22\x0a   \
      class=\x22Red\
\x22\x0a         id=\x22p\
ath1\x22\x0a         s\
tyle=\x22stroke:#FF\
FFFF;stroke-opac\
ity:1;stroke-lin\
ecap:round;strok\
e-linejoin:round\
;fill:#e96464;fi\
ll-opacity:1\x22 />\
\x0a    </g>\x0a  </g>\
\x0a  <g\x0a     id=\x22g\
2\x22\x0a     transfor\
m=\x22translate(-4,\
 -4.024998855590\
82)\x22\x0a     style=\
\x22enable-backgrou\
nd:new 0 0 32 32\
\x22>\x0a    <g\x0a      \
 id=\x22g1\x22>\x0a      \
<polygon\x0a       \
  points=\x224,22.2\
 4,28 9.8,28 \x22\x0a \
        fill=\x22#f\
fb115\x22\x0a         \
class=\x22Yellow\x22\x0a \
        id=\x22poly\
gon1\x22\x0a         s\
tyle=\x22stroke:#FF\
FFFF;stroke-opac\
ity:1;paint-orde\
r:normal;stroke-\
linecap:round\x22\x0a \
        inkscape\
:label=\x22polygon1\
\x22\x0a         trans\
form=\x22matrix(0.8\
2823736,0,0,0.86\
77351,1.2851622,\
3.2198478)\x22 />\x0a \
   </g>\x0a  </g>\x0a \
 <g\x0a     id=\x22g4\x22\
\x0a     transform=\
\x22translate(-3.99\
999988555908, -4\
.024999559021)\x22\x0a\
     style=\x22enab\
le-background:ne\
w 0 0 32 32;pain\
t-order:normal\x22>\
\x0a    <g\x0a       i\
d=\x22g3\x22\x0a       st\
yle=\x22paint-order\
:normal\x22>\x0a      \
<rect\x0a         x\
=\x225.8000002\x22\x0a   \
      y=\x2213.4\x22\x0a \
        width=\x221\
7.6\x22\x0a         he\
ight=\x228.1999998\x22\
\x0a         fill=\x22\
#1177d7\x22\x0a       \
  class=\x22Blue\x22\x0a \
        transfor\
m=\x22matrix(0.707,\
-0.7072,0.7072,0\
.707,-8.0721,15.\
4048)\x22\x0a         \
id=\x22rect2\x22\x0a     \
    style=\x22displ\
ay:inline;stroke\
:#FFFFFF;stroke-\
width:1.00001;st\
roke-linecap:rou\
nd;stroke-linejo\
in:round;stroke-\
dasharray:none;s\
troke-opacity:1;\
paint-order:norm\
al;fill:#62aef2;\
fill-opacity:1\x22 \
/>\x0a    </g>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x00\x93\
[\
Icon Theme]\x0d\x0aNam\
e=ie_dark\x0d\x0aComme\
nt=An example ic\
on theme\x0d\x0aDirect\
ories=\x0d\x0a\x0d\x0a[]\x0d\x0aSi\
ze=32\x0d\x0aType=Scal\
able\x0d\x0aMinsize=24\
\x0d\x0aMaxSize=64\x0d\x0aCo\
ntext=Applicatio\
ns\
\x00\x00\x00\x93\
[\
Icon Theme]\x0d\x0aNam\
e=ie_dark\x0d\x0aComme\
nt=An example ic\
on theme\x0d\x0aDirect\
ories=\x0d\x0a\x0d\x0a[]\x0d\x0aSi\
ze=32\x0d\x0aType=Scal\
able\x0d\x0aMinsize=24\
\x0d\x0aMaxSize=64\x0d\x0aCo\
ntext=Applicatio\
ns\
\x00\x00\x07\x92\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2.0025 -\
2.0025 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg2\x22\x0a   s\
odipodi:docname=\
\x22spray.svg\x22\x0a   i\
nkscape:version=\
\x221.4 (86a8ad7, 2\
024-10-11)\x22\x0a   x\
mlns:inkscape=\x22h\
ttp://www.inksca\
pe.org/namespace\
s/inkscape\x22\x0a   x\
mlns:sodipodi=\x22h\
ttp://sodipodi.s\
ourceforge.net/D\
TD/sodipodi-0.dt\
d\x22\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0a   xmln\
s:svg=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a  <defs\x0a    \
 id=\x22defs2\x22 />\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview2\x22\x0a     p\
agecolor=\x22#00000\
0\x22\x0a     borderco\
lor=\x22#FFFFFF\x22\x0a  \
   borderopacity\
=\x220.25\x22\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0a     in\
kscape:pageopaci\
ty=\x220.0\x22\x0a     in\
kscape:pagecheck\
erboard=\x220\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   inkscape:zoom\
=\x2224.3125\x22\x0a     \
inkscape:cx=\x2215.\
979434\x22\x0a     ink\
scape:cy=\x2216\x22\x0a  \
   inkscape:wind\
ow-width=\x221920\x22\x0a\
     inkscape:wi\
ndow-height=\x22996\
\x22\x0a     inkscape:\
window-x=\x22-9\x22\x0a  \
   inkscape:wind\
ow-y=\x22-9\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg2\x22 \
/>\x0a  <g\x0a     tra\
nsform=\x22translat\
e(-0.002, -0.002\
1)\x22\x0a     id=\x22g2\x22\
\x0a     style=\x22fil\
l:#FFFFFF;fill-o\
pacity:1\x22>\x0a    <\
g\x0a       transfo\
rm=\x22matrix(0.054\
6867102384567, 0\
, 0, 0.054686710\
2384567, 0, 0)\x22\x0a\
       id=\x22g1\x22\x0a \
      style=\x22fil\
l:#FFFFFF;fill-o\
pacity:1\x22>\x0a     \
 <path\x0a         \
d=\x22M128, 0L192, \
0C209.7, 0 224, \
14.3 224, 32L224\
, 128L96, 128L96\
, 32C96, 14.3 11\
0.3, 0 128, 0zM0\
, 256C0, 203 43,\
 160 96, 160L224\
, 160C277, 160 3\
20, 203 320, 256\
L320, 464C320, 4\
90.5 298.5, 512 \
272, 512L48, 512\
C21.5, 512 0, 49\
0.5 0, 464L0, 25\
6zM240, 336A80 8\
0 0 1 0 80, 336A\
80 80 0 1 0 240,\
 336zM256, 64A32\
 32 0 1 1 320, 6\
4A32 32 0 1 1 25\
6, 64zM384, 32A3\
2 32 0 1 1 384, \
96A32 32 0 1 1 3\
84, 32zM448, 64A\
32 32 0 1 1 512,\
 64A32 32 0 1 1 \
448, 64zM480, 12\
8A32 32 0 1 1 48\
0, 192A32 32 0 1\
 1 480, 128zM448\
, 256A32 32 0 1 \
1 512, 256A32 32\
 0 1 1 448, 256z\
M384, 128A32 32 \
0 1 1 384, 192A3\
2 32 0 1 1 384, \
128z\x22\x0a         i\
d=\x22path1\x22\x0a      \
   style=\x22fill:#\
FFFFFF;fill-opac\
ity:1\x22 />\x0a    </\
g>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x06\xcc\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2.0025 -\
3.775 32 32\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg2\x22\x0a   so\
dipodi:docname=\x22\
eraser-gray.svg\x22\
\x0a   inkscape:ver\
sion=\x221.4 (e7c3f\
eb100, 2024-10-0\
9)\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   xmlns:sod\
ipodi=\x22http://so\
dipodi.sourcefor\
ge.net/DTD/sodip\
odi-0.dtd\x22\x0a   xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
\x0a   xmlns:svg=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a  <d\
efs\x0a     id=\x22def\
s2\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  id=\x22namedview2\
\x22\x0a     pagecolor\
=\x22#000000\x22\x0a     \
bordercolor=\x22#FF\
FFFF\x22\x0a     borde\
ropacity=\x220.25\x22\x0a\
     inkscape:sh\
owpageshadow=\x222\x22\
\x0a     inkscape:p\
ageopacity=\x220.0\x22\
\x0a     inkscape:p\
agecheckerboard=\
\x220\x22\x0a     inkscap\
e:deskcolor=\x22#d1\
d1d1\x22\x0a     inksc\
ape:zoom=\x2225.218\
75\x22\x0a     inkscap\
e:cx=\x2216\x22\x0a     i\
nkscape:cy=\x2216\x22\x0a\
     inkscape:wi\
ndow-width=\x221920\
\x22\x0a     inkscape:\
window-height=\x229\
69\x22\x0a     inkscap\
e:window-x=\x220\x22\x0a \
    inkscape:win\
dow-y=\x220\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg2\x22 \
/>\x0a  <g\x0a     tra\
nsform=\x22translat\
e(-2.144, -2.143\
7)\x22\x0a     id=\x22g2\x22\
\x0a     style=\x22fil\
l:#FFFFFF;fill-o\
pacity:1\x22>\x0a    <\
g\x0a       transfo\
rm=\x22matrix(0.055\
4079748690128, 0\
, 0, 0.055407974\
8690128, 0, 0)\x22\x0a\
       id=\x22g1\x22\x0a \
      style=\x22fil\
l:#FFFFFF;fill-o\
pacity:1\x22>\x0a     \
 <path\x0a         \
d=\x22M290.7, 57.4L\
57.4, 290.7C32.4\
, 315.7 32.4, 35\
6.2 57.4, 381.2L\
137.4, 461.2C149\
.4, 473.2 165.7,\
 479.9 182.7, 47\
9.9L288, 480L297\
.4, 480L512, 480\
C529.7, 480 544,\
 465.7 544, 448C\
544, 430.3 529.7\
, 416 512, 416L3\
87.9, 416L518.6,\
 285.3C543.6, 26\
0.3 543.6, 219.8\
 518.6, 194.8L38\
1.3, 57.4C356.3,\
 32.4 315.8, 32.\
4 290.8, 57.4zM2\
97.4, 416L288, 4\
16L182.6, 416L10\
2.6, 336L227.3, \
211.3L364.7, 348\
.7L297.4, 416z\x22\x0a\
         id=\x22pat\
h1\x22\x0a         sty\
le=\x22fill:#FFFFFF\
;fill-opacity:1\x22\
 />\x0a    </g>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x02\xf3\
\x00\
\x00\x0c\xdfx\xda\xd5VKo\xe20\x10\xbe\xf7WD\
\xee\xa5\x95\x9a\x87\x13B\x09KZiU\xf5\xc4\xde\xba\
\xe7\x95\x9b\x98$*\xc4\xc8v\x09\xf0\xebwl\xe2<\
\xa0\xa0\xb6\xcb\xae\xbaNp\xe2\xf9\xe6=c\x93\xc9\xfd\
z1\xb7V\x94\x8b\x82\x951\xc2\x8e\x87,Z&,\
-\xca,F?\x9f\x1e\xed\x11\xb2\x84$eJ\xe6\xac\
\xa41*\x19\xba\xbf\xbb\x98\x88UvaY\xd6\xaa\xa0\
\xd5w\xb6\x8e\x91\xed[p\x07\xeaF\x1ah5bM\
(\xd2\x18\x81\x10\x0e\xf4J\x80\x81%\xfc\xc6)KJ\
\xb2\x00\xbd\x82\xac\xa8\x03\x0c;\xe6\xf2E$dI\xc7\
\x1d5\x03\xebj4$#\x92\xde\xdeX\xbe\xe7\x0fl\
\xec\xd9\x18_k~\x88\xa1\x14c#\x15\xa3\x5c\xca\xe5\
\xd8u\xab\xaar\x0c\xd1a<s\x95)\xb1$\x09\x15\
\xae\xa1w\xe4\x8dS\x8d\xbc!8\x82\xbd\xf2\x84\xce@\
\x05uJ*\xdd\x87\xa7\x87\x06\xb4='\x95i\xab\xa6\
g\xbd\x0a\xb4]\xdf\xf3<\xd7\x04W\x1b[e'9\
\xef\x80u\x92\xd2\x99P\x22\xbb\xf4\xa9\x15\xe4\xcfr5\
\xd6\xa4P\x05\x95\xaaB\xb4\x9c\x0d\xa9N\xb7e-I\
F\x136g<F\x97^\xa8\xae\x1axf<\xa5\xbc\
\x81\xf4\xe8A\x0c\xf2U\xc8M\x8c<\xc77BM}\
D\xce*\xa5Z\xe4$eU\x8c\xfc}\x06\x05v4\
xo\xe1IN\x93\x17\xca\x9f\x19\xe1\xe0\xbb\xe4\xaft\
\x9f+\xa5\xe2\xc5\xb8\x98bu\xedsl\x19[\x80\xf9\
\x81\x13\xe0C/\x13hP\x1c:\xd1m4\x08\x06\x07\
 8\x86\x87\xfb\xd4\xaa(! \xbb*R\x99\x03\x1e\
\xf9\xde\x11\x8e\x9c\x16Y.c\x14E\xc7t\xa8\xdd\x11\
\x1d\xc16'\xb0\x05Y\x17\x8bbK!'\x07\xe1&\
\xaf\x9c\xd3R\xdas\xb2\xa1\xdcl\xac\xba1\xb2\xb6\x0f\
\xa6\x0a\xfee\xa4%'\xa5\x80&^\xa8$\xc3\xeb\x9c\
Hze\xfb7\xb0s\xafk\x16!7s\xd8?\xb3\
b>\x1f_\xce\xf4\xf8\xa6\x16v]\xc31\xd6\x8d\xd9\
Z\xe9i]\x10\xc9\x8b\xf5\x15h\xf4\xf4]\xbf\x18\xe5\
;\x9f2\xdc,\xdfm\x0d\xecq\x9aH#\x07{(\
F#\xd4.7m\x8a\xd4\xa8\xab\x16tH\xa6L]\
\x1a\x07-^w\xbd\xe9\xaf\x95+\xd0p\x8fzt\xe8\
*\x0a\xe5N\xd7\xe4;B\xd9\x95\x07Bq3]\xa7\
\xfa\xd1)W\x16\xbe\xa7R\x7f\x5c\x80A\x9b\xd5\xac\x1f\
U\x164P\x1f\xaca\xbf\x03\x03\xc3\x92\xc8\xbc\xcbc\
Y\xc0\xf4\x03\x077\x16\x9eb\xdf\xcc\xe1tPO\xb0\
6S8\xc5a\xf3\x08\xa6Zf\xfbC\x0b\x05\x9aU\
\xcf#\xad`7\xe3`\x8b\xfa\xc6\x8e\xd5\xc7\xb8\xab\xdc\
k\xd3\xdeI}\xef\xf5D9\xa2\xaf\xb5qF\x9f\xda\
8\xfb%\xbe\xfdX\xd7\x9e\xec\x87a/\xeb\x1f\xd2\xf6\
\x7f\xb4O\xb8G\xff\xc06\xffD\xbf\xe1\xafvR{\
\xe79\xaa\xc3\xfeQ\x1d\x1d\x1e\xd5\xc37\x8ej|\xc6\
\xa3::\xfbQ\xdd|Y}\x95Z\xf9\x7f\xa5V\x18\
\xff\xfbb\xe13\xfc\xb1N\xd4G\xf4\xdd\xc5o5\xe6\
K\xbb\
\x00\x00\x04\xcb\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
transform=\x22trans\
late(0, 0)\x22>\x0d\x0a  \
  <g transform=\x22\
matrix(0.875, 0,\
 0, 0.875, 0, 0)\
\x22>\x0d\x0a      <g tra\
nsform=\x22translat\
e(0, 0)\x22>\x0d\x0a     \
   <g transform=\
\x22matrix(1.1429, \
0, 0, 1.1429, 0,\
 0)\x22>\x0d\x0a         \
 <g id=\x22Layer_1\x22\
 transform=\x22tran\
slate(-1.8666, -\
1.8666)\x22 style=\x22\
enable-backgroun\
d:new 0 0 32 32\x22\
>\x0d\x0a            <\
g transform=\x22mat\
rix(0.9333, 0, 0\
, 0.9333, 0, 0)\x22\
>\x0d\x0a             \
 <g id=\x22MoreColo\
rs\x22>\x0d\x0a          \
      <path d=\x22M\
32, 15.2C31.5, 7\
.8 25, 2 17, 2C8\
.7, 2 2, 8.3 2, \
16C2, 24.8 8.7, \
32 17, 32C18.7, \
32 20, 30.7 20, \
29C20, 27.9 19.4\
, 27 18.6, 26.4C\
18.2, 26.2 18, 2\
5.8 18, 25.3C18,\
 24.6 18.6, 24 1\
9.3, 24L19.3, 24\
L24, 24C28.4, 24\
 32, 20.4 32, 16\
C32, 15.7 32, 15\
.4 32, 15.2zM8, \
16C6.9, 16 6, 15\
.1 6, 14C6, 12.9\
 6.9, 12 8, 12C9\
.1, 12 10, 12.9 \
10, 14C10, 15.1 \
9.1, 16 8, 16zM1\
5, 12C13.3, 12 1\
2, 10.7 12, 9C12\
, 7.3 13.3, 6 15\
, 6C16.7, 6 18, \
7.3 18, 9C18, 10\
.7 16.7, 12 15, \
12zM24, 18C21.8,\
 18 20, 16.2 20,\
 14C20, 11.8 21.\
8, 10 24, 10C26.\
2, 10 28, 11.8 2\
8, 14C28, 16.2 2\
6.2, 18 24, 18z\x22\
 fill=\x22#FFFFFF\x22 \
class=\x22Black\x22 />\
\x0d\x0a              \
</g>\x0d\x0a          \
  </g>\x0d\x0a        \
  </g>\x0d\x0a        \
</g>\x0d\x0a      </g>\
\x0d\x0a    </g>\x0d\x0a  </\
g>\x0d\x0a</svg>\
\x00\x00\x03z\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2.00\
25 32 32\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22 >\x0d\x0a\
  <g transform=\x22\
translate(0, -0.\
0032)\x22>\x0d\x0a    <g \
transform=\x22matri\
x(0.054687496274\
7097, 0, 0, 0.05\
46874962747097, \
0, 0)\x22>\x0d\x0a      <\
path d=\x22M288, 10\
9.3L288, 352C288\
, 369.7 273.7, 3\
84 256, 384C238.\
3, 384 224, 369.\
7 224, 352L224, \
109.3L150.6, 182\
.7C138.1, 195.2 \
117.8, 195.2 105\
.3, 182.7C92.8, \
170.2 92.8, 149.\
9 105.3, 137.4L2\
33.3, 9.4C245.8,\
 -3.1 266.1, -3.\
1 278.6, 9.4L406\
.6, 137.4C419.1,\
 149.9 419.1, 17\
0.2 406.6, 182.7\
C394.1, 195.2 37\
3.8, 195.2 361.3\
, 182.7L288, 109\
.3zM64, 352L192,\
 352C192, 387.3 \
220.7, 416 256, \
416C291.3, 416 3\
20, 387.3 320, 3\
52L448, 352C483.\
3, 352 512, 380.\
7 512, 416L512, \
448C512, 483.3 4\
83.3, 512 448, 5\
12L64, 512C28.7,\
 512 0, 483.3 0,\
 448L0, 416C0, 3\
80.7 28.7, 352 6\
4, 352zM432, 456\
A24 24 0 1 0 432\
, 408A24 24 0 1 \
0 432, 456z\x22 />\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a</svg>\
\x00\x00\x05\xd1\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-6.675 -2\
 32 32\x22\x0a   versi\
on=\x221.1\x22\x0a   id=\x22\
svg1\x22\x0a   sodipod\
i:docname=\x22curso\
r-gray.svg\x22\x0a   i\
nkscape:version=\
\x221.4 (86a8ad7, 2\
024-10-11)\x22\x0a   x\
mlns:inkscape=\x22h\
ttp://www.inksca\
pe.org/namespace\
s/inkscape\x22\x0a   x\
mlns:sodipodi=\x22h\
ttp://sodipodi.s\
ourceforge.net/D\
TD/sodipodi-0.dt\
d\x22\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0a   xmln\
s:svg=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a  <defs\x0a    \
 id=\x22defs1\x22 />\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview1\x22\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#000000\x22\x0a  \
   borderopacity\
=\x220.25\x22\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0a     in\
kscape:pageopaci\
ty=\x220.0\x22\x0a     in\
kscape:pagecheck\
erboard=\x220\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   inkscape:zoom\
=\x2224.3125\x22\x0a     \
inkscape:cx=\x2215.\
979434\x22\x0a     ink\
scape:cy=\x2216\x22\x0a  \
   inkscape:wind\
ow-width=\x221920\x22\x0a\
     inkscape:wi\
ndow-height=\x22996\
\x22\x0a     inkscape:\
window-x=\x22-9\x22\x0a  \
   inkscape:wind\
ow-y=\x22-9\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg1\x22 \
/>\x0a  <g\x0a     id=\
\x22Select\x22\x0a     tr\
ansform=\x22transla\
te(-11.6575, -4.\
6628)\x22\x0a     styl\
e=\x22enable-backgr\
ound:new 0 0 32 \
32\x22>\x0a    <g\x0a    \
   transform=\x22ma\
trix(1.165696382\
52258, 0, 0, 1.1\
6569638252258, 0\
, 0)\x22\x0a       id=\
\x22g1\x22>\x0a      <pat\
h\x0a         d=\x22M1\
8.2, 20L26, 20L1\
0, 4L10, 26L15.3\
, 20.7L18, 27.4C\
18.2, 27.9 18.8,\
 28.2 19.3, 27.9\
L20.2, 27.5C20.7\
, 27.3 21, 26.7 \
20.7, 26.2L18.2,\
 20z\x22\x0a         f\
ill=\x22#000000\x22\x0a  \
       class=\x22Bl\
ack\x22\x0a         id\
=\x22path1\x22\x0a       \
  style=\x22fill:#0\
00000;fill-opaci\
ty:1\x22 />\x0a    </g\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x0b]\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x2232\x22\x0a   heig\
ht=\x2232\x22\x0a   fill=\
\x22currentColor\x22\x0a \
  class=\x22bi bi-m\
agic\x22\x0a   viewBox\
=\x220 0 32 32\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg1\x22\x0a   so\
dipodi:docname=\x22\
magic.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (e7c3feb100,\
 2024-10-09)\x22\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0a  \
 xmlns:sodipodi=\
\x22http://sodipodi\
.sourceforge.net\
/DTD/sodipodi-0.\
dtd\x22\x0a   xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22\x0a   xm\
lns:svg=\x22http://\
www.w3.org/2000/\
svg\x22>\x0a  <defs\x0a  \
   id=\x22defs1\x22 />\
\x0a  <sodipodi:nam\
edview\x0a     id=\x22\
namedview1\x22\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#000000\x22\x0a\
     borderopaci\
ty=\x220.25\x22\x0a     i\
nkscape:showpage\
shadow=\x222\x22\x0a     \
inkscape:pageopa\
city=\x220.0\x22\x0a     \
inkscape:pageche\
ckerboard=\x220\x22\x0a  \
   inkscape:desk\
color=\x22#d1d1d1\x22\x0a\
     showgrid=\x22t\
rue\x22\x0a     inksca\
pe:zoom=\x2212.5\x22\x0a \
    inkscape:cx=\
\x2216.44\x22\x0a     ink\
scape:cy=\x2219.28\x22\
\x0a     inkscape:w\
indow-width=\x22192\
0\x22\x0a     inkscape\
:window-height=\x22\
1008\x22\x0a     inksc\
ape:window-x=\x220\x22\
\x0a     inkscape:w\
indow-y=\x220\x22\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0a \
    inkscape:cur\
rent-layer=\x22svg1\
\x22>\x0a    <inkscape\
:grid\x0a       id=\
\x22grid1\x22\x0a       u\
nits=\x22px\x22\x0a      \
 originx=\x220\x22\x0a   \
    originy=\x220\x22\x0a\
       spacingx=\
\x221\x22\x0a       spaci\
ngy=\x221\x22\x0a       e\
mpcolor=\x22#0099e5\
\x22\x0a       empopac\
ity=\x220.30196078\x22\
\x0a       color=\x22#\
0099e5\x22\x0a       o\
pacity=\x220.149019\
61\x22\x0a       empsp\
acing=\x225\x22\x0a      \
 enabled=\x22true\x22\x0a\
       visible=\x22\
true\x22 />\x0a  </sod\
ipodi:namedview>\
\x0a  <path\x0a     d=\
\x22m 18.632458,7.1\
97339 a 0.841877\
5,0.84971561 0 1\
 0 1.683755,0 V \
4.0890806 a 0.84\
18775,0.84971561\
 0 0 0 -1.683755\
,0 z m 7.576894,\
0.05948 A 0.8418\
7713,0.84971524 \
0 0 0 25.018937,\
6.0553216 l -2.1\
77094,2.1973637 \
a 0.84187713,0.8\
4971524 0 1 0 1.\
190415,1.2014974\
 z M 14.916413,9\
.4541827 A 0.841\
87713,0.84971524\
 0 1 0 16.106827\
,8.2526853 L 13.\
929732,6.0553216\
 a 0.84187713,0.\
84971524 0 0 0 -\
1.190415,1.20149\
75 z m -1.045611\
,4.2485763 a 0.8\
4187729,0.849715\
4 0 1 0 0,-1.699\
43 h -3.079588 a\
 0.84187729,0.84\
97154 0 1 0 0,1.\
69943 z m 14.286\
654,0 a 0.841877\
29,0.8497154 0 1\
 0 0,-1.69943 h \
-3.079587 a 0.84\
187729,0.8497154\
 0 0 0 0,1.69943\
 z m -3.138519,5\
.948007 a 0.8418\
7713,0.84971524 \
0 1 0 1.190415,-\
1.201497 l -2.17\
7094,-2.197365 a\
 0.84187713,0.84\
971524 0 1 0 -1.\
190415,1.201497 \
z m -6.386479,1.\
966241 a 0.84187\
75,0.84971561 0 \
0 0 1.683755,0 v\
 -3.108259 a 0.8\
418775,0.8497156\
1 0 0 0 -1.68375\
5,0 z m 3.12168,\
-8.661997 a 0.84\
187713,0.8497152\
4 0 0 0 0,-1.199\
799 l -1.192097,\
-1.203197 a 0.84\
187713,0.8497152\
4 0 0 0 -1.19041\
5,0 l -2.177095,\
2.199064 a 0.841\
87713,0.84971524\
 0 0 0 0,1.20149\
8 l 1.192099,1.2\
03196 a 0.841877\
13,0.84971524 0 \
0 0 1.190414,0 l\
 2.177094,-2.197\
364 z m -5.05126\
3,5.09829 a 0.84\
187713,0.8497152\
4 0 0 0 0,-1.199\
797 l -1.192097,\
-1.203196 a 0.84\
187713,0.8497152\
4 0 0 0 -1.19041\
4,0 L 3.7244976,\
26.346521 a 0.84\
187713,0.8497152\
4 0 0 0 0,1.2014\
99 l 1.192098,1.\
203195 a 0.84187\
713,0.84971524 0\
 0 0 1.1904143,0\
 z\x22\x0a     id=\x22pat\
h1\x22\x0a     style=\x22\
stroke-width:1.6\
9157;fill:#00000\
0;fill-opacity:1\
\x22 />\x0a</svg>\x0a\
\x00\x00\x08\x9b\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -3.502\
5 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg2\x22\x0a   sodipo\
di:docname=\x22fill\
.svg\x22\x0a   inkscap\
e:version=\x221.4 (\
86a8ad7, 2024-10\
-11)\x22\x0a   xmlns:i\
nkscape=\x22http://\
www.inkscape.org\
/namespaces/inks\
cape\x22\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0a   \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22\x0a   xmlns:svg=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a  \
<defs\x0a     id=\x22d\
efs2\x22 />\x0a  <sodi\
podi:namedview\x0a \
    id=\x22namedvie\
w2\x22\x0a     pagecol\
or=\x22#ffffff\x22\x0a   \
  bordercolor=\x22#\
000000\x22\x0a     bor\
deropacity=\x220.25\
\x22\x0a     inkscape:\
showpageshadow=\x22\
2\x22\x0a     inkscape\
:pageopacity=\x220.\
0\x22\x0a     inkscape\
:pagecheckerboar\
d=\x220\x22\x0a     inksc\
ape:deskcolor=\x22#\
d1d1d1\x22\x0a     ink\
scape:zoom=\x2225.2\
1875\x22\x0a     inksc\
ape:cx=\x2216\x22\x0a    \
 inkscape:cy=\x2215\
.980173\x22\x0a     in\
kscape:window-wi\
dth=\x221920\x22\x0a     \
inkscape:window-\
height=\x22996\x22\x0a   \
  inkscape:windo\
w-x=\x22-9\x22\x0a     in\
kscape:window-y=\
\x22-9\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22svg2\x22 />\x0a  \
<g\x0a     transfor\
m=\x22translate(-0.\
1208, -0.0013)\x22\x0a\
     id=\x22g2\x22\x0a   \
  style=\x22stroke:\
#000000;stroke-o\
pacity:1;fill:#0\
00000;fill-opaci\
ty:1\x22>\x0a    <g\x0a  \
     transform=\x22\
matrix(0.0488209\
053874016, 0, 0,\
 0.0488209053874\
016, 0, 0)\x22\x0a    \
   id=\x22g1\x22\x0a     \
  style=\x22stroke:\
#000000;stroke-o\
pacity:1;fill:#0\
00000;fill-opaci\
ty:1\x22>\x0a      <pa\
th\x0a         d=\x22M\
41.4, 9.4C53.9, \
-3.1 74.1, -3.1 \
86.6, 9.4L168, 9\
0.7L221.1, 37.6C\
249.2, 9.5 294.8\
, 9.5 322.9, 37.\
6L474.3, 189.1C5\
02.4, 217.2 502.\
4, 262.8 474.3, \
290.9L283.9, 481\
.4C246.4, 518.9 \
185.6, 518.9 148\
.1, 481.4L30.6, \
363.9C-6.9, 326.\
4 -6.9, 265.6 30\
.6, 228.1L122.7,\
 136L41.4, 54.6C\
28.9, 42.1 28.9,\
 21.8 41.4, 9.3z\
M217.4, 230.7L16\
8, 181.3L75.9, 2\
73.4C71.7, 277.6\
 68.9, 282.7 67.\
5, 288L386.7, 28\
8L429, 245.7C432\
.1, 242.6 432.1,\
 237.5 429, 234.\
4L277.7, 82.9C27\
4.6, 79.8 269.5,\
 79.8 266.4, 82.\
9L213.3, 136L262\
.7, 185.4C275.2,\
 197.9 275.2, 21\
8.2 262.7, 230.7\
C250.2, 243.2 22\
9.9, 243.2 217.4\
, 230.7zM512, 51\
2C476.7, 512 448\
, 483.3 448, 448\
C448, 422.8 480.\
6, 368.4 499.2, \
339.3C505.2, 329\
.9 518.7, 329.9 \
524.7, 339.3C543\
.4, 368.4 576, 4\
22.8 576, 448C57\
6, 483.3 547.3, \
512 512, 512z\x22\x0a \
        id=\x22path\
1\x22\x0a         styl\
e=\x22stroke:#00000\
0;stroke-opacity\
:1;fill:#000000;\
fill-opacity:1\x22 \
/>\x0a    </g>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x0b?\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   he\
ight=\x2232\x22\x0a   vie\
wBox=\x220 0 32 32\x22\
\x0a   width=\x2232\x22\x0a \
  version=\x221.1\x22\x0a\
   id=\x22svg1\x22\x0a   \
sodipodi:docname\
=\x22selection-elli\
pse.svg\x22\x0a   inks\
cape:version=\x221.\
4 (e7c3feb100, 2\
024-10-09)\x22\x0a   x\
mlns:inkscape=\x22h\
ttp://www.inksca\
pe.org/namespace\
s/inkscape\x22\x0a   x\
mlns:sodipodi=\x22h\
ttp://sodipodi.s\
ourceforge.net/D\
TD/sodipodi-0.dt\
d\x22\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0a   xmln\
s:svg=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a  <defs\x0a    \
 id=\x22defs1\x22 />\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview1\x22\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#000000\x22\x0a  \
   borderopacity\
=\x220.25\x22\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0a     in\
kscape:pageopaci\
ty=\x220.0\x22\x0a     in\
kscape:pagecheck\
erboard=\x220\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   showgrid=\x22tru\
e\x22\x0a     inkscape\
:zoom=\x2211.313708\
\x22\x0a     inkscape:\
cx=\x22-0.13258252\x22\
\x0a     inkscape:c\
y=\x2218.605747\x22\x0a  \
   inkscape:wind\
ow-width=\x221920\x22\x0a\
     inkscape:wi\
ndow-height=\x22969\
\x22\x0a     inkscape:\
window-x=\x220\x22\x0a   \
  inkscape:windo\
w-y=\x220\x22\x0a     ink\
scape:window-max\
imized=\x221\x22\x0a     \
inkscape:current\
-layer=\x22svg1\x22>\x0a \
   <inkscape:gri\
d\x0a       id=\x22gri\
d1\x22\x0a       units\
=\x22px\x22\x0a       ori\
ginx=\x220\x22\x0a       \
originy=\x220\x22\x0a    \
   spacingx=\x221\x22\x0a\
       spacingy=\
\x221\x22\x0a       empco\
lor=\x22#0099e5\x22\x0a  \
     empopacity=\
\x220.30196078\x22\x0a   \
    color=\x22#0099\
e5\x22\x0a       opaci\
ty=\x220.14901961\x22\x0a\
       empspacin\
g=\x225\x22\x0a       ena\
bled=\x22true\x22\x0a    \
   visible=\x22true\
\x22 />\x0a  </sodipod\
i:namedview>\x0a  <\
path\x0a     d=\x22m 8\
.0608586,27.6500\
77 1.7052486,-2.\
240781 c 1.21199\
48,0.803299 2.57\
90118,1.381111 4\
.0446808,1.67706\
3 l -0.38051,2.7\
90407 C 11.47135\
6,29.510349 9.68\
15494,28.70705 8\
.0608586,27.6500\
77 m 14.2057074,\
-2.240781 1.7052\
48,2.254874 c -1\
.606598,1.085159\
 -3.396404,1.846\
179 -5.355326,2.\
212596 l -0.3805\
1,-2.790407 c 1.\
465668,-0.295952\
 2.818593,-0.873\
764 4.030588,-1.\
677063 m 4.8057,\
-7.145132 2.8045\
,0.38051 C 29.51\
0349,20.603596 2\
8.70705,22.42158\
8 27.635985,24 l\
 -2.240782,-1.70\
5249 c 0.803299,\
-1.197901 1.3811\
11,-2.564919 1.6\
77063,-4.030587 \
M 2.17,18.616488\
 4.9604067,18.23\
5978 c 0.2959522\
,1.465668 0.8737\
637,2.832686 1.6\
770626,4.04468 L\
 4.3966882,23.98\
5907 C 3.3397159\
,22.365216 2.536\
417,20.57541 2.1\
7,18.616488 M 25\
.409296,9.766107\
2 27.650077,8.06\
08586 c 1.099252\
,1.6206908 1.874\
365,3.4245904 2.\
226689,5.3976054\
 l -2.790407,0.3\
8051 C 26.790407\
,12.359212 26.21\
2595,10.978102 2\
5.409296,9.76610\
72 M 18.235978,4\
.9604067 18.6164\
88,2.17 c 1.9589\
22,0.366417 3.74\
8728,1.1697159 5\
.369419,2.226688\
2 L 22.280658,6.\
6374693 C 21.068\
664,5.8341704 19\
.701646,5.256358\
9 18.235978,4.96\
04067 M 9.766107\
2,6.6374693 8.06\
08586,4.3966882 \
C 9.6815494,3.33\
97159 11.471356,\
2.536417 13.4302\
78,2.17 l 0.3805\
1,2.7904067 C 12\
.345119,5.256358\
9 10.978102,5.83\
41704 9.7661072,\
6.6374693 M 4.96\
04067,13.810788 \
2.17,13.430278 C\
 2.536417,11.471\
356 3.3397159,9.\
6815494 4.396688\
2,8.0608586 L 6.\
6374693,9.766107\
2 C 5.8341704,10\
.978102 5.256358\
9,12.345119 4.96\
04067,13.810788 \
Z\x22\x0a     id=\x22path\
1\x22\x0a     style=\x22s\
troke-width:1.40\
93\x22 />\x0a</svg>\x0a\
\x00\x00\x0b0\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   width=\x22\
32mm\x22\x0a   height=\
\x2232mm\x22\x0a   viewBo\
x=\x220 0 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg1\x22\x0a   i\
nkscape:version=\
\x221.4 (e7c3feb100\
, 2024-10-09)\x22\x0a \
  sodipodi:docna\
me=\x22gradient.svg\
\x22\x0a   xmlns:inksc\
ape=\x22http://www.\
inkscape.org/nam\
espaces/inkscape\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:xlink=\x22http://\
www.w3.org/1999/\
xlink\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22>\x0a  <sodip\
odi:namedview\x0a  \
   id=\x22namedview\
1\x22\x0a     pagecolo\
r=\x22#ffffff\x22\x0a    \
 bordercolor=\x22#0\
00000\x22\x0a     bord\
eropacity=\x220.25\x22\
\x0a     inkscape:s\
howpageshadow=\x222\
\x22\x0a     inkscape:\
pageopacity=\x220.0\
\x22\x0a     inkscape:\
pagecheckerboard\
=\x22true\x22\x0a     ink\
scape:deskcolor=\
\x22#d1d1d1\x22\x0a     i\
nkscape:document\
-units=\x22px\x22\x0a    \
 inkscape:zoom=\x22\
3.920673\x22\x0a     i\
nkscape:cx=\x22139.\
38934\x22\x0a     inks\
cape:cy=\x22119.494\
79\x22\x0a     inkscap\
e:window-width=\x22\
1920\x22\x0a     inksc\
ape:window-heigh\
t=\x22969\x22\x0a     ink\
scape:window-x=\x22\
0\x22\x0a     inkscape\
:window-y=\x220\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22la\
yer1\x22\x0a     showg\
rid=\x22true\x22\x0a     \
showborder=\x22true\
\x22>\x0a    <inkscape\
:grid\x0a       id=\
\x22grid1\x22\x0a       u\
nits=\x22px\x22\x0a      \
 originx=\x220\x22\x0a   \
    originy=\x220\x22\x0a\
       spacingx=\
\x220.26458333\x22\x0a   \
    spacingy=\x220.\
26458333\x22\x0a      \
 empcolor=\x22#0099\
e5\x22\x0a       empop\
acity=\x220.3019607\
8\x22\x0a       color=\
\x22#0099e5\x22\x0a      \
 opacity=\x220.1490\
1961\x22\x0a       emp\
spacing=\x225\x22\x0a    \
   enabled=\x22true\
\x22\x0a       visible\
=\x22true\x22 />\x0a  </s\
odipodi:namedvie\
w>\x0a  <defs\x0a     \
id=\x22defs1\x22>\x0a    \
<linearGradient\x0a\
       id=\x22linea\
rGradient6\x22\x0a    \
   inkscape:coll\
ect=\x22always\x22>\x0a  \
    <stop\x0a      \
   style=\x22stop-c\
olor:#8438a8;sto\
p-opacity:1;\x22\x0a  \
       offset=\x220\
\x22\x0a         id=\x22s\
top6\x22 />\x0a      <\
stop\x0a         st\
yle=\x22stop-color:\
#507dbe;stop-opa\
city:0.82741117;\
\x22\x0a         offse\
t=\x221\x22\x0a         i\
d=\x22stop7\x22 />\x0a   \
 </linearGradien\
t>\x0a    <linearGr\
adient\x0a       in\
kscape:collect=\x22\
always\x22\x0a       x\
link:href=\x22#line\
arGradient6\x22\x0a   \
    id=\x22linearGr\
adient7\x22\x0a       \
x1=\x22128.94836\x22\x0a \
      y1=\x2276.981\
72\x22\x0a       x2=\x223\
66.65533\x22\x0a      \
 y2=\x22416.46246\x22\x0a\
       gradientU\
nits=\x22userSpaceO\
nUse\x22\x0a       gra\
dientTransform=\x22\
matrix(0.0649978\
9,0,0,0.06499789\
,-0.23159838,-0.\
16141677)\x22 />\x0a  \
</defs>\x0a  <g\x0a   \
  inkscape:label\
=\x22Katman 1\x22\x0a    \
 inkscape:groupm\
ode=\x22layer\x22\x0a    \
 id=\x22layer1\x22>\x0a  \
  <circle\x0a      \
 id=\x22path5\x22\x0a    \
   style=\x22fill:#\
ef8946;stroke:#7\
07070;stroke-wid\
th:0.264583\x22\x0a   \
    cx=\x22183.8268\
6\x22\x0a       cy=\x2233\
0.94232\x22\x0a       \
r=\x220.035955299\x22 \
/>\x0a    <rect\x0a   \
    style=\x22vecto\
r-effect:non-sca\
ling-stroke;fill\
:url(#linearGrad\
ient7);fill-opac\
ity:1;stroke:non\
e;stroke-width:0\
.0171973;stroke-\
linecap:round;st\
roke-linejoin:ro\
und;stroke-dasha\
rray:0, 0.189171\
;stroke-dashoffs\
et:0;stroke-opac\
ity:1;-inkscape-\
stroke:hairline\x22\
\x0a       id=\x22rect\
6\x22\x0a       width=\
\x2226.45833\x22\x0a     \
  height=\x2226.458\
33\x22\x0a       x=\x222.\
6458333\x22\x0a       \
y=\x222.6458333\x22 />\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x03\x80\
\x00\
\x00\x12Qx\xda\xedX\xcdn\xdb8\x10\xbe/\xd0w\
\x18\xb0\x87\xb4@L\xf3\x9fR\x10\xb5@U\xecI\xbd\
\xed\xa2\xc7B\xb5U[\xa8#\x07\xb2\x1a'}\xb5=\
\xec#\xf5\x15:\x14)\x89N\xebm\x17\xcd!(\xec\
\x1f\x92\xf3\x893#r>\x8e\xc6\xfe\xf2\xcf\xbf\x97/\
o\xaf6pS\xb5\xbbz\xdbdg\x9c\xb23\xa8\x9a\
\xc5vY7\xab\xec\xec\xef\xbf\xfe\x9c%g/_<\
\xf9\xe3rw\xb3\x82\x9b\xba\xda\xbf\xda\xdefd&`\
\xa6\xa8dV\x83\x14\xf8!\x80V\x9a]F\xd6]w\
}1\x9f\xef\xf7{\xba\x97t\xdb\xae\xe6\x8216G\
e\x02h\x05\xe0r\x05\xf52#EyW\xb5\xef8\
\x81\xae-\x9b\xdd\x87m{\x95\x91~\xb8)\xbb\xea\x19\
;\x87\x99\xe8\xcd?'\xb0\xeb\xee6UF\xaa\xa6|\
\xbf\xa9f\xef\xcb\xc5\xc7U\xbb\xfd\xd4,/\x9aj\x0f\
\x0c\xdf\x9a\x0b\xf7%\xbd\xfd\xdeCd\xf4\xaa\xec\xda\xfa\
\xf6\x19\xa3\x89U\xe990\xff\x89\xa4\xe7\x83\xde\x11M\
N\xb9\x12f\xd0\x8c\xa5H\xf3\xa8W\xa6\x95\x9d\xbcN\
\xd2\x81\xae\xd3>\x10\x11\xb8.\xbb5\xe0F\xbdQ&\
\xa1\xd2\xa8s\x90&)&!\xe5TX\x99G\x80\xa1\
,\x95\xa0\xac\xc0\x0b\xe2\x1c\x14c(X\x04y/\xe4\
*\xe14\xe5<\x5cI4Mx2\xe8\x89\x18\xe8-\
\x17\x13p\xe0\xd7$\x9f\x09|\xa87\x9b\x8c<e\xfd\
\xcb\x8b\xb3\xedu\xb9\xa8\xbb\xbb\x8c`P\x17\x9br\x87\
dx\xb5\xc1`\x11\x98\x1f.u\x1e\xaf5\x96\xa6\xf1\
0\x1a\xfb\x13i\xfe'i\xa4\xa4J\xeb\x88'\x13\x10\
x\x22-FT\x066(Ay\x22\x02O\x14\x92\x86\
\x0d\x0c\xd2\x8c\xa6,\x8dx2\x01\x81'#\xe0x\xd2\
\xbbQ\xf7\x05?\xf5D\x9c\xc7O\x1c\x99&T\xab\x88\
8\x11\x10\x88\xc3\x04Fu \x0e\xb3c\xb6\xc9\x15\x17\
\x8e\x22\xe1\x0a\xd74Mc\xe2L@ \xce\x08 W\
\xbc\x1bu_8\x11\xe7\x91\x13\xa7\xad\x16\x1d`A \
\x84qY\x80\x00\x86C*E\xad\xb0\x04\xf6\xf5\xb2[\
gD'.\xb9\x10XW\xf5j\xdda\xb8\xb8q\x0f\
\x13\x02-*b0\xdb\xbb\xbe;\x85\xf8Q\x84xL\
\x05\xb8\x90\xfe8\xe6~`\x15U\xa0\x99\xa1\xb6\xaf\x03\
lJ\x8d4\x08\xb0P\x18x\xa0\xe0\xdcu\xa3\x9ck\
*\x22\xd1y\xf4\x96\x98?\xea\xd8i\xe9\xea\x8c\x1cG\
\xf8\xe0Q<\x81\xa0\xe2\x9fI0\x18\xf4b\xe1\x1d\xca\
A\xce\xfd\x1d\x8d2n?\xf7Ye06\xc8\xdeM\
1\xca?W\xc9\x84\x90;\xfcb\x9c5?q\xeda\
\xb86d\x0f\xa9\xc6\xe4\xe1+\xd61w\x84\xcadJ\
\x1e\xc2X\xc7\x87#\xc9\x83sk_\xdb\x1f\xc5Q\xbe\
\x96V\xdaS\x1c\x1f>g\xc8T\x87\xd3j\xd2\xfe\xb8\
\x85\x5c?\x029\xc7\xf3\xd7?\xdb\x03\x00\x9c\xb9\x80Z\
\x07`=\xc0c\x99;*\xe4\x13\xa0\x0dV\x038c\
4\xa1\x853\x0e\x93\x13\x0f\x14\xfe6\xec\x08\xe4X\x91\
`\xd12\x01X\xa2\xa8A\xc5\x19\x15\x11\x10\xdcF\x80\
\xbb/\x0e\xde\xc6\xb46\xb8\xbf\xd8_*S\x1e\x90\x7f\
\xc6\x05\xda\xa4\xe2\xa7\xe8\xe7\x7f\xbe\xff7\xf9\xf4\xc4\x01\
\xfd=\xda\xb9[z[7\xcb\xed\xfe\x80S\x13+\x1c\
\xf5X\xe1:\x9d\xbbVQ\x0d\x22u\xc6\x14\xf6\xd8\x16\
.\x81\xe7\x22 a\x02\xce.\xc4\xa8\xc9\xd9\xe7\x1f\xa6\
\xe3\xdfm\xe3D\xd2/\xdfu\xc2\x14jh\x1d4\xb4\
\xc2\xe6}\xeb6\xcc9\x11\xc8K\xd7\x16n_E\x92\
\xfbmv(\x0b\xd3\xfc \xeci\xe1]|K\xddc\
L=\xb6\xc5\x97\xee?\x9e\x17_\x01\x94+N\xc7\
\x00\x00\x03b\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-6 -4 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-6, -4)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
New\x22>\x0d\x0a      <g>\
\x0d\x0a        <path \
d=\x22M19, 4L7, 4C6\
.4, 4 6, 4.4 6, \
5L6, 27C6, 27.6 \
6.4, 28 7, 28L25\
, 28C25.6, 28 26\
, 27.6 26, 27L26\
, 11L19, 4zM24, \
26L8, 26L8, 6L18\
, 6L18, 11C18, 1\
1.6 18.4, 12 19,\
 12L24, 12L24, 2\
6z\x22 fill=\x22#00000\
0\x22 class=\x22Black\x22\
 />\x0d\x0a      </g>\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a  <g id=\x22Laye\
r_1\x22 transform=\x22\
translate(-6, -4\
)\x22 style=\x22enable\
-background:new \
0 0 32 32\x22>\x0d\x0a   \
 <g id=\x22New\x22>\x0d\x0a \
     <g>\x0d\x0a      \
  <path d=\x22M19, \
4L7, 4C6.4, 4 6,\
 4.4 6, 5L6, 27C\
6, 27.6 6.4, 28 \
7, 28L25, 28C25.\
6, 28 26, 27.6 2\
6, 27L26, 11L19,\
 4zM24, 26L8, 26\
L8, 6L18, 6L18, \
11C18, 11.6 18.4\
, 12 19, 12L24, \
12L24, 26z\x22 fill\
=\x22#000000\x22 class\
=\x22Black\x22 />\x0d\x0a   \
   </g>\x0d\x0a    </g\
>\x0d\x0a  </g>\x0d\x0a</svg\
>\
\x00\x00\x07G\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-5.82 -2\
 32 32\x22 xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22 >\x0d\x0a  \
<g transform=\x22tr\
anslate(-5.0927,\
 -3.433227537819\
05E-07)\x22>\x0d\x0a    <\
g transform=\x22mat\
rix(0.6363638043\
40363, 0, 0, 0.6\
36363804340363, \
0, 0)\x22>\x0d\x0a      <\
path d=\x22M36, 4L2\
6, 4C26, 5.1 25.\
1, 6 24, 6C22.9,\
 6 22, 5.1 22, 4\
L12, 4C9.8, 4 8,\
 5.8 8, 8L8, 40C\
8, 42.2 9.8, 44 \
12, 44L36, 44C38\
.2, 44 40, 42.2 \
40, 40L40, 8C40,\
 5.8 38.2, 4 36,\
 4z\x22 fill=\x22#455A\
64\x22 />\x0d\x0a    </g>\
\x0d\x0a  </g>\x0d\x0a  <g t\
ransform=\x22transl\
ate(-5.092700209\
80835, -5.531311\
03586679E-07)\x22>\x0d\
\x0a    <g transfor\
m=\x22matrix(0.6363\
63804340363, 0, \
0, 0.63636380434\
0363, 0, 0)\x22>\x0d\x0a \
     <path d=\x22M3\
6, 41L12, 41C11.\
4, 41 11, 40.6 1\
1, 40L11, 8C11, \
7.4 11.4, 7 12, \
7L36, 7C36.6, 7 \
37, 7.4 37, 8L37\
, 40C37, 40.6 36\
.6, 41 36, 41z\x22 \
fill=\x22#fff\x22 />\x0d\x0a\
    </g>\x0d\x0a  </g>\
\x0d\x0a  <g transform\
=\x22translate(-5.0\
9270007629395, -\
3.43322753781905\
E-07)\x22>\x0d\x0a    <g \
transform=\x22matri\
x(0.636363804340\
363, 0, 0, 0.636\
363804340363, 0,\
 0)\x22>\x0d\x0a      <g \
fill=\x22#90A4AE\x22>\x0d\
\x0a        <path d\
=\x22M26, 4C26, 5.1\
 25.1, 6 24, 6C2\
2.9, 6 22, 5.1 2\
2, 4L15, 4L15, 8\
C15, 9.1 15.9, 1\
0 17, 10L31, 10C\
32.1, 10 33, 9.1\
 33, 8L33, 4L26,\
 4z\x22 fill=\x22#90A4\
AE\x22 />\x0d\x0a      </\
g>\x0d\x0a    </g>\x0d\x0a  \
</g>\x0d\x0a  <g trans\
form=\x22translate(\
-5.0927007247924\
8, 0)\x22>\x0d\x0a    <g \
transform=\x22matri\
x(0.636363804340\
363, 0, 0, 0.636\
363804340363, 0,\
 0)\x22>\x0d\x0a      <g \
fill=\x22#90A4AE\x22>\x0d\
\x0a        <path d\
=\x22M24, 0C21.8, 0\
 20, 1.8 20, 4C2\
0, 6.2 21.8, 8 2\
4, 8C26.2, 8 28,\
 6.2 28, 4C28, 1\
.8 26.2, 0 24, 0\
zM24, 6C22.9, 6 \
22, 5.1 22, 4C22\
, 2.9 22.9, 2 24\
, 2C25.1, 2 26, \
2.9 26, 4C26, 5.\
1 25.1, 6 24, 6z\
\x22 fill=\x22#90A4AE\x22\
 />\x0d\x0a      </g>\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a  <g transfor\
m=\x22translate(-5.\
09269992523193, \
3.20434576650541\
E-08)\x22>\x0d\x0a    <g \
transform=\x22matri\
x(0.636363804340\
363, 0, 0, 0.636\
363804340363, 0,\
 0)\x22>\x0d\x0a      <po\
lygon points=\x2230\
.6,18.6 21.6,27.\
6 17.4,23.3 14.9\
,25.8 21.7,32.5 \
33.1,21.1\x22 fill=\
\x22#4CAF50\x22 />\x0d\x0a  \
  </g>\x0d\x0a  </g>\x0d\x0a\
</svg>\
\x00\x00\x08Y\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   sodipodi:do\
cname=\x22select-ci\
rcle-gray.svg\x22\x0a \
  inkscape:versi\
on=\x221.4 (86a8ad7\
, 2024-10-11)\x22\x0a \
  xmlns:inkscape\
=\x22http://www.ink\
scape.org/namesp\
aces/inkscape\x22\x0a \
  xmlns:sodipodi\
=\x22http://sodipod\
i.sourceforge.ne\
t/DTD/sodipodi-0\
.dtd\x22\x0a   xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns:svg=\x22http:/\
/www.w3.org/2000\
/svg\x22>\x0a  <defs\x0a \
    id=\x22defs2\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     id=\
\x22namedview2\x22\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#000000\x22\
\x0a     borderopac\
ity=\x220.25\x22\x0a     \
inkscape:showpag\
eshadow=\x222\x22\x0a    \
 inkscape:pageop\
acity=\x220.0\x22\x0a    \
 inkscape:pagech\
eckerboard=\x220\x22\x0a \
    inkscape:des\
kcolor=\x22#d1d1d1\x22\
\x0a     inkscape:z\
oom=\x2224.3125\x22\x0a  \
   inkscape:cx=\x22\
15.979434\x22\x0a     \
inkscape:cy=\x2216\x22\
\x0a     inkscape:w\
indow-width=\x22192\
0\x22\x0a     inkscape\
:window-height=\x22\
996\x22\x0a     inksca\
pe:window-x=\x22-9\x22\
\x0a     inkscape:w\
indow-y=\x22-9\x22\x0a   \
  inkscape:windo\
w-maximized=\x221\x22\x0a\
     inkscape:cu\
rrent-layer=\x22svg\
2\x22 />\x0a  <g\x0a     \
transform=\x22trans\
late(-3.0905, -3\
.0905)\x22\x0a     id=\
\x22g2\x22>\x0a    <g\x0a   \
    transform=\x22m\
atrix(1.42420983\
314514, 0, 0, 1.\
42420983314514, \
0, 0)\x22\x0a       id\
=\x22g1\x22>\x0a      <pa\
th\x0a         d=\x22M\
6.35, 20.25L7.56\
, 18.66C8.42, 19\
.23 9.39, 19.64 \
10.43, 19.85L10.\
16, 21.83C8.77, \
21.57 7.5, 21 6.\
35, 20.25M16.43,\
 18.66L17.64, 20\
.26C16.5, 21.03 \
15.23, 21.57 13.\
84, 21.83L13.57,\
 19.85C14.61, 19\
.64 15.57, 19.23\
 16.43, 18.66M19\
.84, 13.59L21.83\
, 13.86C21.57, 1\
5.25 21, 16.54 2\
0.24, 17.66L18.6\
5, 16.45C19.22, \
15.6 19.63, 14.6\
3 19.84, 13.59M2\
.17, 13.84L4.15,\
 13.57C4.36, 14.\
61 4.77, 15.58 5\
.34, 16.44L3.75,\
 17.65C3, 16.5 2\
.43, 15.23 2.17,\
 13.84M18.66, 7.\
56L20.25, 6.35C2\
1.03, 7.5 21.58,\
 8.78 21.83, 10.\
18L19.85, 10.45C\
19.64, 9.4 19.23\
, 8.42 18.66, 7.\
56M13.57, 4.15L1\
3.84, 2.17C15.23\
, 2.43 16.5, 3 1\
7.65, 3.75L16.44\
, 5.34C15.58, 4.\
77 14.61, 4.36 1\
3.57, 4.15M7.56,\
 5.34L6.35, 3.75\
C7.5, 3 8.77, 2.\
43 10.16, 2.17L1\
0.43, 4.15C9.39,\
 4.36 8.42, 4.77\
 7.56, 5.34M4.15\
, 10.43L2.17, 10\
.16C2.43, 8.77 3\
, 7.5 3.75, 6.35\
L5.34, 7.56C4.77\
, 8.42 4.36, 9.3\
9 4.15, 10.43z\x22\x0a\
         id=\x22pat\
h1\x22\x0a         sty\
le=\x22stroke:none;\
stroke-opacity:1\
;fill:#000000;fi\
ll-opacity:1\x22 />\
\x0a    </g>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x08;\
\x00\
\x00(\x9bx\xda\xd5Z\xcbnd\xb7\x11\xdd\x07\xc8?\
\x5c\xf4fl\xc0\xa2\xc8\xe2\xdb\x18\xd9\x80\x85d%\xef\
\xec\xb5!{\x14Y\xc8\x8c4\x90\xe4\xd1\xc4\xbf\x96E\
>)\xbf\x90C\xb2\xaa\xc8n \x81\x17\x92\x90\x86\xc7\
v\x1f\xf2\xd6\x83uX\xbc\xc5\xba\xf3\xef\x7f\xfe\xeb\xed\
\xb7\x9f?\xbc\xdf>]\xdd?\xdc\xdc\xdd\x9e\xbdq\xc6\
\xbe\xd9\xaen\x7f\xb9{ws{}\xf6\xe6\xc7\x1f\xfe\
zR\xde|\xfb\xcd\x9f\xff\xf4\xf6\xe1\xd3\xf5\xf6\xe9\xe6\
\xea\xe9\xbb\xbb\xcfg\xbb\x13\xdaN\xbc\xc9\x9e\xe2\xe6\x09\
\x7fv\x1b\xb4\xdc>\x9c\xed~}|\xfc\xf8\xf5\xe9\xe9\
\xd3\xd3\x93y\xf2\xe6\xee\xfe\xfa\x94\xac\xb5\xa7\x10\xdem\
\xd0\xb2mo\xaf\xb7\x9bwg\xbb\xf3\xcb\x8f\x97?\xb9\
\xdd\xf6x\x7fy\xfb\xf0\xb7\xbb\xfb\x0fg\xbb\xfe\xf3\xfd\
\xe5\xe3\xd5\x17P]\x5cH5S\xaa.\xe7\xec\xfer\
b\xf3W\xdb\x89\xeb\x16\xad+\xde\xd9\x88\xf9/w\xdb\
\xc3\xe3?\xde_\x9d\xed\xaen/\x7f~\x7fu\xf2\xf3\
\xe5/\x7f\xbf\xbe\xbf\xfb\xed\xf6\xdd\xd7\xb7WO\x9b\xc5\
?Ts\xfbw\xd7\x8dw\xf3\x8b\xc9\x0f\x97\x8f\xf77\
\x9f\xbf\xb0\xc6\xd6@9\xd9J5\xa4\x88\xff|\xb5\xd9\
\xf1\xe7\xbf\xcc|)\xfa\x9aF\xfd\x09\xf0\xf1\xf2\xf1\xd7\
\x0d\xeb\xfb\xbe`\x0d\x19N\x93\xf5\xc6\x85p\x9e\x8b\xf1\
\x81\x14o\x19\xf3\xb1\xc1l\x12%\x85\x0e\xb3\xd9\x9d+\
,&\xdb\xb8\xa90a\x1a\x0bR\xe5\x03\x9f\x97j\x82\
[\xe6\xab7\xd5\xfa)?\xf1P\xaf\x98\xad\xab<;\
w\xe0\xfc\xef\xbb\xedt\xae\xf7T\x16,\xbf\xf4\xff\x7f\
\x84\xda`,\xb8\xf3\xe4\xa8\xb8\x1a\x8f\x92\xda\x90L\x0d\
\x0b\xb5\xc1\xedG\xcfc\x9efp\x05r\xec\x15\x0ej\
T\x98\xa9S\xe5Lm$\x13\xea2\x1f1\x9f\x17j\
'\x1e\xea;\x0e\xd3\xba\xca\xb3s\x07\xce?'\xb5\xde\
\xd8\xe8r\xcc\xc5E\xecV\x97\x8f\x90ZG\xd6\x14\xbb\
p\xeb\x5c4\x94\xdc\x8c\x9fs\xd6\xe42\xe3\xab\x98\xe3\
?\xf1\xe0g*`\x02\xa7\x09f\xd8QBv\xafO\
x<\xe1\x17\x8e\x97\x016\xa2\x03\xe2\x85\xea\x107\x0f\
\x16\xf2\x9c<7\x93\xd5\xd7\x10}\xf1\x11\xb9|\x8c<\
\xc7l2\xad<#O\x5c]\x03\x18\xf0\xc4\x12`\x86\
B\x80@&H\xa5\x85B\xd5/$'o(\xafO\
$<\x11W\x92\xe7\x00\xdb\xd0\x01\xf1\xa1\xebX\x5c<\
X\xc43rl\x8f\x8dO\x88\xaetf\xe3K]\x0e\
=\xe4B?\x03\x83A07\xc2\x09\xdcS8\x19[\
\xe8\x1c5O\xe60\xe3hl\x16\x09\xfa\x22\xf9\xf1\xb3\
\xb1A\xe7\xfdg\x84\x9e\xba\xc9\xf3 \xce\xd7\xd4\xb55\
[\xc88J\xe7\xcdT\x9b$\xec\x08TGp\xa4\x0a\
\xe9e\xebn\x16\xc5H}\x93RZ\xe6qV\xc4E\
\xdae\xe3\x5cV\xdd0X\x0b-\x96\xa1.\xc6\xe9\xd8\
\xc4\xc3\xe7\x89\xdbr\xb0a\x9a\xfc\xb2RU/\x81h\
\xe6\x978u\xf7\xe2\xb2\xe1\xf6\xa3\xfc2\xfb\xcd&g\
}t1\x1d\xc3~sT\x0d\xf9\x08\xd6C#\x86a\
S\xe2\xbco\xc99~b4\xf5-\x84\xa8\x99\xdc\xde\
\xf2\xfc|\xc0L\xa9\x1aX\xc6\x8d\x88\x98\x96\xf9N\xa4\
\x9f\xe2\x8aYs\xc7a\x1a\xed\xf2~\xfas\xe0\xee\x0b\
\x1d\x14\xd8\xa5\xd9zG\xc7@\x5c%\x1c\xa5\xca\xdb@\
MEM&\xa7\xc1\x9a%\xe3\xed`\x0d\xf9RBQ\
\xd6\x90\x17\x9e\x16\xd6\x06\x9e\xac\xf1\xbc\xb2\xc4\xe2\x13\x0f\
\xcd\xc2\x1a\xdb\x14\xd2\xd8\x99}O_(\xd7\x9c\x0d\xd5\
\x06W\x8e\x81\xb2\x18\x11\xd5$\x94\x0d\xd4T\xc4\x8a\xdb\
b\xa7,a,v\xc62\xaa\x9f\xa2\x84e\x8c\x17\x0d\
hGJ\xd6\x98\x13jXN`W\xe8\x95(\xb6$\
D\xb1\x0b\xfb\xfe\xbd\x10Q\xa8\xa8m\xcc\xe9(r\xcb\
\xa5d\x5c\x99\x87\xe2\x80=\xa7\x10\xdf\x94Gz\xe5d\
\xc8\xb9\x9e^\x05\xab\x8c\xf3P,\x98Y\xf8b<\xd3\
\x8b\xe75\x9d\xbax\x9a\x985\xeb\xa1\xc8F\xf5Pd\
\x7f\x0e\xdc}\x11\xe2\x8e\x82.\x14\x139I\xc94\x90\
TL\xae\x9a\xe0\xab\x16L\x0e\xe7V\xd0z\x09E@\
\xaa\xbdF\x8a\x9d\x80\xf6\xab\x980\xceL\x8f\xa7\x82\x94\
Jx-%\xcaR)\xf9\xd8\xae\xa4R)y\x18\x06\
\xf9\xa3P\xf2\x90\xf7Z&u\xa4E\x12\xcf\xa1Fi\
\xad\x90.V\xb4\x84a\x9dR!5\x83.kA4\
\x9c\xd1rh8\xa9px\xaf\xc5Q\xab\x9d\xa6\xe2\xbe\
f\xaf\xa5\x11\x07D*#\x8e\xd6~(_\xed\xaeu\
\x147,&Q\xee?\xcc\xa2\xdcm@Tm\xf1\xd4\
\xbbN\xe3\xc6/w\x1f2\xa5\xd1,\xe2=\xc2\xcb\xfd\
j\xe0y}\x93y\xbe\x9f\xb14#\xd6\x0d\x94je\
\xdb\x85/os\x7f\xad~?'\x95\xc9\x94\x94B\x8c\
6%\xec7O\xc7Ce\x0d&E\xc9@\xe4\x8d]\
\xe2\xd5\xee\x0a\x89S\xae1\xa9\x98\xa3=\xf1\xe0B\xa4\
\x85(\xd1-D\x96j\x1c\xcd\xe9\x12Z\x02L&\x15\
3\x97\x82\x85K\x16g.\xf7\x1c\x7f\xdeV\xd7\xffh\
P\x1fC[Z\x0e}n,\xf39&m\xe7\x16\xec\
\xach\x1c\x97\x8c8\xd0\x22\xd8\x22\x8bRW\xd4\x0e\xa8\
\xfdh\x9e\x95v3\xcbj\xf7y(V8\xac\x8a,\
\xbb\xb4\xef\xf0\xabu\xa2\x8f\xa1\xff\xcc\x1cJ\x07\x99\x03\
&\xfd\xe5\x11MA#\xd4\x8c\x98\x07\x11d\x96D-\
s(\x8dc\x9e\x95>3\xcbj\xdby(\xd6\xae\xf3\
\xb0*\xb2RL\xec9\xfcj-\xe7\xa3h43\x89\
\xda&\x96\x8aB\xda\xc8#\xa0\x0aG\xb8\x05\xca\xa9'\
\xc2\xcc\x95*g*\xb5;,\xf3\xd2>\x16ym'\
\xb3z\xc5l]\xe4\xc5\xb9}\xe7\x9f\xf7%\xc9\xdd\x1f\
oS\x09>\x1c\x0d\xa1\x84\x1a3\x96\xf9\x92\xf4\xc1\x10\
y}K\x22\xf3\x8a\xd3\xaa\x15\xd7\x17\x5cI\x82\x96\xad\
\x14\xac\x89\xbe\xceB\x19\xa9\x99\x9c\xd7\xc2U\xa0T\xae\
\x8aG\xe9\xda\xc5\x83V\xe4\xaa\x9dkW1.\xc5\xbc\
\xb8\xd6\xd9\x8b\x9bz>\xf09\xc1\x0av\xc5\x9co\xec\
'\x16\x87\xef\x84{ZMS;6I\xf2N\x0bg\
\xc2x\x8c\x85\x9d\x8b\x0bf\xe7\x05\xf3\xda\xba\xf8\xac\xd8\
E\xbbD\x86\x8d\xf3-\xa1\xfb&\x87\x94\xdf\xf6\x83\xfe\
j\xfb\xf08Z]\x93W\xeeO\x11\x82\xe8\xd6\xfeT\
\xdfF\xb44\xa8\xe6\x00w\xa8d\x80[T\xa2\xa1\xf7\
\xa4\xd2\x0c\xff\xc0\x9d,\x1b\xe6tg\xbaNi\xc1\xaa\
~\x0e\xb0\x03\xac@=<X\xc2\xeb1|\x14\x9d1\
\x0d\xcfhi\x09;\xdc\xd2\x12\xee\xa4\xa7%X\x9aZ\
\x82{W\xab(\xb7\xbd\x8d\x95g\xe8\x07VneZ\
\xa8\x13i\xc1\xa2]\xb0Xgq\xf6m\xcf\xf1Wd\
\xf5\x18\xbe-\xccM\xcf_\x034o\xe5k\x80\xa6\xa9\
|\x0e\xd0\x01\xf9\x1e0\x07\xbc\xc9n&\xee\xf8\x00\xb0\
d.\x0f(\xbd\xfa\x80\xa6\xa6h\x98\x03lC\x07\xc4\
\x0bQ!n\x1e\xac\xe39ivFN\xe0\xe0\x13J\
@\xd0\x9c\x16\x9a3\x85\x5c)\xfc\x7f'o\xb5(\xbf\
\xfbk\xd6#\x09\xd2\x85\xcb\xa8\xb6r\x8f\x97\xc5@k\
\x82 n\x14F\xc8q\x1cm\x0e\xc9\xe5(\x8e\x81\xda\
>\xc8%\x1c\x8b\xbd\x0f\x15\xf0\x16-(#\x91\x8e\x88\
G\x1b\xc0\xfb\x93Zs\xa3\xd5\x02u\x90\x10]\x1b\x80\
h\xaf\xcd#\xde\xd7\xc5]\x10\x0e\xe3\xd8\xff\xea@v\
(\xe2\xb1\xdd,\xaa\xc2\xd0.~\xc8\xce*_\x9f\x1b\
,x\x10/]\x870\xf7\x8f\xdd\x18H\x84\x5c\xc7@\
\xe9\x9d\xb4>\x10\xfa\x13\xb5-m\x0c\xc41PT\x04\
5\x86\xc3^\xc9\xeb\x03\xb5\xb5\x80\xdb\x0028\xf4\xdd\
F\xfd\xf2\x89\xa0x\x1f/\xda\x06\xa6\xd0\xbc\xf0p\xb7\
\xa6\x0bj\x07K#\x9dR\xc2\xc2\xe06\x9e\xc4[\xa6\
\x0d\xc0\xcf\xee\xbco\x0a\x10\xc4P\xa11gT5A\
\x07\xce\xa9 \xfe\xbd\xe1'O\x80\x07\xeb\x89\x15 v\
T\x02\xbc\xcel\xa2\x22I\x0a\xaa\x0f\xea:`k\xeb\
pT:\xa9\x1dz\x18\x88\xc6\xa6^\x97\xe1\x02\xe4\xe0\
u\xc42j\x18_l\xa9\x05\x1b\xa4\xe7\xdc\xbfLS\
\xff\xe4J\xadE1\xfe\x9e\x06j8Gm+\x222\
m[\xb4\xb7&H'\xfc\xbf\xd6>\x00\x8e[_\xbb\
\x0d\x8c\x16\x0a\xaa\x9e\xdcD\x02^\xa7\xbd\x1b\x19\xc6w\
\xe0\x83\xad\xf5\xfb\xf7\x84\xb4.\xe3\xd3-\xf6\x85E\xb4\
\x08\x05\x15\xb9\xf1\xed7\xf8\x96\xbd\x88\x97\xef_\xc5[\
-\x15{%\xe6G\xd7\xd7b?\xd4\x0b\x5c\x94\xe1a\
\xd3\xd1\xf6g,\x17\xad\x11o{\xcf\xb8\xc5'cu\
\xd8[Xrs\xd57e\x17\x87f\xff\xd0\x11\xf0\xb6\
\xfdm\xc1o\xfe\x03\xd4\xa1\xd4\xc4\
\x00\x00\x02\x7f\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!--\x0d\x0a // 1\
6pxls (c) by Pau\
l mackenzie <pau\
l@whatspauldoing\
.com>\x0d\x0a //\x0d\x0a // \
16pxls is licens\
ed under a\x0d\x0a // \
Creative Commons\
 Attribution-Sha\
reAlike 4.0 Inte\
rnational Licens\
e.\x0d\x0a //\x0d\x0a // You\
 should have rec\
eived a copy of \
the license alon\
g with this\x0d\x0a //\
 work. If not, s\
ee <http://creat\
ivecommons.org/l\
icenses/by-sa/4.\
0/>.\x0d\x0a-->\x0d\x0a\x0d\x0a<sv\
g fill=\x22#000000\x22\
 width=\x22800px\x22 h\
eight=\x22800px\x22 vi\
ewBox=\x220 0 16 16\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22>\x0d\x0a    <path\
 d=\x22M9 3.793V9H7\
V3.864L5.914 4.9\
5 4.5 3.536 8.03\
6 0l.707.707.707\
.707 2.121 2.122\
-1.414 1.414L9 3\
.793zM16 11v5H0v\
-5h2v3h12v-3h2z\x22\
 fill-rule=\x22even\
odd\x22/>\x0d\x0a</svg>\
\x00\x00\x03A\
\x00\
\x00\x0c\xbex\xda\xe5W\xedn\x9b0\x14\xfd\xdf\xa7@\
\xde\x9fV*\x8em0\x1fii\xa5\xa9\xda\x13t\x0f\
@\xc0!\xa8\xc4F\x86\x16\xd2\xa7\xdf5\x01\x12H\xba\
i\xed6\xa9\x1aI\x94\xf8\x9e\xfbe\x9fcCn\xef\
\xdbma\xbd\x08]\xe5JF\x88b\x82,!\x13\x95\
\xe62\x8b\xd0\xf7\xc7ov\x80\xac\xaa\x8ee\x1a\x17J\
\x8a\x08I\x85\xee\xef.n\xab\x97\xec\xc2\xb2\xac\x97\x5c\
4_U\x1b!\x9bY\xf0v\xcc\x1bu\xc0!#\xed\
\x0cy\x1a!\x08\xda\xa3\x15\xe4/\xe1\xb3LU\x22\xe3\
-\xa4\xd5\xf1\xae\xc2\x80\xef}\xe5S\x95\xc4\xa5X\x1e\
eq\xadK\xe1'\xceZ\xac(!\xd7\x16#\xcc\xb5\
)\xb1Ix5\x0d\x11m\xa9tm\xaf\xf3B\x1ce\
.ev\xd6\xadM\xcb<B\xa1w\x16\xdc\x1d\x83\xb0\
L\xb2Z\x0e.\x11\xda\xd4u\xb9\x5c,\x9a\xa6\xc1\x83\
\x11+\x9d-L\xd1\xaa\x8c\x13Q-\x06\xfbQ\xfc0\
\xf11~0\xe0J=\xebD\xac!\x85\xc0R\xd4\x8b\
\x87\xc7\x87\x11\xb4\x09N\xeb\xf4\x90fR\xbdq\xba\xba\
\x8c\x10\xb2\x18\x16\xb0/\xf6\x92\xfd\xd4\xf3\x0e\x5coS\
\xb1\xaeL\xc8\x9e!3b\xc8Zt\xd0\xc8\x92\x99S\
j\xa8>8\x8e\xa6=\xa1\x96U\xc6\x99HT\xa1t\
\x84\xbe\xac\xbb\xab\x07VJ\xa7B\x0f\x10\xe9\xae\x09\xa4\
`\xb5\xf2z\x17!\x82\x19\xef\x91\x91\x8aj\xa3\x1a\x93\
\xba\xda\xc4\xa9j\x22\xc4\xe6\x0e\x06<\xca@\xce\xe1\xc9\
F$OB\xafT\xac\xa1\xf5\x13\x97TTOC\x7f\
)5\xaf\xb9\xc7\xabR[\x10\xa1\x8b9\xf5\xfd\xc0\x9b\
\xc3\x09l\x00\x0a[\x87s\x97\x9c\xcc \x81\xbeh\x80\
}\x9f\x90`\x8e5\xb9\x84Y\xd9M\x9e\xd6\x1b\xf0\x0a\
\x19y\xc3c#\xf2lS\x1b1\x86ox\xb4g&\
\xd6C\xbb\xb7\xa1m\xdc\xe6\xdb\xfcU\xc0\xb2\x9cL:\
y\xd6Z\xc8\xda.\xe2\x9d\xd0\xfd\xe6\xed\x95\x91\xed]\
k\x1d\xcb\x0a$\x0bk\xb3\x8dk\x9d\xb7\x97\x04\x07\xdc\
w\xa8O\xfckb^\x87!h\x982\xc2]\xeaN\
~_\xa1\x83\xa6 \xff]7\x1a\xf2O*@S\x85\
\x80\x02\xc4\xe3A@\xc3`\x88\xecci\x1f\x0b\xd1E\
.\xc5\x80\xc1^\xa0\x11\xe2\x04\x1d\x0c\xbb\xb9\xa1e\x11\
r\xa7.'\x96\xaa\xd6\xeaI\xcc\x05|@\x06\x0e\x19\
/\xdbS\xd0t\x04k\x0a\x87\x91z\x96\xe9\x11nZ\
7 \x9d\xc4\xec\x0a\xa8\x04'X\xb1\xec\xcb\xdd\x98\x81\
\xdd\xcb|Io\xf6iG\xb4\xaf2\xe2=M\xb0\x14\
\x8b\xac\xe3\xab\xffz\x936 $\xf0\x18s|:\xf2\
6\x0cY\x80\x19\xa1N\xe8\x1a\xd6\xe0\x17\xe7\x8cMY\
s\xfaA\xdf\xf7\xafz{?\xc5\xcc\x0eG\xc3o\x15\
\xfb\xa4\x9a\xb0\xddSU\xfci\xe6\x09\x86\xcdI\x89\xe7\
\x07@:\xa7^\xe0q\xe6\x19\xaa\xcf\x99\xa9\x83C\xb8\
\x18\xbd\xb6\x1dL\x98G\x1d\x16N\xa5`\x07\xffN\x0c\
\xec?\x13\x03?6\x0f\x87t\x11\xafDq\xd6\xe5\xaf\
\x09\x86\x93\xd0\xe1p\xac\xcfU2\x98\x8f\xac6\xc3@\
\x9d\xc3\xbc\xa0\xd3\x8e\x17\xc2\xf11\x13\x0c\x9f\x0a\xe6#\
\xa7\xde\x87\xc4\xe4\xcf\xd5\xf4\xf1N>\xab\xd2\xbc\xf7\xdc\
\x8c\xf6U\x97\x8ccBh\xe0y|\xb0\xa71<\xbb\
ix\x0a_J\xf8\x03\xb1\x0f\xd6\xcf\x850\xc3Wx\
\xfa{\xd7\xcd\xec\xd6<\xc0\xde]\xfc\x002\x99f\xa6\
\
\x00\x00\x0c\xee\
\x00\
\x00c%x\xda\xed\x5cY\x8f\xe36\x12~\x9f_!\
x^2\xd8\x11\xcdC<\xe4>\x82d'\x01\x82E\
\xb0A\x92\xc5>\xab%\xda\xad\x8c-9\x92\xfa\x9a_\
\xbfEZ\xb2u\xd0n\xb7\xdb\x9du\x12\xbb1\x18\x89\
EI\xc5\xaa\xaf\x0e\x16)]~\xfd\xb8\x98{\xf7\xba\
(\xd3<\xbb\x1a\x11\x84G\x9e\xce\xe2<I\xb3\xd9\xd5\
\xe8?\xbf~\xef\xab\x91WVQ\x96D\xf3<\xd3W\
\xa3,\x1f}}\xfd\xee\xb2\xbc\x9f\xbd\xf3<\x0f.\xce\
\xcaI\x12_\x8dn\xabj9\x19\x8f\x97w\xc5\x1c\xe5\
\xc5l\x9c\xc4c=\xd7\x0b\x9dU\xe5\x98 2\x1em\
\xba\xc7\x9b\xeeq\xa1\xa3*\xbd\xd7q\xbeX\xe4Yi\
\xaf\xcc\xca\xf7\xad\xceE2]\xf7~xx@\x0f\xcc\
v\x22a\x18\x8e1\x1dS\xeaC\x0f\xbf|\xca\xaa\xe8\
\xd1\xef^\x0a<\xba.\xa5\x18\xe31\xd06=\xf7\xeb\
5)A*K\xf8\xb7\xee\xde4\xa02\xbf+b=\
\x85\xeb4\xcat5\xfe\xf4\xeb\xa75\xd1\xc7(\xa9\x92\
\xd6m\xd2\xecs\x19GK\xddyj\xd3\xb8\x92@\xb4\
\xd0\xe52\x8au9n\xda\xed\xf5\xcd-'I\x1e\x9b\
>W\xa3J/\x96\xf3\xa8\xd2(\xfd\x9cg\x11\x8a\x96\
K\xd4\xf0\xdc\x5c9i)\x97\xf8\x89\xbe\xf7\xbe\x924\
`D\xd1$\x8e?z\x14S\xecc\xeac\xf1au\
Yr5\x82[({\xd2\xbet\xd5\x90\xea\x87o\xf3\
\xc7\xab\x11\xf6\xb0\xc7\x05\xc2!\x11\x82{\x14\xe8\x02~\
\xd2v\xba\xd5\xe9\xec\xb6\xba\x1a)lO\x1f\xd2\xa4\xba\
\xbd\x1aQBG\xd7p~\x99\xe8ii\xdaW\xcf2\
gt\xe4\x8d-i=@3\xba\xc4<\xac\xee\xd8\x8c\
\xe5\xe6&\x07-\xe7\x89\x06\x9dU\xc5\xddJ,-z\
\x99EK\xdfvZ\xa4\xc92O\x01}W\xa3i4\
/\xb7\xf7\xec\xdch\x9aV\xfe\x22*fi\xe6\xdf\xe4\
U\x95/`\xa4CR\xb1\x1a\x9f\x832\xd7S7\xa1\
\xca\x97\x9b\xf65\x13\x0fi\x96\xe4\x0f\xd0\xe71]\xa4\
_4\x88\x83l\xe9\xf2t5bt\x0b\x0d\x86@\xa8\
\xdav\xf3F\x1b\xa1\x92[z\xd4\x0a\x22!m\xeeq\
\x97\xa5Fp\xcb\xc7\xfa\xbc\xbc\xcd\x1ff\x85Q\x97K\
\xe8\xf1]Q\x80\x9d\xfb\xf3\xe8I\x17W#\xfb\xdf`\
\x1c\x00\xd9;\xe3\x0d\xfc\xfe\xbd7\xb7\x811\x86H\x85\
\x98\xc8!\xab1\x0cRq\xc40\xc7\xa1\xe8\x13\xbf\xe4\
FQA\xbfy\x19\xcdty\x1b\xc1\x10\x01}.b\
\x0e6\x96V\xf0X\x8c\x9a\x91\xdf\xe4E\xa2\x8b5\x81\
\xf4\x08q>\xcfa\x88\xef\x85\xfd\xd5$s\xab\x860\
\xb5\xbf\xd1\x06\xdf7\x11`\xef\xda\x9e_\xae\x1fnd\
\xb9\xea\xe2y9\xa0)\xcd\xe0Y>#Hrp;\
j\xd4\xa5\xc1\xd0\x19\x222\x00\x97\x17\xaeI`\xf8\xc6\
EX7\x1d\xac[\xcd\x13\xcd\xcd\x15\xdb\xdc\xa4z2\
\xbe\xe6\xf1\xc9\xb47\x866\x1eZ\x9am_\xe8*J\
\xa2*\xda\xf0\xdf\xb4\xf0f\x10\xe0n'?\x7f\xfa\xfe\
\xba\xbe\xfde\x1cO\xfe\x9b\x17\x9f\x9b\xa7y\x9e\xe9\x10\
\xdd\xe4w\x80\xb9\xd1\xf5\xba\xf92\x89'\xe0 \x17Q\
u\x9d.@`\xc6\xb7\xfe\x03\x1c\xe2\xe5xC\xe8t\
6lon\xba\xbam\xa1W\x9e\xd6\x19n\x92x\x91\
\x9a\x8b\xc6\xbfT\xe9|\xfe\x83yH=\xdc\xd6M\xd3\
j\xae7\x8d\x97\xe3\x9a\xfbzl\xe3\xd6\xe0.\xc7\xcd\
\xd0\xed\xd9\xac\xb6\x84FniV\xea\xacLM\xf0\xea\
XEY=\xcd\xa1%IKp\xccO\xd0m\x9ef\
\x03\x8b\x99G7z~5\xfa\x16\xb0a\xddw\xd9\x02\
\x8c5\x9f\x01\x5cgE~\xb7\x5c\x80\xe3\xab;4\xda\
\x985\xc3{\x96\xb1\xdd\xac\xb9\x99\xeb\xe0\xca>\x97\x0f\
\xfboa\xcd@E\xc7U\x0b\x17O\x1b\x0fh~p\
\xaa\x10\xa5D\x84*\xd0\x10\x7fZ$@\xbcOQ\x10\
\x04!\x0b9\xd0T\x8b\xd6\xf8\xb3&\xe6\xb4\xaf\xab=\
Y\x13\x98d\x8bdF`\xf8!\x94\xb4\xefV\xcb\xa4\
6\xf8\x09\xb9\x80\x5c\xa4\xca\x0b_O\xa7p0\xc9 \
\xe7\xb9\x98\x02\x9c&\xef\xb54\x7f\xf6\xc4\xdft\xb7\xa7\
\xc5\xdd\x5c\x9b\xae_\xc0s\x5c\x94U\x91\x7f\xd6\xab+\
W\xc7+\x07;\xc1\x881\xce\xb0jZ\x8d\xf4A\x80\
\x13\x10_\x96\xb4\x1b\x7f\x83\xb85\x01,\xeb\xa2i\xb5\
's\x88\x11\xd5$h\xda\x92\x08|[Q\x80\x22\xdb\
\x8f2\xad\xf9tZ\xeaj\x82\x9b\xb6\x0d\xb7\xcb\x08\x22\
\xa2o=\x19\x5c\x0567oY\xc8e\xa5\x1f[\xea\
\x02\xdb\x9c\xd8$\x04|5\xd8\x9d.\xee\xf5Pn\xd3\
\x1c\xeeg\x8f\xeb\xfb]\xd8\x96\x07\xab\xa3NS\x09\xf1\
mB0\xe2\x8a\xb1\xe5\xe3\x85\x19g\x1d\x9a&\x04Q\
\xbe\xea4\x8d\x16\xe9\xfciRFY\xe9\xc3\x13\xd3\xe9\
\xc5\x5cW0t\xbfvu\x13\x0c\x97>\x00\xff\x9d\x86\
\x95~\xb0\xfd\xf5\xf5\xb3C\x1bT\x04\xc0L\x17u\x02\
IA\x18\x00\xaf\x8bS\x02`$\x8cI\xd1\x03\x94\x91\
\x98\xa2\xc4g>\xf5\xa9\x1a]_V\xc0W\xd6\xf6Z\
k\xb3,r#\xaf\x8e\xc5\xad\xefb.R$\xf4\xb9\
\x1f\xfa\xa1\xec\xd0\xb7\xf0\xb4\x95\xab\x9ef\xac\xd0\xa1\x17\
\xfc@Pn\x01\x5cS\xba|\xbc\x1c[.\xae\xe1\x7f\
\x18\xd3\x9f\x1e\x12]\x1fwL\x84\x10\x86D\xc8\xb8\xe0\
]\x84\x84\xa0$\xc9\x03\xaav\x22\xc4\x0f\x8f\x84\x11\x9f\
\xf5Q\xe2\xe2k+g\x87\xa0\x84\x9dQ\xb2?J(\
C\x10g\x06(\xe1\x88\xb3\x80\xe2P>\x83\x12_\x1c\
\x0d'>\xee#\xc5\xc5\xdbV\xee\xba\x0a\xab\xd5s\x93\
\xcf\x93\x8b\x17@'Pg\xe8\xec\x0d\x1d&P(\x05\
\xed\xe4<v&B\x15\xe1\xed\xbc~\x1bt\xe8\xf1\xb0\
#\xfa\xd8q1\xb7\x95\xbdC\xbc\x8c\x08\xceP\xd9?\
\x16!N\xa9d\x94\xf4\xa0\x12 3\x8b|&[\xf1\
\xc9\xb1p\xa2\x06\xb1\xc8\xc1\xd7V\xce\x0eA\x09\x11g\
\x94\xec\x8d\x12.\x11\x083 \xa2\xefP0\x91B\x85\
\xfcY\x87\xe2\xcb#F#?\xec\xa3\xc5\xc5\xdfV\x0e\
\x8f\x12\x8f>\xe92\x9de y/\xca\xbco\x96K\
\xef\x878\xcf\xcexz\x01\x9e\x18\xc6}<\x99\x12\x15\
\x07\xe3f\xcf\x07(\xff\x98!j\x98\xe0\xb8\x18\xdc\xca\
\xe2!\xee\xe7\x9b\xf9\xdc{\xca\xef\xbcL\xeb\xc4KK\
\xaf\xba\xd5\x9e\xc9q<s9\xf2\xfe\x0d\xe7\x85=.\
\xbd\xa8\xd0^\x96\xc6\xfa\xa3wsWyY^y\x85\
\xfe\xfd.-t\x82\xce\x80{\x1d\xe08\xa2!\x81\xa9\
\x0d\xd9\x07pG\x86\xdcp\xfe\xb5\x15t.6\x0f\x01\
\xdd\x8f\xd1g\xed\x95w\x80'\x03\xbd\xb2\x8a\x9e\xbc\x87\
\xb4\xbaM3\x0b?\x88\x88\xa6\x90\xf8\xd1\x83\xc9\xfc\xea\
\x805\x07\x80\xcc\xd5A\x94%\x1e\xe4W\xe6\xc4\xb3E\
\xbb\xf2\x8c\xc1\x17`\x103\xc6y\xaf0$Q\x00\xee\
$ \xc1~\x18<f$\xb5(\xf4\xb9\x03\x87\x03F\
\xb7\xb2z\x08\x0e\x7f0+\x8d\xde]\xa9\xad\xdf+\xb5\
W\xe5\x1e\x8c\xb6\x88\xe2\xca \xb3\xf0R\x08\xa6\xde\xb4\
\xc8\x17@\x07\xe7\x08r\xd7g\x9c\xbd\x04g\x94\x85\xa4\
\x97\xd2S\x8c\x94\xe0\x5c\xee\x8d\xb3#V\x9a\x1a\xa4\xf9\
\xd4\x85\xb5>\xb3[\xd9=\x04k\xbfh\xed\x99\x95\x9e\
r2\x1e\xdf\xa63\xf49Y-\x90\xdb;\x8d\x0d\xd0\
\xca\xb17\xcdk\xcc%6\xad\xf3\xa2\xe4\x1e\x02\xee\x16\
\xc4\xcd\xba\xf2\x9b\x91\x80\x86\xedU\xaa\xee\x92\xc5j0\
\x1c,\x07~N\x97o\x16\xe5\xba\xf3\x9f\xf5\xfa\x04\xb2\
\x83`\xdd\xcb\x9a\xb5V\x8e\x98\xa5\x0e\xc4o\xd7(\x08\
v\xce\xa3\xf7X\xa5\x10\xb1\xf9{\xd5*\x85\xc0\x98\xcb\
\xfe\x22\x05d/\xd5\x09\xacQl\xd5\x90\x00a\x87\xc4\
\xa1!px\x5c\x91-\x1a\x22\x83\x15\xa4\xcdv\x05'\
q\xad\xa1~\xa0\xdf_C\x94QA\xc3Wi\x88\xc3\
\xf5\x7f\x0d\xfd\x84\x883B\x03\xf1\x16\xfa\xf1\xd9\x81\x1a\
\x82\x16<%g\x0d\xd9\xc5'\x02nL\x86\x84\xbf\x8d\
\x86\xfcC\xadh\x1a\x9b\xbf\xb3\x8e\xac\x8e\x18\x92&\xd6\
\xbc\x95\x8az3\xec\xfd\x95\xc4\x92H\xeb\xb3\xab[)\
\x89#\xa5\xc0\xd5\xbd\xa1\x96\x0e6&*#-\xf0Y\
OVO\x12\x85!8<\xf9\x96z\xea\xa5\xd2/p\
{B\x06\xf8\xac)\xab)\x89A\xde\xe0\xf6\xc4\xdbj\
\xea`\xabJ\xa2 \xe0\xec/\xaa\xab\xcb\xf1\xec<\x8b\
\xdf9\x8b\x17\xd8L-\xbb\xb3\xf8\x00\xe1@\x11\xce\xf6\
Xr9\xe6\x04\x1e\xc3\x81tM\xde\xfb<n\xe5\xf2\
(\xcb.\xff\xcc\xe7\xa6>\xf4\xb3\xd9\xf3\x18\xaf^\x0d\
8\xd7\x85^Y\x17\x0aMz\xae\xc8\xdee!v\xfc\
\xb2\x90\xd8\xbf,4\xe4\xf6\xf0\x0a\xe4\x03\xc8\xd3\x8b\x92\
\xc4\x8b\xe7Qi\xab\x91\xb9\x97\xdf\xfc\x06N\xb8\xf4\xf2\
i]\x9b\x8c-\xe4J\x18\xa1ix\xf2\x00>K\xe8\
aK\xe6\xe5SY\xe9E\xdd\xc5[FV\xc1g@\
\xbe\x0e\x90f\x0f\xbb\x08\x02)\xf7G\xe4\xf16\x22\xb4\
0\xf9\x82b\xa5\x8b\xe5C`\x99f\xde\xbf>}\xe7\
\xfd\x04p\x5cD\x9e\xce\xee\xd3\x22\xcf\xac\x97s\x96\xbf\
\xd7\x11\xb4\xb5\x87{\xe7\x06\xed=vx\xf7\xf7p\xff\
\xd4\xde\x5c\xde\xda\xc5\x1d\x1c\xbe\x8b\xfb\xa9\xce\x9e$\x08\
\xb3\xb7q\x09\x04\x1c@Z\xe5\xda\xacM\x04\x0a\x19\xfc\
\xe8p\xb3\xb6\x8bd\x18\xadW\xaa:U\x1c\xa7\x80.\
\xf6\xc8\xc5\x22n\xfe^\x91\x8b\x11\xc4\xa8d\xe2T\xb3\
\xb1AY\x1b\x0c\xfc9\xb9\xed*{\xef\x9f\xe5\xbeZ\
\xb2\x18\xd2{&\xa4:)\xd1\xf6=M\xbd\x98\xea;\
g\x13\x0a\x05v2A\x9d\x13\x117u\xb5cW\x1a\
\x97/\x07\xfb^V\xa1\x00\x120w\xbe\xddWv\xa8\
\x9e\xd7\xf5\x86^\x15\x10B\xcc\x0b7\xc6w\xc0\xa1\x19\
\xd7Wvg\xc4G\x9f\x06\x90\xfb\xc1\xa3\xc9\x87\x93\x01\
G\x18rN\xe4I\x83\xa3^`\xef\xad\xc56\xee\x8d\
\x22w)a@x\xb4\xebf\xc4\xc8\x7f\xb0xK9\
F\x81u\x92\xcfB\xc2\xa9_b\xaa\x1a\xe6\x8d\x18\xa3\
c\x85\x18\x1c\xd2\x0f\xa3\x81\xd3\xe8lR8m\xa7\x11\
pAex\xd2\xb8\xa8\xb7b\xf4R\x91\xe6\x1d%\xa4\
\xa8Q\xb5\xdbi\xb8\xa9\xe6\xb5(B \xfa\xd2 \x1c\
\xec\xc0\xa5\x82 n\xd7\xba\xdc\x10\x19\x84q\x12 e\
\xc2u0\xd8T\xaa\xcc.)\xea\x08\xe3\x01\xa2&T\
32\x0c\xe3.\x92\x11B\xbd1\xa5\xb3\xed\xef\xff\x17\
\xc6\xcd;XD\xb1\xd3\xac\xaa\xfc\x11\x19\xe1\x8f\xf6u\
dGJ\xc8\x0eO\x09\x0fVg\xa2\x86\x13\x11\xf0\x80\
\x82\xaaP\xbc,9\xa3\x92\x87\xa7\xea\x0c6\xab\xfa0\
\xf1\x910S\xa10I\xa1\x9d\xbcvG*\xbc\x0e\x17\
\x08\x9b\xa4\x00\x07\xee\xa4\xbb\xb7/iU\xe0\x94D\xb5\
\x9d\xc1YkG\xd0Z\xa7\x90vt\xbd\xd5qZ\xb2\
\xedz\xeb$\x88\xef\x5c\x09e\xe0`\x03#\x192\x19\
0\xecp\xdd\xae\x0c\xb5?\xfc\xd1\x09\x01\x07\xc6\xa2\x08\
S\xe4T'cC})D!]\x11\xe2\x8f\xd3W\
'\xe98k\xec\xa5\x1a\xdb\xe4\xdb\xef\x9e\xcb\xcfw\x19\
\xba{\x0e\xe0r-\xa3\x93r\xcc0\x13\xc0\xc1\x89:\
\xe6=\xe7\xaf;\xb5+(\xc2\xb2\x9bC\xbf\xa9vO\
\xcb\x1a\xff\x06\xfa\xb5S!\xd9\xd3o=w\xe2Nw\
\xcb\xcd.\xfdn<\xde1Sk+\xf9\xb4\x1c\xed\xa9\
-\x19\x1fT\x98\xd8\xad\x5c\x81\x14\x84F\xf1\x87(\xb7\
\x93\xee\x9d\xd5{\x5c\xf5\xd6\x13\xde\xe6\xbf\xd9\xf3_\xd0\
\xd9\xd39\xf4\xbe\xa6C\x9e\xfd\x9a\x8e\xfb\xfb<\xcd\xab\
\x81\xe5\xe0k;N>\xd6\xf1\xe3\xa3@\xccl\x0c\xe7\
\xeaCg\xa2]\x17\x0aw~ \x07RB\x1er\xa6\
x\x7f\xeb\x00G\xe6\x1d\xc9~\x0a\xb9\x0aK\xd4\x19\xb2\
V\xb3\x04\xe7\x9a\x8b\x83\xb4A=3KrG@\xfd\
\xea[X\xaf\xaa\xd6\x10\xa5B\xa5\xb08\xd9o\xe6\xf4\
\xe6\xd4\xcf\x17d^R&u-\xd4\xe2\x97\x09\x10\x87\
\x81$\x9c\xf2\xd3\x12\xe0\x10u\xdd\x1d\xc6\xee\xccjK\
\xe5\xdcdnH\x82\xd9p)\xb4\xdf\xd9\xb8g\x0d\xa7\
\xf6\x0a\xed\x87\xf6\xec\xfc\xbd\xe1@1\xb1\xab\x12w\x98\
\xc5\xd7\x8b\x98\xbb,\xbe6a>0x\x8cB\xdc}\
C\xe4q]\xb4\xed\xf8\x81\xb5\x5cj\x9a\xabB\xe1 \
\xb5\x0d\xfeD\xcc}\xb5\x94\xce\xe8\xdf\xd3\xdc\x93\x80\x1a\
K}\x8d\xb9\x13\x98\xda(y\xca\xc6\xfe\xe51\xfe\xfd\
A\xbf\xb0\x86\xe6\xa0\xb5\xea'\xacg9,D*h\
\x7f+q\xbb\xc5\xfb\xec\xf86_\xaf\x15\xef\x8e\xf2A\
H\x98\xc4x`\xf4!$\xb18 \xbd\xdcV!\xc9\
 \xb7u~\x07\x0f\xb2ai\xb3\xdb\xa1L]\xa4n\
\x98?\xce\xc4\xf4\x18\x81\x9eR\x15\xd0S\x8bS\x7f\x22\
\xcb\xc7\x82\x91\x80\xfd\x09\xe2\xbc\xdc\xaf\xa0\xb9k\xfb\x84\
1\x89\x10\xa6B\xc6\xfaD\xdf\x82V\xb3\x0c\xbe\x97\xf1\
\xfbo\x10\xf2\xe9>\xe6\xcf\x02Ld\x88\xfb\xfb\x839\
1\x8e\xa1\xc3\xbc\x9d\xda\xc2,\xd5,\xc9\x12\xe7\x92\xac\
\x14 \x08\x19\xb8\x96d\x87\xa4\xbe\xf9\x1fg~{\x04\
\x07\x80\x15\xc7A\xc0\xc3\xb3\x038\xd4\x01\x04\xcclP\
\x14\xa7\xef\x01\xc2\xfd\xca0\xbb\xf6BX\xab\x10(0\
kh\xfd\x84\x9fC\xe2,\xba/Z\xed\xf2\x00`\x01\
G\xf7\x01\xf5\xa6\x87g|\x00\xa6L\xf5y\xa7\x88\xf7\
R\x17\xfb-\x5c\x82D\xd8{]\xbc\xbb'\x83\x10\xba\
mOF\x974t\x00\xc7Y|8\x86\x0b0\xa5\x8f\
@\xb1\xb3\x0b8\xd4\x050\xc2%\x91\xa7\xef\x02\xe8\x9e\
\x1b\x88v\xed;\xdaf\x17[\xcch\xb7\x0b\xf0\xb9\xb3\
(yi\xbeR~\xfd\xee\x7fO\xd4Nb\
\x00\x00\x06\xda\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2.0025 -\
2.0025 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg2\x22\x0a   s\
odipodi:docname=\
\x22line.svg\x22\x0a   in\
kscape:export-fi\
lename=\x22..\x5cpngic\
ons\x5c96px\x5cline-gr\
ay_96x96.png\x22\x0a  \
 inkscape:export\
-xdpi=\x22288\x22\x0a   i\
nkscape:export-y\
dpi=\x22288\x22\x0a   ink\
scape:version=\x221\
.4 (86a8ad7, 202\
4-10-11)\x22\x0a   xml\
ns:inkscape=\x22htt\
p://www.inkscape\
.org/namespaces/\
inkscape\x22\x0a   xml\
ns:sodipodi=\x22htt\
p://sodipodi.sou\
rceforge.net/DTD\
/sodipodi-0.dtd\x22\
\x0a   xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
>\x0a  <defs\x0a     i\
d=\x22defs2\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     id=\x22name\
dview2\x22\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#000000\x22\x0a    \
 borderopacity=\x22\
0.25\x22\x0a     inksc\
ape:showpageshad\
ow=\x222\x22\x0a     inks\
cape:pageopacity\
=\x220.0\x22\x0a     inks\
cape:pagechecker\
board=\x220\x22\x0a     i\
nkscape:deskcolo\
r=\x22#d1d1d1\x22\x0a    \
 inkscape:zoom=\x22\
24.3125\x22\x0a     in\
kscape:cx=\x2215.97\
9434\x22\x0a     inksc\
ape:cy=\x2216\x22\x0a    \
 inkscape:window\
-width=\x221920\x22\x0a  \
   inkscape:wind\
ow-height=\x22996\x22\x0a\
     inkscape:wi\
ndow-x=\x22-9\x22\x0a    \
 inkscape:window\
-y=\x22-9\x22\x0a     ink\
scape:window-max\
imized=\x221\x22\x0a     \
inkscape:current\
-layer=\x22svg2\x22 />\
\x0a  <g\x0a     trans\
form=\x22translate(\
-1.9116, -1.9116\
)\x22\x0a     id=\x22g2\x22\x0a\
     style=\x22fill\
:none;fill-opaci\
ty:1;stroke:#000\
000;stroke-opaci\
ty:1\x22>\x0a    <g\x0a  \
     transform=\x22\
matrix(0.0636360\
123753548, 0, 0,\
 0.0636360123753\
548, 0, 0)\x22\x0a    \
   id=\x22g1\x22\x0a     \
  style=\x22fill:no\
ne;fill-opacity:\
1;stroke:#000000\
;stroke-opacity:\
1\x22>\x0a      <line\x0a\
         x1=\x2250\x22\
\x0a         y1=\x2245\
0\x22\x0a         x2=\x22\
450\x22\x0a         y2\
=\x2250\x22\x0a         t\
ransform=\x22matrix\
(-1, 0, 0, -1, 5\
00, 500)\x22\x0a      \
   stroke=\x22#0000\
00\x22\x0a         str\
oke-width=\x2240px\x22\
\x0a         stroke\
-linecap=\x22round\x22\
\x0a         id=\x22li\
ne1\x22\x0a         st\
yle=\x22fill:none;f\
ill-opacity:1;st\
roke:#000000;str\
oke-opacity:1\x22 /\
>\x0a    </g>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x02j\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22  aria-hid\
den=\x22true\x22 focus\
able=\x22false\x22 rol\
e=\x22img\x22 class=\x22i\
conify iconify--\
whh\x22 width=\x221.01\
em\x22 height=\x221em\x22\
 preserveAspectR\
atio=\x22xMidYMid m\
eet\x22 viewBox=\x220 \
0 1024 1023\x22 sty\
le=\x22transform: r\
otate(360deg);\x22>\
<path d=\x22M996 99\
0q-28 33-68 33t-\
68-33t-28-79t28-\
79l36-51V584q0 2\
6-17 43L517 990q\
-34 33-81 33t-81\
-33L33 668Q0 634\
 0 587t33-81l287\
-286v100q0 53 37\
.5 90.5T448 448t\
90.5-37.5T576 32\
0v-76l268 268h52\
q27 0 45.5 18.5T\
960 576v205l36 5\
1q28 33 28 79t-2\
8 79zM448.5 384q\
-26.5 0-45.5-19t\
-19-45V64q0-27 1\
9-45.5T448.5 0t4\
5 18.5T512 64v25\
6q0 26-18.5 45t-\
45 19z\x22 fill=\x22cu\
rrentColor\x22></pa\
th></svg>\
\x00\x00\x08\x0d\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg1\
\x22\x0a   sodipodi:do\
cname=\x22delete-gr\
ay.svg\x22\x0a   inksc\
ape:version=\x221.4\
 (86a8ad7, 2024-\
10-11)\x22\x0a   xmlns\
:inkscape=\x22http:\
//www.inkscape.o\
rg/namespaces/in\
kscape\x22\x0a   xmlns\
:sodipodi=\x22http:\
//sodipodi.sourc\
eforge.net/DTD/s\
odipodi-0.dtd\x22\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0a   xmlns:sv\
g=\x22http://www.w3\
.org/2000/svg\x22>\x0a\
  <defs\x0a     id=\
\x22defs1\x22 />\x0a  <so\
dipodi:namedview\
\x0a     id=\x22namedv\
iew1\x22\x0a     pagec\
olor=\x22#ffffff\x22\x0a \
    bordercolor=\
\x22#000000\x22\x0a     b\
orderopacity=\x220.\
25\x22\x0a     inkscap\
e:showpageshadow\
=\x222\x22\x0a     inksca\
pe:pageopacity=\x22\
0.0\x22\x0a     inksca\
pe:pagecheckerbo\
ard=\x220\x22\x0a     ink\
scape:deskcolor=\
\x22#d1d1d1\x22\x0a     i\
nkscape:zoom=\x2217\
.832349\x22\x0a     in\
kscape:cx=\x2222.96\
3884\x22\x0a     inksc\
ape:cy=\x2216.65512\
5\x22\x0a     inkscape\
:window-width=\x221\
920\x22\x0a     inksca\
pe:window-height\
=\x22996\x22\x0a     inks\
cape:window-x=\x22-\
9\x22\x0a     inkscape\
:window-y=\x22-9\x22\x0a \
    inkscape:win\
dow-maximized=\x221\
\x22\x0a     inkscape:\
current-layer=\x22s\
vg1\x22\x0a     showgr\
id=\x22true\x22>\x0a    <\
inkscape:grid\x0a  \
     id=\x22grid1\x22\x0a\
       units=\x22px\
\x22\x0a       originx\
=\x220\x22\x0a       orig\
iny=\x220\x22\x0a       s\
pacingx=\x221\x22\x0a    \
   spacingy=\x221\x22\x0a\
       empcolor=\
\x22#0099e5\x22\x0a      \
 empopacity=\x220.3\
0196078\x22\x0a       \
color=\x22#0099e5\x22\x0a\
       opacity=\x22\
0.14901961\x22\x0a    \
   empspacing=\x225\
\x22\x0a       enabled\
=\x22true\x22\x0a       v\
isible=\x22true\x22 />\
\x0a  </sodipodi:na\
medview>\x0a  <g\x0a  \
   id=\x22Layer_1\x22\x0a\
     transform=\x22\
matrix(0.8571416\
6,0,0,0.85714168\
,-1.9999999,-2)\x22\
\x0a     style=\x22fil\
l:#000000;fill-o\
pacity:1;stroke:\
none;stroke-opac\
ity:1\x22>\x0a    <g\x0a \
      transform=\
\x22scale(1.5555577\
)\x22\x0a       id=\x22g1\
\x22\x0a       style=\x22\
fill:#000000;fil\
l-opacity:1;stro\
ke:none;stroke-o\
pacity:1\x22>\x0a     \
 <polygon\x0a      \
   points=\x223,19 \
5,21 12,14 19,21\
 21,19 14,12 21,\
5 19,3 12,10 5,3\
 3,5 10,12 \x22\x0a   \
      class=\x22dx_\
gray\x22\x0a         i\
d=\x22polygon1\x22\x0a   \
      style=\x22fil\
l:#000000;fill-o\
pacity:1;stroke:\
none;stroke-opac\
ity:1;stroke-wid\
th:0.75;stroke-d\
asharray:none;st\
roke-linecap:rou\
nd;paint-order:s\
troke fill marke\
rs;vector-effect\
:non-scaling-str\
oke;-inkscape-st\
roke:hairline\x22\x0a \
        inkscape\
:label=\x22polygon1\
\x22 />\x0a    </g>\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x03p\
\x00\
\x00\x12Kx\xda\xedX\xcdn\xe36\x10\xbe/\xd0w\
\x18\xb0\x87\xec\x026\xcd\x7fJA\xb4\x0bD@N\xea\
\xadE\x8e\x85\xd6Vl\xa1\x8e\x1c\xc8j\x9c\xf4\xd5z\
\xe8#\xed+\xecP\xa4$:\xbb.Z\xa4\x87\xa0\xb0\
\xe3\x90\x9cO\x9c\x19i\xe6\xd3p\x92/\x7f\xfeu\xf5\
\xe9\xe9~\x0b\x8fU\xbb\xafwMv\xc1)\xbb\x80\xaa\
Y\xeeVu\xb3\xce.~\xf9\xf9f\x9e\x5c|\xfa\xf8\
\xc3\xbb\xab\xfd\xe3\x1a\x1e\xeb\xeap\xbd{\xca\xc8\x5c\xc0\
\x5cQ\xc9\xac\x06)\xf0K\x00\xad4\xfb\x8cl\xba\xee\
\xe1r\xb18\x1c\x0e\xf4 \xe9\xae]/\x04cl\x81\
\xca\x04\xd0\x0a\xc0\xd5\x1a\xeaUF\x8a\xf2\xb9j\x7f\xe5\
\x04\xba\xb6l\xf6w\xbb\xf6>#\xfdr[v\xd5{\
6\x83\xb9\xe8\xcd\x7f \xb0\xef\x9e\xb7UF\xaa\xa6\xfc\
\xbc\xad\xe6\x9f\xcb\xe5o\xebv\xf7{\xb3\xbal\xaa\x03\
0\xfc\xd1\x5c\xb8_\xd2\xdb\xef=DF\xef\xcb\xae\xad\
\x9f\xde3\x9aX\x95\xce\x80\xf9o$}\x18\xf4Nh\
r\xca\x950\x83f,E\x9a'\xbd2\xad\xec\xe4u\
\x92\x8et\x9d\xf6\x91\x88\xc0C\xd9m\x00\x03\xf5\x932\
\x09\x95F\xcd@\x9a\xa4\x98\x84\x94Sae\x1e\x01\x86\
\xb2T\x82\xb2\x02/\x88\x19(\xc6P\xb0\x08\xf2^\xc8\
U\xc2i\xcay\xb8\x92h\x9a\xf0d\xd0\x131\xd0[\
.&\xe0\xc8\xafI\xfe pWo\xb7\x19\xf9\x91\xf5\
\x1f/\xcew\x0f\xe5\xb2\xee\x9e3\x82I]n\xcb=\
\x92\xe1z\x8b\xc9\x22\xb08~\xd4E\xfc\xac\xb14\xad\
\x87\xd58\x9fI\xf3/I#%UZG<\x99\x80\
\xc0\x13i1\xa32\xb0A\x09\xca\x13\x11x\xa2\x904\
l`\x90f4ei\xc4\x93\x09\x08<\x19\x01\xc7\x93\
\xde\x8dz)\xf8\xadg\xe2\xbc}\xe2\xc84\xa1ZE\
\xc4\x89\x80@\x1c&0\xab\x03q\x98\x1d\xabM\xae\xb8\
p\x14\x09W\xb8\xa6i\x1a\x13g\x02\x02qF\x00\xb9\
\xe2\xdd\xa8\x97\xc2\x998o\x9c8m\xb5\xec\x00\x1b\x02\
!\x8c\xab\x02\x040\x1dR)j\x85%p\xa8W\xdd\
&#:q\xc5\x85\xc0\xa6\xaa\xd7\x9b\x0e\xd3\xc5\x8d;\
L\x08\xb4\xa8\x88\xc9l\x9f\xfb\xe9\x9c\xe27\x91\xe2\xb1\
\x14\xe0\x83\xf4\xafc\xee\x17VQ\x05\x9a\x19j\xfb>\
\xc0\xa6\xd4H\x83\x00\x0b\x8d\x81\x07\x0a\xce\xdd4\xca\xb9\
\xa6\x22\x12\x9dGo\x89\xf9W\x1d'-]\x9f\x91\xe3\
\x0a\x0f\x1e\xc5\x13\x08*\xfeL\x82\xc1\xa0\x17\x0b\xefP\
\x0er\xee\xefh\x941\xfc\xdcW\x95\xc1\xd8 {7\
\xc5(\xbf\xb6\x939\x93\xec\x15$\x1b\xca\x86Tc\xd5\
\xf0\xad\xeaX4BK2U\x0da\xac#\xc2\x89\xaa\
q\xd3\x7fN'\xf0vSw\xd59\x81\xff}\x95\x90\
\xa9\x0e\xef\xa7I\xfb\x17,T\xf7\x11\xc89\xbeq\xfd\
i\x1e\x00\xe0\xcce\xd2:\x00;\x00\x1e\xcb\xdcq \
\x9f\x00m\xf0\xfc\xc7\x1d\xa3\x09-\x9cq\x98\x9cx\xa0\
\xf0\xb7aG \xc7\x1e\x04\xdb\x94\x09\xc0\xa6D\x0d*\
\xce\xa8\x88\x80\xe06\x02\xdc}q\xf06\xa6g\x83\x97\
\x0f\xfbV\x0a\x88q\x896\xa9\xf8G\xf4\xf3\x7f\xb0\xff\
=\xf9\xf4\xc4\x01\xfd=\xda\xb9[\xba\xad\x9b\xd5\xeep\
\xc4\xa9\x89\x15\x8ez\xacp\x93\xce\xdd\xa8\xa8\x06\x91:\
c\x0ag\x1c\x0bW\xb2s\x11\x90\xb0\x01w\x17b\xd4\
\xe4\xec\xdb\xf8\x9e\x0a\xe7\xff-\x80\x22\xe9\xc3\xe0&a\
\x0a5\x8c\x0e\x1aFa\xf3~t\x81sN\x04\xf2\xd3\
\x8d\x85\x8b\xafHr\x1fn\x87\xb2\xb0\xcd/Bl\x0b\
\xef\xe2\xf5!\xber\xff\xdd\xf9\xf8\x15\x0bPN~\
\x00\x00\x01_\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -2)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
Send\x22>\x0d\x0a      <p\
olygon points=\x222\
,20 8,22.4 24,10\
 12,24 12,30 16.\
3,25.7 22,28 30,\
2  \x22 fill=\x22#0000\
00\x22 class=\x22Black\
\x22 />\x0d\x0a    </g>\x0d\x0a\
  </g>\x0d\x0a</svg>\
\x00\x00\x07\x92\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg width\
=\x22800px\x22 height=\
\x22800px\x22 viewBox=\
\x220 0 24 24\x22 fill\
=\x22none\x22 xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a<pat\
h d=\x22M2.23177 10\
.3862C1.82042 8.\
65816 3.13073 6.\
99933 4.90701 6.\
99933H19.0915C20\
.8685 6.99933 22\
.1789 8.65932 21\
.7664 10.3877L20\
.6921 14.889C20.\
3966 16.1271 19.\
2901 17.0007 18.\
0172 17.0007H5.9\
7854C4.70507 17.\
0007 3.5982 16.1\
263 3.30329 14.8\
875L2.23177 10.3\
862ZM7.00003 11.\
5C7.41424 11.5 7\
.75003 11.1642 7\
.75003 10.75C7.7\
5003 10.3358 7.4\
1424 10 7.00003 \
10C6.58582 10 6.\
25003 10.3358 6.\
25003 10.75C6.25\
003 11.1642 6.58\
582 11.5 7.00003\
 11.5ZM10.25 10.\
75C10.25 10.3358\
 9.91424 10 9.50\
003 10C9.08582 1\
0 8.75003 10.335\
8 8.75003 10.75C\
8.75003 11.1642 \
9.08582 11.5 9.5\
0003 11.5C9.9142\
4 11.5 10.25 11.\
1642 10.25 10.75\
ZM8.25003 14C8.6\
6424 14 9.00003 \
13.6642 9.00003 \
13.25C9.00003 12\
.8358 8.66424 12\
.5 8.25003 12.5C\
7.83582 12.5 7.5\
0003 12.8358 7.5\
0003 13.25C7.500\
03 13.6642 7.835\
82 14 8.25003 14\
ZM11.5 13.25C11.\
5 12.8358 11.164\
2 12.5 10.75 12.\
5C10.3358 12.5 1\
0 12.8358 10 13.\
25C10 13.6642 10\
.3358 14 10.75 1\
4C11.1642 14 11.\
5 13.6642 11.5 1\
3.25ZM13.25 14C1\
3.6642 14 14 13.\
6642 14 13.25C14\
 12.8358 13.6642\
 12.5 13.25 12.5\
C12.8358 12.5 12\
.5 12.8358 12.5 \
13.25C12.5 13.66\
42 12.8358 14 13\
.25 14ZM16.5 13.\
25C16.5 12.8358 \
16.1642 12.5 15.\
75 12.5C15.3358 \
12.5 15 12.8358 \
15 13.25C15 13.6\
642 15.3358 14 1\
5.75 14C16.1642 \
14 16.5 13.6642 \
16.5 13.25ZM12 1\
1.5C12.4142 11.5\
 12.75 11.1642 1\
2.75 10.75C12.75\
 10.3358 12.4142\
 10 12 10C11.585\
8 10 11.25 10.33\
58 11.25 10.75C1\
1.25 11.1642 11.\
5858 11.5 12 11.\
5ZM15.25 10.75C1\
5.25 10.3358 14.\
9142 10 14.5 10C\
14.0858 10 13.75\
 10.3358 13.75 1\
0.75C13.75 11.16\
42 14.0858 11.5 \
14.5 11.5C14.914\
2 11.5 15.25 11.\
1642 15.25 10.75\
ZM17 11.5C17.414\
2 11.5 17.75 11.\
1642 17.75 10.75\
C17.75 10.3358 1\
7.4142 10 17 10C\
16.5858 10 16.25\
 10.3358 16.25 1\
0.75C16.25 11.16\
42 16.5858 11.5 \
17 11.5Z\x22 fill=\x22\
#212121\x22/>\x0a</svg\
>\
\x00\x00\x07\x02\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x2224\x22\x0a   heig\
ht=\x2224\x22\x0a   viewB\
ox=\x220 0 24 24\x22\x0a \
  fill=\x22none\x22\x0a  \
 stroke=\x22current\
Color\x22\x0a   stroke\
-width=\x222\x22\x0a   st\
roke-linecap=\x22ro\
und\x22\x0a   stroke-l\
inejoin=\x22round\x22\x0a\
   version=\x221.1\x22\
\x0a   id=\x22svg6\x22\x0a  \
 sodipodi:docnam\
e=\x22flip-horizont\
al-2.svg\x22\x0a   ink\
scape:export-fil\
ename=\x22flip-hori\
zontal-2.png\x22\x0a  \
 inkscape:export\
-xdpi=\x22128\x22\x0a   i\
nkscape:export-y\
dpi=\x22128\x22\x0a   ink\
scape:version=\x221\
.4 (86a8ad7, 202\
4-10-11)\x22\x0a   xml\
ns:inkscape=\x22htt\
p://www.inkscape\
.org/namespaces/\
inkscape\x22\x0a   xml\
ns:sodipodi=\x22htt\
p://sodipodi.sou\
rceforge.net/DTD\
/sodipodi-0.dtd\x22\
\x0a   xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
>\x0a  <defs\x0a     i\
d=\x22defs6\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     id=\x22name\
dview6\x22\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#000000\x22\x0a    \
 borderopacity=\x22\
0.25\x22\x0a     inksc\
ape:showpageshad\
ow=\x222\x22\x0a     inks\
cape:pageopacity\
=\x220.0\x22\x0a     inks\
cape:pagechecker\
board=\x220\x22\x0a     i\
nkscape:deskcolo\
r=\x22#d1d1d1\x22\x0a    \
 inkscape:zoom=\x22\
32.416667\x22\x0a     \
inkscape:cx=\x2211.\
984576\x22\x0a     ink\
scape:cy=\x2212\x22\x0a  \
   inkscape:wind\
ow-width=\x221920\x22\x0a\
     inkscape:wi\
ndow-height=\x22996\
\x22\x0a     inkscape:\
window-x=\x22-9\x22\x0a  \
   inkscape:wind\
ow-y=\x22-9\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg6\x22 \
/>\x0a  <path\x0a     \
d=\x22m3 7 5 5-5 5V\
7\x22\x0a     style=\x22s\
troke:#000000;st\
roke-opacity:1\x22\x0a\
     id=\x22path1\x22 \
/>\x0a  <path\x0a     \
d=\x22m21 7-5 5 5 5\
V7\x22\x0a     style=\x22\
stroke:#000000;s\
troke-opacity:1\x22\
\x0a     id=\x22path2\x22\
 />\x0a  <path\x0a    \
 d=\x22M12 20v2\x22\x0a  \
   style=\x22stroke\
:#000000;stroke-\
opacity:1\x22\x0a     \
id=\x22path3\x22 />\x0a  \
<path\x0a     d=\x22M1\
2 14v2\x22\x0a     sty\
le=\x22stroke:#0000\
00;stroke-opacit\
y:1\x22\x0a     id=\x22pa\
th4\x22 />\x0a  <path\x0a\
     d=\x22M12 8v2\x22\
\x0a     style=\x22str\
oke:#000000;stro\
ke-opacity:1\x22\x0a  \
   id=\x22path5\x22 />\
\x0a  <path\x0a     d=\
\x22M12 2v2\x22\x0a     s\
tyle=\x22stroke:#00\
0000;stroke-opac\
ity:1\x22\x0a     id=\x22\
path6\x22 />\x0a</svg>\
\x0a\
\x00\x00\x0c{\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2.015 -2\
 32 32\x22\x0a   versi\
on=\x221.1\x22\x0a   id=\x22\
svg5\x22\x0a   sodipod\
i:docname=\x22zoomo\
ut.svg\x22\x0a   inksc\
ape:version=\x221.4\
 (e7c3feb100, 20\
24-10-09)\x22\x0a   xm\
lns:inkscape=\x22ht\
tp://www.inkscap\
e.org/namespaces\
/inkscape\x22\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:svg=\x22http://www\
.w3.org/2000/svg\
\x22>\x0a  <defs\x0a     \
id=\x22defs5\x22 />\x0a  \
<sodipodi:namedv\
iew\x0a     id=\x22nam\
edview5\x22\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0a     bordercol\
or=\x22#000000\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x22false\x22\x0a \
    inkscape:des\
kcolor=\x22#d1d1d1\x22\
\x0a     inkscape:z\
oom=\x2217.25\x22\x0a    \
 inkscape:cx=\x2216\
\x22\x0a     inkscape:\
cy=\x2216\x22\x0a     ink\
scape:window-wid\
th=\x221366\x22\x0a     i\
nkscape:window-h\
eight=\x22761\x22\x0a    \
 inkscape:window\
-x=\x220\x22\x0a     inks\
cape:window-y=\x220\
\x22\x0a     inkscape:\
window-maximized\
=\x221\x22\x0a     inksca\
pe:current-layer\
=\x22svg5\x22 />\x0a  <g\x0a\
     id=\x22Capa_1\x22\
\x0a     transform=\
\x22translate(-0.01\
51003814697264, \
-5.3405761768488\
E-07)\x22\x0a     styl\
e=\x22enable-backgr\
ound:new 0 0 297\
 297\x22>\x0a    <g\x0a  \
     transform=\x22\
matrix(0.0942760\
929465294, 0, 0,\
 0.0942760929465\
294, 0, 0)\x22\x0a    \
   id=\x22g2\x22>\x0a    \
  <g\x0a         id\
=\x22g1\x22>\x0a        <\
path\x0a           \
d=\x22M150.08, 100.\
079C150.078, 100\
.079 150.077, 10\
0.079 150.075, 1\
00.079L70.044, 1\
00.12C64.543, 10\
0.122 60.086, 10\
4.583 60.089, 11\
0.083C60.092, 11\
5.582 64.55, 120\
.038 70.048, 120\
.038C70.05, 120.\
038 70.052, 120.\
038 70.054, 120.\
038L150.085, 119\
.998C155.585, 11\
9.995 160.042, 1\
15.534 160.039, \
110.034C160.036,\
 104.535 155.578\
, 100.079 150.08\
, 100.079z\x22\x0a    \
       fill=\x22#00\
0000\x22\x0a          \
 class=\x22Black\x22\x0a \
          id=\x22pa\
th1\x22 />\x0a      </\
g>\x0a    </g>\x0a  </\
g>\x0a  <g\x0a     id=\
\x22g5\x22\x0a     transf\
orm=\x22translate(-\
0.0151, 0)\x22\x0a    \
 style=\x22enable-b\
ackground:new 0 \
0 297 297\x22>\x0a    \
<g\x0a       transf\
orm=\x22matrix(0.09\
42760929465294, \
0, 0, 0.09427609\
29465294, 0, 0)\x22\
\x0a       id=\x22g4\x22>\
\x0a      <g\x0a      \
   id=\x22g3\x22>\x0a    \
    <path\x0a      \
     d=\x22M288.985\
, 246.75L206.059\
, 163.745C229.42\
8, 121.854 223.3\
47, 67.804 187.8\
14, 32.237C167.0\
48, 11.449 139.4\
36, 0 110.064, 0\
C80.691, 0 53.07\
6, 11.449 32.306\
, 32.237C-10.558\
, 75.151 -10.557\
, 144.967 32.306\
, 187.871C53.076\
, 208.664 80.692\
, 220.114 110.06\
4, 220.114C129.1\
61, 220.114 147.\
51, 215.269 163.\
721, 206.17L246.\
611, 289.139C251\
.674, 294.208 25\
8.426, 297 265.6\
22, 297C272.818,\
 297 279.57, 294\
.208 284.635, 28\
9.139L288.987, 2\
84.784C299.461, \
274.298 299.461,\
 257.236 288.985\
, 246.75zM46.398\
, 173.794C11.289\
, 138.651 11.289\
, 81.465 46.398,\
 46.315C63.404, \
29.294 86.015, 1\
9.918 110.064, 1\
9.918C134.113, 1\
9.918 156.72, 29\
.294 173.723, 46\
.314C208.839, 81\
.463 208.839, 13\
8.65 173.723, 17\
3.794C156.719, 1\
90.818 134.113, \
200.194 110.064,\
 200.194C86.015,\
 200.195 63.404,\
 190.819 46.398,\
 173.794zM274.89\
4, 270.704L270.5\
41, 275.06C269.2\
4, 276.363 267.4\
93, 277.081 265.\
621, 277.081C263\
.75, 277.081 262\
.004, 276.363 26\
0.702, 275.061L1\
80.382, 194.666C\
182.944, 192.525\
 185.427, 190.26\
3 187.814, 187.8\
72C190.207, 185.\
478 192.459, 182\
.995 194.585, 18\
0.441L274.895, 2\
60.827C277.567, \
263.506 277.568,\
 268.027 274.894\
, 270.704z\x22\x0a    \
       fill=\x22#00\
0000\x22\x0a          \
 class=\x22Black\x22\x0a \
          id=\x22pa\
th2\x22 />\x0a      </\
g>\x0a    </g>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x07\x8f\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   he\
ight=\x2232\x22\x0a   vie\
wBox=\x220 0 32 32\x22\
\x0a   width=\x2232\x22\x0a \
  version=\x221.1\x22\x0a\
   id=\x22svg2\x22\x0a   \
sodipodi:docname\
=\x22invert-colors.\
svg\x22\x0a   inkscape\
:version=\x221.4 (e\
7c3feb100, 2024-\
10-09)\x22\x0a   xmlns\
:inkscape=\x22http:\
//www.inkscape.o\
rg/namespaces/in\
kscape\x22\x0a   xmlns\
:sodipodi=\x22http:\
//sodipodi.sourc\
eforge.net/DTD/s\
odipodi-0.dtd\x22\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0a   xmlns:sv\
g=\x22http://www.w3\
.org/2000/svg\x22>\x0a\
  <defs\x0a     id=\
\x22defs2\x22 />\x0a  <so\
dipodi:namedview\
\x0a     id=\x22namedv\
iew2\x22\x0a     pagec\
olor=\x22#ffffff\x22\x0a \
    bordercolor=\
\x22#000000\x22\x0a     b\
orderopacity=\x220.\
25\x22\x0a     inkscap\
e:showpageshadow\
=\x222\x22\x0a     inksca\
pe:pageopacity=\x22\
0.0\x22\x0a     inksca\
pe:pagecheckerbo\
ard=\x22true\x22\x0a     \
inkscape:deskcol\
or=\x22#d1d1d1\x22\x0a   \
  showgrid=\x22true\
\x22\x0a     inkscape:\
zoom=\x2215.291667\x22\
\x0a     inkscape:c\
x=\x223.3678474\x22\x0a  \
   inkscape:cy=\x22\
9.253406\x22\x0a     i\
nkscape:window-w\
idth=\x221920\x22\x0a    \
 inkscape:window\
-height=\x22969\x22\x0a  \
   inkscape:wind\
ow-x=\x220\x22\x0a     in\
kscape:window-y=\
\x220\x22\x0a     inkscap\
e:window-maximiz\
ed=\x221\x22\x0a     inks\
cape:current-lay\
er=\x22svg2\x22>\x0a    <\
inkscape:grid\x0a  \
     id=\x22grid2\x22\x0a\
       units=\x22px\
\x22\x0a       originx\
=\x220\x22\x0a       orig\
iny=\x220\x22\x0a       s\
pacingx=\x221\x22\x0a    \
   spacingy=\x221\x22\x0a\
       empcolor=\
\x22#0099e5\x22\x0a      \
 empopacity=\x220.3\
0196078\x22\x0a       \
color=\x22#0099e5\x22\x0a\
       opacity=\x22\
0.14901961\x22\x0a    \
   empspacing=\x225\
\x22\x0a       enabled\
=\x22true\x22\x0a       v\
isible=\x22true\x22 />\
\x0a  </sodipodi:na\
medview>\x0a  <path\
\x0a     d=\x22M 32,0 \
H 0 v 32 h 32 z\x22\
\x0a     fill=\x22none\
\x22\x0a     id=\x22path1\
\x22\x0a     style=\x22st\
roke-width:1.333\
33\x22 />\x0a  <path\x0a \
    d=\x22M 23.5466\
67,10.573333 16,\
3.0266667 8.4533\
333,10.573333 c \
-4.16,4.16 -4.16\
,10.92 0,15.08 2\
.0799997,2.08 4.\
8133337,3.12 7.5\
466667,3.12 2.73\
3333,0 5.466667,\
-1.04 7.546667,-\
3.12 4.16,-4.16 \
4.16,-10.92 0,-1\
5.08 z M 16,26.1\
2 c -2.133333,0 \
-4.146667,-0.826\
667 -5.653333,-2\
.346667 C 8.8266\
667,22.253333 8,\
20.253333 8,18.1\
2 8,15.986667 8.\
8266667,13.97333\
3 10.346667,12.4\
66667 L 16,6.8 Z\
\x22\x0a     id=\x22path2\
\x22\x0a     style=\x22st\
roke-width:1.333\
33\x22 />\x0a</svg>\x0a\
\x00\x00\x06\xb2\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   width=\x22\
32\x22\x0a   height=\x223\
2\x22\x0a   viewBox=\x220\
 0 32 32\x22\x0a   ver\
sion=\x221.1\x22\x0a   id\
=\x22svg1\x22\x0a   inksc\
ape:version=\x221.4\
 (86a8ad7, 2024-\
10-11)\x22\x0a   sodip\
odi:docname=\x22squ\
are.svg\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0a\
   xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22\x0a   xmlns:s\
vg=\x22http://www.w\
3.org/2000/svg\x22>\
\x0a  <sodipodi:nam\
edview\x0a     id=\x22\
namedview1\x22\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#000000\x22\x0a\
     borderopaci\
ty=\x220.25\x22\x0a     i\
nkscape:showpage\
shadow=\x222\x22\x0a     \
inkscape:pageopa\
city=\x220.0\x22\x0a     \
inkscape:pageche\
ckerboard=\x220\x22\x0a  \
   inkscape:desk\
color=\x22#d1d1d1\x22\x0a\
     inkscape:do\
cument-units=\x22px\
\x22\x0a     showgrid=\
\x22true\x22\x0a     inks\
cape:zoom=\x2223.78\
125\x22\x0a     inksca\
pe:cx=\x2216\x22\x0a     \
inkscape:cy=\x2215.\
978975\x22\x0a     ink\
scape:window-wid\
th=\x221920\x22\x0a     i\
nkscape:window-h\
eight=\x22996\x22\x0a    \
 inkscape:window\
-x=\x22-9\x22\x0a     ink\
scape:window-y=\x22\
-9\x22\x0a     inkscap\
e:window-maximiz\
ed=\x221\x22\x0a     inks\
cape:current-lay\
er=\x22layer1\x22>\x0a   \
 <inkscape:grid\x0a\
       id=\x22grid1\
\x22\x0a       units=\x22\
px\x22\x0a       origi\
nx=\x220\x22\x0a       or\
iginy=\x220\x22\x0a      \
 spacingx=\x221\x22\x0a  \
     spacingy=\x221\
\x22\x0a       empcolo\
r=\x22#0099e5\x22\x0a    \
   empopacity=\x220\
.30196078\x22\x0a     \
  color=\x22#0099e5\
\x22\x0a       opacity\
=\x220.14901961\x22\x0a  \
     empspacing=\
\x225\x22\x0a       enabl\
ed=\x22true\x22\x0a      \
 visible=\x22true\x22 \
/>\x0a  </sodipodi:\
namedview>\x0a  <de\
fs\x0a     id=\x22defs\
1\x22 />\x0a  <g\x0a     \
inkscape:label=\x22\
Layer 1\x22\x0a     in\
kscape:groupmode\
=\x22layer\x22\x0a     id\
=\x22layer1\x22>\x0a    <\
path\x0a       d=\x22M\
 5,5 V 27 H 27 V\
 5 Z M 8,8 H 24 \
V 24 H 8 Z\x22\x0a    \
   style=\x22fill:#\
000000;fill-opac\
ity:1\x22\x0a       id\
=\x22path2\x22\x0a       \
sodipodi:nodetyp\
es=\x22cccccccccc\x22 \
/>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x07\x22\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   id\
=\x22mdi-serial-por\
t\x22\x0a   viewBox=\x220\
 0 32 32\x22\x0a   ver\
sion=\x221.1\x22\x0a   so\
dipodi:docname=\x22\
Pictogrammers-Ma\
terial-Serial-po\
rt.svg\x22\x0a   width\
=\x2232\x22\x0a   height=\
\x2232\x22\x0a   inkscape\
:version=\x221.4 (e\
7c3feb100, 2024-\
10-09)\x22\x0a   xmlns\
:inkscape=\x22http:\
//www.inkscape.o\
rg/namespaces/in\
kscape\x22\x0a   xmlns\
:sodipodi=\x22http:\
//sodipodi.sourc\
eforge.net/DTD/s\
odipodi-0.dtd\x22\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0a   xmlns:sv\
g=\x22http://www.w3\
.org/2000/svg\x22>\x0a\
  <defs\x0a     id=\
\x22defs1\x22 />\x0a  <so\
dipodi:namedview\
\x0a     id=\x22namedv\
iew1\x22\x0a     pagec\
olor=\x22#ffffff\x22\x0a \
    bordercolor=\
\x22#000000\x22\x0a     b\
orderopacity=\x220.\
25\x22\x0a     inkscap\
e:showpageshadow\
=\x222\x22\x0a     inksca\
pe:pageopacity=\x22\
0.0\x22\x0a     inksca\
pe:pagecheckerbo\
ard=\x220\x22\x0a     ink\
scape:deskcolor=\
\x22#d1d1d1\x22\x0a     s\
howgrid=\x22true\x22\x0a \
    inkscape:zoo\
m=\x2215.291667\x22\x0a  \
   inkscape:cx=\x22\
7.2915531\x22\x0a     \
inkscape:cy=\x2214.\
125341\x22\x0a     ink\
scape:window-wid\
th=\x221328\x22\x0a     i\
nkscape:window-h\
eight=\x22942\x22\x0a    \
 inkscape:window\
-x=\x2245\x22\x0a     ink\
scape:window-y=\x22\
45\x22\x0a     inkscap\
e:window-maximiz\
ed=\x220\x22\x0a     inks\
cape:current-lay\
er=\x22mdi-serial-p\
ort\x22>\x0a    <inksc\
ape:grid\x0a       \
id=\x22grid1\x22\x0a     \
  units=\x22px\x22\x0a   \
    originx=\x220\x22\x0a\
       originy=\x22\
0\x22\x0a       spacin\
gx=\x221\x22\x0a       sp\
acingy=\x221\x22\x0a     \
  empcolor=\x22#009\
9e5\x22\x0a       empo\
pacity=\x220.301960\
78\x22\x0a       color\
=\x22#0099e5\x22\x0a     \
  opacity=\x220.149\
01961\x22\x0a       em\
pspacing=\x225\x22\x0a   \
    enabled=\x22tru\
e\x22\x0a       visibl\
e=\x22true\x22 />\x0a  </\
sodipodi:namedvi\
ew>\x0a  <path\x0a    \
 d=\x22m 9.266129,4\
 h 13.467742 v 2\
.6935484 h 2.693\
549 v 4.0403226 \
h -4.040323 v 8.\
080645 H 10.6129\
04 V 10.733871 H\
 6.5725805 V 6.6\
935484 H 9.26612\
9 V 4 m 13.46774\
2,8.080645 h 2.6\
93549 v 6.733871\
 h -2.693549 v -\
6.733871 m -8.08\
0645,8.080645 h \
2.693549 v 9.427\
42 H 14.653226 V\
 20.16129 M 6.57\
25805,12.080645 \
H 9.266129 v 6.7\
33871 H 6.572580\
5 Z\x22\x0a     id=\x22pa\
th1\x22\x0a     style=\
\x22stroke-width:1.\
34677\x22 />\x0a</svg>\
\x0a\
\x00\x00\x01\xb2\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -8.91\
27 32 32\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22 >\x0d\x0a\
  <g transform=\x22\
translate(-1.952\
68128414154, -8.\
74558092651367)\x22\
>\x0d\x0a    <g transf\
orm=\x22matrix(0.06\
53575137257576, \
0, 0, 0.06535751\
37257576, 0, 0)\x22\
>\x0d\x0a      <ellips\
e cx=\x22244.068\x22 c\
y=\x22242.153\x22 rx=\x22\
194.068\x22 ry=\x2288.\
418\x22 fill=\x22rgb(2\
55, 255, 255)\x22 f\
ill-opacity=\x220\x22 \
stroke=\x22#000000\x22\
 stroke-width=\x224\
0px\x22 />\x0d\x0a    </g\
>\x0d\x0a  </g>\x0d\x0a</svg\
>\
\x00\x00\x09<\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2.005 -2\
.005 32 32\x22\x0a   v\
ersion=\x221.1\x22\x0a   \
id=\x22svg2\x22\x0a   sod\
ipodi:docname=\x22d\
ropper.svg\x22\x0a   i\
nkscape:version=\
\x221.4 (86a8ad7, 2\
024-10-11)\x22\x0a   x\
mlns:inkscape=\x22h\
ttp://www.inksca\
pe.org/namespace\
s/inkscape\x22\x0a   x\
mlns:sodipodi=\x22h\
ttp://sodipodi.s\
ourceforge.net/D\
TD/sodipodi-0.dt\
d\x22\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0a   xmln\
s:svg=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a  <defs\x0a    \
 id=\x22defs2\x22 />\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview2\x22\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#000000\x22\x0a  \
   borderopacity\
=\x220.25\x22\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0a     in\
kscape:pageopaci\
ty=\x220.0\x22\x0a     in\
kscape:pagecheck\
erboard=\x220\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   inkscape:zoom\
=\x2225.21875\x22\x0a    \
 inkscape:cx=\x2216\
\x22\x0a     inkscape:\
cy=\x2215.980173\x22\x0a \
    inkscape:win\
dow-width=\x221920\x22\
\x0a     inkscape:w\
indow-height=\x2299\
6\x22\x0a     inkscape\
:window-x=\x22-9\x22\x0a \
    inkscape:win\
dow-y=\x22-9\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
\x0a     showgrid=\x22\
true\x22>\x0a    <inks\
cape:grid\x0a      \
 id=\x22grid1\x22\x0a    \
   units=\x22px\x22\x0a  \
     originx=\x220\x22\
\x0a       originy=\
\x220\x22\x0a       spaci\
ngx=\x221\x22\x0a       s\
pacingy=\x221\x22\x0a    \
   empcolor=\x22#00\
99e5\x22\x0a       emp\
opacity=\x220.30196\
078\x22\x0a       colo\
r=\x22#0099e5\x22\x0a    \
   opacity=\x220.14\
901961\x22\x0a       e\
mpspacing=\x225\x22\x0a  \
     enabled=\x22tr\
ue\x22\x0a       visib\
le=\x22true\x22 />\x0a  <\
/sodipodi:namedv\
iew>\x0a  <g\x0a     t\
ransform=\x22transl\
ate(-0.0054, -0.\
006)\x22\x0a     id=\x22g\
2\x22\x0a     style=\x22f\
ill:#000000;fill\
-opacity:1\x22>\x0a   \
 <g\x0a       trans\
form=\x22matrix(0.0\
546829737722874,\
 0, 0, 0.0546829\
737722874, 0, 0)\
\x22\x0a       id=\x22g1\x22\
\x0a       style=\x22f\
ill:#000000;fill\
-opacity:1\x22>\x0a   \
   <path\x0a       \
  d=\x22M341.6, 29.\
2L240.1, 130.8L2\
30.7, 121.4C218.\
2, 108.9 197.9, \
108.9 185.4, 121\
.4C172.9, 133.9 \
172.9, 154.2 185\
.4, 166.7L345.4,\
 326.7C357.9, 33\
9.2 378.2, 339.2\
 390.7, 326.7C40\
3.2, 314.2 403.2\
, 293.9 390.7, 2\
81.4L381.3, 272L\
482.8, 170.4C521\
.8, 131.4 521.8,\
 68.2 482.8, 29.\
3C443.8, -9.6 38\
0.6, -9.7 341.7,\
 29.3zM55.4, 323\
.3C40.4, 338.3 3\
2, 358.7 32, 379\
.9L32, 422.3L5.4\
, 462.2C-3.1, 47\
4.9 -1.4, 491.8 \
9.4, 502.6C20.2,\
 513.4 37.1, 515\
.1 49.8, 506.6L8\
9.7, 480L132.1, \
480C153.3, 480 1\
73.7, 471.6 188.\
7, 456.6L309.4, \
335.9L264.1, 290\
.6L143.4, 411.3C\
140.4, 414.3 136\
.3, 416 132.1, 4\
16L96, 416L96, 3\
79.9C96, 375.7 9\
7.7, 371.6 100.7\
, 368.6L221.4, 2\
47.9L176.1, 202.\
6L55.4, 323.3z\x22\x0a\
         id=\x22pat\
h1\x22\x0a         sty\
le=\x22fill:#000000\
;fill-opacity:1\x22\
 />\x0a    </g>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x07\xf6\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   he\
ight=\x2232\x22\x0a   vie\
wBox=\x220 0 32 32\x22\
\x0a   width=\x2232\x22\x0a \
  version=\x221.1\x22\x0a\
   id=\x22svg1\x22\x0a   \
sodipodi:docname\
=\x22selection-drag\
.svg\x22\x0a   inkscap\
e:version=\x221.4 (\
e7c3feb100, 2024\
-10-09)\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0a\
   xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22\x0a   xmlns:s\
vg=\x22http://www.w\
3.org/2000/svg\x22>\
\x0a  <defs\x0a     id\
=\x22defs1\x22 />\x0a  <s\
odipodi:namedvie\
w\x0a     id=\x22named\
view1\x22\x0a     page\
color=\x22#ffffff\x22\x0a\
     bordercolor\
=\x22#000000\x22\x0a     \
borderopacity=\x220\
.25\x22\x0a     inksca\
pe:showpageshado\
w=\x222\x22\x0a     inksc\
ape:pageopacity=\
\x220.0\x22\x0a     inksc\
ape:pagecheckerb\
oard=\x220\x22\x0a     in\
kscape:deskcolor\
=\x22#d1d1d1\x22\x0a     \
showgrid=\x22true\x22\x0a\
     inkscape:zo\
om=\x2215.291667\x22\x0a \
    inkscape:cx=\
\x22-0.55585831\x22\x0a  \
   inkscape:cy=\x22\
9.6457766\x22\x0a     \
inkscape:window-\
width=\x221920\x22\x0a   \
  inkscape:windo\
w-height=\x22969\x22\x0a \
    inkscape:win\
dow-x=\x220\x22\x0a     i\
nkscape:window-y\
=\x220\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22svg1\x22>\x0a    \
<inkscape:grid\x0a \
      id=\x22grid1\x22\
\x0a       units=\x22p\
x\x22\x0a       origin\
x=\x220\x22\x0a       ori\
giny=\x220\x22\x0a       \
spacingx=\x221\x22\x0a   \
    spacingy=\x221\x22\
\x0a       empcolor\
=\x22#0099e5\x22\x0a     \
  empopacity=\x220.\
30196078\x22\x0a      \
 color=\x22#0099e5\x22\
\x0a       opacity=\
\x220.14901961\x22\x0a   \
    empspacing=\x22\
5\x22\x0a       enable\
d=\x22true\x22\x0a       \
visible=\x22true\x22 /\
>\x0a  </sodipodi:n\
amedview>\x0a  <pat\
h\x0a     d=\x22m 19.6\
54321,22.086421 \
h 4.148148 v -4.\
14815 h 2.765433\
 v 4.14815 h 4.1\
48147 v 2.76543 \
H 26.567902 V 29\
 h -2.765433 v -\
4.148149 h -4.14\
8148 z m -2.7654\
31,0 v 2.76543 h\
 -4.148149 v -2.\
76543 z m -6.913\
5811,0 v 2.76543\
 H 4.4444444 v -\
5.530864 h 2.765\
4323 v 2.765434 \
z M 4.4444444,16\
.555556 v -4.148\
149 h 2.7654323 \
v 4.148149 z m 0\
,-6.9135815 V 4.\
1111104 H 9.9753\
089 V 6.8765427 \
H 7.2098767 V 9.\
6419745 Z M 12.7\
40741,4.1111104 \
h 4.148149 v 2.7\
654323 h -4.1481\
49 z m 8.296296,\
0 h 5.530865 V 9\
.6419745 H 23.80\
2469 V 6.8765427\
 h -2.765432 z m\
 5.530865,8.2962\
966 v 2.765432 h\
 -2.765433 v -2.\
765432 z\x22\x0a     i\
d=\x22path1\x22\x0a     s\
tyle=\x22stroke-wid\
th:1.3827\x22 />\x0a</\
svg>\x0a\
\x00\x00\x06A\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-4 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg1\
\x22\x0a   sodipodi:do\
cname=\x22copy.svg\x22\
\x0a   inkscape:ver\
sion=\x221.4 (86a8a\
d7, 2024-10-11)\x22\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0a   xmlns:sodipo\
di=\x22http://sodip\
odi.sourceforge.\
net/DTD/sodipodi\
-0.dtd\x22\x0a   xmlns\
=\x22http://www.w3.\
org/2000/svg\x22\x0a  \
 xmlns:svg=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a  <defs\
\x0a     id=\x22defs1\x22\
 />\x0a  <sodipodi:\
namedview\x0a     i\
d=\x22namedview1\x22\x0a \
    pagecolor=\x22#\
ffffff\x22\x0a     bor\
dercolor=\x22#00000\
0\x22\x0a     borderop\
acity=\x220.25\x22\x0a   \
  inkscape:showp\
ageshadow=\x222\x22\x0a  \
   inkscape:page\
opacity=\x220.0\x22\x0a  \
   inkscape:page\
checkerboard=\x220\x22\
\x0a     inkscape:d\
eskcolor=\x22#d1d1d\
1\x22\x0a     inkscape\
:zoom=\x2224.3125\x22\x0a\
     inkscape:cx\
=\x2215.979434\x22\x0a   \
  inkscape:cy=\x221\
6\x22\x0a     inkscape\
:window-width=\x221\
920\x22\x0a     inksca\
pe:window-height\
=\x22996\x22\x0a     inks\
cape:window-x=\x22-\
9\x22\x0a     inkscape\
:window-y=\x22-9\x22\x0a \
    inkscape:win\
dow-maximized=\x221\
\x22\x0a     inkscape:\
current-layer=\x22s\
vg1\x22 />\x0a  <g\x0a   \
  id=\x22Layer_1\x22\x0a \
    transform=\x22t\
ranslate(-4, -2)\
\x22\x0a     style=\x22en\
able-background:\
new 0 0 32 32\x22>\x0a\
    <g\x0a       id\
=\x22Copy\x22>\x0a      <\
path\x0a         d=\
\x22M21, 2L11, 2C10\
.5, 2 10, 2.5 10\
, 3L10, 8L5, 8C4\
.5, 8 4, 8.5 4, \
9L4, 29C4, 29.5 \
4.5, 30 5, 30L21\
, 30C21.5, 30 22\
, 29.5 22, 29L22\
, 24L27, 24C27.5\
, 24 28, 23.5 28\
, 23L28, 9L21, 2\
zM20, 28L6, 28L6\
, 10L14, 10L14, \
15C14, 15.5 14.5\
, 16 15, 16L20, \
16L20, 28zM26, 2\
2L22, 22L22, 15L\
15, 8L12, 8L12, \
4L20, 4L20, 9C20\
, 9.5 20.5, 10 2\
1, 10L26, 10L26,\
 22z\x22\x0a         f\
ill=\x22#000000\x22\x0a  \
       class=\x22Bl\
ack\x22\x0a         id\
=\x22path1\x22\x0a       \
  style=\x22fill:#0\
00000;fill-opaci\
ty:1\x22 />\x0a    </g\
>\x0a  </g>\x0a</svg>\x0a\
\
\x00\x00\x03\x86\
\x00\
\x00\x12Qx\xda\xedX\xcdn\xdb8\x10\xbe\x17\xd8w\
\x18\xb0\x874@L\xf3\x9fR\x10\xb5@U\xf4\xa4\xbd\
\xed\xa2\xc7\x85j\xab\xb6PG\x0ed5N\xf6\xd5z\
\xe8#\xf5\x15:\x14)\x89N\xeb\xa2\xc5\xe6\x10,\xec\
8$\xe7\x13gF\x9a\xf98\x9a\xe4\xeb\xe7/W\xaf\
\xee\xae7p[\xb5\xbbz\xdbdg\x9c\xb23\xa8\x9a\
\xc5vY7\xab\xec\xec\xef\xbf\xde\xce\x92\xb3W/\xff\
xv\xb5\xbb]\xc1m]\xed_o\xef22\x130\
ST2\xabA\x0a\xfc\x12@+\xcd.#\xeb\xae\xbb\
\xb9\x9c\xcf\xf7\xfb=\xddK\xbamWs\xc1\x18\x9b\xa3\
2\x01\xb4\x02p\xb5\x82z\x99\x91\xa2\xbc\xaf\xda\x7f8\
\x81\xae-\x9b\xdd\x87m{\x9d\x91~\xb9)\xbb\xea\x05\
\xbb\x80\x99\xe8\xcd\x9f\x13\xd8u\xf7\x9b*#US\xbe\
\xdfT\xb3\xf7\xe5\xe2\xe3\xaa\xdd~j\x96\x97M\xb5\x07\
\x86?\x9a\x0b\xf7Kz\xfb\xbd\x87\xc8\xe8u\xd9\xb5\xf5\
\xdd\x0bF\x13\xab\xd2\x0b`\xfe\x1bI\xe7\x83\xde\x11M\
N\xb9\x12f\xd0\x8c\xa5H\xf3\xa8W\xa6\x95\x9d\xbcN\
\xd2\x81\xae\xd3>\x10\x11\xb8)\xbb5`\xa0\xfeT&\
\xa1\xd2\xa8\x0b\x90&)&!\xe5TX\x99G\x80\xa1\
,\x95\xa0\xac\xc0\x0b\xe2\x02\x14c(X\x04y/\xe4\
*\xe14\xe5<\x5cI4Mx2\xe8\x89\x18\xe8-\
\x17\x13p\xe0\xd7$\xff\x12\xf8Po6\x19y\xce\xfa\
\x8f\x17g\xdb\x9brQw\xf7\x19\xc1\xa4.6\xe5\x0e\
\xc9\xf0z\x83\xc9\x220?|\xd4y\xfc\xac\xb14\xad\
\x87\xd58\x9fH\xf3\x9b\xa4\x91\x92*\xad#\x9eL@\
\xe0\x89\xb4\x98Q\x19\xd8\xa0\x04\xe5\x89\x08<QH\x1a\
60H3\x9a\xb24\xe2\xc9\x04\x04\x9e\x8c\x80\xe3I\
\xefF=\x14\xfc\xd6\x13q\x9e>qd\x9aP\xad\x22\
\xe2D@ \x0e\x13\x98\xd5\x818\xcc\x8e\xd5&W\x5c\
8\x8a\x84+\x5c\xd34\x8d\x893\x01\x818#\x80\x5c\
\xf1n\xd4C\xe1D\x9c'N\x9c\xb6Zt\x80\x0d\x81\
\x10\xc6U\x01\x02\x98\x0e\xa9\x14\xb5\xc2\x12\xd8\xd7\xcbn\
\x9d\x11\x9d\xb8\xe2B`]\xd5\xabu\x87\xe9\xe2\xc6\xbd\
L\x08\xb4\xa8\x88\xc9l\xef\xfb\xe9\x94\xe2'\x91\xe2\xb1\
\x14\xe0\x83\xf4\xc71\xf7\x0b\xab\xa8\x02\xcd\x0c\xb5}\x1f\
`Sj\xa4A\x80\x85\xc6\xc0\x03\x05\xe7n\x1a\xe5\x5c\
S\x11\x89\xce\xa3\xb7\xc4\xfcQ\xc7IK\xd7g\xe4\xb8\
\xc2\x17\x8f\xe2\x09\x04\x15\xffN\x82\xc1\xa0\x17\x0b\xefP\
\x0er\xee\xefh\x941\xfc\xdcW\x95\xc1\xd8 {7\
\xc5(\xffZ'\x13R\xee\xf0\xcbq\xd7\xfc\xc4\xb5\xc7\
\xe1\xdaP=\xa4\x1a\x8b\x87\xefX\xc7\xda\x11:\x93\xa9\
x\x08c\x1d\x1f\x8e\x14\x8f\xb7\xfd\xe7x\xf1x\xb7\xae\
\xbb\xea\x94\xc0\xc7/\x162\xd5\xe1\x98\x9a\xb4?g\xa1\
\xc8\x8f@\xce\xf1\xe0\xf5/\xf5\x00\x00g.\x93\xd6\x01\
\xd8\x08\xf0X\xe6\x8e\x03\xf9\x04h\x83m\x00\xee\x18M\
h\xe1\x8c\xc3\xe4\xc4\x03\x85\xbf\x0d;\x029\xb6\x22\xd8\
\xadL\x00\xf6&jPqFE\x04\x04\xb7\x11\xe0\xee\
\x8b\x83\xb71=\x1b<|\xd8\xff\xd4\x9f<\x22\xff\x8c\
K\xb4I\xc5/\xd1\xcf\xff\xdd\xfes\xf2\xe9\x89\x03\xfa\
G\xb4s\xb7\xf4\xaen\x96\xdb\xfd\x01\xa7&V8\xea\
\xb1\xc2M:w\xa3\xa2\x1aD\xea\x8c)\x9cq,\x5c\
\xe5\xceE@\xc2\x06\xdc]\x88Q\x93\xb3)\xbe\x9c[\
\xfb\xc6F\xe1\xfctp\x9a\xffo\xf1\x13I\x1f\x057\
\x09S\xa8at\xd00\x0a\x9b\xf7\xa3\x8b\x9bs\x22\x90\
\x9en,\x5cxE\x92\xfbh;\x94\x85m~\x11B\
[x\x17\xdf3\xf8\x18a\x8f\x85\xf8\xca\xfd\x8f\xe7\xe5\
7\x1e[O\xb6\
\x00\x00\x03\x0d\
\x00\
\x00\x0aGx\xda\xddV\xddn\x9b0\x18\xbd\xefS \
\xeff\x93\x06\xd8\x84\xfc@C+M\xd5\x9e\xa0\xbb\xeb\
\x8d\x8b\x1d\xf0Bld\x93@\xfa\xf4\xb3\x01\x03i\x92\
n\xd5TMZH\xa4\xf8\x9c\xef\xcf\x9f\xcf\xe7d}\
\xdf\xec\x0a\xe7@\xa5b\x82'\x00y\x108\x94\xa7\x82\
0\x9e%\xe0\xc7\xe3ww\x05\x1cUaNp!8\
M\x00\x17\xe0\xfe\xeef\xad\x0e\xd9\x8d\xe38\x07F\xeb\
o\xa2I\x80\x1b:n\xe8\xc1`\xee\xcc\x02\xfd\x06-\
9FE-\xc0H\x02\xb4c\xd8.\x94\xceQ\xeaO\
LD\xca\xf1N\x87Ns\x9an\xa9\xf4\xb4Ig\xce\
\xb7*\xc5%\x8d'\x81B\xe7\xf3j\x81W\x98,\xbf\
:\x01\x0cB\x17A\x17\xa1/\xa7\xf6\xb4)\x85\xac\xdc\
\x0d+h\x17\xd9\xf3\x9eJ\x9e\xb1Tp\xf5\xd4g\x99\
\x05\x9e\x86.\xfa5\xa4d\x09\x88\x16\x17\xc9\xe3\x94\xd4\
\xbd\xe3*\xb6&\x09\xc8\xab\xaa\x8c}\xbf\xaek\xcf\x82\
\x9e\x90\x99o\xaaP%N\xa9\xf2->\xf1\xb7\x9d\x18\
\xfc-\xe0)\xb1\x97)\xdd\xe8\x10\xd4\xe3\xb4\xf2\x1f\x1e\
\x1f\x06\xd2\x85\x1e\xa9\xc8\x18\xe6${=k\xf3\x06\x10\
B\xdf\xb6\xb3Ov\xc8\xde\xb4\xbc\xd3\xa6kB7\xca\
\xb8tGfV!p\xfc\x96\x1a\x8e\xcd\xec\x89\x98\xf3\
\x1f\x0d\x07\xa8;a\xc7)qFSQ\x08\x99\x80O\
\x9b\xf6\xd5\x13\xcfB\x12*-\x05\xdb\xd7\x09%t\xb7\
XuL\x00\xf4\x82y\xcf\x0cG\xa1rQ\x9b\xd0*\
\xc7D\xd4\x09\x08^\x1b\x18r\x12\x01^\xe2{\x1d<\
\x0b,u\xe9g&\x84\xaa\xad\xad\x8f \xf3\xf4\x16&\
y&\xcdv+\xb9\xa7\xaf\xdd^\x84\xd8\xe9\x82Bo\
\x86\xce\xebN\xf5\xa0\xa0\xb9\x17-\xa3p\x16\x9e\x91\xba\
T\xb4x\x8d\xd6\x8c\xeb-\xba5#U\xae\xf9(\x80\
W,r\xca\xb2\xbc\xd2\xca\x8c\xae\xc50S\x1a]\xe1\
\x8eop;\xdc\xb0\x1d{\xa1z\xc7\xe8\xac\xe8\xbd\x94\
\x94Wn\x81\x8fT\xf6\xc3}\xd7\xda\xac\x07\x1b\xd3\xac\
\xce\xadS\x89Y\xdb\xdd;\xce\x9e\xb3Jk\xb7l\x06\
DH\x961\xde\x8cgb\xa1\xe3\x142\xe3\xa4\xef\xa8\
f,j\xc0\x8eS\x8c\xee\xcaQfQD\xe7Sf\
\xa2\x91\x19D\xd1\x02.W\x03}\xc5k\xe2\x82\xc2\xc8\
8\x9d\xe4\xeaKH\xc0$\x0f\xc7\xcf\x05=\xd5\x8b\xb9\
9\x15\xd3p\x8f\xf6\xc3\xe5\x9fOW\x8bK\x9aV\xbd\
\xfa\xaa\xa3q:h@H\x97n6\xfaK\xcc\x05w\
u\xaf\x0b\x9d\xd8U\x95\x14[z\xab\xef\xbe\x22\xee\x07\
\xab]\xb8}\xe11\xba\xedL\x06\xb6[v\x12\x8b\x91\
\x17X@\x87\xa3\xfa\x00c)\xf6\x9cL\xc1\x9f\x82\xf1\
S\x94`=\x8aR\xe2\xa3)\x85\xde\xba\xf6\xec\xfbj\
\xe2\x1c3i<\xc1xW\x98-Y\x15Xu\xdb9\
\xb6ZF\x81\xd7\x96h;<\xd1\x84\x11,4\xbf7\
\x86^F\xb6\x81\xffi\xa3\xe6\xbfm\xd4\xd8\xa1\xe1\xbb\
\x19\x03\xa4/\x9b\xf9\xdf6\x87D\xe6\xb9\xd6\x9c%5\
\xcf\x074\xa7G\xc7\x8c\x7f\xda\xad\xc5\xfbe5m\xda\
\xa0\xab\xd9|\xf5\xb1\xad\xfb\xe7\xbaZ\xbeCW\xf0\xa2\
\xac\xd6\xe6O\xc3\xdd\xcd/\xfe\xe8\x22\x18\
\x00\x00\x08\xc4\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-3.1665 -\
1.9998 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg8\x22\x0a   s\
odipodi:docname=\
\x22text.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (86a8ad7, 20\
24-10-11)\x22\x0a   xm\
lns:inkscape=\x22ht\
tp://www.inkscap\
e.org/namespaces\
/inkscape\x22\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:svg=\x22http://www\
.w3.org/2000/svg\
\x22>\x0a  <defs\x0a     \
id=\x22defs8\x22 />\x0a  \
<sodipodi:namedv\
iew\x0a     id=\x22nam\
edview8\x22\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0a     bordercol\
or=\x22#000000\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x220\x22\x0a     \
inkscape:deskcol\
or=\x22#d1d1d1\x22\x0a   \
  showgrid=\x22true\
\x22\x0a     inkscape:\
zoom=\x2224.3125\x22\x0a \
    inkscape:cx=\
\x2215.979434\x22\x0a    \
 inkscape:cy=\x2216\
\x22\x0a     inkscape:\
window-width=\x2219\
20\x22\x0a     inkscap\
e:window-height=\
\x22996\x22\x0a     inksc\
ape:window-x=\x22-9\
\x22\x0a     inkscape:\
window-y=\x22-9\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22sv\
g8\x22>\x0a    <inksca\
pe:grid\x0a       i\
d=\x22grid8\x22\x0a      \
 units=\x22px\x22\x0a    \
   originx=\x220\x22\x0a \
      originy=\x220\
\x22\x0a       spacing\
x=\x221\x22\x0a       spa\
cingy=\x221\x22\x0a      \
 empcolor=\x22#0099\
e5\x22\x0a       empop\
acity=\x220.3019607\
8\x22\x0a       color=\
\x22#0099e5\x22\x0a      \
 opacity=\x220.1490\
1961\x22\x0a       emp\
spacing=\x225\x22\x0a    \
   enabled=\x22true\
\x22\x0a       visible\
=\x22true\x22 />\x0a  </s\
odipodi:namedvie\
w>\x0a  <g\x0a     tra\
nsform=\x22matrix(0\
.96643453,0,0,0.\
92591904,-4.8039\
544,-2.3206938)\x22\
\x0a     style=\x22str\
oke:#000000;stro\
ke-opacity:1\x22\x0a  \
   id=\x22g8\x22>\x0a    \
<g\x0a       transf\
orm=\x22scale(2.333\
3)\x22\x0a       id=\x22g\
7\x22\x0a       style=\
\x22stroke:#000000;\
stroke-opacity:1\
\x22>\x0a      <g\x0a    \
     class=\x22Blac\
k\x22\x0a         tran\
sform=\x22translate\
(1.5,-1)\x22\x0a      \
   id=\x22g6\x22\x0a     \
    style=\x22strok\
e:#000000;stroke\
-opacity:1\x22>\x0a   \
     <g\x0a        \
   id=\x22g5\x22\x0a     \
      style=\x22str\
oke:#000000;stro\
ke-opacity:1\x22>\x0a \
         <path\x0a \
            d=\x22M\
 11.643102,14.57\
168 H 9.9015035 \
L 8.5469269,11.2\
93037 H 4.096175\
1 L 2.838354,14.\
57168 H 1 L 5.45\
07518,3 H 7.1923\
503 Z M 8.063149\
5,10.135869 6.32\
1551,4.7357519 4\
.5799525,10.1358\
69 Z\x22\x0a          \
   id=\x22path4\x22\x0a  \
           style\
=\x22fill:#000000;f\
ill-opacity:1;st\
roke:none;stroke\
-width:0;stroke-\
opacity:1;stroke\
-dasharray:none\x22\
\x0a             so\
dipodi:nodetypes\
=\x22ccccccccccccc\x22\
 />\x0a        </g>\
\x0a      </g>\x0a    \
</g>\x0a  </g>\x0a</sv\
g>\x0a\
\x00\x00\x07\x05\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x2224\x22\x0a   heig\
ht=\x2224\x22\x0a   viewB\
ox=\x220 0 24 24\x22\x0a \
  fill=\x22none\x22\x0a  \
 stroke=\x22current\
Color\x22\x0a   stroke\
-width=\x222\x22\x0a   st\
roke-linecap=\x22ro\
und\x22\x0a   stroke-l\
inejoin=\x22round\x22\x0a\
   version=\x221.1\x22\
\x0a   id=\x22svg6\x22\x0a  \
 sodipodi:docnam\
e=\x22flip-vertical\
-2.svg\x22\x0a   inksc\
ape:export-filen\
ame=\x22flip-vertic\
al-2.png\x22\x0a   ink\
scape:export-xdp\
i=\x22128\x22\x0a   inksc\
ape:export-ydpi=\
\x22128\x22\x0a   inkscap\
e:version=\x221.4 (\
86a8ad7, 2024-10\
-11)\x22\x0a   xmlns:i\
nkscape=\x22http://\
www.inkscape.org\
/namespaces/inks\
cape\x22\x0a   xmlns:s\
odipodi=\x22http://\
sodipodi.sourcef\
orge.net/DTD/sod\
ipodi-0.dtd\x22\x0a   \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22\x0a   xmlns:svg=\
\x22http://www.w3.o\
rg/2000/svg\x22>\x0a  \
<defs\x0a     id=\x22d\
efs6\x22 />\x0a  <sodi\
podi:namedview\x0a \
    id=\x22namedvie\
w6\x22\x0a     pagecol\
or=\x22#ffffff\x22\x0a   \
  bordercolor=\x22#\
000000\x22\x0a     bor\
deropacity=\x220.25\
\x22\x0a     inkscape:\
showpageshadow=\x22\
2\x22\x0a     inkscape\
:pageopacity=\x220.\
0\x22\x0a     inkscape\
:pagecheckerboar\
d=\x220\x22\x0a     inksc\
ape:deskcolor=\x22#\
d1d1d1\x22\x0a     ink\
scape:zoom=\x2232.4\
16667\x22\x0a     inks\
cape:cx=\x2211.9845\
76\x22\x0a     inkscap\
e:cy=\x2212\x22\x0a     i\
nkscape:window-w\
idth=\x221920\x22\x0a    \
 inkscape:window\
-height=\x22996\x22\x0a  \
   inkscape:wind\
ow-x=\x22-9\x22\x0a     i\
nkscape:window-y\
=\x22-9\x22\x0a     inksc\
ape:window-maxim\
ized=\x221\x22\x0a     in\
kscape:current-l\
ayer=\x22svg6\x22 />\x0a \
 <path\x0a     d=\x22m\
17 3-5 5-5-5h10\x22\
\x0a     style=\x22str\
oke:#000000;stro\
ke-opacity:1\x22\x0a  \
   id=\x22path1\x22 />\
\x0a  <path\x0a     d=\
\x22m17 21-5-5-5 5h\
10\x22\x0a     style=\x22\
stroke:#000000;s\
troke-opacity:1\x22\
\x0a     id=\x22path2\x22\
 />\x0a  <path\x0a    \
 d=\x22M4 12H2\x22\x0a   \
  style=\x22stroke:\
#000000;stroke-o\
pacity:1\x22\x0a     i\
d=\x22path3\x22 />\x0a  <\
path\x0a     d=\x22M10\
 12H8\x22\x0a     styl\
e=\x22stroke:#00000\
0;stroke-opacity\
:1\x22\x0a     id=\x22pat\
h4\x22 />\x0a  <path\x0a \
    d=\x22M16 12h-2\
\x22\x0a     style=\x22st\
roke:#000000;str\
oke-opacity:1\x22\x0a \
    id=\x22path5\x22 /\
>\x0a  <path\x0a     d\
=\x22M22 12h-2\x22\x0a   \
  style=\x22stroke:\
#000000;stroke-o\
pacity:1\x22\x0a     i\
d=\x22path6\x22 />\x0a</s\
vg>\x0a\
\x00\x00\x069\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -5.400\
9 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg2\x22\x0a   sodipo\
di:docname=\x22rect\
angle.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (86a8ad7, 20\
24-10-11)\x22\x0a   xm\
lns:inkscape=\x22ht\
tp://www.inkscap\
e.org/namespaces\
/inkscape\x22\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:svg=\x22http://www\
.w3.org/2000/svg\
\x22>\x0a  <defs\x0a     \
id=\x22defs2\x22 />\x0a  \
<sodipodi:namedv\
iew\x0a     id=\x22nam\
edview2\x22\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0a     bordercol\
or=\x22#000000\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x220\x22\x0a     \
inkscape:deskcol\
or=\x22#d1d1d1\x22\x0a   \
  inkscape:zoom=\
\x2224.3125\x22\x0a     i\
nkscape:cx=\x2215.9\
79434\x22\x0a     inks\
cape:cy=\x2216\x22\x0a   \
  inkscape:windo\
w-width=\x221920\x22\x0a \
    inkscape:win\
dow-height=\x22996\x22\
\x0a     inkscape:w\
indow-x=\x22-9\x22\x0a   \
  inkscape:windo\
w-y=\x22-9\x22\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22 /\
>\x0a  <g\x0a     tran\
sform=\x22translate\
(-1.504897735023\
5, -4.9878532699\
585)\x22\x0a     id=\x22g\
2\x22\x0a     style=\x22s\
troke:#000000;st\
roke-opacity:1\x22>\
\x0a    <g\x0a       t\
ransform=\x22matrix\
(0.0623481683433\
056, 0, 0, 0.062\
3481683433056, 0\
, 0)\x22\x0a       id=\
\x22g1\x22\x0a       styl\
e=\x22stroke:#00000\
0;stroke-opacity\
:1\x22>\x0a      <rect\
\x0a         x=\x2244.\
137\x22\x0a         y=\
\x22100\x22\x0a         w\
idth=\x22409.091\x22\x0a \
        height=\x22\
300\x22\x0a         rx\
=\x220\x22\x0a         ry\
=\x220\x22\x0a         fi\
ll=\x22rgb(216, 216\
, 216)\x22\x0a        \
 fill-opacity=\x220\
\x22\x0a         strok\
e=\x22#000000\x22\x0a    \
     stroke-widt\
h=\x2240px\x22\x0a       \
  id=\x22rect1\x22\x0a   \
      style=\x22str\
oke:#000000;stro\
ke-opacity:1\x22 />\
\x0a    </g>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x09\x5c\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -6.55 \
32 32\x22\x0a   versio\
n=\x221.1\x22\x0a   id=\x22s\
vg3\x22\x0a   sodipodi\
:docname=\x22undo-g\
ray.svg\x22\x0a   inks\
cape:version=\x221.\
4 (e7c3feb100, 2\
024-10-09)\x22\x0a   x\
mlns:inkscape=\x22h\
ttp://www.inksca\
pe.org/namespace\
s/inkscape\x22\x0a   x\
mlns:sodipodi=\x22h\
ttp://sodipodi.s\
ourceforge.net/D\
TD/sodipodi-0.dt\
d\x22\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0a   xmln\
s:svg=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a  <defs\x0a    \
 id=\x22defs3\x22 />\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview3\x22\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#000000\x22\x0a  \
   borderopacity\
=\x220.25\x22\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0a     in\
kscape:pageopaci\
ty=\x220.0\x22\x0a     in\
kscape:pagecheck\
erboard=\x220\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   inkscape:zoom\
=\x2225.21875\x22\x0a    \
 inkscape:cx=\x2216\
\x22\x0a     inkscape:\
cy=\x2216\x22\x0a     ink\
scape:window-wid\
th=\x221920\x22\x0a     i\
nkscape:window-h\
eight=\x22969\x22\x0a    \
 inkscape:window\
-x=\x220\x22\x0a     inks\
cape:window-y=\x220\
\x22\x0a     inkscape:\
window-maximized\
=\x221\x22\x0a     inksca\
pe:current-layer\
=\x22svg3\x22 />\x0a  <g\x0a\
     transform=\x22\
translate(-11.97\
1, -16.521)\x22\x0a   \
  id=\x22g3\x22\x0a     s\
tyle=\x22fill:#0000\
00;fill-opacity:\
1\x22>\x0a    <g\x0a     \
  transform=\x22mat\
rix(0.2028985321\
52176, 0, 0, 0.2\
02898532152176, \
0, 0)\x22\x0a       id\
=\x22g2\x22\x0a       sty\
le=\x22fill:#000000\
;fill-opacity:1\x22\
>\x0a      <g\x0a     \
    id=\x22g1\x22\x0a    \
     style=\x22fill\
:#000000;fill-op\
acity:1\x22>\x0a      \
  <path\x0a        \
   d=\x22M18.100006\
, 0C21.799988, 0\
.0000002 25.2999\
88, 1.2999886 27\
.899994, 3.59999\
28C30.600006, 5.\
8999971 32, 9.00\
00046 32, 12.299\
993C32, 15.59999\
8 30.600006, 18.\
700005 27.899994\
, 20.999995C27.5\
, 21.399989 26.8\
99994, 21.600001\
 26.399994, 21.6\
00001C25.899994,\
 21.600001 25.29\
9988, 21.399989 \
24.899994, 20.99\
9995C24.100006, \
20.300013 24.100\
006, 19.099999 2\
4.899994, 18.300\
011C26.699982, 1\
6.700005 27.6999\
82, 14.599998 27\
.699982, 12.2999\
93C27.699982, 10\
.000005 26.69998\
2, 7.899998 24.8\
99994, 6.299991C\
23.100006, 4.699\
9992 20.699982, \
3.7999898 18.100\
006, 3.7999898C1\
5.5, 3.7999898 1\
3.100006, 4.6999\
992 11.299988, 6\
.299991C10, 7.39\
99976 9.1000061,\
 8.8999985 8.699\
9817, 10.500006L\
13.299988, 15.09\
9998L0, 15.09999\
8L1.1000061, 2.8\
999954L5.5, 7.29\
99915C6.1999817,\
 5.8999971 7.100\
0061, 4.6999992 \
8.3999939, 3.599\
9928C10.899994, \
1.2999886 14.399\
994, 0.0000002 1\
8.100006, 0z\x22\x0a  \
         fill=\x22#\
000000\x22\x0a        \
   id=\x22path1\x22\x0a  \
         transfo\
rm=\x22rotate(0, 12\
8, 128) translat\
e(59, 81.4249991\
774559) scale(4.\
3125)\x22\x0a         \
  style=\x22fill:#0\
00000;fill-opaci\
ty:1\x22 />\x0a      <\
/g>\x0a    </g>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x02\xd5\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2.0025 \
-2.0025 32 32\x22 x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22 >\x0d\x0a  <g transf\
orm=\x22translate(-\
0.0021, -0.0021)\
\x22>\x0d\x0a    <g trans\
form=\x22matrix(0.0\
546875037252903,\
 0, 0, 0.0546875\
037252903, 0, 0)\
\x22>\x0d\x0a      <path \
d=\x22M128, 32C128,\
 14.3 113.7, 0 9\
6, 0C78.3, 0 64,\
 14.3 64, 32L64,\
 64L32, 64C14.3,\
 64 0, 78.3 0, 9\
6C0, 113.7 14.3,\
 128 32, 128L64,\
 128L64, 384C64,\
 419.3 92.7, 448\
 128, 448L352, 4\
48L352, 384L128,\
 384L128, 32zM38\
4, 480C384, 497.\
7 398.3, 512 416\
, 512C433.7, 512\
 448, 497.7 448,\
 480L448, 448L48\
0, 448C497.7, 44\
8 512, 433.7 512\
, 416C512, 398.3\
 497.7, 384 480,\
 384L448, 384L44\
8, 128C448, 92.7\
 419.3, 64 384, \
64L160, 64L160, \
128L384, 128L384\
, 480z\x22 />\x0d\x0a    \
</g>\x0d\x0a  </g>\x0d\x0a</\
svg>\
\x00\x00\x04\xbd\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -6 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -6)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
VisibilityOff\x22>\x0d\
\x0a      <path d=\x22\
M6, 8L8.4, 10.4C\
4.5, 12.7 2, 16 \
2, 16C2, 16 8, 2\
4 16, 24C17.8, 2\
4 19.4, 23.6 21,\
 23L24, 26L26, 2\
4L8, 6L6, 8zM10.\
9, 12.9L12.4, 14\
.4C12.1, 14.9 12\
, 15.4 12, 16C12\
, 18.2 13.8, 20 \
16, 20C16.6, 20 \
17.1, 19.9 17.6,\
 19.6L19.1, 21.1\
C18.2, 21.7 17.1\
, 22 16, 22C12.7\
, 22 10, 19.3 10\
, 16C10, 14.9 10\
.3, 13.8 10.9, 1\
2.9z\x22 fill=\x22#000\
000\x22 class=\x22Blac\
k\x22 />\x0d\x0a    </g>\x0d\
\x0a  </g>\x0d\x0a  <g id\
=\x22Layer_1\x22 trans\
form=\x22translate(\
-2, -6)\x22 style=\x22\
enable-backgroun\
d:new 0 0 32 32\x22\
>\x0d\x0a    <g id=\x22Vi\
sibilityOff\x22>\x0d\x0a \
     <path d=\x22M1\
6, 12L20, 16C20,\
 13.8 18.2, 12 1\
6, 12z\x22 fill=\x22#0\
00000\x22 class=\x22Bl\
ack\x22 />\x0d\x0a    </g\
>\x0d\x0a  </g>\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -6)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
VisibilityOff\x22>\x0d\
\x0a      <path d=\x22\
M16, 8C14.8, 8 1\
3.6, 8.2 12.5, 8\
.5L14.2, 10.2C14\
.8, 10 15.3, 9.9\
 15.9, 9.9C19.2,\
 9.9 21.9, 12.6 \
21.9, 15.9C21.9,\
 16.5 21.8, 17.1\
 21.6, 17.6L24.7\
, 20.7C28, 18.6 \
30, 16 30, 16C30\
, 16 24, 8 16, 8\
z\x22 fill=\x22#000000\
\x22 class=\x22Black\x22 \
/>\x0d\x0a    </g>\x0d\x0a  \
</g>\x0d\x0a</svg>\
\x00\x00\x05G\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   en\
able-background=\
\x22new 0 0 32 32\x22\x0a\
   viewBox=\x220 0 \
32 32\x22\x0a   versio\
n=\x221.1\x22\x0a   id=\x22s\
vg1\x22\x0a   sodipodi\
:docname=\x22roundr\
ectangle.svg\x22\x0a  \
 inkscape:versio\
n=\x221.4 (86a8ad7,\
 2024-10-11)\x22\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0a  \
 xmlns:sodipodi=\
\x22http://sodipodi\
.sourceforge.net\
/DTD/sodipodi-0.\
dtd\x22\x0a   xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22\x0a   xm\
lns:svg=\x22http://\
www.w3.org/2000/\
svg\x22>\x0a  <defs\x0a  \
   id=\x22defs1\x22 />\
\x0a  <sodipodi:nam\
edview\x0a     id=\x22\
namedview1\x22\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#000000\x22\x0a\
     borderopaci\
ty=\x220.25\x22\x0a     i\
nkscape:showpage\
shadow=\x222\x22\x0a     \
inkscape:pageopa\
city=\x220.0\x22\x0a     \
inkscape:pageche\
ckerboard=\x220\x22\x0a  \
   inkscape:desk\
color=\x22#d1d1d1\x22\x0a\
     inkscape:zo\
om=\x2224.3125\x22\x0a   \
  inkscape:cx=\x221\
5.979434\x22\x0a     i\
nkscape:cy=\x2216\x22\x0a\
     inkscape:wi\
ndow-width=\x221920\
\x22\x0a     inkscape:\
window-height=\x229\
96\x22\x0a     inkscap\
e:window-x=\x22-9\x22\x0a\
     inkscape:wi\
ndow-y=\x22-9\x22\x0a    \
 inkscape:window\
-maximized=\x221\x22\x0a \
    inkscape:cur\
rent-layer=\x22svg1\
\x22 />\x0a  <path\x0a   \
  d=\x22m4 11v10c0 \
2.2 1.8 4 4 4h16\
c2.2 0 4-1.8 4-4\
v-10c0-2.2-1.8-4\
-4-4h-16c-2.2 0-\
4 1.8-4 4z\x22\x0a    \
 fill=\x22none\x22\x0a   \
  stroke=\x22#000\x22\x0a\
     stroke-mite\
rlimit=\x2210\x22\x0a    \
 stroke-width=\x222\
\x22\x0a     id=\x22path1\
\x22\x0a     style=\x22st\
roke:#000000;str\
oke-opacity:1;st\
roke-width:3;str\
oke-dasharray:no\
ne;stroke-lineca\
p:round;paint-or\
der:normal\x22 />\x0a<\
/svg>\x0a\
\x00\x00\x04\x1d\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2.85\
5 32 32\x22 xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22 >\x0d\x0a \
 <g id=\x22Layer_1\x22\
 transform=\x22tran\
slate(0, 0.0196)\
\x22 style=\x22enable-\
background:new 0\
 0 32 32\x22>\x0d\x0a    \
<g transform=\x22ma\
trix(0.875683128\
833771, 0, 0, 0.\
875683128833771,\
 0, 0)\x22>\x0d\x0a      \
<path d=\x22M31.1, \
8.3C30, 7.6 28.6\
, 8.1 28.2, 9.2L\
26.3, 13.3C26.1,\
 13.7 25.7, 13.9\
 25.3, 13.9L25.3\
, 13.9C24.6, 13.\
9 24.1, 13.3 24.\
3, 12.6L26, 4.4C\
26.2, 3.3 25.6, \
2.3 24.5, 2C23.4\
, 1.8 22.4, 2.4 \
22.1, 3.5L20.2, \
11.1C20.1, 11.6 \
19.7, 11.9 19.2,\
 11.9L19.1, 11.9\
C18.5, 11.9 18, \
11.4 18, 10.8L18\
, 2.1C18, 1.1 17\
.3, 0.2 16.4, 0C\
15.1, -0.2 14, 0\
.8 14, 2L14, 10.\
9C14, 11.5 13.5,\
 12 12.9, 12L12.\
8, 12C12.3, 12 1\
1.9, 11.7 11.8, \
11.2L10, 3.6C9.7\
, 2.4 8.4, 1.7 7\
.3, 2.2C6.3, 2.5\
 5.9, 3.6 6.1, 4\
.6L8.6, 15.9C8.8\
, 16.7 7.9, 17.4\
 7.1, 17L3.1, 14\
.4C2.3, 13.9 1.3\
, 14 0.6, 14.7C-\
0.2, 15.5 -0.2, \
16.8 0.6, 17.6L1\
0.9, 28C12.1, 29\
.3 13.9, 30 15.8\
, 30L20, 30C22.9\
, 30 24.7, 28 25\
.9, 25.2L31.8, 1\
0.9C32.2, 10 31.\
9, 8.9 31.1, 8.3\
z\x22 fill=\x22#000000\
\x22 class=\x22Black\x22 \
/>\x0d\x0a    </g>\x0d\x0a  \
</g>\x0d\x0a</svg>\
\x00\x00\x03r\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -2)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
Printer\x22>\x0d\x0a     \
 <g>\x0d\x0a        <p\
olygon points=\x221\
0,4 22,4 22,12 2\
4,12 24,2 8,2 8,\
12 10,12   \x22 fil\
l=\x22#000000\x22 clas\
s=\x22Black\x22 />\x0d\x0a  \
    </g>\x0d\x0a    </\
g>\x0d\x0a  </g>\x0d\x0a  <g\
 id=\x22Layer_1\x22 tr\
ansform=\x22transla\
te(-2, -2.000000\
95367432)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
Printer\x22>\x0d\x0a     \
 <g>\x0d\x0a        <p\
ath d=\x22M28, 10L2\
6, 10L26, 13C26,\
 13.6 25.6, 14 2\
5, 14L7, 14C6.4,\
 14 6, 13.6 6, 1\
3L6, 10L4, 10C2.\
9, 10 2, 10.9 2,\
 12L2, 24C2, 25.\
1 2.9, 26 4, 26L\
8, 26L8, 30L24, \
30L24, 26L28, 26\
C29.1, 26 30, 25\
.1 30, 24L30, 12\
C30, 10.9 29.1, \
10 28, 10zM22, 2\
4L22, 26L22, 28L\
10, 28L10, 26L10\
, 24L10, 20L22, \
20L22, 24z\x22 fill\
=\x22#000000\x22 class\
=\x22Black\x22 />\x0d\x0a   \
   </g>\x0d\x0a    </g\
>\x0d\x0a  </g>\x0d\x0a</svg\
>\
\x00\x00\x04\x83\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-4 -4 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-4, -4)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
Cut\x22>\x0d\x0a      <pa\
th d=\x22M9, 18C6.2\
, 18 4, 20.2 4, \
23C4, 25.8 6.2, \
28 9, 28C11.8, 2\
8 14, 25.8 14, 2\
3C14, 20.2 11.8,\
 18 9, 18zM9, 26\
C7.3, 26 6, 24.7\
 6, 23C6, 21.3 7\
.3, 20 9, 20C10.\
7, 20 12, 21.3 1\
2, 23C12, 24.7 1\
0.7, 26 9, 26z\x22 \
fill=\x22#000000\x22 c\
lass=\x22Black\x22 />\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a  <g id=\x22Laye\
r_1\x22 transform=\x22\
translate(-4, -4\
)\x22 style=\x22enable\
-background:new \
0 0 32 32\x22>\x0d\x0a   \
 <g id=\x22Cut\x22>\x0d\x0a \
     <polygon po\
ints=\x2220.7,14.8 \
26,4 17.4,11.6  \
\x22 fill=\x22#000000\x22\
 class=\x22Black\x22 /\
>\x0d\x0a    </g>\x0d\x0a  <\
/g>\x0d\x0a  <g id=\x22La\
yer_1\x22 transform\
=\x22translate(-4, \
-4)\x22 style=\x22enab\
le-background:ne\
w 0 0 32 32\x22>\x0d\x0a \
   <g id=\x22Cut\x22>\x0d\
\x0a      <path d=\x22\
M23, 18C22.4, 18\
 21.8, 18.1 21.3\
, 18.3L6, 4L13, \
18L16, 18L18.6, \
20.6C18.2, 21.3 \
18, 22.1 18, 23C\
18, 25.8 20.2, 2\
8 23, 28C25.8, 2\
8 28, 25.8 28, 2\
3C28, 20.2 25.8,\
 18 23, 18zM23, \
26C21.3, 26 20, \
24.7 20, 23C20, \
21.3 21.3, 20 23\
, 20C24.7, 20 26\
, 21.3 26, 23C26\
, 24.7 24.7, 26 \
23, 26z\x22 fill=\x22#\
000000\x22 class=\x22B\
lack\x22 />\x0d\x0a    </\
g>\x0d\x0a  </g>\x0d\x0a</sv\
g>\
\x00\x00\x06\xe9\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-1.9999 -\
2.7367 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg2\x22\x0a   s\
odipodi:docname=\
\x22select-rectangl\
e-gray.svg\x22\x0a   i\
nkscape:version=\
\x221.4 (e7c3feb100\
, 2024-10-09)\x22\x0a \
  xmlns:inkscape\
=\x22http://www.ink\
scape.org/namesp\
aces/inkscape\x22\x0a \
  xmlns:sodipodi\
=\x22http://sodipod\
i.sourceforge.ne\
t/DTD/sodipodi-0\
.dtd\x22\x0a   xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns:svg=\x22http:/\
/www.w3.org/2000\
/svg\x22>\x0a  <defs\x0a \
    id=\x22defs2\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     id=\
\x22namedview2\x22\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#000000\x22\
\x0a     borderopac\
ity=\x220.25\x22\x0a     \
inkscape:showpag\
eshadow=\x222\x22\x0a    \
 inkscape:pageop\
acity=\x220.0\x22\x0a    \
 inkscape:pagech\
eckerboard=\x220\x22\x0a \
    inkscape:des\
kcolor=\x22#d1d1d1\x22\
\x0a     inkscape:z\
oom=\x2212.609375\x22\x0a\
     inkscape:cx\
=\x2211.697646\x22\x0a   \
  inkscape:cy=\x221\
8.042131\x22\x0a     i\
nkscape:window-w\
idth=\x221920\x22\x0a    \
 inkscape:window\
-height=\x22969\x22\x0a  \
   inkscape:wind\
ow-x=\x220\x22\x0a     in\
kscape:window-y=\
\x220\x22\x0a     inkscap\
e:window-maximiz\
ed=\x221\x22\x0a     inks\
cape:current-lay\
er=\x22svg2\x22 />\x0a  <\
g\x0a     transform\
=\x22translate(-4.4\
2104959106445, -\
5.89473290176392\
)\x22\x0a     id=\x22g2\x22\x0a\
     style=\x22fill\
:#000000;fill-op\
acity:1;stroke:n\
one;stroke-opaci\
ty:1\x22>\x0a    <g\x0a  \
     transform=\x22\
matrix(1.4736832\
3802948, 0, 0, 1\
.47368323802948,\
 0, 0)\x22\x0a       i\
d=\x22g1\x22\x0a       st\
yle=\x22fill:#00000\
0;fill-opacity:1\
;stroke:none;str\
oke-opacity:1\x22>\x0a\
      <path\x0a    \
     d=\x22M14, 17L\
17, 17L17, 14L19\
, 14L19, 17L22, \
17L22, 19L19, 19\
L19, 22L17, 22L1\
7, 19L14, 19zM12\
, 17L12, 19L9, 1\
9L9, 17zM7, 17L7\
, 19L3, 19L3, 15\
L5, 15L5, 17zM3,\
 13L3, 10L5, 10L\
5, 13zM3, 8L3, 4\
L7, 4L7, 6L5, 6L\
5, 8zM9, 4L12, 4\
L12, 6L9, 6zM15,\
 4L19, 4L19, 8L1\
7, 8L17, 6L15, 6\
zM19, 10L19, 12L\
17, 12L17, 10z\x22\x0a\
         id=\x22pat\
h1\x22\x0a         sty\
le=\x22fill:#000000\
;fill-opacity:1;\
stroke:none;stro\
ke-opacity:1\x22 />\
\x0a    </g>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x0c\xf3\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x2232\x22\x0a   heig\
ht=\x2232\x22\x0a   viewB\
ox=\x220 0 32 32\x22\x0a \
  fill=\x22none\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg2\x22\x0a   s\
odipodi:docname=\
\x22mirror.svg\x22\x0a   \
inkscape:version\
=\x221.4 (86a8ad7, \
2024-10-11)\x22\x0a   \
xmlns:inkscape=\x22\
http://www.inksc\
ape.org/namespac\
es/inkscape\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns=\x22ht\
tp://www.w3.org/\
2000/svg\x22\x0a   xml\
ns:svg=\x22http://w\
ww.w3.org/2000/s\
vg\x22>\x0a  <defs\x0a   \
  id=\x22defs2\x22 />\x0a\
  <sodipodi:name\
dview\x0a     id=\x22n\
amedview2\x22\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#000000\x22\x0a \
    borderopacit\
y=\x220.25\x22\x0a     in\
kscape:showpages\
hadow=\x222\x22\x0a     i\
nkscape:pageopac\
ity=\x220.0\x22\x0a     i\
nkscape:pagechec\
kerboard=\x220\x22\x0a   \
  inkscape:deskc\
olor=\x22#d1d1d1\x22\x0a \
    inkscape:zoo\
m=\x2224.3125\x22\x0a    \
 inkscape:cx=\x2215\
.979434\x22\x0a     in\
kscape:cy=\x2216\x22\x0a \
    inkscape:win\
dow-width=\x221920\x22\
\x0a     inkscape:w\
indow-height=\x2299\
6\x22\x0a     inkscape\
:window-x=\x22-9\x22\x0a \
    inkscape:win\
dow-y=\x22-9\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0a  <path\x0a    \
 d=\x22M16 27.15C19\
.7334 27.15 22.7\
6 22.2834 22.76 \
16.28C22.76 10.2\
767 19.7334 5.41\
003 16 5.41003C1\
2.2665 5.41003 9\
.23995 10.2767 9\
.23995 16.28C9.2\
3995 22.2834 12.\
2665 27.15 16 27\
.15ZM21.76 16.28\
C21.76 19.1252 2\
1.0408 21.6534 1\
9.9308 23.4382C1\
8.8117 25.2377 1\
7.395 26.15 16 2\
6.15C14.6049 26.\
15 13.1882 25.23\
77 12.0691 23.43\
82C11.6735 22.80\
21 11.3276 22.07\
17 11.0462 21.26\
61L20.896 11.132\
2C21.4394 12.622\
3 21.76 14.3805 \
21.76 16.28Z\x22\x0a  \
   fill=\x22#212121\
\x22\x0a     id=\x22path1\
\x22\x0a     style=\x22fi\
ll:#000000;fill-\
opacity:1\x22 />\x0a  \
<path\x0a     d=\x22M1\
5.9999 1C14.1037\
 1 12.3329 1.947\
68 11.2811 3.525\
43L10.2571 5.061\
45C9.96749 5.495\
85 9.56954 5.847\
15 9.10258 6.080\
63L7.52034 6.871\
75C5.10484 8.079\
5 4.0849 10.9871\
 5.21662 13.4392\
L5.8183 14.7428C\
6.18646 15.5405 \
6.18646 16.4595 \
5.8183 17.2572L5\
.21662 18.5608C4\
.0849 21.0129 5.\
10484 23.9205 7.\
52035 25.1283L9.\
10258 25.9194C9.\
56955 26.1529 9.\
96749 26.5042 10\
.2571 26.9386L11\
.2811 28.4746C12\
.3329 30.0523 14\
.1037 31 15.9999\
 31C17.8961 31 1\
9.6669 30.0523 2\
0.7187 28.4746L2\
1.7427 26.9386C2\
2.0323 26.5042 2\
2.4303 26.1529 2\
2.8972 25.9194L2\
4.4795 25.1283C2\
6.895 23.9205 27\
.9149 21.0129 26\
.7832 18.5608L26\
.1815 17.2572C25\
.8133 16.4595 25\
.8133 15.5405 26\
.1815 14.7428L26\
.7832 13.4392C27\
.9149 10.9871 26\
.895 8.0795 24.4\
795 6.87175L22.8\
972 6.08063C22.4\
303 5.84715 22.0\
323 5.49584 21.7\
427 5.06145L20.7\
187 3.52543C19.6\
669 1.94768 17.8\
961 1 15.9999 1Z\
M12.9452 4.63483\
C13.6261 3.61348\
 14.7724 3 15.99\
99 3C17.2274 3 1\
8.3737 3.61348 1\
9.0546 4.63483L2\
0.0786 6.17085C2\
0.5613 6.89484 2\
1.2245 7.48035 2\
2.0028 7.86948L2\
3.585 8.6606C25.\
0343 9.38525 25.\
6463 11.1298 24.\
9673 12.6011L24.\
3656 13.9047C23.\
752 15.2342 23.7\
52 16.7658 24.36\
56 18.0953L24.96\
73 19.3989C25.64\
63 20.8702 25.03\
43 22.6147 23.58\
5 23.3394L22.002\
8 24.1305C21.224\
5 24.5197 20.561\
3 25.1052 20.078\
6 25.8292L19.054\
6 27.3652C18.373\
7 28.3865 17.227\
4 29 15.9999 29C\
14.7724 29 13.62\
61 28.3865 12.94\
52 27.3652L11.92\
12 25.8292C11.43\
85 25.1052 10.77\
53 24.5197 9.997\
01 24.1305L8.414\
77 23.3394C6.965\
47 22.6147 6.353\
5 20.8702 7.0325\
4 19.3989L7.6342\
2 18.0953C8.2478\
2 16.7658 8.2478\
2 15.2342 7.6342\
2 13.9047L7.0325\
4 12.6011C6.3535\
1 11.1298 6.9654\
7 9.38525 8.4147\
7 8.6606L9.99701\
 7.86948C10.7753\
 7.48035 11.4385\
 6.89484 11.9212\
 6.17085L12.9452\
 4.63483Z\x22\x0a     \
fill=\x22#212121\x22\x0a \
    id=\x22path2\x22\x0a \
    style=\x22fill:\
#000000;fill-opa\
city:1\x22 />\x0a</svg\
>\x0a\
\x00\x00\x04\x02\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -2)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
FullScreenExit\x22>\
\x0d\x0a      <polygon\
 points=\x2224,8 24\
,2 20,2 20,12 30\
,12 30,8  \x22 fill\
=\x22#727272\x22 class\
=\x22Black\x22 />\x0d\x0a   \
 </g>\x0d\x0a  </g>\x0d\x0a \
 <g id=\x22Layer_1\x22\
 transform=\x22tran\
slate(-2, -2)\x22 s\
tyle=\x22enable-bac\
kground:new 0 0 \
32 32\x22>\x0d\x0a    <g \
id=\x22FullScreenEx\
it\x22>\x0d\x0a      <pol\
ygon points=\x222,2\
4 8,24 8,30 12,3\
0 12,20 2,20  \x22 \
fill=\x22#727272\x22 c\
lass=\x22Black\x22 />\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a  <g id=\x22Laye\
r_1\x22 transform=\x22\
translate(-2, -2\
)\x22 style=\x22enable\
-background:new \
0 0 32 32\x22>\x0d\x0a   \
 <g id=\x22FullScre\
enExit\x22>\x0d\x0a      \
<polygon points=\
\x228,8 2,8 2,12 12\
,12 12,2 8,2  \x22 \
fill=\x22#727272\x22 c\
lass=\x22Black\x22 />\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a  <g id=\x22Laye\
r_1\x22 transform=\x22\
translate(-2, -2\
)\x22 style=\x22enable\
-background:new \
0 0 32 32\x22>\x0d\x0a   \
 <g id=\x22FullScre\
enExit\x22>\x0d\x0a      \
<polygon points=\
\x2220,30 24,30 24,\
24 30,24 30,20 2\
0,20  \x22 fill=\x22#7\
27272\x22 class=\x22Bl\
ack\x22 />\x0d\x0a    </g\
>\x0d\x0a  </g>\x0d\x0a</svg\
>\
\x00\x00\x08\xb8\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -6.605\
 32 32\x22\x0a   versi\
on=\x221.1\x22\x0a   id=\x22\
svg3\x22\x0a   sodipod\
i:docname=\x22redo-\
gray.svg\x22\x0a   ink\
scape:version=\x221\
.4 (e7c3feb100, \
2024-10-09)\x22\x0a   \
xmlns:inkscape=\x22\
http://www.inksc\
ape.org/namespac\
es/inkscape\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns=\x22ht\
tp://www.w3.org/\
2000/svg\x22\x0a   xml\
ns:svg=\x22http://w\
ww.w3.org/2000/s\
vg\x22>\x0a  <defs\x0a   \
  id=\x22defs3\x22 />\x0a\
  <sodipodi:name\
dview\x0a     id=\x22n\
amedview3\x22\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#000000\x22\x0a \
    borderopacit\
y=\x220.25\x22\x0a     in\
kscape:showpages\
hadow=\x222\x22\x0a     i\
nkscape:pageopac\
ity=\x220.0\x22\x0a     i\
nkscape:pagechec\
kerboard=\x220\x22\x0a   \
  inkscape:deskc\
olor=\x22#d1d1d1\x22\x0a \
    inkscape:zoo\
m=\x2225.21875\x22\x0a   \
  inkscape:cx=\x221\
6\x22\x0a     inkscape\
:cy=\x2216\x22\x0a     in\
kscape:window-wi\
dth=\x221920\x22\x0a     \
inkscape:window-\
height=\x22969\x22\x0a   \
  inkscape:windo\
w-x=\x220\x22\x0a     ink\
scape:window-y=\x22\
0\x22\x0a     inkscape\
:window-maximize\
d=\x221\x22\x0a     inksc\
ape:current-laye\
r=\x22svg3\x22 />\x0a  <g\
\x0a     transform=\
\x22translate(-11.9\
71, -16.5763)\x22\x0a \
    id=\x22g3\x22\x0a    \
 style=\x22fill:#00\
0000;fill-opacit\
y:1\x22>\x0a    <g\x0a   \
    transform=\x22m\
atrix(0.20289853\
2152176, 0, 0, 0\
.202898532152176\
, 0, 0)\x22\x0a       \
id=\x22g2\x22\x0a       s\
tyle=\x22fill:#0000\
00;fill-opacity:\
1\x22>\x0a      <g\x0a   \
      id=\x22g1\x22\x0a  \
       style=\x22fi\
ll:#000000;fill-\
opacity:1\x22>\x0a    \
    <path\x0a      \
     d=\x22M13.8659\
97, 0C17.570007,\
 0.0000001 21.05\
3009, 1.7499998 \
23.67099, 4.9230\
035C24.899994, 6\
.4070119 25.8559\
88, 8.126006 26.\
537994, 9.990995\
3L30.934998, 4.0\
270075L32, 20.67\
3L18.665985, 20.\
673L23.264008, 1\
4.436003C22.8890\
08, 12.231993 21\
.997986, 10.2030\
01 20.653992, 8.\
574004C18.841003\
, 6.376006 16.43\
1, 5.1650079 13.\
865997, 5.165007\
9C11.302002, 5.1\
650079 8.8919983\
, 6.376006 7.080\
9937, 8.574004C5\
.2640076, 10.766\
996 4.2659912, 1\
3.691007 4.26599\
12, 16.798002C4.\
2659912, 18.4389\
91 4.553009, 20.\
019009 5.0830078\
, 21.479L0.55700\
68, 21.479C0.195\
0073, 19.976986 \
0, 18.402004 0, \
16.798002C0, 12.\
311003 1.4440002\
, 8.0899953 4.06\
20117, 4.9230035\
C6.6789856, 1.74\
99998 10.158997,\
 0.0000001 13.86\
5997, 0z\x22\x0a      \
     fill=\x22#0000\
00\x22\x0a           i\
d=\x22path1\x22\x0a      \
     transform=\x22\
rotate(0, 128, 1\
28) translate(59\
, 81.68590605258\
94) scale(4.3125\
)\x22\x0a           st\
yle=\x22fill:#00000\
0;fill-opacity:1\
\x22 />\x0a      </g>\x0a\
    </g>\x0a  </g>\x0a\
</svg>\x0a\
\x00\x00\x09\xe3\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2.0175 \
-2 32 32\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22 >\x0d\x0a\
  <g id=\x22Capa_1\x22\
 transform=\x22tran\
slate(-0.0176003\
814697268, -5.14\
984130894902E-07\
)\x22 style=\x22enable\
-background:new \
0 0 297 297\x22>\x0d\x0a \
   <g transform=\
\x22matrix(0.094276\
0929465294, 0, 0\
, 0.094276092946\
5294, 0, 0)\x22>\x0d\x0a \
     <g>\x0d\x0a      \
  <path d=\x22M150.\
079, 100.075C150\
.077, 100.075 15\
0.075, 100.075 1\
50.073, 100.075L\
120.034, 100.093\
L120.048, 70.048\
C120.051, 64.549\
 115.594, 60.087\
 110.095, 60.085\
C110.093, 60.085\
 110.092, 60.085\
 110.09, 60.085C\
104.592, 60.085 \
100.136, 64.539 \
100.133, 70.038L\
100.118, 100.103\
L70.051, 100.121\
C64.552, 100.124\
 60.095, 104.584\
 60.098, 110.084\
C60.101, 115.584\
 64.559, 120.037\
 70.057, 120.037\
C70.059, 120.037\
 70.061, 120.037\
 70.063, 120.037\
L100.109, 120.01\
9L100.094, 150.0\
69C100.091, 155.\
568 104.548, 160\
.028 110.047, 16\
0.031C110.049, 1\
60.031 110.05, 1\
60.031 110.052, \
160.031C115.55, \
160.031 120.007,\
 155.577 120.01,\
 150.079L120.025\
, 120.009L150.08\
6, 119.991C155.5\
85, 119.988 160.\
04, 115.527 160.\
037, 110.027C160\
.034, 104.529 15\
5.576, 100.075 1\
50.079, 100.075z\
\x22 fill=\x22#000000\x22\
 class=\x22Black\x22 /\
>\x0d\x0a      </g>\x0d\x0a \
   </g>\x0d\x0a  </g>\x0d\
\x0a  <g id=\x22Capa_1\
\x22 transform=\x22tra\
nslate(-0.0176, \
0)\x22 style=\x22enabl\
e-background:new\
 0 0 297 297\x22>\x0d\x0a\
    <g transform\
=\x22matrix(0.09427\
60929465294, 0, \
0, 0.09427609294\
65294, 0, 0)\x22>\x0d\x0a\
      <g>\x0d\x0a     \
   <path d=\x22M288\
.969, 246.75L206\
.053, 163.745C22\
9.421, 121.855 2\
23.342, 67.803 1\
87.811, 32.237C1\
67.048, 11.449 1\
39.438, 0 110.06\
9, 0C80.701, 0 5\
3.091, 11.449 32\
.323, 32.237C-10\
.54, 75.148 -10.\
54, 144.966 32.3\
23, 187.868C53.0\
9, 208.661 80.70\
1, 220.111 110.0\
69, 220.111C129.\
164, 220.111 147\
.51, 215.266 163\
.719, 206.167L24\
6.598, 289.138C2\
51.662, 294.209 \
258.412, 297 265\
.607, 297C272.8,\
 297 279.552, 29\
4.209 284.617, 2\
89.138L288.971, \
284.778C299.443,\
 274.293 299.442\
, 257.232 288.96\
9, 246.75zM46.41\
2, 173.794C11.30\
4, 138.651 11.30\
5, 81.462 46.412\
, 46.311C63.418,\
 29.291 86.024, \
19.916 110.069, \
19.916C134.114, \
19.916 156.719, \
29.291 173.722, \
46.311C208.834, \
81.46 208.834, 1\
38.649 173.72, 1\
73.795C156.719, \
190.819 134.114,\
 200.195 110.069\
, 200.195C86.024\
, 200.195 63.418\
, 190.819 46.412\
, 173.794zM274.8\
79, 270.704L270.\
524, 275.064C269\
.225, 276.366 26\
7.478, 277.084 2\
65.607, 277.084C\
263.737, 277.084\
 261.991, 276.36\
5 260.689, 275.0\
64L180.378, 194.\
664C182.94, 192.\
522 185.424, 190\
.261 187.81, 187\
.87C190.203, 185\
.476 192.453, 18\
2.992 194.578, 1\
80.441L274.879, \
260.825C277.553,\
 263.502 277.553\
, 268.025 274.87\
9, 270.704z\x22 fil\
l=\x22#000000\x22 clas\
s=\x22Black\x22 />\x0d\x0a  \
    </g>\x0d\x0a    </\
g>\x0d\x0a  </g>\x0d\x0a</sv\
g>\
\x00\x00\x0e\xbf\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Uploa\
ded to: SVG Repo\
, www.svgrepo.co\
m, Generator: SV\
G Repo Mixer Too\
ls -->\x0a\x0a<svg\x0a   \
width=\x22800px\x22\x0a  \
 height=\x22800px\x22\x0a\
   viewBox=\x220 0 \
24 24\x22\x0a   fill=\x22\
none\x22\x0a   version\
=\x221.1\x22\x0a   id=\x22sv\
g10\x22\x0a   sodipodi\
:docname=\x22serial\
-port-svgrepo-co\
m.svg\x22\x0a   inksca\
pe:export-filena\
me=\x22serial-port-\
svgrepo-com.png\x22\
\x0a   inkscape:exp\
ort-xdpi=\x223.8399\
999\x22\x0a   inkscape\
:export-ydpi=\x223.\
8399999\x22\x0a   inks\
cape:version=\x221.\
4 (86a8ad7, 2024\
-10-11)\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0a\
   xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22\x0a   xmlns:s\
vg=\x22http://www.w\
3.org/2000/svg\x22>\
\x0a  <defs\x0a     id\
=\x22defs10\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     id=\x22name\
dview10\x22\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0a     bordercol\
or=\x22#000000\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x220\x22\x0a     \
inkscape:deskcol\
or=\x22#d1d1d1\x22\x0a   \
  inkscape:zoom=\
\x220.97875\x22\x0a     i\
nkscape:cx=\x22400\x22\
\x0a     inkscape:c\
y=\x22400\x22\x0a     ink\
scape:window-wid\
th=\x221920\x22\x0a     i\
nkscape:window-h\
eight=\x221001\x22\x0a   \
  inkscape:windo\
w-x=\x22-9\x22\x0a     in\
kscape:window-y=\
\x22-9\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22svg10\x22 />\x0a \
 <path\x0a     d=\x22M\
6.99998 11.5C7.4\
142 11.5 7.74998\
 11.1642 7.74998\
 10.75C7.74998 1\
0.3358 7.4142 10\
 6.99998 10C6.58\
577 10 6.24998 1\
0.3358 6.24998 1\
0.75C6.24998 11.\
1642 6.58577 11.\
5 6.99998 11.5Z\x22\
\x0a     fill=\x22#212\
121\x22\x0a     id=\x22pa\
th1\x22 />\x0a  <path\x0a\
     d=\x22M10.25 1\
0.75C10.25 11.16\
42 9.9142 11.5 9\
.49998 11.5C9.08\
577 11.5 8.74998\
 11.1642 8.74998\
 10.75C8.74998 1\
0.3358 9.08577 1\
0 9.49998 10C9.9\
142 10 10.25 10.\
3358 10.25 10.75\
Z\x22\x0a     fill=\x22#2\
12121\x22\x0a     id=\x22\
path2\x22 />\x0a  <pat\
h\x0a     d=\x22M8.249\
98 14C8.6642 14 \
8.99998 13.6642 \
8.99998 13.25C8.\
99998 12.8358 8.\
6642 12.5 8.2499\
8 12.5C7.83577 1\
2.5 7.49998 12.8\
358 7.49998 13.2\
5C7.49998 13.664\
2 7.83577 14 8.2\
4998 14Z\x22\x0a     f\
ill=\x22#212121\x22\x0a  \
   id=\x22path3\x22 />\
\x0a  <path\x0a     d=\
\x22M11.5 13.25C11.\
5 13.6642 11.164\
2 14 10.75 14C10\
.3358 14 9.99998\
 13.6642 9.99998\
 13.25C9.99998 1\
2.8358 10.3358 1\
2.5 10.75 12.5C1\
1.1642 12.5 11.5\
 12.8358 11.5 13\
.25Z\x22\x0a     fill=\
\x22#212121\x22\x0a     i\
d=\x22path4\x22 />\x0a  <\
path\x0a     d=\x22M13\
.25 14C13.6642 1\
4 14 13.6642 14 \
13.25C14 12.8358\
 13.6642 12.5 13\
.25 12.5C12.8358\
 12.5 12.5 12.83\
58 12.5 13.25C12\
.5 13.6642 12.83\
58 14 13.25 14Z\x22\
\x0a     fill=\x22#212\
121\x22\x0a     id=\x22pa\
th5\x22 />\x0a  <path\x0a\
     d=\x22M16.5 13\
.25C16.5 13.6642\
 16.1642 14 15.7\
5 14C15.3358 14 \
15 13.6642 15 13\
.25C15 12.8358 1\
5.3358 12.5 15.7\
5 12.5C16.1642 1\
2.5 16.5 12.8358\
 16.5 13.25Z\x22\x0a  \
   fill=\x22#212121\
\x22\x0a     id=\x22path6\
\x22 />\x0a  <path\x0a   \
  d=\x22M12 11.5C12\
.4142 11.5 12.75\
 11.1642 12.75 1\
0.75C12.75 10.33\
58 12.4142 10 12\
 10C11.5858 10 1\
1.25 10.3358 11.\
25 10.75C11.25 1\
1.1642 11.5858 1\
1.5 12 11.5Z\x22\x0a  \
   fill=\x22#212121\
\x22\x0a     id=\x22path7\
\x22 />\x0a  <path\x0a   \
  d=\x22M15.25 10.7\
5C15.25 11.1642 \
14.9142 11.5 14.\
5 11.5C14.0858 1\
1.5 13.75 11.164\
2 13.75 10.75C13\
.75 10.3358 14.0\
858 10 14.5 10C1\
4.9142 10 15.25 \
10.3358 15.25 10\
.75Z\x22\x0a     fill=\
\x22#212121\x22\x0a     i\
d=\x22path8\x22 />\x0a  <\
path\x0a     d=\x22M17\
 11.5C17.4142 11\
.5 17.75 11.1642\
 17.75 10.75C17.\
75 10.3358 17.41\
42 10 17 10C16.5\
858 10 16.25 10.\
3358 16.25 10.75\
C16.25 11.1642 1\
6.5858 11.5 17 1\
1.5Z\x22\x0a     fill=\
\x22#212121\x22\x0a     i\
d=\x22path9\x22 />\x0a  <\
path\x0a     d=\x22M4.\
90701 6.99933C3.\
13073 6.99933 1.\
82042 8.65816 2.\
23177 10.3862L3.\
30329 14.8875C3.\
5982 16.1263 4.7\
0507 17.0007 5.9\
7854 17.0007H18.\
0172C19.2901 17.\
0007 20.3966 16.\
1271 20.6921 14.\
889L21.7664 10.3\
877C22.1789 8.65\
932 20.8685 6.99\
933 19.0915 6.99\
933H4.90701ZM3.6\
9099 10.0388C3.5\
0402 9.25334 4.0\
9961 8.49933 4.9\
0701 8.49933H19.\
0915C19.8992 8.4\
9933 20.4949 9.2\
5387 20.3074 10.\
0395L19.2331 14.\
5408C19.0988 15.\
1036 18.5958 15.\
5007 18.0172 15.\
5007H5.97854C5.3\
9969 15.5007 4.8\
9657 15.1032 4.7\
6252 14.5401L3.6\
9099 10.0388Z\x22\x0a \
    fill=\x22#21212\
1\x22\x0a     id=\x22path\
10\x22 />\x0a</svg>\x0a\
\x00\x00\x02\xc1\
<\
?xml version=\x221.\
0\x22 encoding=\x22iso\
-8859-1\x22?>\x0d\x0a<!--\
 Uploaded to: SV\
G Repo, www.svgr\
epo.com, Generat\
or: SVG Repo Mix\
er Tools -->\x0d\x0a<!\
DOCTYPE svg PUBL\
IC \x22-//W3C//DTD \
SVG 1.1//EN\x22 \x22ht\
tp://www.w3.org/\
Graphics/SVG/1.1\
/DTD/svg11.dtd\x22>\
\x0d\x0a<svg fill=\x22#00\
0000\x22 version=\x221\
.1\x22 id=\x22Capa_1\x22 \
xmlns=\x22http://ww\
w.w3.org/2000/sv\
g\x22  \x0d\x0a\x09 width=\x228\
00px\x22 height=\x2280\
0px\x22 viewBox=\x220 \
0 498.78 498.781\
\x22\x0d\x0a\x09 xml:space=\x22\
preserve\x22>\x0d\x0a<g>\x0d\
\x0a\x09<g>\x0d\x0a\x09\x09<polygo\
n points=\x22452.88\
,439.875 45.9,43\
9.875 45.9,367.9\
65 0,367.965 0,4\
85.775 498.78,48\
5.775 498.78,366\
.435 452.88,366.\
435 \x09\x09\x0d\x0a\x09\x09\x09\x22/>\x0d\x0a\
\x09\x09<polygon point\
s=\x22134.086,241.5\
57 134.086,406.2\
15 374.333,406.2\
15 374.333,241.5\
57 438.082,241.5\
57 254.209,13.00\
5 \x0d\x0a\x09\x09\x0970.334,24\
1.557 \x09\x09\x22/>\x0d\x0a\x09</\
g>\x0d\x0a</g>\x0d\x0a</svg>\
\
\x00\x00\x02\xc3\
<\
svg fill=\x22none\x22 \
height=\x2214\x22 view\
Box=\x220 0 14 14\x22 \
width=\x2214\x22 xmlns\
=\x22http://www.w3.\
org/2000/svg\x22 ><\
clipPath id=\x22a\x22>\
<path d=\x22m0 0h14\
v14h-14z\x22/></cli\
pPath><g clip-pa\
th=\x22url(#a)\x22 str\
oke=\x22#000001\x22 st\
roke-linecap=\x22ro\
und\x22 stroke-line\
join=\x22round\x22><pa\
th d=\x22m11.5.5h1c\
.2652 0 .5196.10\
5357.7071.292893\
.1875.187537.292\
9.441887.2929.70\
7107v1\x22/><path d\
=\x22m.5 2.5v-1c0-.\
26522.105357-.51\
957.292893-.7071\
07.187537-.18753\
6.441887-.292893\
.707107-.292893h\
1\x22/><path d=\x22m5.\
5.5h3\x22/><path d=\
\x22m13.5 5.5v3\x22/><\
path d=\x22m.5 5.5v\
3\x22/><path d=\x22m11\
.5 13.5h1c.2652 \
0 .5196-.1054.70\
71-.2929s.2929-.\
4419.2929-.7071v\
-1\x22/><path d=\x22m.\
5 11.5v1c0 .2652\
.105357.5196.292\
893.7071.187537.\
1875.441887.2929\
.707107.2929h1\x22/\
><path d=\x22m5.5 1\
3.5h3\x22/></g></sv\
g>\
\x00\x00\x07?\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2.05\
25 32 32\x22 xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22 >\x0d\x0a\
  <g id=\x22Layer_1\
\x22 transform=\x22tra\
nslate(-3.0107, \
-1.0059)\x22>\x0d\x0a    \
<g transform=\x22ma\
trix(1.003584623\
33679, 0, 0, 1.0\
0358462333679, 0\
, 0)\x22>\x0d\x0a      <g\
>\x0d\x0a        <path\
 d=\x22M27.1, 19.2C\
27.2, 19 27.3, 1\
8.8 27.3, 18.5C2\
7.4, 18.3 27.4, \
18.1 27.5, 18L30\
.9, 17L30.9, 13L\
27.5, 12C27.4, 1\
1.8 27.4, 11.6 2\
7.3, 11.5C27.2, \
11.3 27.2, 11 27\
.1, 10.8C27, 10.\
6 26.9, 10.4 26.\
8, 10.2C26.7, 10\
 26.6, 9.9 26.6,\
 9.7L28.3, 6.6L2\
5.5, 3.8L22.4, 5\
.5C22.2, 5.4 22.\
1, 5.3 21.9, 5.3\
C21.7, 5.2 21.5,\
 5.1 21.3, 5C21.\
1, 4.9 20.9, 4.8\
 20.6, 4.8C20.4,\
 4.7 20.3, 4.7 2\
0.1, 4.6L19, 1L1\
5, 1L14, 4.4C13.\
8, 4.5 13.6, 4.5\
 13.5, 4.6C13.3,\
 4.7 13, 4.7 12.\
8, 4.8C12.6, 4.9\
 12.4, 5 12.2, 5\
.1C12, 5.2 11.9,\
 5.3 11.7, 5.3L8\
.5, 3.7L5.7, 6.5\
L7.4, 9.6C7.3, 9\
.8 7.2, 10 7.2, \
10.2C7.1, 10.4 7\
, 10.6 6.9, 10.8\
C6.8, 11 6.7, 11\
.2 6.7, 11.5C6.6\
, 11.7 6.6, 11.8\
 6.5, 12L3, 13L3\
, 17L6.4, 18C6.5\
, 18.2 6.5, 18.4\
 6.6, 18.5C6.7, \
18.7 6.7, 18.9 6\
.8, 19.2C6.9, 19\
.4 7, 19.6 7.1, \
19.8C7.2, 20 7.3\
, 20.1 7.3, 20.3\
L5.6, 23.4L8.4, \
26.2L11.5, 24.5C\
11.7, 24.6 11.8,\
 24.7 12, 24.7C1\
2.2, 24.8 12.4, \
24.9 12.6, 25C12\
.8, 25.1 13, 25.\
2 13.3, 25.2C13.\
5, 25.3 13.6, 25\
.3 13.8, 25.4L14\
.8, 28.8L18.8, 2\
8.8L19.8, 25.4C2\
0, 25.3 20.2, 25\
.3 20.3, 25.2C20\
.5, 25.1 20.8, 2\
5.1 21, 25C21.2,\
 24.9 21.4, 24.8\
 21.6, 24.7C21.8\
, 24.6 21.9, 24.\
5 22.1, 24.5L25.\
2, 26.2L28, 23.4\
L26.3, 20.3C26.4\
, 20.1 26.5, 20 \
26.5, 19.8C26.9,\
 19.6 27.1, 19.4\
 27.1, 19.2zM17,\
 22C13.1, 22 10,\
 18.9 10, 15C10,\
 11.1 13.1, 8 17\
, 8C20.9, 8 24, \
11.1 24, 15C24, \
18.9 20.9, 22 17\
, 22z\x22 />\x0d\x0a     \
 </g>\x0d\x0a    </g>\x0d\
\x0a  </g>\x0d\x0a  <g id\
=\x22Layer_1\x22 trans\
form=\x22translate(\
-3.0107005722045\
9, -1.0059001525\
8789)\x22>\x0d\x0a    <g \
transform=\x22matri\
x(1.003584623336\
79, 0, 0, 1.0035\
8462333679, 0, 0\
)\x22>\x0d\x0a      <g>\x0d\x0a\
        <circle \
cx=\x2217\x22 cy=\x2215\x22 \
r=\x224\x22 />\x0d\x0a      \
</g>\x0d\x0a    </g>\x0d\x0a\
  </g>\x0d\x0a</svg>\
\x00\x00\x08\x03\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2.037\
5 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg2\x22\x0a   sodipo\
di:docname=\x22zoom\
reset.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (86a8ad7, 20\
24-10-11)\x22\x0a   xm\
lns:inkscape=\x22ht\
tp://www.inkscap\
e.org/namespaces\
/inkscape\x22\x0a   xm\
lns:sodipodi=\x22ht\
tp://sodipodi.so\
urceforge.net/DT\
D/sodipodi-0.dtd\
\x22\x0a   xmlns=\x22http\
://www.w3.org/20\
00/svg\x22\x0a   xmlns\
:svg=\x22http://www\
.w3.org/2000/svg\
\x22>\x0a  <defs\x0a     \
id=\x22defs2\x22 />\x0a  \
<sodipodi:namedv\
iew\x0a     id=\x22nam\
edview2\x22\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0a     bordercol\
or=\x22#000000\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x220\x22\x0a     \
inkscape:deskcol\
or=\x22#d1d1d1\x22\x0a   \
  inkscape:zoom=\
\x2224.3125\x22\x0a     i\
nkscape:cx=\x2215.9\
79434\x22\x0a     inks\
cape:cy=\x2216\x22\x0a   \
  inkscape:windo\
w-width=\x221920\x22\x0a \
    inkscape:win\
dow-height=\x22996\x22\
\x0a     inkscape:w\
indow-x=\x22-9\x22\x0a   \
  inkscape:windo\
w-y=\x22-9\x22\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22 /\
>\x0a  <g\x0a     id=\x22\
Layer_1\x22\x0a     tr\
ansform=\x22transla\
te(-2, -2)\x22\x0a    \
 style=\x22enable-b\
ackground:new 0 \
0 32 32\x22>\x0a    <p\
ath\x0a       d=\x22M2\
9.7, 27.3L22, 19\
.6L21.9, 19.5C23\
.2, 17.7 24, 15.\
4 24, 13C24, 6.9\
 19.1, 2 13, 2C6\
.9, 2 2, 6.9 2, \
13C2, 19.1 6.9, \
24 13, 24C15.4, \
24 17.7, 23.2 19\
.5, 21.9C19.5, 2\
1.9 19.5, 22 19.\
6, 22L27.3, 29.7\
C27.6, 30 28.2, \
30 28.5, 29.7L29\
.7, 28.5C30.1, 2\
8.2 30.1, 27.6 2\
9.7, 27.3zM4, 13\
C4, 8 8, 4 13, 4\
C18, 4 22, 8 22,\
 13C22, 18 18, 2\
2 13, 22C8, 22 4\
, 18 4, 13z\x22\x0a   \
    fill=\x22#00000\
0\x22\x0a       class=\
\x22Black\x22\x0a       i\
d=\x22path1\x22\x0a      \
 style=\x22fill:#00\
0000;fill-opacit\
y:1\x22 />\x0a  </g>\x0a \
 <g\x0a     id=\x22g2\x22\
\x0a     transform=\
\x22translate(4, 3.\
96250009536743)\x22\
\x0a     style=\x22ena\
ble-background:n\
ew 0 0 16 16\x22>\x0a \
   <g\x0a       id=\
\x22Check_2_\x22>\x0a    \
  <path\x0a        \
 d=\x22M 1.9742931,\
7.3830334 3.3161\
954,6.0411311 6,\
8.7249358 11.367\
609,3.3573265 12\
.709512,4.699228\
8 6,11.40874 c 0\
,0 -4.0257069,-4\
.0928017 -4.0257\
069,-4.0257066 z\
\x22\x0a         fill=\
\x22#000000\x22\x0a      \
   class=\x22Black\x22\
\x0a         id=\x22pa\
th2\x22\x0a         st\
yle=\x22stroke-widt\
h:0.670951;fill:\
#000000;fill-opa\
city:1\x22 />\x0a    <\
/g>\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x02O\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-8.4, -8.4)\x22>\x0d\
\x0a    <g transfor\
m=\x22matrix(1.4, 0\
, 0, 1.4, 0, 0)\x22\
>\x0d\x0a      <path d\
=\x22M19.1, 16L25.7\
, 9.4C26.1, 9 26\
.1, 8.4 25.7, 8L\
24, 6.3C23.6, 5.\
9 23, 5.9 22.6, \
6.3L16, 12.9L9.4\
, 6.3C9, 5.9 8.4\
, 5.9 8, 6.3L6.3\
, 8C5.9, 8.4 5.9\
, 9 6.3, 9.4L12.\
9, 16L6.3, 22.6C\
5.9, 23 5.9, 23.\
6 6.3, 24L8, 25.\
7C8.4, 26.1 9, 2\
6.1 9.4, 25.7L16\
, 19.1L22.6, 25.\
7C23, 26.1 23.6,\
 26.1 24, 25.7L2\
5.7, 24C26.1, 23\
.6 26.1, 23 25.7\
, 22.6L19.1, 16z\
\x22 />\x0d\x0a    </g>\x0d\x0a\
  </g>\x0d\x0a</svg>\
\x00\x00\x02p\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!--\x0d\x0a // 1\
6pxls (c) by Pau\
l mackenzie <pau\
l@whatspauldoing\
.com>\x0d\x0a //\x0d\x0a // \
16pxls is licens\
ed under a\x0d\x0a // \
Creative Commons\
 Attribution-Sha\
reAlike 4.0 Inte\
rnational Licens\
e.\x0d\x0a //\x0d\x0a // You\
 should have rec\
eived a copy of \
the license alon\
g with this\x0d\x0a //\
 work. If not, s\
ee <http://creat\
ivecommons.org/l\
icenses/by-sa/4.\
0/>.\x0d\x0a-->\x0d\x0a\x0d\x0a<sv\
g fill=\x22#000000\x22\
 width=\x22800px\x22 h\
eight=\x22800px\x22 vi\
ewBox=\x220 0 16 16\
\x22 xmlns=\x22http://\
www.w3.org/2000/\
svg\x22>\x0d\x0a    <path\
 d=\x22M7 5.222V0h2\
v5.193l1.107-1.1\
07L11.52 5.5 7.9\
86 9.036 4.45 5.\
5l1.414-1.414L7 \
5.222zM16 11v5H0\
v-5h2v3h12v-3h2z\
\x22 fill-rule=\x22eve\
nodd\x22/>\x0d\x0a</svg>\
\x00\x00\x04\x02\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -2)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
FullScreenExit\x22>\
\x0d\x0a      <polygon\
 points=\x2224,8 24\
,2 20,2 20,12 30\
,12 30,8  \x22 fill\
=\x22#000000\x22 class\
=\x22Black\x22 />\x0d\x0a   \
 </g>\x0d\x0a  </g>\x0d\x0a \
 <g id=\x22Layer_1\x22\
 transform=\x22tran\
slate(-2, -2)\x22 s\
tyle=\x22enable-bac\
kground:new 0 0 \
32 32\x22>\x0d\x0a    <g \
id=\x22FullScreenEx\
it\x22>\x0d\x0a      <pol\
ygon points=\x222,2\
4 8,24 8,30 12,3\
0 12,20 2,20  \x22 \
fill=\x22#000000\x22 c\
lass=\x22Black\x22 />\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a  <g id=\x22Laye\
r_1\x22 transform=\x22\
translate(-2, -2\
)\x22 style=\x22enable\
-background:new \
0 0 32 32\x22>\x0d\x0a   \
 <g id=\x22FullScre\
enExit\x22>\x0d\x0a      \
<polygon points=\
\x228,8 2,8 2,12 12\
,12 12,2 8,2  \x22 \
fill=\x22#000000\x22 c\
lass=\x22Black\x22 />\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a  <g id=\x22Laye\
r_1\x22 transform=\x22\
translate(-2, -2\
)\x22 style=\x22enable\
-background:new \
0 0 32 32\x22>\x0d\x0a   \
 <g id=\x22FullScre\
enExit\x22>\x0d\x0a      \
<polygon points=\
\x2220,30 24,30 24,\
24 30,24 30,20 2\
0,20  \x22 fill=\x22#0\
00000\x22 class=\x22Bl\
ack\x22 />\x0d\x0a    </g\
>\x0d\x0a  </g>\x0d\x0a</svg\
>\
\x00\x00\x08\x10\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-3.0775 -\
2 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg3\x22\x0a   sodipo\
di:docname=\x22exit\
-black.svg\x22\x0a   i\
nkscape:version=\
\x221.4 (e7c3feb100\
, 2024-10-09)\x22\x0a \
  xmlns:inkscape\
=\x22http://www.ink\
scape.org/namesp\
aces/inkscape\x22\x0a \
  xmlns:sodipodi\
=\x22http://sodipod\
i.sourceforge.ne\
t/DTD/sodipodi-0\
.dtd\x22\x0a   xmlns=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns:svg=\x22http:/\
/www.w3.org/2000\
/svg\x22>\x0a  <defs\x0a \
    id=\x22defs3\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     id=\
\x22namedview3\x22\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#000000\x22\
\x0a     borderopac\
ity=\x220.25\x22\x0a     \
inkscape:showpag\
eshadow=\x222\x22\x0a    \
 inkscape:pageop\
acity=\x220.0\x22\x0a    \
 inkscape:pagech\
eckerboard=\x220\x22\x0a \
    inkscape:des\
kcolor=\x22#d1d1d1\x22\
\x0a     inkscape:z\
oom=\x2225.21875\x22\x0a \
    inkscape:cx=\
\x2216\x22\x0a     inksca\
pe:cy=\x2216\x22\x0a     \
inkscape:window-\
width=\x221920\x22\x0a   \
  inkscape:windo\
w-height=\x22969\x22\x0a \
    inkscape:win\
dow-x=\x220\x22\x0a     i\
nkscape:window-y\
=\x220\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22svg3\x22 />\x0a  \
<g\x0a     id=\x22Laye\
r_1\x22\x0a     transf\
orm=\x22translate(-\
4.3083, -2.15390\
015258789)\x22\x0a    \
 style=\x22enable-b\
ackground:new 0 \
0 32 32\x22>\x0a    <g\
\x0a       transfor\
m=\x22matrix(1.0769\
225358963, 0, 0,\
 1.0769225358963\
, 0, 0)\x22\x0a       \
id=\x22g1\x22>\x0a      <\
path\x0a         d=\
\x22M20, 4.7L20, 9.\
1C22.4, 10.5 24,\
 13.1 24, 16C24,\
 20.4 20.4, 24 1\
6, 24C11.6, 24 8\
, 20.4 8, 16C8, \
13 9.6, 10.5 12,\
 9.1L12, 4.7C7.3\
, 6.3 4, 10.8 4,\
 16C4, 22.6 9.4,\
 28 16, 28C22.6,\
 28 28, 22.6 28,\
 16C28, 10.8 24.\
7, 6.3 20, 4.7z\x22\
\x0a         fill=\x22\
#000000\x22\x0a       \
  class=\x22Black\x22\x0a\
         id=\x22pat\
h1\x22\x0a         sty\
le=\x22fill:#000000\
;fill-opacity:1\x22\
 />\x0a    </g>\x0a  <\
/g>\x0a  <g\x0a     id\
=\x22g3\x22\x0a     trans\
form=\x22translate(\
-4.3083014495849\
6, -2.1539)\x22\x0a   \
  style=\x22enable-\
background:new 0\
 0 32 32\x22>\x0a    <\
g\x0a       transfo\
rm=\x22matrix(1.076\
9225358963, 0, 0\
, 1.076922535896\
3, 0, 0)\x22\x0a      \
 id=\x22g2\x22>\x0a      \
<path\x0a         d\
=\x22M17, 14L15, 14\
C14.4, 14 14, 13\
.6 14, 13L14, 3C\
14, 2.4 14.4, 2 \
15, 2L17, 2C17.6\
, 2 18, 2.4 18, \
3L18, 13C18, 13.\
6 17.6, 14 17, 1\
4z\x22\x0a         fil\
l=\x22#000000\x22\x0a    \
     class=\x22Blac\
k\x22\x0a         id=\x22\
path2\x22\x0a         \
style=\x22fill:#000\
000\x22 />\x0a    </g>\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x05\xa2\
\x00\
\x00\x1dNx\xda\xedY\xcdn\x1b7\x10\xbe\x17\xe8;\
\x10\xdb\x83\x13 Zs\xf8\xcf\xc0J\x80,\xda\x13s\
k\xcf\x85\xe2(\x8ePE\x0al5N\xf2j=\xf4\
\x91\xfa\x0a\x99\xe1rH\xcah\x80\x02u\x80\xba\x90m\
\xd8;\x229\x1cr\xbf\xf9\xf8\x0d\xfd\xd7\x1f\x7f^<\
\xff\xf8n+>\xac\xafo6\xfb\xdd\xf2\x0cFy&\
\xd6\xbb\xcb\xfd\xeb\xcd\xeejy\xf6\xcb\xcf?-\xc2\xd9\
\xf3g\xdf\x7fwq\xf3\xe1J|\xd8\xaco_\xec?\
.\x87\x85\x1b\xa5\xf1V,\x94\xd0\xf43\x08\xf4\xb2\xbb\
Y\x0eo\x0f\x87\xf7O\xcf\xcfooo\xc7[=\xee\
\xaf\xaf\xce\x95\x94\xf2\x1c\x07\x0f\x02\xbd\x08qq%6\
\xaf\x97CZ}Z_\xff\x0a\x838\x5c\xafv7o\
\xf6\xd7\xef\x96C~\xdc\xae\x0e\xebG\x0b\x83\xee\x9d\x95\
\xd2\x05\xe7\x8c\xb5\xf0D,\xe2\x18\xa3\x0e\x12\x00\x5c\xc4\
\xa9\xe3\x8f\x0bi\x1f\x0f\xe2\xe6\xf0i\xbb^\x0e\xeb\xdd\
\xea\xd5v\xbdx\xb5\xba\xfc\xed\xeaz\xff\xfb\xee\xf5\xd3\
\xdd\xfaVH\xfc6\x12F7\xff\x1er\x049\x86n\
\xdaw\xab\xc3\xf5\xe6\xe3#9\x06o\xa2\x91Q\x83\x8f\
^\xaa\xf0D\xc8\xf9\xe7\xef\x1b\x1e\xb3\xb7\xaf\xf8\x83\x11\
\x8cV\xec\xa4\xb7\xba\x91_\x8dE\xba\xe8[\x00\xcd:\
\x1a{wt\xdb@MS\xda;\x9d\xa9\xfb\x9d\x0f\xf0\
\xa3\xf7\xab\xc3[\x81o\xe4e\xb4\xa3\xf4\x18\xa2\x81\x14\
\xe4\xe8\xe8q\x01c\x98|\xc4\x0d \xc3\x8cJ\x04(\
\x86\x17\xc1\x94N>)\xebG3?O\xca\xc9Q\x95\
.\xca\xa9\xf2Lc\x95\x83y\x06r\x9b\x94\xf1<\xdf\
 \xdel\xb6\xdb\xe5\xf0\x83\xcc_\xb3\xb9\xd8\xbf_]\
n\x0e\x9f\x96\x03\xb6_nW7\x88\xae\x17[|\xbf\
\x838\xbf\xbb\xac\xf3\xe3u\x1d\xdb\xbd\xd5\x9e\xf9\xa9\xfe\
\xfd\xe7\xb841\x06\x15\xb4\x0e\x8e\xd6\x82oGJ\x90\
R9\xc2F\x90\xc1\xc9x\xc2\xe5=\xe2\xd2\x17la\
\xde\xa7\x0e\xa3\x1d~\x92r\x05\x8b\xd8\x07\x01\xe8f\xd0\
\xe1\xb6\x8c\x06QW\xf0\x0b!\x9b\xbe\xb8\x80\x18F\x97\
\xb4\xd4s\xab2nt\x93\x96av\xa4,z\x14\xd4\
\x9a;\xe7\x09\x84\x8az\x0e%\x9b\xc9\x84y\x9elM\
:\xf6]5\x0f\x9c\xfd\xf8n\x92\x84\xf1\xb9\x1a\xc1\xe4\
K\x8aPxA`t\x81cG\xab[z\xf7\xfc\xf9\
\x81%\x0c\x129\x127f\x86\xd1'\x22\xbf\x9f\x84\xa9\
\xd9\xa1$cR\xc2\x84g-\x83\x09\xb1\x89\x00+\xb8\
\x03\xe7;\xc3\x22\xe4S5)}$S<R\xb9\x83\
\xf6lJZQ\x1f[}\xd9\xd1L\xca\xc6\x02GB\
,\x82\xbe\xe0\x1d\xc2l\x96\xd4\x80h\x93\x8a%Q\x95\
\xd1\x98`\xc5\xbd\xb2\x80\xf9\xe48\x83\xd0\x08%-\xd0\
\xc0\x99\xb9\x9b\xc3U\xa9P[\x84\x02[\xd6k%\xa5\
$\x94\xf4Q\x94c\xa9\xdf\x8d#\xe3_\xa6\xcc\xb7?\
Q\x8cv\xd1\xa2\xde\xe9N\x94(\x9d\xf6\x0a?\xf3\x0a\
N\x09r\x8f'\x0a\x18\xcb\xe8\xb2\x09\xf8|\xd0\x01\x8d\
\xa8k\xcb\xc3#\xd9\x08\xd6*\xafM\xc3\x10\x1e1\xda\
\x19\xcc\xdd\xe8\xf5I\x95\xdc+\x86\xbcg\xd8\xd0\x99\x0e\
L\x9b\xc5\xac'>\x1d\xf6\x13\x99E\x1c(\xe2e\x1d\
\x99\x043M#\xcd\xce\x1cf\xfd\x04\xa6*\x10Gm\
V\xb1\x19g\xe6\x9e\xdd \xb3u\xc8%\x07)So\
m\x9d\xa0\xf2)\x8d\x8c\xc0z${\x8d\x95Dq\xc6\
X\xa3\xf1\xc4\xdd\x92g\xcc\xb1\xaaJ\xd8./\xech\
\xd9\x0fP\x88H\x1d\xc0d\x80\x94\x1c9e\xc5\xb7\xa8\
!\xe3\x14\x0bnL\x14\xa1@\xda`\xd1XT\xac!\
\x00\xfb\x22\x1a$\xc9`\x96\x1dZ\xf8\x02\xc0\x05\x22L\
x\xae2#\x95\xa2\x9e\x0bH-Z\x8dj[)\x0a\
\xb6\xabE\xc1N\xa4f\xd8 NgC\xa3Q\x80\x8c\
\x8eQ\xce\xb8\x22g\x16.\x17\xaa\xac\x87r\x06\xb8\x12\
>\x89 \x16D:k\xa0\xa2/L\xce\x1bN\x5c\x13\
\xb3\xc5=I\xe3+#y\x07\xa8\x04\xd1E\x1d\x19E\
\x0aF\x97\xa95\xd5#(\x8b\x8a\xccJ\x81\xeb\x96\x04\
\xb2\x88\x1c\xea2\x01\x97,y8r|\x0d\xc2\x08\x96\
Zy\xd6\xe88 \x11m}\x19\xed\x15=\xb8\xec\xed\
\xb4\x11\xf2\xa2\x0d>Di\xb59e\xf0=fp\xab\
q)\x0d[\x8dK\xd6d\xf8\x14!\x0b\x8f\x1dV\xef\
!\xd7\xca\xdd\xb11)>\xf0l\xae\x07j\x05\x90{\
\xb2\x17\x04\xb0J\x96a\x1e\xd1\xdd\xe4\xb8:\x0f\x94\x88\
\xb5\x8c\xa0\xe2Wp\x8eb5\x83\xe4\x11J\x9b\xd6I\
\xf1\xb9H\xcf\xb5\x9e\xa6\x04\xc784\x17\xd4\x1e\xc3\xe0\
\xca{\xaeR\xf82\x8b\xa6vI\x03\xaf\x80\x12k\xd2\
\xc0\xcb\xc3\xa4!\xa3;\x955@;\xcf\xe9\xd6\xc0\xf3\
\xbd\x00v\x95G\x9bt\xbc\x9f\x9f_\x82\xac\xbc\x98\x02\
/\xd6c\xd96\x85\xd2\x11\x02\xb1\x8e\x8f|M\x81\x1f\
\x0bfJ,iRS\x0b0\x19vN2\x81X)\
\xf0\xa5\x83\x12\xad\x1f]O\x98\xba\x00$AQ\x05\xb0\
%\x8e5\xbe\xb3\x12E\x5c\xb5\x02rW\xd3\x0a.\xaf\
\x87k\xb6\xecHE\xd7]\x98L\xad\xd6\xa3W\x22\xc8\
\xec\xe2\xeb:K\x9a\x88)8K\x8e\xa9V\x9e\x103\
\xedZ~\xf9\xf8\x9a\xcc\xbc\xf1u\xb3\x121\xaa*\xdb\
\xd8m\xe9\xe7\x97_\xb92y\xe8\xd7':*}$\
\xecQ4\x22\x19A\x90V\x9d\xf8\xef>u\xbd\xae\xf7\
\x83:\x81\xd2\xd5\x98\x00X\x07D-\x00*Q\xd1\xad\
bg\xda\xa93\xe8\x8a\xa2\x8dC\x0aj\x1e\xbdOm\
.\x8f2\x5c\xd7\x1b\x15\xecf\xf4\x91\x8bf\xa2\xfbf\
\xe4\xa9\xeb8\x0a\xab\x8b\xfe\xff \xceO8\xfff\xe7\
\xbc\xf3\x1d\xce=t8o\xf7\xd3\x08(w\x0c6\xd7\
\x03\xd1\x1d\x83\xb4\x8e#\x00W\x8f\xde\xa76\x17\xe2\x5c\
yh8o\xb7\xf1\xd9Eg\xa2v\xf7G)\xd6\xc6\
\xc5Y\xbd\xff\x87p~A\xff\xe0|\xf6\x05\xf1\xe6\x84\
\xa8\
\x00\x00\x07v\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -5.112\
5 32 32\x22\x0a   vers\
ion=\x221.1\x22\x0a   id=\
\x22svg2\x22\x0a   sodipo\
di:docname=\x22open\
-gray.svg\x22\x0a   in\
kscape:version=\x22\
1.4 (e7c3feb100,\
 2024-10-09)\x22\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0a  \
 xmlns:sodipodi=\
\x22http://sodipodi\
.sourceforge.net\
/DTD/sodipodi-0.\
dtd\x22\x0a   xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22\x0a   xm\
lns:svg=\x22http://\
www.w3.org/2000/\
svg\x22>\x0a  <defs\x0a  \
   id=\x22defs2\x22 />\
\x0a  <sodipodi:nam\
edview\x0a     id=\x22\
namedview2\x22\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#000000\x22\x0a\
     borderopaci\
ty=\x220.25\x22\x0a     i\
nkscape:showpage\
shadow=\x222\x22\x0a     \
inkscape:pageopa\
city=\x220.0\x22\x0a     \
inkscape:pageche\
ckerboard=\x220\x22\x0a  \
   inkscape:desk\
color=\x22#d1d1d1\x22\x0a\
     inkscape:zo\
om=\x2225.21875\x22\x0a  \
   inkscape:cx=\x22\
16\x22\x0a     inkscap\
e:cy=\x2216\x22\x0a     i\
nkscape:window-w\
idth=\x221920\x22\x0a    \
 inkscape:window\
-height=\x22969\x22\x0a  \
   inkscape:wind\
ow-x=\x220\x22\x0a     in\
kscape:window-y=\
\x220\x22\x0a     inkscap\
e:window-maximiz\
ed=\x221\x22\x0a     inks\
cape:current-lay\
er=\x22svg2\x22 />\x0a  <\
g\x0a     transform\
=\x22translate(0, -\
1.5578)\x22\x0a     id\
=\x22g2\x22\x0a     style\
=\x22fill:#000000;f\
ill-opacity:1\x22>\x0a\
    <g\x0a       tr\
ansform=\x22matrix(\
0.04861427098512\
65, 0, 0, 0.0486\
142709851265, 0,\
 0)\x22\x0a       id=\x22\
g1\x22\x0a       style\
=\x22fill:#000000;f\
ill-opacity:1\x22>\x0a\
      <path\x0a    \
     d=\x22M384, 48\
0L432, 480C443.4\
, 480 453.9, 474\
 459.6, 464.1L57\
1.6, 272.1C577.4\
, 262.2 577.4, 2\
50 571.7, 240C56\
6, 230 555.5, 22\
4 544, 224L144, \
224C132.6, 224 1\
22.1, 230 116.4,\
 239.9L48, 357.1\
L48, 96C48, 87.2\
 55.2, 80 64, 80\
L181.5, 80C185.7\
, 80 189.8, 81.7\
 192.8, 84.7L219\
.3, 111.2C240.3,\
 132.2 268.8, 14\
4 298.5, 144L416\
, 144C424.8, 144\
 432, 151.2 432,\
 160L432, 192L48\
0, 192L480, 160C\
480, 124.7 451.3\
, 96 416, 96L298\
.5, 96C281.5, 96\
 265.2, 89.3 253\
.2, 77.3L226.7, \
50.7C214.7, 38.7\
 198.4, 32 181.4\
, 32L64, 32C28.7\
, 32 0, 60.7 0, \
96L0, 416C0, 451\
.3 28.7, 480 64,\
 480L87.7, 480L3\
84, 480z\x22\x0a      \
   id=\x22path1\x22\x0a  \
       style=\x22fi\
ll:#000000;fill-\
opacity:1\x22 />\x0a  \
  </g>\x0a  </g>\x0a</\
svg>\x0a\
\x00\x00\x07\x05\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   he\
ight=\x2232\x22\x0a   vie\
wBox=\x220 0 32 32\x22\
\x0a   width=\x2232\x22\x0a \
  version=\x221.1\x22\x0a\
   id=\x22svg1\x22\x0a   \
sodipodi:docname\
=\x22pencil.svg\x22\x0a  \
 inkscape:versio\
n=\x221.4 (e7c3feb1\
00, 2024-10-09)\x22\
\x0a   xmlns:inksca\
pe=\x22http://www.i\
nkscape.org/name\
spaces/inkscape\x22\
\x0a   xmlns:sodipo\
di=\x22http://sodip\
odi.sourceforge.\
net/DTD/sodipodi\
-0.dtd\x22\x0a   xmlns\
=\x22http://www.w3.\
org/2000/svg\x22\x0a  \
 xmlns:svg=\x22http\
://www.w3.org/20\
00/svg\x22>\x0a  <defs\
\x0a     id=\x22defs1\x22\
 />\x0a  <sodipodi:\
namedview\x0a     i\
d=\x22namedview1\x22\x0a \
    pagecolor=\x22#\
ffffff\x22\x0a     bor\
dercolor=\x22#00000\
0\x22\x0a     borderop\
acity=\x220.25\x22\x0a   \
  inkscape:showp\
ageshadow=\x222\x22\x0a  \
   inkscape:page\
opacity=\x220.0\x22\x0a  \
   inkscape:page\
checkerboard=\x220\x22\
\x0a     inkscape:d\
eskcolor=\x22#d1d1d\
1\x22\x0a     inkscape\
:zoom=\x2218.536299\
\x22\x0a     inkscape:\
cx=\x2216.966709\x22\x0a \
    inkscape:cy=\
\x2215.564056\x22\x0a    \
 inkscape:window\
-width=\x221920\x22\x0a  \
   inkscape:wind\
ow-height=\x22969\x22\x0a\
     inkscape:wi\
ndow-x=\x220\x22\x0a     \
inkscape:window-\
y=\x220\x22\x0a     inksc\
ape:window-maxim\
ized=\x221\x22\x0a     in\
kscape:current-l\
ayer=\x22svg1\x22\x0a    \
 showgrid=\x22true\x22\
>\x0a    <inkscape:\
grid\x0a       id=\x22\
grid1\x22\x0a       un\
its=\x22px\x22\x0a       \
originx=\x220\x22\x0a    \
   originy=\x220\x22\x0a \
      spacingx=\x22\
1\x22\x0a       spacin\
gy=\x221\x22\x0a       em\
pcolor=\x22#0099e5\x22\
\x0a       empopaci\
ty=\x220.30196078\x22\x0a\
       color=\x22#0\
099e5\x22\x0a       op\
acity=\x220.1490196\
1\x22\x0a       empspa\
cing=\x225\x22\x0a       \
enabled=\x22true\x22\x0a \
      visible=\x22t\
rue\x22 />\x0a  </sodi\
podi:namedview>\x0a\
  <path\x0a     d=\x22\
m 26.117654,8.40\
90916 1.581237,-\
1.549974 C 28.49\
7426,6.0605834 2\
8.528688,5.19952\
38 27.824208,4.4\
793467 L 27.2918\
75,3.9470129 C 2\
6.58733,3.242467\
 25.726202,3.320\
7572 24.927735,4\
.0878952 L 23.34\
6431,5.6535674 Z\
 M 7.6587156,26.\
821003 24.739894\
,9.7555247 22,7 \
4.9032582,24.081\
111 3.4158763,27\
.556813 c -0.140\
8825,0.375753 0.\
2505023,0.814164\
 0.6262555,0.657\
585 z\x22\x0a     id=\x22\
path1\x22\x0a     styl\
e=\x22stroke-width:\
0.668006\x22 />\x0a</s\
vg>\x0a\
\x00\x00\x0d\xe9\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x221em\x22\x0a   hei\
ght=\x221em\x22\x0a   vie\
wBox=\x220 0 32 32\x22\
\x0a   class=\x22bi bi\
-brush\x22\x0a   fill=\
\x22currentColor\x22\x0a \
  version=\x221.1\x22\x0a\
   id=\x22svg1\x22\x0a   \
sodipodi:docname\
=\x22brush.svg\x22\x0a   \
inkscape:version\
=\x221.4 (86a8ad7, \
2024-10-11)\x22\x0a   \
xmlns:inkscape=\x22\
http://www.inksc\
ape.org/namespac\
es/inkscape\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns=\x22ht\
tp://www.w3.org/\
2000/svg\x22\x0a   xml\
ns:svg=\x22http://w\
ww.w3.org/2000/s\
vg\x22>\x0a  <sodipodi\
:namedview\x0a     \
id=\x22namedview1\x22\x0a\
     pagecolor=\x22\
#ffffff\x22\x0a     bo\
rdercolor=\x22#0000\
00\x22\x0a     bordero\
pacity=\x220.25\x22\x0a  \
   inkscape:show\
pageshadow=\x222\x22\x0a \
    inkscape:pag\
eopacity=\x220.0\x22\x0a \
    inkscape:pag\
echeckerboard=\x220\
\x22\x0a     inkscape:\
deskcolor=\x22#d1d1\
d1\x22\x0a     inkscap\
e:zoom=\x2217.19153\
4\x22\x0a     inkscape\
:cx=\x2211.022867\x22\x0a\
     inkscape:cy\
=\x2216.985104\x22\x0a   \
  inkscape:windo\
w-width=\x221920\x22\x0a \
    inkscape:win\
dow-height=\x22996\x22\
\x0a     inkscape:w\
indow-x=\x22-9\x22\x0a   \
  inkscape:windo\
w-y=\x22-9\x22\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0a    \
 inkscape:curren\
t-layer=\x22layer1\x22\
\x0a     showgrid=\x22\
true\x22>\x0a    <inks\
cape:grid\x0a      \
 id=\x22grid1\x22\x0a    \
   units=\x22px\x22\x0a  \
     originx=\x220\x22\
\x0a       originy=\
\x220\x22\x0a       spaci\
ngx=\x221\x22\x0a       s\
pacingy=\x221\x22\x0a    \
   empcolor=\x22#00\
99e5\x22\x0a       emp\
opacity=\x220.30196\
078\x22\x0a       colo\
r=\x22#0099e5\x22\x0a    \
   opacity=\x220.14\
901961\x22\x0a       e\
mpspacing=\x225\x22\x0a  \
     enabled=\x22tr\
ue\x22\x0a       visib\
le=\x22true\x22 />\x0a  <\
/sodipodi:namedv\
iew>\x0a  <defs\x0a   \
  id=\x22defs1\x22>\x0a  \
  <filter\x0a      \
 style=\x22color-in\
terpolation-filt\
ers:sRGB\x22\x0a      \
 id=\x22filter2\x22\x0a  \
     x=\x22-0.05859\
8499\x22\x0a       y=\x22\
-0.074647084\x22\x0a  \
     width=\x221.11\
71181\x22\x0a       he\
ight=\x221.1494136\x22\
>\x0a      <feGauss\
ianBlur\x0a        \
 stdDeviation=\x220\
.032040936\x22\x0a    \
     id=\x22feGauss\
ianBlur2\x22 />\x0a   \
 </filter>\x0a  </d\
efs>\x0a  <g\x0a     i\
nkscape:groupmod\
e=\x22layer\x22\x0a     i\
d=\x22layer1\x22\x0a     \
inkscape:label=\x22\
Layer 1\x22\x0a     tr\
ansform=\x22matrix(\
0.85769537,0,0,0\
.86353624,2.1241\
392,1.9256237)\x22>\
\x0a    <path\x0a     \
  style=\x22display\
:inline;fill:#ca\
5d5d;fill-opacit\
y:1;stroke:#0000\
00;stroke-width:\
1.50321998;strok\
e-dasharray:none\
;stroke-opacity:\
1;paint-order:no\
rmal;filter:url(\
#filter2);stroke\
-linejoin:miter;\
stroke-linecap:r\
ound\x22\x0a       d=\x22\
M 9.9117002,21.4\
29319 C 9.989700\
2,21.083319 9.69\
5,20.016 9.828,1\
9.562 c 0.363,-1\
.233 0.964,-2.80\
8 1.907,-4.02 3.\
879,-4.979 11.49\
4,-11.209 17.316\
,-14.298 0.368,-\
0.195 0.908,-0.0\
82 1.327,0.278 0\
.421,0.361 0.621\
,0.885 0.491,1.2\
86 -2.197,6.806 \
-7.654,15.855 -1\
1.991,20.352 -1.\
217,1.257 -2.679\
247,1.413078 -4.\
408277,2.223973\x22\
\x0a       transfor\
m=\x22matrix(0.9173\
3221,0,0,0.92858\
849,0.0902633,2.\
1896622)\x22\x0a      \
 id=\x22path3\x22 />\x0a \
   <path\x0a       \
style=\x22display:i\
nline;fill:#92b6\
f0;fill-opacity:\
1;stroke:#000000\
;stroke-width:1.\
37732;stroke-lin\
ecap:round;strok\
e-dasharray:none\
;stroke-opacity:\
1;paint-order:no\
rmal;filter:url(\
#filter2)\x22\x0a     \
  d=\x22m 14.174,25\
.656 c -0.440868\
,0.206762 0.0524\
3,1.126067 -0.05\
6,1.796 -0.21657\
,1.338067 -0.961\
573,2.946306 -3.\
168,3.151 C 8.81\
23292,30.801315 \
6.52319,30.54673\
8 4.212,29.887 3\
.7801793,29.7637\
35 3.3523883,29.\
600932 2.926,29.\
417 2.5363642,29\
.248922 2.155944\
7,29.024383 1.81\
6,28.74 1.586923\
2,28.548365 1.39\
96288,28.313692 \
1.268,28.061 1.1\
006255,27.739686\
 1.0516667,27.40\
4166 1.125,27.12\
 1.251667,26.629\
165 1.6914367,26\
.414163 1.986,26\
.307 2.78544,26.\
016162 3.2079624\
,25.544434 3.614\
,24.829 3.770963\
8,24.552431 3.91\
8,24.257 4.085,2\
3.918 l 0.19,-0.\
384 C 4.52,23.04\
 4.808,22.49 5.1\
88,21.906 6.098,\
20.504 7.0344495\
,20.270595 8.248\
4495,20.509595 8\
.5284495,20.5655\
95 13.935,25.573\
 14.174,25.656\x22\x0a\
       transform\
=\x22matrix(0.91733\
221,0,0,0.928588\
49,0.0902633,2.1\
896622)\x22\x0a       \
id=\x22path1\x22\x0a     \
  sodipodi:nodet\
ypes=\x22csssssssss\
ccccc\x22 />\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x03\xf2\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -2)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
FullScreen\x22>\x0d\x0a  \
    <polygon poi\
nts=\x222,12 6,12 6\
,6 12,6 12,2 2,2\
  \x22 fill=\x22#72727\
2\x22 class=\x22Black\x22\
 />\x0d\x0a    </g>\x0d\x0a \
 </g>\x0d\x0a  <g id=\x22\
Layer_1\x22 transfo\
rm=\x22translate(-2\
, -2)\x22 style=\x22en\
able-background:\
new 0 0 32 32\x22>\x0d\
\x0a    <g id=\x22Full\
Screen\x22>\x0d\x0a      \
<polygon points=\
\x226,20 2,20 2,30 \
12,30 12,26 6,26\
  \x22 fill=\x22#72727\
2\x22 class=\x22Black\x22\
 />\x0d\x0a    </g>\x0d\x0a \
 </g>\x0d\x0a  <g id=\x22\
Layer_1\x22 transfo\
rm=\x22translate(-2\
, -2)\x22 style=\x22en\
able-background:\
new 0 0 32 32\x22>\x0d\
\x0a    <g id=\x22Full\
Screen\x22>\x0d\x0a      \
<polygon points=\
\x2220,2 20,6 26,6 \
26,12 30,12 30,2\
  \x22 fill=\x22#72727\
2\x22 class=\x22Black\x22\
 />\x0d\x0a    </g>\x0d\x0a \
 </g>\x0d\x0a  <g id=\x22\
Layer_1\x22 transfo\
rm=\x22translate(-2\
, -2)\x22 style=\x22en\
able-background:\
new 0 0 32 32\x22>\x0d\
\x0a    <g id=\x22Full\
Screen\x22>\x0d\x0a      \
<polygon points=\
\x2226,26 20,26 20,\
30 30,30 30,20 2\
6,20  \x22 fill=\x22#7\
27272\x22 class=\x22Bl\
ack\x22 />\x0d\x0a    </g\
>\x0d\x0a  </g>\x0d\x0a</svg\
>\
\x00\x00\x05k\
\x00\
\x00\x12(x\xda\xcdXKs\x9bH\x10\xbe\xa7*\xff\
a\x8a\x5c\xa2*3\x9a7\x8cl%[[\xa9=\xed\
\xde\xb2\x97\xbd!\x18#\xd6\x88Q\x01\xb6\xa4\xfc\xfa\xed\
\x01\xf1\x12\x92\xd7\x87$\x159\xb2\xa1\xbb\xe9\x99\xfe\xbe\
\xee\xa6'\x0f\x9f\x8f\xbb\x1c\xbd\x98\xb2\xcal\xb1\xf6(\
&\x1e2El\x93\xacH\xd7\xde\xdf_\xff\xf0C\x0f\
UuT$Qn\x0b\xb3\xf6\x0a\xeb}\xfe\xf4\xfe\xdd\
C\xf5\x92\xbe\x7f\x87\x10z\xc9\xcc\xe1w{\x5c{\x04\
\x11$I\xf3\xf5Z\xcd\xe0\x94\xb6\x92,Y{\xf0\x9c\
j\xef*Xd\x0f\xdfUb\xe3\x22\xda\x81\xefm\x9c\
\x19\x0c\x06g\xeb\xe2\xa9\x8a\xa3\xbdY\x8d\x1c\x09\xf41\
TQ\x18%\xc1\x1db\x84\x09\x9f\x12\x9f\xd2\xc5\xc5\x03\
\xe6\xb8\xb7e\xed?f\xb9\x199\xde\x17\xe9u\xbbc\
\xb2\xcf\xd6\x9eV\xd7\xb5\xa7\x89\x16\xd0*\xaaUg\x03\
\x9e\xebz\xbfZ.\x0f\x87\x03\xee\x84\xd8\x96\xe9\xd2\xad\
[\xed\xa3\xd8T\xcbN>v\xd0\xc5\xde;\xe8\x04\xb8\
\xb2\xcfel\x1e\xc1\x87\xc1\x85\xa9\x97_\xbe~\xe9\x95\
>\xc1I\x9d\x8c\xfcL\xd6?\xf0feF\x08Y\xf6\
 \x9e\x97{I\xdfj\xba9\xb6\x96\x15\x98n\xec\xf1\
\xe4\x83\x1e\xc7v\xe7}rF\x0f\x89y\xac\x1a\xeb\x96\
Mw\xab<\xb4l\x95=\xa3.\xfa\xc4e\xc6\xc8\xb4\
\x97\x9d\x91Dh\x1f\xa5&\xb6\xb9-\xd7\xde\x87\xc7\xe6\
\xd3i6\xb6LL\xd9\xe9H\xf3\x99\xea,`\x9b\xd5\
'H;\xccd\xa7\xea\xa9\xab\xb6\xf6\xe0\xbcW\xdb(\
\xb1\x87\xb5W\x97\xcfff\xe4\x0cFn\xc8U\x83x\
k\xe2'SnlT&7\xfc$\xa6z\xea\xb6\x1a\
\xc6\xee\xa73q\xdbHK\x17\xfcc\x94W\xfd\x93y\
\xb41yU\x9fr\xd3\x00\x18=\xe7\xf5\xcci\x9cg\
{\xbf\xb6\xbe\xdb\xc3\xc5\xe3\xcek\x0b\xc2\x8d\x0d}\xb3\
v\xe7\x22\x92\x92P\xa6I8w\x0e\x1cS\xae\xb1V\
\x01\x9d\x83\x17\x03\x1c,`X)\xce\xe6\xcf\x1e\xb2\x02\
 \xf5\x0fYRo\xc1\x8bf\xe4\x96\xc9\xd6d\xe9\xb6\
\x86\xd2\xd1\xea\x96\x09\xec\xc3\xd7\xb7\x94\xa7\xd7\x94\xbb\xe8\
\x98\xed\xb2o\x06\xb0\xa5\xf3\x08\x9e\xcb\xd2\x14\xb5\x9fG\
'\x07R\xd3r\xba\x1c\xdd\xdb\xfc\x94\xda\xa2\xc3\xb2e\
\xa1\xaaK\xfbd\xfc<+\xcc\xbf6+V\xa8\xb4\xcf\
Er\x8fFrp|)n0XA\x1f\xda\x1f;\
\x19\x98\xa4\x9b\x8f\x9a\xdd\xa1\xf6\xbb\xb8G\xd0\x85\xf2V\
L9\xb9CTkh]R.\xee\xfb2\x80\x15k\
(e\xae\xb0\x12\x14\x09\xcep\xc09:\xdfr\xc8L\
!A\x1abI\x03\xf8K\xb1f \xe6\x02\xab \xec\
\xef)\xa1\x98K\x06\xee\xc1N\xcb\xfe\xde\xe9\x15\x11\xde\
\xa8\x10\xcf\x08\xd0\x1e\x92t\xa4Ly[\xe8 .M\
\x5c\x9f5\xd0\x1c\x00\xe7\x00k\xde\x83\x8d\x10\xf0\xc3a\
\xafR\xf0AvN\x0b!\x15\xa6\x8c\x0d\xf2.\x17\xe8\
\xe5\x03S\x02vYm\xca\x1c\x88\xadWHM\xe0\xbf\
F\xcbw\xc2\xbf\x0d\xdcE\xdbC\x02\xd1\xbbEo\xec\
\xf2\xc7\xa6\x03`M\x01\xc1\xa1\xe1\x01\xd2\xf4\x0a\xd4G\
viu)pa\xb9\xbd\xfeBa\xf17\x85\xc5\xdf\
\x14\x16\xfbu\xc2bo\x0a\x8b\xbd),\xde\xd7\xe52\
\x9d\xd6g]FE\x05\x93\x014\xf7]T\x97\xd9\xf1\
#\xbdC\xa4\xf9\x07\x17>\x15\x98q\xa6E\xe8\xaeq\
HCN\xc3\xc5\xb8\xf0\xa1\x0b\xde\xaam&\xa0mH\
5)n\x05\xe3\xd6\xbc\xb4)\x13X\x0e\x0de(m\
\x0e\x1dG\x057K\xfb\x0a\xde\xb7\xa8\xb9Q\xef\xaf\xd3\
C80C\x1d=\x94\x8f\xe9\x99\x83Fp@D\x00\
(\xb9\x0b-\x98\x04\xbc\x86\xcb^K\xb5\xc4L0\xe6\
\x1c\xfb\x94\x01>\x00\xae^\x0c\x9e\xcbc3/\xd3\x11\
\x16\xe5i&\xeaz\x0b\x1fe\xeb\x1c\xfd\x00\x87BN\
\xd0\x0f\xf0\xf0\xf2\x9d\x80OEp\x05|\x89\x83\xb1\xfc\
\xa7b\x0f\x05\x01\xb0s\x87\x19\x0b\xc7\xd8\xbf\x0d\xa1\xeb\
\x0c)\xc1y\xcbF\xe0\xd8\xf0\xfb\xabAICHs\
\xa9\x02\xe2\x18\xa4\x90\xfe\x02\xc6\x11\xa5\x16s\xf0\xc5\xff\
\x80\xcf\xe94\xf5\xc1\x17\x91\xe2\x0a\xfc\x1c\x87!\x9d\xc3\
\xaf4\x84Dg\xf0\xef#x\xb3\xfb\xcd\xa8\xb6j\xf0\
z\xad\xfb|wF(Ww(\xa4?\x91\x10\x063\
\x0b!\x01'\xda\x11\xa2 \x85)\x1f7\xa1\x81\x109\
\x22d\x1f\xd5\xdb\xde\x00\xf4\x7f\xb9g\xe1\xcc\xc84\xf2\
\x85b\x98\xc2\x98\xf3'\xf2\xb5\xc6B3\xe4s!A\
\xa4\x9d\x881\x18\x95T0\x91\xcd\x1e\xfdgF\xcb\x08\
'\x01;\xa5\x01\xe0D]\xd7\xf8\x91\xec\xbc\x06o\x83\
%\xf4N\xd5\xc1\xda\xb7\xa7\xf6j\xa4g\xa1\x82\x905\
\x93p\x00\xf65\xe6\x01\x13<\x18\x01\xbc9\xc2\xe1\xa7\
9\x99\x82\xe7\xa8Hs3\x82\xa9\x83\xc4\xe51\x0b`\
H\xa4\x0ak\xada%\x09\x87w\xfa\x1b\x91\xd40I\
\xf5\x94/\xc7\xcf\xeb|A\x1dJ\x16JH\x01\xe8\x97\
n\xf0\xa3!\xd20\x9f\x86\x0a\xde\x97<\x148\xe4\x9c\
(X\x0e6\x1c\x0a\xc1\xee\x04\xa50\xe3\xca\x9b\xe4|\
\x90\xb1\xfb\xb9w7\xfe\xf9\x8c\xb6\xa2\xf7gl;\xed\
\x84-8\xaf\xc0\xd4\x19\xdc_\xd0\xd5\xb2rI\xd6D\
\x9aD\x80XYF\xa7Ua\x0b\xf3:\x94n\xac\x0e\
`\xdf>\xa3\xd2\xc5\x8c`\xd0\xe5\x94!\x09/E9\
\x00\xb9\x09\x84\x0a\xe1e<\x07r\xd4g\x86\xd3\xb2M\
L}\xda\x1b8\x03\xc4\xf0\x99\xbd\xff\xaf\x1eYFI\
L]^\x9c\x7f-\xa6\x19\xd8N\x07d~\xd8\x80\xc2\
\x84\xf3\x81@Tp<4\xbf\xd1\xf1\xe0|bzp\
\xff?\x00\x7f\xff\x03c\xcf\xb9\xc9\
\x00\x00\x15\x06\
<\
?xml version=\x221.\
0\x22 encoding=\x22utf\
-8\x22?><!-- Upload\
ed to: SVG Repo,\
 www.svgrepo.com\
, Generator: SVG\
 Repo Mixer Tool\
s -->\x0a<svg fill=\
\x22#000000\x22 width=\
\x22800px\x22 height=\x22\
800px\x22 viewBox=\x22\
0 0 14 14\x22 role=\
\x22img\x22 focusable=\
\x22false\x22 aria-hid\
den=\x22true\x22 xmlns\
=\x22http://www.w3.\
org/2000/svg\x22><p\
ath d=\x22m 1.69275\
,12.9793 c -0.15\
08,-0.051 -0.304\
9,-0.1433 -0.39,\
-0.2325 -0.085,-\
0.089 -0.1532,-0\
.2209 -0.1828,-0\
.3536 -0.011,-0.\
049 -0.011,-0.08\
8 -0.012,-0.8636\
 l -10e-5,-0.812\
6 0.2523,0 0.252\
4,0 10e-5,0.7584\
 c 10e-5,0.8342 \
0,0.7987 0.037,0\
.8706 0.037,0.06\
9 0.111,0.1211 0\
.1959,0.1382 0.1\
048,0.021 0.2355\
,-0.047 0.2813,-\
0.1473 0.033,-0.\
072 0.032,-0.053\
 0.032,-0.8675 l\
 10e-5,-0.7524 0\
.2546,0 0.2546,0\
 0.3717,0.6309 0\
.3718,0.6308 0,-\
0.2764 0,-0.2764\
 0.2643,0 0.2643\
,0 0,0.7871 0,0.\
787 -0.2576,0 -0\
.2577,0 -0.3748,\
-0.6135 -0.3746,\
-0.6135 0,0.3116\
 c 0,0.3559 0,0.\
3522 -0.059,0.46\
78 -0.09,0.1849 \
-0.2854,0.3473 -\
0.5117,0.4247 l \
-0.056,0.019 -0.\
1473,0 -0.1471,0\
 -0.061,-0.021 z\
 m 3.3481,-0.043\
 c -0.2434,-0.03\
8 -0.4585,-0.149\
5 -0.6315,-0.327\
6 -0.1594,-0.164\
5 -0.259,-0.3591\
 -0.2975,-0.5821\
 -0.084,-0.4869 \
0.1612,-0.9686 0\
.6044,-1.1867 0.\
3107,-0.1528 0.6\
612,-0.1541 0.97\
4,0 0.2262,0.109\
 0.4035,0.2852 0\
.5176,0.5142 0.0\
25,0.051 0.063,0\
.1495 0.07,0.181\
8 l 0,0.019 -0.2\
363,0 -0.2362,0 \
-0.018,-0.034 c \
-0.045,-0.086 -0\
.1288,-0.1763 -0\
.2174,-0.2341 -0\
.1239,-0.081 -0.\
2536,-0.1156 -0.\
4031,-0.1082 -0.\
1689,0.01 -0.323\
2,0.079 -0.441,0\
.2016 -0.1243,0.\
1293 -0.1852,0.2\
798 -0.1852,0.45\
73 0,0.1899 0.06\
9,0.3527 0.2033,\
0.4822 0.1019,0.\
098 0.2066,0.151\
7 0.3495,0.1791 \
0.048,0.01 0.175\
9,0.01 0.2288,0 \
0.1989,-0.039 0.\
3693,-0.1616 0.4\
651,-0.3361 l 0.\
022,-0.04 0.2337\
,0 c 0.1881,0 0.\
2337,0 0.2337,0.\
01 0,0.019 -0.04\
5,0.139 -0.075,0\
.2003 -0.161,0.3\
289 -0.4765,0.55\
89 -0.8391,0.611\
7 -0.079,0.012 -\
0.2515,0.011 -0.\
3265,-3e-4 z m 2\
.3129,0.01 c -0.\
2673,-0.039 -0.4\
807,-0.1442 -0.6\
601,-0.3244 -0.4\
915,-0.4937 -0.4\
079,-1.316 0.173\
4,-1.7057 0.3234\
,-0.2166 0.7406,\
-0.2475 1.0904,-\
0.08 0.4408,0.21\
04 0.6904,0.6682\
 0.6278,1.1511 -\
0.055,0.4257 -0.\
3594,0.7872 -0.7\
694,0.9147 -0.11\
52,0.036 -0.1672\
,0.043 -0.3119,0\
.045 -0.073,0 -0\
.1403,8e-4 -0.15\
02,-7e-4 z m 0.2\
643,-0.4526 c 0.\
3284,-0.066 0.56\
19,-0.3848 0.526\
,-0.7189 -0.031,\
-0.2841 -0.2241,\
-0.5064 -0.5043,\
-0.5799 -0.066,-\
0.017 -0.1911,-0\
.022 -0.265,-0.0\
1 -0.266,0.046 -\
0.4684,0.2318 -0\
.5392,0.4952 -0.\
014,0.051 -0.016\
,0.07 -0.016,0.1\
573 -2e-4,0.082 \
0,0.1079 0.013,0\
.152 0.044,0.174\
2 0.1438,0.3155 \
0.2917,0.4114 0.\
1442,0.093 0.320\
9,0.1262 0.4936,\
0.092 z m 4.0615\
,0.4526 c -0.132\
6,-0.019 -0.2566\
,-0.056 -0.3589,\
-0.1074 -0.6082,\
-0.3033 -0.8097,\
-1.0584 -0.432,-\
1.6197 0.1611,-0\
.2392 0.4079,-0.\
406 0.689,-0.465\
5 0.3449,-0.073 \
0.6879,0.016 0.9\
623,0.2512 0.137\
1,0.1172 0.2592,\
0.3018 0.3192,0.\
4822 0.022,0.067\
 0.048,0.1748 0.\
042,0.1797 0,0 -\
0.097,0.039 -0.2\
127,0.084 -0.115\
7,0.045 -0.2252,\
0.088 -0.2433,0.\
096 -0.018,0.01 \
-0.2778,0.1073 -\
0.5768,0.2203 -0\
.299,0.1128 -0.5\
473,0.2071 -0.55\
16,0.2095 -0.01,\
0 0.01,0.018 0.0\
39,0.049 0.093,0\
.089 0.199,0.143\
7 0.3292,0.1705 \
0.063,0.013 0.18\
2,0.013 0.2488,0\
 0.2166,-0.042 0\
.4049,-0.1972 0.\
4876,-0.4024 l 0\
.017,-0.042 0.23\
11,0 0.2311,0 -0\
.01,0.041 c -0.0\
82,0.3704 -0.370\
2,0.6871 -0.7342\
,0.8067 -0.1215,\
0.04 -0.1838,0.0\
5 -0.331,0.051 -\
0.071,9e-4 -0.13\
74,4e-4 -0.1473,\
0 z m 0.036,-1.3\
739 c 0.2875,-0.\
1075 0.5304,-0.1\
983 0.5397,-0.20\
19 l 0.017,-0.01\
 -0.032,-0.027 c\
 -0.1298,-0.1111\
 -0.2834,-0.164 \
-0.4556,-0.157 -\
0.1593,0.01 -0.2\
899,0.057 -0.409\
8,0.1577 -0.1172\
,0.099 -0.2096,0\
.268 -0.225,0.41\
27 l 0,0.035 0.0\
23,-0.01 c 0.013\
,0 0.2586,-0.096\
 0.546,-0.2037 z\
 m -2.983,0.2628\
 0,-1.1089 0.434\
2,0 c 0.4103,0 0\
.4376,0 0.5001,0\
.015 0.1764,0.03\
4 0.3195,0.093 0\
.4596,0.192 0.07\
3,0.051 0.2067,0\
.185 0.2599,0.25\
98 0.052,0.073 0\
.1224,0.2129 0.1\
503,0.2985 0.117\
9,0.3625 0.042,0\
.7627 -0.2003,1.\
051 -0.1873,0.22\
32 -0.4592,0.364\
9 -0.7536,0.3926\
 -0.038,0 -0.233\
9,0.01 -0.4581,0\
.01 l -0.3921,0 \
0,-1.1089 z m 0.\
871,0.6615 c 0.2\
579,-0.053 0.452\
6,-0.2379 0.5213\
,-0.4949 0.014,-\
0.052 0.016,-0.0\
69 0.016,-0.1602\
 0,-0.091 0,-0.1\
087 -0.015,-0.15\
97 -0.053,-0.199\
1 -0.1763,-0.350\
9 -0.3553,-0.438\
3 -0.034,-0.016 \
-0.088,-0.037 -0\
.121,-0.046 -0.0\
58,-0.015 -0.067\
,-0.016 -0.2477,\
-0.018 l -0.1878\
,0 0,0.6683 0,0.\
6682 0.1728,0 c \
0.119,0 0.1866,-\
0.01 0.2175,-0.0\
13 z m -6.1881,-\
1.4992 0,-0.2764\
 0.2644,0 0.2643\
,0 0,0.2764 0,0.\
2763 -0.2643,0 -\
0.2644,0 0,-0.27\
63 z m -2.3852,-\
5.4343 0,-4.5632\
 0.1502,0 0.1502\
,0 0,3.2301 c 0,\
3.5786 0,3.2528 \
0.039,3.4548 0.0\
88,0.4125 0.27,0\
.8253 0.5059,1.1\
487 0.1853,0.254\
 0.4189,0.4777 0\
.7011,0.6713 0.3\
804,0.2611 0.803\
3,0.457 1.3251,0\
.6138 0.015,0 -0\
.4035,0.01 -1.42\
55,0.01 l -1.446\
4,6e-4 0,-4.563 \
z m 4.0003,4.547\
9 c 0.5032,-0.10\
66 1.0421,-0.373\
5 1.4851,-0.7352\
 0.5723,-0.4676 \
0.9292,-1.017 1.\
048,-1.6139 0.03\
1,-0.1569 0.03,-\
0.091 0.033,-1.3\
68 l 0,-1.188 1.\
5006,2.4565 c 0.\
8253,1.3511 1.50\
05,2.4581 1.5005\
,2.4601 0,0 -1.2\
688,0 -2.8193,0 \
l -2.8194,-3e-4 \
0.068,-0.014 z m\
 7.6299,-3.1316 \
0,-3.1467 -1.054\
5,0 -1.0544,0 0,\
1.1036 0,1.1036 \
-1.4629,-2.4819 \
c -0.8047,-1.365\
 -1.4731,-2.499 \
-1.4853,-2.52 l \
-0.022,-0.038 1.\
4867,0 1.4868,0 \
0,1.1025 0,1.102\
5 1.0574,0 1.057\
5,0 0,-1.1025 0,\
-1.1025 0.1501,0\
 0.1503,0 0,4.56\
32 0,4.563 -0.15\
03,0 -0.1501,0 0\
,-3.1467 z m -8.\
3528,1.0859 c -0\
.2748,-0.05 -0.5\
144,-0.177 -0.67\
19,-0.3572 -0.15\
13,-0.173 -0.238\
1,-0.3775 -0.278\
3,-0.6551 -0.01,\
-0.068 -0.011,-0\
.2588 -0.012,-3.\
0626 l 0,-2.9905\
 1.0937,0 1.0936\
,0 0,3.0115 0,3.\
0116 -0.013,0.07\
7 c -0.057,0.339\
6 -0.1908,0.581 \
-0.4164,0.752 -0\
.2241,0.1699 -0.\
5476,0.2574 -0.7\
896,0.2137 z\x22/><\
/svg>\
\x00\x00\x01\xd4\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -4 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -4)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
TV\x22>\x0d\x0a      <pat\
h d=\x22M28, 4L4, 4\
C2.9, 4 2, 4.9 2\
, 6L2, 22C2, 23.\
1 2.9, 24 4, 24L\
10, 24L10, 28L22\
, 28L22, 24L28, \
24C29.1, 24 30, \
23.1 30, 22L30, \
6C30, 4.9 29.1, \
4 28, 4zM28, 22L\
4, 22L4, 6L28, 6\
L28, 22z\x22 fill=\x22\
#000000\x22 class=\x22\
Black\x22 />\x0d\x0a    <\
/g>\x0d\x0a  </g>\x0d\x0a</s\
vg>\
\x00\x00\x08*\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   sodipodi:do\
cname=\x22paste-gra\
y.svg\x22\x0a   inksca\
pe:version=\x221.4 \
(e7c3feb100, 202\
4-10-09)\x22\x0a   xml\
ns:inkscape=\x22htt\
p://www.inkscape\
.org/namespaces/\
inkscape\x22\x0a   xml\
ns:sodipodi=\x22htt\
p://sodipodi.sou\
rceforge.net/DTD\
/sodipodi-0.dtd\x22\
\x0a   xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns:\
svg=\x22http://www.\
w3.org/2000/svg\x22\
>\x0a  <defs\x0a     i\
d=\x22defs2\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     id=\x22name\
dview2\x22\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#000000\x22\x0a    \
 borderopacity=\x22\
0.25\x22\x0a     inksc\
ape:showpageshad\
ow=\x222\x22\x0a     inks\
cape:pageopacity\
=\x220.0\x22\x0a     inks\
cape:pagechecker\
board=\x220\x22\x0a     i\
nkscape:deskcolo\
r=\x22#d1d1d1\x22\x0a    \
 inkscape:zoom=\x22\
25.21875\x22\x0a     i\
nkscape:cx=\x2216\x22\x0a\
     inkscape:cy\
=\x2216\x22\x0a     inksc\
ape:window-width\
=\x221920\x22\x0a     ink\
scape:window-hei\
ght=\x22969\x22\x0a     i\
nkscape:window-x\
=\x220\x22\x0a     inksca\
pe:window-y=\x220\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
svg2\x22 />\x0a  <g\x0a  \
   transform=\x22tr\
anslate(0, 0)\x22\x0a \
    id=\x22g2\x22\x0a    \
 style=\x22fill:#00\
0000;fill-opacit\
y:1\x22>\x0a    <g\x0a   \
    transform=\x22m\
atrix(0.05468749\
62747097, 0, 0, \
0.05468749627470\
97, 0, 0)\x22\x0a     \
  id=\x22g1\x22\x0a      \
 style=\x22fill:#00\
0000;fill-opacit\
y:1\x22>\x0a      <pat\
h\x0a         d=\x22M1\
04.6, 48L64, 48C\
28.7, 48 0, 76.7\
 0, 112L0, 384C0\
, 419.3 28.7, 44\
8 64, 448L160, 4\
48L160, 400L64, \
400C55.2, 400 48\
, 392.8 48, 384L\
48, 112C48, 103.\
2 55.2, 96 64, 9\
6L80, 96C80, 113\
.7 94.3, 128 112\
, 128L184.4, 128\
C202, 108.4 227.\
6, 96 256, 96L31\
8, 96C310.9, 68.\
4 285.8, 48 256,\
 48L215.4, 48C21\
1.6, 20.9 188.2,\
 0 160, 0C131.8,\
 0 108.4, 20.9 1\
04.6, 48zM144, 5\
6A16 16 0 1 1 17\
6, 56A16 16 0 1 \
1 144, 56zM448, \
464L256, 464C247\
.2, 464 240, 456\
.8 240, 448L240,\
 192C240, 183.2 \
247.2, 176 256, \
176L396.1, 176L4\
64, 243.9L464, 4\
48C464, 456.8 45\
6.8, 464 448, 46\
4zM256, 512L448,\
 512C483.3, 512 \
512, 483.3 512, \
448L512, 243.9C5\
12, 231.2 506.9,\
 219 497.9, 210L\
430, 142.1C421, \
133.1 408.8, 128\
 396.1, 128L256,\
 128C220.7, 128 \
192, 156.7 192, \
192L192, 448C192\
, 483.3 220.7, 5\
12 256, 512z\x22\x0a  \
       id=\x22path1\
\x22\x0a         style\
=\x22fill:#000000;f\
ill-opacity:1\x22 /\
>\x0a    </g>\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x06\xc4\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   he\
ight=\x2256\x22\x0a   vie\
wBox=\x220 0 56 56\x22\
\x0a   width=\x2256\x22\x0a \
  version=\x221.1\x22\x0a\
   id=\x22svg1\x22\x0a   \
sodipodi:docname\
=\x22eyedropper.svg\
\x22\x0a   inkscape:ve\
rsion=\x221.4 (e7c3\
feb100, 2024-10-\
09)\x22\x0a   xmlns:in\
kscape=\x22http://w\
ww.inkscape.org/\
namespaces/inksc\
ape\x22\x0a   xmlns:so\
dipodi=\x22http://s\
odipodi.sourcefo\
rge.net/DTD/sodi\
podi-0.dtd\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22>\x0a  <\
defs\x0a     id=\x22de\
fs1\x22 />\x0a  <sodip\
odi:namedview\x0a  \
   id=\x22namedview\
1\x22\x0a     pagecolo\
r=\x22#ffffff\x22\x0a    \
 bordercolor=\x22#0\
00000\x22\x0a     bord\
eropacity=\x220.25\x22\
\x0a     inkscape:s\
howpageshadow=\x222\
\x22\x0a     inkscape:\
pageopacity=\x220.0\
\x22\x0a     inkscape:\
pagecheckerboard\
=\x220\x22\x0a     inksca\
pe:deskcolor=\x22#d\
1d1d1\x22\x0a     inks\
cape:zoom=\x2213.10\
7143\x22\x0a     inksc\
ape:cx=\x2228.03814\
7\x22\x0a     inkscape\
:cy=\x2228\x22\x0a     in\
kscape:window-wi\
dth=\x221142\x22\x0a     \
inkscape:window-\
height=\x22942\x22\x0a   \
  inkscape:windo\
w-x=\x2245\x22\x0a     in\
kscape:window-y=\
\x2245\x22\x0a     inksca\
pe:window-maximi\
zed=\x220\x22\x0a     ink\
scape:current-la\
yer=\x22svg1\x22 />\x0a  \
<path\x0a     d=\x22m3\
9.6485 28.9024.6\
563-.7266c1.1484\
-1.1953 1.1953-2\
.6016-.0235-3.82\
03l-.7031-.6797c\
3.5859-3.2109 7.\
5703-3.6563 10.0\
313-6.1641 3.492\
-3.5156 2.3438-8\
.4375-.0936-10.8\
984-2.4379-2.484\
4-7.3127-3.5391-\
10.8987-.0938-2.\
5312 2.4376-2.95\
31 6.4454-6.164 \
10.0313l-.6797-.\
7032c-1.2187-1.2\
187-2.625-1.1718\
-3.8203-.0234l-.\
7266.6563c-1.429\
7 1.3828-1.1718 \
2.6015.0703 3.84\
37l.9844.9844-17\
.6953 17.7188c-7\
.2422 7.2421-3.7\
5 6.1171-7.6875 \
11.6718l2.086 2.\
2266c5.3905-3.91\
41 4.664-.0703 1\
2-7.4063l17.8124\
-17.6953 1.0079 \
1.0078c1.2421 1.\
2422 2.4609 1.5 \
3.8437.0704zm-29\
.5313 17.2265c-.\
8671-.9375-.7031\
-1.8281.2344-2.7\
656l19.9453-20.0\
391 2.5547 2.554\
7-20.039 20.0156\
c-.8203.8438-1.8\
985 1.1016-2.695\
4.2344z\x22\x0a     id\
=\x22path1\x22 />\x0a</sv\
g>\x0a\
\x00\x00\x04K\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -4 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -4)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
Image\x22>\x0d\x0a      <\
path d=\x22M29, 4L3\
, 4C2.5, 4 2, 4.\
5 2, 5L2, 27C2, \
27.5 2.5, 28 3, \
28L29, 28C29.5, \
28 30, 27.5 30, \
27L30, 5C30, 4.5\
 29.5, 4 29, 4zM\
28, 26L4, 26L4, \
6L28, 6L28, 26z\x22\
 fill=\x22#000000\x22 \
class=\x22Black\x22 />\
\x0d\x0a    </g>\x0d\x0a  </\
g>\x0d\x0a  <g id=\x22Lay\
er_1\x22 transform=\
\x22translate(-2, -\
4)\x22 style=\x22enabl\
e-background:new\
 0 0 32 32\x22>\x0d\x0a  \
  <g id=\x22Image\x22>\
\x0d\x0a      <circle \
cx=\x2221\x22 cy=\x2211\x22 \
r=\x223\x22 fill=\x22#FFB\
115\x22 class=\x22Yell\
ow\x22 />\x0d\x0a    </g>\
\x0d\x0a  </g>\x0d\x0a  <g i\
d=\x22Layer_1\x22 tran\
sform=\x22translate\
(-2, -4)\x22 style=\
\x22enable-backgrou\
nd:new 0 0 32 32\
\x22>\x0d\x0a    <g id=\x22I\
mage\x22>\x0d\x0a      <p\
olygon points=\x222\
0,24 10,14 6,18 \
6,24  \x22 fill=\x22#0\
39C23\x22 class=\x22Gr\
een\x22 />\x0d\x0a    </g\
>\x0d\x0a  </g>\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-2, -4)\x22 style\
=\x22enable-backgro\
und:new 0 0 32 3\
2\x22>\x0d\x0a    <g id=\x22\
Image\x22>\x0d\x0a      <\
g class=\x22st1\x22>\x0d\x0a\
        <polygon\
 points=\x2222,24 1\
8,20 20,18 26,24\
   \x22 fill=\x22#039C\
23\x22 class=\x22Green\
\x22 />\x0d\x0a      </g>\
\x0d\x0a    </g>\x0d\x0a  </\
g>\x0d\x0a</svg>\
\x00\x00\x07\x8d\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -8.16\
 32 32\x22 xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22 >\x0d\x0a  \
<g transform=\x22tr\
anslate(0, -6.16\
)\x22>\x0d\x0a    <g tran\
sform=\x22matrix(0.\
0280000045895576\
, 0, 0, 0.028000\
0045895576, 0, 0\
)\x22>\x0d\x0a      <g>\x0d\x0a\
        <path d=\
\x22M500, 220C561.3\
33, 220 620.333,\
 228.333 677, 24\
5C733.667, 261.6\
67 780.667, 282.\
333 818, 307C855\
.333, 331.667 88\
8.333, 357.333 9\
17, 384C945.667,\
 410.667 966.667\
, 434.333 980, 4\
55C993.333, 475.\
667 1000, 490.66\
7 1000, 500C1000\
, 509.333 993.33\
3, 524 980, 544C\
966.667, 564 945\
.667, 587.667 91\
7, 615C888.333, \
642.333 855.333,\
 668.333 818, 69\
3C780.667, 717.6\
67 733.667, 738.\
333 677, 755C620\
.333, 771.667 56\
1.333, 780 500, \
780C438.667, 780\
 379.667, 771.66\
7 323, 755C266.3\
33, 738.333 219.\
333, 717.667 182\
, 693C144.667, 6\
68.333 111.667, \
642.333 83, 615C\
54.333, 587.667 \
33.333, 564 20, \
544C6.667, 524 0\
, 509.333 0, 500\
C0, 490.667 6.66\
7, 475.667 20, 4\
55C33.333, 434.3\
33 54.333, 410.6\
67 83, 384C111.6\
67, 357.333 144.\
667, 331.667 182\
, 307C219.333, 2\
82.333 266.333, \
261.667 323, 245\
C379.667, 228.33\
3 438.667, 220 5\
00, 220C500, 220\
 500, 220 500, 2\
20M500, 714C561.\
333, 714 613.667\
, 693 657, 651C7\
00.333, 609 722,\
 558.667 722, 50\
0C722, 440 700.3\
33, 389 657, 347\
C613.667, 305 56\
1.333, 284 500, \
284C438.667, 284\
 386.333, 305 34\
3, 347C299.667, \
389 278, 440 278\
, 500C278, 558.6\
67 299.667, 609 \
343, 651C386.333\
, 693 438.667, 7\
14 500, 714C500,\
 714 500, 714 50\
0, 714M500, 500C\
505.333, 505.333\
 517.667, 506 53\
7, 502C556.333, \
498 573, 494.333\
 587, 491C601, 4\
87.667 609.333, \
490.667 612, 500\
C612, 529.333 60\
1, 554.333 579, \
575C557, 595.667\
 530.667, 606 50\
0, 606C469.333, \
606 443.333, 595\
.667 422, 575C40\
0.667, 554.333 3\
90, 529.333 390,\
 500C390, 469.33\
3 400.667, 443.6\
67 422, 423C443.\
333, 402.333 469\
.333, 392 500, 3\
92C509.333, 392 \
512.667, 399.667\
 510, 415C507.33\
3, 430.333 503.3\
33, 446 498, 462\
C492.667, 478 49\
3.333, 490.667 5\
00, 500C500, 500\
 500, 500 500, 5\
00\x22 />\x0d\x0a      </\
g>\x0d\x0a    </g>\x0d\x0a  \
</g>\x0d\x0a</svg>\
\x00\x00\x08\x15\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2 -2 32 \
32\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   sodipodi:do\
cname=\x22circle-gr\
ay.svg\x22\x0a   inksc\
ape:version=\x221.4\
 (86a8ad7, 2024-\
10-11)\x22\x0a   xmlns\
:inkscape=\x22http:\
//www.inkscape.o\
rg/namespaces/in\
kscape\x22\x0a   xmlns\
:sodipodi=\x22http:\
//sodipodi.sourc\
eforge.net/DTD/s\
odipodi-0.dtd\x22\x0a \
  xmlns=\x22http://\
www.w3.org/2000/\
svg\x22\x0a   xmlns:sv\
g=\x22http://www.w3\
.org/2000/svg\x22>\x0a\
  <defs\x0a     id=\
\x22defs2\x22 />\x0a  <so\
dipodi:namedview\
\x0a     id=\x22namedv\
iew2\x22\x0a     pagec\
olor=\x22#ffffff\x22\x0a \
    bordercolor=\
\x22#000000\x22\x0a     b\
orderopacity=\x220.\
25\x22\x0a     inkscap\
e:showpageshadow\
=\x222\x22\x0a     inksca\
pe:pageopacity=\x22\
0.0\x22\x0a     inksca\
pe:pagecheckerbo\
ard=\x220\x22\x0a     ink\
scape:deskcolor=\
\x22#d1d1d1\x22\x0a     i\
nkscape:zoom=\x2225\
.21875\x22\x0a     ink\
scape:cx=\x2216\x22\x0a  \
   inkscape:cy=\x22\
12.768278\x22\x0a     \
inkscape:window-\
width=\x221920\x22\x0a   \
  inkscape:windo\
w-height=\x22996\x22\x0a \
    inkscape:win\
dow-x=\x22-9\x22\x0a     \
inkscape:window-\
y=\x22-9\x22\x0a     inks\
cape:window-maxi\
mized=\x221\x22\x0a     i\
nkscape:current-\
layer=\x22g2\x22\x0a     \
showgrid=\x22true\x22>\
\x0a    <inkscape:g\
rid\x0a       id=\x22g\
rid1\x22\x0a       uni\
ts=\x22px\x22\x0a       o\
riginx=\x220\x22\x0a     \
  originy=\x220\x22\x0a  \
     spacingx=\x221\
\x22\x0a       spacing\
y=\x221\x22\x0a       emp\
color=\x22#0099e5\x22\x0a\
       empopacit\
y=\x220.30196078\x22\x0a \
      color=\x22#00\
99e5\x22\x0a       opa\
city=\x220.14901961\
\x22\x0a       empspac\
ing=\x225\x22\x0a       e\
nabled=\x22true\x22\x0a  \
     visible=\x22tr\
ue\x22 />\x0a  </sodip\
odi:namedview>\x0a \
 <g\x0a     id=\x22Cap\
a_1\x22\x0a     transf\
orm=\x22matrix(0.92\
887419,0,0,0.920\
12721,0.99195841\
,1.0770303)\x22\x0a   \
  style=\x22fill:#0\
00000;fill-opaci\
ty:1;stroke:none\
;stroke-opacity:\
1;stroke-width:0\
.99946959;stroke\
-dasharray:none\x22\
>\x0a    <g\x0a       \
transform=\x22scale\
(0.96195179)\x22\x0a  \
     id=\x22g2\x22\x0a   \
    style=\x22fill:\
#000000;fill-opa\
city:1;stroke:no\
ne;stroke-opacit\
y:1;stroke-width\
:1.03900175;stro\
ke-dasharray:non\
e\x22>\x0a      <ellip\
se\x0a         styl\
e=\x22fill:none;fil\
l-rule:evenodd;s\
troke:#000000;st\
roke-width:3.335\
22;stroke-lineca\
p:round;stroke-l\
inejoin:bevel;st\
roke-dasharray:n\
one;stroke-opaci\
ty:1;paint-order\
:stroke fill mar\
kers\x22\x0a         i\
d=\x22path1\x22\x0a      \
   cx=\x2214.557998\
\x22\x0a         cy=\x221\
4.600277\x22\x0a      \
   rx=\x2212.881395\
\x22\x0a         ry=\x221\
3.019702\x22 />\x0a   \
 </g>\x0a  </g>\x0a</s\
vg>\x0a\
\x00\x00\x08\x13\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(0, 0)\x22 style=\x22\
enable-backgroun\
d:new 0 0 508 50\
8\x22>\x0d\x0a    <g tran\
sform=\x22matrix(0.\
0551181100308895\
, 0, 0, 0.055118\
1100308895, 0, 0\
)\x22>\x0d\x0a      <circ\
le cx=\x22254\x22 cy=\x22\
254\x22 r=\x22254\x22 fil\
l=\x22#000000\x22 clas\
s=\x22Black\x22 />\x0d\x0a  \
  </g>\x0d\x0a  </g>\x0d\x0a\
  <g id=\x22Layer_1\
\x22 transform=\x22tra\
nslate(-8.773803\
71022696E-07, -5\
.53131103586679E\
-07)\x22 style=\x22ena\
ble-background:n\
ew 0 0 508 508\x22>\
\x0d\x0a    <g transfo\
rm=\x22matrix(0.055\
1181100308895, 0\
, 0, 0.055118110\
0308895, 0, 0)\x22>\
\x0d\x0a      <path d=\
\x22M252, 414L256, \
414C318.8, 414 3\
71.2, 363.6 370,\
 300.8C370, 292.\
8 368.8, 285.2 3\
67.2, 278C360, 2\
46.4 324, 210 29\
8, 170.8C270.8, \
133.2 254, 93.2 \
254, 94.4C253.6,\
 93.6 236.8, 133\
.6 210, 170.8C18\
4.4, 210 148, 24\
6.8 140.8, 277.6\
C138.8, 284.8 13\
8, 292.4 138, 30\
0.4C136.8, 363.2\
 189.2, 414 252,\
 414z\x22 fill=\x22#FF\
FFFF\x22 class=\x22Whi\
te\x22 />\x0d\x0a    </g>\
\x0d\x0a  </g>\x0d\x0a  <g i\
d=\x22Layer_1\x22 tran\
sform=\x22translate\
(-1.029968261789\
8E-06, -2.670288\
07954262E-07)\x22 s\
tyle=\x22enable-bac\
kground:new 0 0 \
508 508\x22>\x0d\x0a    <\
g transform=\x22mat\
rix(0.0551181100\
308895, 0, 0, 0.\
0551181100308895\
, 0, 0)\x22>\x0d\x0a     \
 <g>\x0d\x0a        <p\
ath d=\x22M177.2, 3\
53.6C183.2, 353.\
2 186.8, 347.6 1\
84.4, 342.8C181.\
2, 335.6 178.4, \
328 177.2, 320C1\
75.6, 312 175.2,\
 304.4 175.6, 29\
6.8C176.8, 264.8\
 207.6, 221.6 22\
7.2, 178.4C229.2\
, 174.8 230.8, 1\
70.8 232.4, 167.\
2C231.6, 168.4 2\
30.8, 169.6 230,\
 170.4C203.6, 21\
0.8 166, 249.2 1\
59.2, 280.4C157.\
6, 287.6 156.8, \
295.6 156.8, 303\
.6C157.2, 320.4 \
161.6, 335.6 169\
.2, 349.6C171.2,\
 352.4 174, 354 \
177.2, 353.6L177\
.2, 353.6z\x22 fill\
=\x22#000000\x22 class\
=\x22Black\x22 />\x0d\x0a   \
   </g>\x0d\x0a    </g\
>\x0d\x0a  </g>\x0d\x0a  <g \
id=\x22Layer_1\x22 tra\
nsform=\x22translat\
e(-4.19616698721\
37E-07, -2.28881\
835795391E-06)\x22 \
style=\x22enable-ba\
ckground:new 0 0\
 508 508\x22>\x0d\x0a    \
<g transform=\x22ma\
trix(0.055118110\
0308895, 0, 0, 0\
.055118110030889\
5, 0, 0)\x22>\x0d\x0a    \
  <g>\x0d\x0a        <\
ellipse cx=\x22188.\
401\x22 cy=\x22365.998\
\x22 rx=\x228.4\x22 ry=\x229\
.2\x22 fill=\x22#00000\
0\x22 class=\x22Black\x22\
 transform=\x22matr\
ix(-0.042, -0.99\
91, 0.9991, -0.0\
42, -169.3631, 5\
69.6013)\x22 />\x0d\x0a  \
    </g>\x0d\x0a    </\
g>\x0d\x0a  </g>\x0d\x0a</sv\
g>\
\x00\x00\x0e\xdd\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   width=\x22\
31.994951\x22\x0a   he\
ight=\x2232.000015\x22\
\x0a   viewBox=\x2232 \
32 8.9386878 8.9\
401026\x22\x0a   versi\
on=\x221.1\x22\x0a   id=\x22\
svg1\x22\x0a   inkscap\
e:version=\x221.4 (\
86a8ad7, 2024-10\
-11)\x22\x0a   sodipod\
i:docname=\x22lasso\
_select.svg\x22\x0a   \
inkscape:export-\
filename=\x22lasso_\
select.png\x22\x0a   i\
nkscape:export-x\
dpi=\x221.6256\x22\x0a   \
inkscape:export-\
ydpi=\x221.6256\x22\x0a  \
 xmlns:inkscape=\
\x22http://www.inks\
cape.org/namespa\
ces/inkscape\x22\x0a  \
 xmlns:sodipodi=\
\x22http://sodipodi\
.sourceforge.net\
/DTD/sodipodi-0.\
dtd\x22\x0a   xmlns=\x22h\
ttp://www.w3.org\
/2000/svg\x22\x0a   xm\
lns:svg=\x22http://\
www.w3.org/2000/\
svg\x22>\x0a  <sodipod\
i:namedview\x0a    \
 id=\x22namedview1\x22\
\x0a     pagecolor=\
\x22#ffffff\x22\x0a     b\
ordercolor=\x22#000\
000\x22\x0a     border\
opacity=\x220.25\x22\x0a \
    inkscape:sho\
wpageshadow=\x222\x22\x0a\
     inkscape:pa\
geopacity=\x220.0\x22\x0a\
     inkscape:pa\
gecheckerboard=\x22\
true\x22\x0a     inksc\
ape:deskcolor=\x22#\
d1d1d1\x22\x0a     ink\
scape:document-u\
nits=\x22px\x22\x0a     i\
nkscape:zoom=\x2216\
\x22\x0a     inkscape:\
cx=\x2216.96875\x22\x0a  \
   inkscape:cy=\x22\
17.5\x22\x0a     inksc\
ape:window-width\
=\x221920\x22\x0a     ink\
scape:window-hei\
ght=\x22996\x22\x0a     i\
nkscape:window-x\
=\x22-9\x22\x0a     inksc\
ape:window-y=\x22-9\
\x22\x0a     inkscape:\
window-maximized\
=\x221\x22\x0a     inksca\
pe:current-layer\
=\x22layer1\x22\x0a     s\
howgrid=\x22true\x22>\x0a\
    <inkscape:gr\
id\x0a       id=\x22gr\
id1\x22\x0a       unit\
s=\x22mm\x22\x0a       or\
iginx=\x220\x22\x0a      \
 originy=\x220\x22\x0a   \
    spacingx=\x221.\
0000395\x22\x0a       \
spacingy=\x221.0000\
395\x22\x0a       empc\
olor=\x22#0099e5\x22\x0a \
      empopacity\
=\x220.30196078\x22\x0a  \
     color=\x22#009\
9e5\x22\x0a       opac\
ity=\x220.14901961\x22\
\x0a       empspaci\
ng=\x225\x22\x0a       en\
abled=\x22true\x22\x0a   \
    visible=\x22tru\
e\x22 />\x0a  </sodipo\
di:namedview>\x0a  \
<defs\x0a     id=\x22d\
efs1\x22 />\x0a  <g\x0a  \
   inkscape:labe\
l=\x22Katman 1\x22\x0a   \
  inkscape:group\
mode=\x22layer\x22\x0a   \
  id=\x22layer1\x22\x0a  \
   transform=\x22tr\
anslate(-201.519\
79,-235.5087)\x22>\x0a\
    <ellipse\x0a   \
    style=\x22fill:\
#4677ef;fill-opa\
city:0.34657;str\
oke:#000000;stro\
ke-width:0.58501\
992;stroke-linec\
ap:butt;stroke-d\
asharray:none;st\
roke-opacity:1;p\
aint-order:norma\
l\x22\x0a       id=\x22pa\
th1\x22\x0a       cx=\x22\
360.98166\x22\x0a     \
  cy=\x22-15.824715\
\x22\x0a       rx=\x222.0\
321822\x22\x0a       r\
y=\x223.0664492\x22\x0a  \
     transform=\x22\
matrix(0.6274904\
8,0.77862423,-0.\
77616391,0.63053\
119,0,0)\x22 />\x0a   \
 <ellipse\x0a      \
 id=\x22path5\x22\x0a    \
   style=\x22fill:#\
ef8946;stroke:#7\
07070;stroke-wid\
th:0.00478869\x22\x0a \
      cx=\x22236.77\
841\x22\x0a       cy=\x22\
272.81592\x22\x0a     \
  rx=\x220.00064945\
634\x22\x0a       ry=\x22\
0.00065205846\x22 /\
>\x0a    <path\x0a    \
   style=\x22fill:#\
707070;fill-opac\
ity:1;stroke:#00\
0000;stroke-widt\
h:0.36375025;str\
oke-linecap:squa\
re;stroke-linejo\
in:round;stroke-\
dasharray:none;s\
troke-opacity:1;\
paint-order:mark\
ers fill stroke\x22\
\x0a       d=\x22m 237\
.41623,273.2039 \
c 0,0 0.11229,-0\
.0331 0.13475,-0\
.21916 0.0226,-0\
.18608 0.0315,-0\
.21502 -0.0628,-\
0.35563 -0.0943,\
-0.14059 -0.5748\
8,-0.0166 -0.574\
88,-0.0166 0,0 -\
0.38986,0.1396 -\
0.72759,0.43419 \
-0.17067,0.14887\
 -0.46709,0.459 \
-0.44014,0.6823 \
0.0269,0.22329 0\
.0943,0.33081 0.\
26499,0.34322 0.\
17066,0.0124 0.5\
1199,-0.0951 0.6\
4224,-0.20676 0.\
13024,-0.11165 0\
.0988,0.0413 0.0\
988,0.0413 0,0 -\
0.65075,0.5815 -\
1.00604,0.85597 \
-0.27894,0.21549\
 -0.86233,0.612 \
-0.8803,0.62441 \
-0.018,0.0124 0.\
0943,0.11992 0.0\
943,0.11992 0,0 \
0.70962,-0.49208\
 1.11382,-0.8311\
6 0.40423,-0.339\
08 0.91622,-0.82\
289 0.91622,-0.8\
2289 0,0 0.0359,\
-0.0413 0,-0.128\
19 -0.0359,-0.08\
69 -0.15269,-0.0\
827 -0.26049,-0.\
0413 -0.10778,0.\
0413 -0.18996,0.\
1093 -0.41319,0.\
17781 -0.12127,0\
.0372 -0.28744,0\
.0744 -0.3638,0.\
0208 -0.0564,-0.\
0397 -0.0982,-0.\
16547 -0.0495,-0\
.26466 0.0512,-0\
.10406 0.0907,-0\
.15983 0.14796,-\
0.23259 0.0478,-\
0.0607 0.16194,-\
0.1685 0.16194,-\
0.1685 0,0 0.251\
51,-0.26879 0.56\
589,-0.40111 0.3\
1439,-0.13233 0.\
47159,-0.11579 0\
.47159,-0.11579 \
0,0 0.13474,-0.0\
05 0.16617,0.099\
2 0.0278,0.0917 \
0.006,0.21063 -0\
.0359,0.27292 -0\
.0816,0.12233 -0\
.19726,0.15284 -\
0.13923,0.20675 \
0.0426,0.0396 0.\
17516,-0.0744 0.\
17516,-0.0744 z\x22\
\x0a       id=\x22path\
6\x22\x0a       sodipo\
di:nodetypes=\x22cs\
scsssscsscscssss\
sscscsssc\x22 />\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x06z\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2.0025 \
-4.8025 32 32\x22 x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22 >\x0d\x0a  <g transf\
orm=\x22translate(-\
0.0006, -0.0018)\
\x22>\x0d\x0a    <g trans\
form=\x22matrix(0.0\
437470972537994,\
 0, 0, 0.0437470\
972537994, 0, 0)\
\x22>\x0d\x0a      <path \
d=\x22M352, 124.5L3\
00.1, 111.5C293.\
6, 109.9 288.8, \
104.4 288.1, 97.\
7C287.4, 91 290.\
9, 84.6 296.8, 8\
1.6L337.6, 61.2L\
294.4, 28.8C288.\
9, 24.7 286.6, 1\
7.5 288.8, 10.9C\
291, 4.3 297.1, \
0 304, 0L416, 0L\
448, 0L464, 0C49\
4.2, 0 522.7, 14\
.2 540.8, 38.4L5\
98.4, 115.2C604.\
6, 123.5 608, 13\
3.6 608, 144C608\
, 170.5 586.5, 1\
92 560, 192L538.\
5, 192C521.5, 19\
2 505.2, 185.3 4\
93.2, 173.3L480,\
 160L448, 160L44\
8, 181.5C448, 20\
6.3 460.8, 229.4\
 481.8, 242.6L58\
8.4, 309.2C620.5\
, 329.3 640, 364\
.4 640, 402.3C64\
0, 462.9 590.9, \
512 530.2, 512L4\
96, 512L432, 512\
L32.3, 512C29, 5\
12 25.7, 511.6 2\
2.7, 510.6C13.5,\
 507.8 6, 501 2.\
4, 492.1C1, 488.\
7 0.2, 485.2 0, \
481.4C-0.2, 477.\
7 0.3, 474.1 1.3\
, 470.7C4.1, 461\
.5 10.9, 454 19.\
9, 450.3C22.9, 4\
49.1 26.1, 448.3\
 29.4, 448.1L433\
.3, 412C441.6, 4\
11.3 448, 404.3 \
448, 395.9C448, \
391.6 446.3, 387\
.5 443.3, 384.5L\
398.9, 340.1C368\
.9, 310.1 352, 2\
69.4 352, 227L35\
2, 181.5L352, 12\
4.5zM512, 72.3C5\
12, 72.2 512, 72\
.1 512, 72C512, \
71.9 512, 71.8 5\
12, 71.7L512, 72\
.3zM510.7, 79.7L\
464.3, 68.1C464.\
1, 69.4 464, 70.\
7 464, 72C464, 8\
5.3 474.7, 96 48\
8, 96C498.6, 96 \
507.5, 89.2 510.\
7, 79.7zM130.9, \
116.5C147.2, 102\
 171.3, 100.3 18\
9.4, 112.4L320, \
199.4L320, 226.9\
C320, 259.7 328.\
4, 291.7 344, 31\
9.9L112, 319.9C1\
05.3, 319.9 99.3\
, 315.7 97, 309.\
5C94.7, 303.3 96\
.5, 296.2 101.6,\
 291.8L171, 232.\
3L18.4, 255.8C11\
.4, 256.9 4.5, 2\
53.2 1.5, 246.8C\
-1.5, 240.4 0, 2\
32.7 5.3, 228L13\
0.9, 116.5z\x22 />\x0d\
\x0a    </g>\x0d\x0a  </g\
>\x0d\x0a</svg>\
\x00\x00\x06\x99\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2.0025 -\
2.0025 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg2\x22\x0a   s\
odipodi:docname=\
\x22pen-gray.svg\x22\x0a \
  inkscape:versi\
on=\x221.4 (e7c3feb\
100, 2024-10-09)\
\x22\x0a   xmlns:inksc\
ape=\x22http://www.\
inkscape.org/nam\
espaces/inkscape\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s=\x22http://www.w3\
.org/2000/svg\x22\x0a \
  xmlns:svg=\x22htt\
p://www.w3.org/2\
000/svg\x22>\x0a  <def\
s\x0a     id=\x22defs2\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
id=\x22namedview2\x22\x0a\
     pagecolor=\x22\
#ffffff\x22\x0a     bo\
rdercolor=\x22#0000\
00\x22\x0a     bordero\
pacity=\x220.25\x22\x0a  \
   inkscape:show\
pageshadow=\x222\x22\x0a \
    inkscape:pag\
eopacity=\x220.0\x22\x0a \
    inkscape:pag\
echeckerboard=\x220\
\x22\x0a     inkscape:\
deskcolor=\x22#d1d1\
d1\x22\x0a     inkscap\
e:zoom=\x2225.21875\
\x22\x0a     inkscape:\
cx=\x2216\x22\x0a     ink\
scape:cy=\x2216\x22\x0a  \
   inkscape:wind\
ow-width=\x221920\x22\x0a\
     inkscape:wi\
ndow-height=\x22969\
\x22\x0a     inkscape:\
window-x=\x220\x22\x0a   \
  inkscape:windo\
w-y=\x220\x22\x0a     ink\
scape:window-max\
imized=\x221\x22\x0a     \
inkscape:current\
-layer=\x22svg2\x22 />\
\x0a  <g\x0a     trans\
form=\x22translate(\
-0.0019, -0.0326\
)\x22\x0a     id=\x22g2\x22\x0a\
     style=\x22fill\
:#000000;fill-op\
acity:1\x22>\x0a    <g\
\x0a       transfor\
m=\x22matrix(0.0547\
428466379642, 0,\
 0, 0.0547428466\
379642, 0, 0)\x22\x0a \
      id=\x22g1\x22\x0a  \
     style=\x22fill\
:#000000;fill-op\
acity:1\x22>\x0a      \
<path\x0a         d\
=\x22M362.7, 19.3L3\
14.3, 67.7L444.3\
, 197.7L492.7, 1\
49.3C517.7, 124.\
3 517.7, 83.8 49\
2.7, 58.8L453.3,\
 19.3C428.3, -5.\
7 387.8, -5.7 36\
2.8, 19.3zM291.7\
, 90.3L58.6, 323\
.5C48.2, 333.9 4\
0.6, 346.8 36.4,\
 360.9L1, 481.2C\
-1.5, 489.7 0.8,\
 498.8 7, 505C13\
.2, 511.2 22.3, \
513.5 30.7, 511.\
1L151, 475.7C165\
.1, 471.5 178, 4\
63.9 188.4, 453.\
5L421.7, 220.3L2\
91.7, 90.3z\x22\x0a   \
      id=\x22path1\x22\
\x0a         style=\
\x22fill:#000000;fi\
ll-opacity:1\x22 />\
\x0a    </g>\x0a  </g>\
\x0a</svg>\x0a\
\x00\x00\x0b\x9b\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-4 -4.025\
 32 32\x22\x0a   versi\
on=\x221.1\x22\x0a   id=\x22\
svg4\x22\x0a   sodipod\
i:docname=\x22pen.s\
vg\x22\x0a   inkscape:\
version=\x221.4 (86\
a8ad7, 2024-10-1\
1)\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   xmlns:sod\
ipodi=\x22http://so\
dipodi.sourcefor\
ge.net/DTD/sodip\
odi-0.dtd\x22\x0a   xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
\x0a   xmlns:svg=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a  <d\
efs\x0a     id=\x22def\
s4\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  id=\x22namedview4\
\x22\x0a     pagecolor\
=\x22#ffffff\x22\x0a     \
bordercolor=\x22#00\
0000\x22\x0a     borde\
ropacity=\x220.25\x22\x0a\
     inkscape:sh\
owpageshadow=\x222\x22\
\x0a     inkscape:p\
ageopacity=\x220.0\x22\
\x0a     inkscape:p\
agecheckerboard=\
\x220\x22\x0a     inkscap\
e:deskcolor=\x22#d1\
d1d1\x22\x0a     showg\
rid=\x22true\x22\x0a     \
inkscape:zoom=\x222\
4.3125\x22\x0a     ink\
scape:cx=\x229.4807\
198\x22\x0a     inksca\
pe:cy=\x2221.347044\
\x22\x0a     inkscape:\
window-width=\x2219\
20\x22\x0a     inkscap\
e:window-height=\
\x22996\x22\x0a     inksc\
ape:window-x=\x22-9\
\x22\x0a     inkscape:\
window-y=\x22-9\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22La\
yer_1\x22>\x0a    <ink\
scape:grid\x0a     \
  id=\x22grid4\x22\x0a   \
    units=\x22px\x22\x0a \
      originx=\x220\
\x22\x0a       originy\
=\x220\x22\x0a       spac\
ingx=\x221\x22\x0a       \
spacingy=\x221\x22\x0a   \
    empcolor=\x22#0\
099e5\x22\x0a       em\
popacity=\x220.3019\
6078\x22\x0a       col\
or=\x22#0099e5\x22\x0a   \
    opacity=\x220.1\
4901961\x22\x0a       \
empspacing=\x225\x22\x0a \
      enabled=\x22t\
rue\x22\x0a       visi\
ble=\x22true\x22 />\x0a  \
</sodipodi:named\
view>\x0a  <g\x0a     \
id=\x22Layer_1\x22\x0a   \
  transform=\x22tra\
nslate(-4.000002\
28881836, -4.025\
)\x22\x0a     style=\x22e\
nable-background\
:new 0 0 32 32\x22>\
\x0a    <g\x0a       i\
d=\x22Edit\x22>\x0a      \
<path\x0a         d\
=\x22M27.6, 8.2L23.\
8, 4.4C23.3, 3.9\
 22.4, 3.9 21.9,\
 4.4L19.4, 6.9L2\
5.2, 12.7L27.7, \
10.2C28.1, 9.6 2\
8.1, 8.8 27.6, 8\
.2z\x22\x0a         fi\
ll=\x22#D11C1C\x22\x0a   \
      class=\x22Red\
\x22\x0a         id=\x22p\
ath1\x22\x0a         s\
tyle=\x22stroke:#00\
0000;stroke-opac\
ity:1;stroke-lin\
ecap:round;strok\
e-linejoin:round\
;fill:#e96464;fi\
ll-opacity:1\x22 />\
\x0a    </g>\x0a  </g>\
\x0a  <g\x0a     id=\x22g\
2\x22\x0a     transfor\
m=\x22translate(-4,\
 -4.024998855590\
82)\x22\x0a     style=\
\x22enable-backgrou\
nd:new 0 0 32 32\
\x22>\x0a    <g\x0a      \
 id=\x22g1\x22>\x0a      \
<polygon\x0a       \
  points=\x224,22.2\
 4,28 9.8,28 \x22\x0a \
        fill=\x22#f\
fb115\x22\x0a         \
class=\x22Yellow\x22\x0a \
        id=\x22poly\
gon1\x22\x0a         s\
tyle=\x22stroke:#00\
0000;stroke-opac\
ity:1;paint-orde\
r:normal;stroke-\
linecap:round\x22\x0a \
        inkscape\
:label=\x22polygon1\
\x22\x0a         trans\
form=\x22matrix(0.8\
2823736,0,0,0.86\
77351,1.2851622,\
3.2198478)\x22 />\x0a \
   </g>\x0a  </g>\x0a \
 <g\x0a     id=\x22g4\x22\
\x0a     transform=\
\x22translate(-3.99\
999988555908, -4\
.024999559021)\x22\x0a\
     style=\x22enab\
le-background:ne\
w 0 0 32 32;pain\
t-order:normal\x22>\
\x0a    <g\x0a       i\
d=\x22g3\x22\x0a       st\
yle=\x22paint-order\
:normal\x22>\x0a      \
<rect\x0a         x\
=\x225.8000002\x22\x0a   \
      y=\x2213.4\x22\x0a \
        width=\x221\
7.6\x22\x0a         he\
ight=\x228.1999998\x22\
\x0a         fill=\x22\
#1177d7\x22\x0a       \
  class=\x22Blue\x22\x0a \
        transfor\
m=\x22matrix(0.707,\
-0.7072,0.7072,0\
.707,-8.0721,15.\
4048)\x22\x0a         \
id=\x22rect2\x22\x0a     \
    style=\x22displ\
ay:inline;stroke\
:#000000;stroke-\
width:1.00001;st\
roke-linecap:rou\
nd;stroke-linejo\
in:round;stroke-\
dasharray:none;s\
troke-opacity:1;\
paint-order:norm\
al;fill:#62aef2;\
fill-opacity:1\x22 \
/>\x0a    </g>\x0a  </\
g>\x0a</svg>\x0a\
\x00\x00\x00\x94\
[\
Icon Theme]\x0d\x0aNam\
e=ie_light\x0d\x0aComm\
ent=An example i\
con theme\x0d\x0aDirec\
tories=\x0d\x0a\x0d\x0a[]\x0d\x0aS\
ize=32\x0d\x0aType=Sca\
lable\x0d\x0aMinsize=2\
4\x0d\x0aMaxSize=64\x0d\x0aC\
ontext=Applicati\
ons\
\x00\x00\x00\x94\
[\
Icon Theme]\x0d\x0aNam\
e=ie_light\x0d\x0aComm\
ent=An example i\
con theme\x0d\x0aDirec\
tories=\x0d\x0a\x0d\x0a[]\x0d\x0aS\
ize=32\x0d\x0aType=Sca\
lable\x0d\x0aMinsize=2\
4\x0d\x0aMaxSize=64\x0d\x0aC\
ontext=Applicati\
ons\
\x00\x00\x07\x92\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2.0025 -\
2.0025 32 32\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg2\x22\x0a   s\
odipodi:docname=\
\x22spray.svg\x22\x0a   i\
nkscape:version=\
\x221.4 (86a8ad7, 2\
024-10-11)\x22\x0a   x\
mlns:inkscape=\x22h\
ttp://www.inksca\
pe.org/namespace\
s/inkscape\x22\x0a   x\
mlns:sodipodi=\x22h\
ttp://sodipodi.s\
ourceforge.net/D\
TD/sodipodi-0.dt\
d\x22\x0a   xmlns=\x22htt\
p://www.w3.org/2\
000/svg\x22\x0a   xmln\
s:svg=\x22http://ww\
w.w3.org/2000/sv\
g\x22>\x0a  <defs\x0a    \
 id=\x22defs2\x22 />\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview2\x22\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#000000\x22\x0a  \
   borderopacity\
=\x220.25\x22\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0a     in\
kscape:pageopaci\
ty=\x220.0\x22\x0a     in\
kscape:pagecheck\
erboard=\x220\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   inkscape:zoom\
=\x2224.3125\x22\x0a     \
inkscape:cx=\x2215.\
979434\x22\x0a     ink\
scape:cy=\x2216\x22\x0a  \
   inkscape:wind\
ow-width=\x221920\x22\x0a\
     inkscape:wi\
ndow-height=\x22996\
\x22\x0a     inkscape:\
window-x=\x22-9\x22\x0a  \
   inkscape:wind\
ow-y=\x22-9\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg2\x22 \
/>\x0a  <g\x0a     tra\
nsform=\x22translat\
e(-0.002, -0.002\
1)\x22\x0a     id=\x22g2\x22\
\x0a     style=\x22fil\
l:#000000;fill-o\
pacity:1\x22>\x0a    <\
g\x0a       transfo\
rm=\x22matrix(0.054\
6867102384567, 0\
, 0, 0.054686710\
2384567, 0, 0)\x22\x0a\
       id=\x22g1\x22\x0a \
      style=\x22fil\
l:#000000;fill-o\
pacity:1\x22>\x0a     \
 <path\x0a         \
d=\x22M128, 0L192, \
0C209.7, 0 224, \
14.3 224, 32L224\
, 128L96, 128L96\
, 32C96, 14.3 11\
0.3, 0 128, 0zM0\
, 256C0, 203 43,\
 160 96, 160L224\
, 160C277, 160 3\
20, 203 320, 256\
L320, 464C320, 4\
90.5 298.5, 512 \
272, 512L48, 512\
C21.5, 512 0, 49\
0.5 0, 464L0, 25\
6zM240, 336A80 8\
0 0 1 0 80, 336A\
80 80 0 1 0 240,\
 336zM256, 64A32\
 32 0 1 1 320, 6\
4A32 32 0 1 1 25\
6, 64zM384, 32A3\
2 32 0 1 1 384, \
96A32 32 0 1 1 3\
84, 32zM448, 64A\
32 32 0 1 1 512,\
 64A32 32 0 1 1 \
448, 64zM480, 12\
8A32 32 0 1 1 48\
0, 192A32 32 0 1\
 1 480, 128zM448\
, 256A32 32 0 1 \
1 512, 256A32 32\
 0 1 1 448, 256z\
M384, 128A32 32 \
0 1 1 384, 192A3\
2 32 0 1 1 384, \
128z\x22\x0a         i\
d=\x22path1\x22\x0a      \
   style=\x22fill:#\
000000;fill-opac\
ity:1\x22 />\x0a    </\
g>\x0a  </g>\x0a</svg>\
\x0a\
\x00\x00\x06\xcc\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   vi\
ewBox=\x22-2.0025 -\
3.775 32 32\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg2\x22\x0a   so\
dipodi:docname=\x22\
eraser-gray.svg\x22\
\x0a   inkscape:ver\
sion=\x221.4 (e7c3f\
eb100, 2024-10-0\
9)\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   xmlns:sod\
ipodi=\x22http://so\
dipodi.sourcefor\
ge.net/DTD/sodip\
odi-0.dtd\x22\x0a   xm\
lns=\x22http://www.\
w3.org/2000/svg\x22\
\x0a   xmlns:svg=\x22h\
ttp://www.w3.org\
/2000/svg\x22>\x0a  <d\
efs\x0a     id=\x22def\
s2\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  id=\x22namedview2\
\x22\x0a     pagecolor\
=\x22#ffffff\x22\x0a     \
bordercolor=\x22#00\
0000\x22\x0a     borde\
ropacity=\x220.25\x22\x0a\
     inkscape:sh\
owpageshadow=\x222\x22\
\x0a     inkscape:p\
ageopacity=\x220.0\x22\
\x0a     inkscape:p\
agecheckerboard=\
\x220\x22\x0a     inkscap\
e:deskcolor=\x22#d1\
d1d1\x22\x0a     inksc\
ape:zoom=\x2225.218\
75\x22\x0a     inkscap\
e:cx=\x2216\x22\x0a     i\
nkscape:cy=\x2216\x22\x0a\
     inkscape:wi\
ndow-width=\x221920\
\x22\x0a     inkscape:\
window-height=\x229\
69\x22\x0a     inkscap\
e:window-x=\x220\x22\x0a \
    inkscape:win\
dow-y=\x220\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg2\x22 \
/>\x0a  <g\x0a     tra\
nsform=\x22translat\
e(-2.144, -2.143\
7)\x22\x0a     id=\x22g2\x22\
\x0a     style=\x22fil\
l:#000000;fill-o\
pacity:1\x22>\x0a    <\
g\x0a       transfo\
rm=\x22matrix(0.055\
4079748690128, 0\
, 0, 0.055407974\
8690128, 0, 0)\x22\x0a\
       id=\x22g1\x22\x0a \
      style=\x22fil\
l:#000000;fill-o\
pacity:1\x22>\x0a     \
 <path\x0a         \
d=\x22M290.7, 57.4L\
57.4, 290.7C32.4\
, 315.7 32.4, 35\
6.2 57.4, 381.2L\
137.4, 461.2C149\
.4, 473.2 165.7,\
 479.9 182.7, 47\
9.9L288, 480L297\
.4, 480L512, 480\
C529.7, 480 544,\
 465.7 544, 448C\
544, 430.3 529.7\
, 416 512, 416L3\
87.9, 416L518.6,\
 285.3C543.6, 26\
0.3 543.6, 219.8\
 518.6, 194.8L38\
1.3, 57.4C356.3,\
 32.4 315.8, 32.\
4 290.8, 57.4zM2\
97.4, 416L288, 4\
16L182.6, 416L10\
2.6, 336L227.3, \
211.3L364.7, 348\
.7L297.4, 416z\x22\x0a\
         id=\x22pat\
h1\x22\x0a         sty\
le=\x22fill:#000000\
;fill-opacity:1\x22\
 />\x0a    </g>\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x01E\
\x00\
\x00\x05\x01x\xda\xedT\xc1j\xc30\x0c\xbd\x0f\xf6\x0f\
B;\xa4\x83\xb6\xb1\xe3et#na\x87\x9d\xd2\xdb\
v\x1eau\x1dC\x9a\x14\xc74m\x7fm\x87}\xd2\
~a\xaa\xdbd\xed`\xb71z\x98\x11\xd2\x13<\xc9\
\xb2\xe0\xf9\xe3\xed=\x99\xac\x17\x05\xac\x94\xadMU\xca\
\x80\x0fY\x00\xaa|\xadf\xa6\xd42x~z\x1c\x8c\
\x82\xc9\xf8\xf2\x22\xa9W\x1aVF5\x0f\xd5Z\xe2 \
\x022\xb13\x04jP\xd6\x12s\xe7\x96\xf7a\xd84\
\xcd\xb0\x11\xc3\xca\xea0b\x8c\x85T\x87@\x0d\x00\x12\
\x0df&1\xcd6\xca\xbep\x04g\xb3\xb2\x9eWv\
!\xd1\xc3\x22s\xaa7\x88\xfa\xd4\xfa\x1a}\x85\xaf9\
\xa2-2g\xcd\xbaG\x14\xe6\xed\x00:6\xf1\xadz\
u@\x13\x8e\x106\x12\xe9\x96\xc6\xcc\x5c.Q \xe4\
\xca\xe8\xdcyh\x89\xc1(l|\x98\x9b\xa2\x90x\xc5\
\xfcA\x08\xdb\xbbC\xbd\x9f\xbb\x8d\x7f1\xbf\xee\xe0\xb7\
\x84\xd2e\xe6r\xa0\x09\xa6\x5c\xf4\x81\xa7<j}\x9c\
\xde\x1c\x1c\xe5\xad\x8bS\x1ewA\xa4\xbef;\xf5E\
\xc2S\xbd\x1f\xf9\x06{\xcf\xc5\xf6\xc7e\x1c/\xe4\x14\
\xff\xaf\xe9|\xd7\xd4\xaa!\xf6j\xb8\xeb\xd4p\xfb\xa5\
\x06~\xcej8\x9d\x9f\xf3\xdf{@\xb2\xfb\x98\xc6\x9f\
\xca\x1c5\x0a\
\x00\x00\x04\xcb\
\xef\
\xbb\xbf<?xml version=\
'1.0' encoding='\
UTF-8'?>\x0d\x0a<svg v\
iewBox=\x22-2 -2 32\
 32\x22 xmlns=\x22http\
://www.w3.org/20\
00/svg\x22 >\x0d\x0a  <g \
transform=\x22trans\
late(0, 0)\x22>\x0d\x0a  \
  <g transform=\x22\
matrix(0.875, 0,\
 0, 0.875, 0, 0)\
\x22>\x0d\x0a      <g tra\
nsform=\x22translat\
e(0, 0)\x22>\x0d\x0a     \
   <g transform=\
\x22matrix(1.1429, \
0, 0, 1.1429, 0,\
 0)\x22>\x0d\x0a         \
 <g id=\x22Layer_1\x22\
 transform=\x22tran\
slate(-1.8666, -\
1.8666)\x22 style=\x22\
enable-backgroun\
d:new 0 0 32 32\x22\
>\x0d\x0a            <\
g transform=\x22mat\
rix(0.9333, 0, 0\
, 0.9333, 0, 0)\x22\
>\x0d\x0a             \
 <g id=\x22MoreColo\
rs\x22>\x0d\x0a          \
      <path d=\x22M\
32, 15.2C31.5, 7\
.8 25, 2 17, 2C8\
.7, 2 2, 8.3 2, \
16C2, 24.8 8.7, \
32 17, 32C18.7, \
32 20, 30.7 20, \
29C20, 27.9 19.4\
, 27 18.6, 26.4C\
18.2, 26.2 18, 2\
5.8 18, 25.3C18,\
 24.6 18.6, 24 1\
9.3, 24L19.3, 24\
L24, 24C28.4, 24\
 32, 20.4 32, 16\
C32, 15.7 32, 15\
.4 32, 15.2zM8, \
16C6.9, 16 6, 15\
.1 6, 14C6, 12.9\
 6.9, 12 8, 12C9\
.1, 12 10, 12.9 \
10, 14C10, 15.1 \
9.1, 16 8, 16zM1\
5, 12C13.3, 12 1\
2, 10.7 12, 9C12\
, 7.3 13.3, 6 15\
, 6C16.7, 6 18, \
7.3 18, 9C18, 10\
.7 16.7, 12 15, \
12zM24, 18C21.8,\
 18 20, 16.2 20,\
 14C20, 11.8 21.\
8, 10 24, 10C26.\
2, 10 28, 11.8 2\
8, 14C28, 16.2 2\
6.2, 18 24, 18z\x22\
 fill=\x22#000000\x22 \
class=\x22Black\x22 />\
\x0d\x0a              \
</g>\x0d\x0a          \
  </g>\x0d\x0a        \
  </g>\x0d\x0a        \
</g>\x0d\x0a      </g>\
\x0d\x0a    </g>\x0d\x0a  </\
g>\x0d\x0a</svg>\
"

qt_resource_name = b"\
\x00\x08\
\x0f\xdf\xb4\x87\
\x00l\
\x00i\x00g\x00h\x00t\x00s\x00v\x00g\
\x00\x07\
\x0a\x89*\x07\
\x00d\
\x00a\x00r\x00k\x00s\x00v\x00g\
\x00\x03\
\x00\x00wG\
\x00p\
\x00n\x00g\
\x00\x09\
\x0alxC\
\x00r\
\x00e\x00s\x00o\x00u\x00r\x00c\x00e\x00s\
\x00\x06\
\x07\x03}\xc3\
\x00i\
\x00m\x00a\x00g\x00e\x00s\
\x00\x0b\
\x01\x16\x80\x07\
\x00c\
\x00h\x00e\x00c\x00k\x00e\x00r\x00.\x00p\x00n\x00g\
\x00\x0d\
\x06\x84\x15g\
\x00c\
\x00h\x00e\x00c\x00k\x00e\x00r\x002\x000\x00.\x00p\x00n\x00g\
\x00\x06\
\x07\xae\xc3\xc3\
\x00t\
\x00h\x00e\x00m\x00e\x00s\
\x00\x07\
\x0f\xb5\xa8K\
\x00i\
\x00e\x00_\x00d\x00a\x00r\x00k\
\x00\x0a\
\x05x\xd4\xa7\
\x00u\
\x00p\x00l\x00o\x00a\x00d\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0ah\x03\xe7\
\x00c\
\x00u\x00r\x00s\x00o\x00r\x00.\x00s\x00v\x00g\
\x00\x08\
\x08GUg\
\x00w\
\x00a\x00n\x00d\x00.\x00s\x00v\x00g\
\x00\x08\
\x00/Wg\
\x00f\
\x00i\x00l\x00l\x00.\x00s\x00v\x00g\
\x00\x14\
\x0b\xaa\xab'\
\x00s\
\x00e\x00l\x00e\x00c\x00t\x00i\x00o\x00n\x00e\x00l\x00l\x00i\x00p\x00s\x00e\x00.\
\x00s\x00v\x00g\
\x00\x0c\
\x09\x87\xaf'\
\x00g\
\x00r\x00a\x00d\x00i\x00e\x00n\x00t\x00.\x00s\x00v\x00g\
\x00\x0d\
\x0dV,g\
\x00t\
\x00h\x00e\x00m\x00e\x00d\x00a\x00r\x00k\x00.\x00s\x00v\x00g\
\x00\x07\
\x04\xcaZ'\
\x00n\
\x00e\x00w\x00.\x00s\x00v\x00g\
\x00\x0e\
\x07,3\x87\
\x00i\
\x00n\x00s\x00p\x00e\x00c\x00t\x00i\x00o\x00n\x00.\x00s\x00v\x00g\
\x00\x13\
\x09\xe4r\xa7\
\x00s\
\x00e\x00l\x00e\x00c\x00t\x00i\x00o\x00n\x00c\x00i\x00r\x00c\x00l\x00e\x00.\x00s\
\x00v\x00g\
\x00\x08\
\x08zW\xa7\
\x00d\
\x00r\x00a\x00g\x00.\x00s\x00v\x00g\
\x00\x0b\
\x07\x8d\xbcg\
\x00u\
\x00p\x00l\x00o\x00a\x00d\x002\x00.\x00s\x00v\x00g\
\x00\x08\
\x09\x06U\xc7\
\x00r\
\x00a\x00y\x00s\x00.\x00s\x00v\x00g\
\x00\x09\
\x06D\xba\x87\
\x00i\
\x00k\x00o\x00n\x00a\x00.\x00s\x00v\x00g\
\x00\x08\
\x00HT\xa7\
\x00l\
\x00i\x00n\x00e\x00.\x00s\x00v\x00g\
\x00\x0a\
\x01\xcam\x87\
\x00b\
\x00u\x00c\x00k\x00e\x00t\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x0e\
\x00p\xc1\x87\
\x00t\
\x00h\x00e\x00m\x00e\x00l\x00i\x00g\x00h\x00t\x00.\x00s\x00v\x00g\
\x00\x0c\
\x07j\xb7\xe7\
\x00r\
\x00p\x00i\x00_\x00s\x00e\x00n\x00d\x00.\x00s\x00v\x00g\
\x00\x0b\
\x07\xc5\x96G\
\x00z\
\x00o\x00o\x00m\x00o\x00u\x00t\x00.\x00s\x00v\x00g\
\x00\x12\
\x0c\x11m\x87\
\x00f\
\x00l\x00i\x00p\x00h\x00o\x00r\x00i\x00z\x00o\x00n\x00t\x00a\x00l\x00.\x00s\x00v\
\x00g\
\x00\x11\
\x05\xb4\xe5\x87\
\x00i\
\x00n\x00v\x00e\x00r\x00t\x00-\x00c\x00o\x00l\x00o\x00r\x00s\x00.\x00s\x00v\x00g\
\
\x00\x0a\
\x08\x8b\x0b\xa7\
\x00s\
\x00q\x00u\x00a\x00r\x00e\x00.\x00s\x00v\x00g\
\x00\x0b\
\x07P<\xc7\
\x00e\
\x00l\x00l\x00i\x00p\x00s\x00e\x00.\x00s\x00v\x00g\
\x00\x0b\
\x06\x12v'\
\x00d\
\x00r\x00o\x00p\x00p\x00e\x00r\x00.\x00s\x00v\x00g\
\x00\x11\
\x0c\xc9\x99G\
\x00s\
\x00e\x00l\x00e\x00c\x00t\x00i\x00o\x00n\x00d\x00r\x00a\x00g\x00.\x00s\x00v\x00g\
\
\x00\x08\
\x06|W\x87\
\x00c\
\x00o\x00p\x00y\x00.\x00s\x00v\x00g\
\x00\x0f\
\x02\xc8\xd0'\
\x00t\
\x00h\x00e\x00m\x00e\x00s\x00y\x00s\x00t\x00e\x00m\x00.\x00s\x00v\x00g\
\x00\x0b\
\x01\x16\x8d\x87\
\x00c\
\x00h\x00e\x00c\x00k\x00e\x00r\x00.\x00s\x00v\x00g\
\x00\x08\
\x0c\xf7U\x87\
\x00t\
\x00e\x00x\x00t\x00.\x00s\x00v\x00g\
\x00\x10\
\x06\xfd#'\
\x00f\
\x00l\x00i\x00p\x00v\x00e\x00r\x00t\x00i\x00c\x00a\x00l\x00.\x00s\x00v\x00g\
\x00\x0d\
\x0fU\x0b\xa7\
\x00r\
\x00e\x00c\x00t\x00a\x00n\x00g\x00l\x00e\x00.\x00s\x00v\x00g\
\x00\x0d\
\x00\x1e\x1c\xe7\
\x00u\
\x00n\x00d\x00o\x00-\x00g\x00r\x00a\x00y\x00.\x00s\x00v\x00g\
\x00\x08\
\x09cW\x87\
\x00c\
\x00r\x00o\x00p\x00.\x00s\x00v\x00g\
\x00\x08\
\x0f\xa8W\x07\
\x00h\
\x00i\x00d\x00e\x00.\x00s\x00v\x00g\
\x00\x08\
\x09\xf8Z\x87\
\x00h\
\x00c\x00i\x00e\x00.\x00p\x00n\x00g\
\x00\x12\
\x05\x0a8\x87\
\x00r\
\x00o\x00u\x00n\x00d\x00r\x00e\x00c\x00t\x00a\x00n\x00g\x00l\x00e\x00.\x00s\x00v\
\x00g\
\x00\x07\
\x06\x81Z'\
\x00p\
\x00a\x00n\x00.\x00s\x00v\x00g\
\x00\x09\
\x00W\xb5\xe7\
\x00p\
\x00r\x00i\x00n\x00t\x00.\x00s\x00v\x00g\
\x00\x07\
\x0a\xc7Z\x07\
\x00c\
\x00u\x00t\x00.\x00s\x00v\x00g\
\x00\x16\
\x05\xc6\xe2g\
\x00s\
\x00e\x00l\x00e\x00c\x00t\x00i\x00o\x00n\x00r\x00e\x00c\x00t\x00a\x00n\x00g\x00l\
\x00e\x00.\x00s\x00v\x00g\
\x00\x0a\
\x09k\xdb\xe7\
\x00m\
\x00i\x00r\x00r\x00o\x00r\x00.\x00s\x00v\x00g\
\x00\x12\
\x01`\x9d\x07\
\x00f\
\x00u\x00l\x00l\x00s\x00c\x00r\x00e\x00e\x00n\x00e\x00x\x00i\x00t\x00.\x00s\x00v\
\x00g\
\x00\x0d\
\x09\xfe\x1c\xe7\
\x00r\
\x00e\x00d\x00o\x00-\x00g\x00r\x00a\x00y\x00.\x00s\x00v\x00g\
\x00\x0a\
\x04\x11v\x07\
\x00z\
\x00o\x00o\x00m\x00i\x00n\x00.\x00s\x00v\x00g\
\x00\x1b\
\x0a\xa5\xa2\xa7\
\x00s\
\x00e\x00r\x00i\x00a\x00l\x00-\x00p\x00o\x00r\x00t\x00-\x00s\x00v\x00g\x00r\x00e\
\x00p\x00o\x00-\x00c\x00o\x00m\x00.\x00s\x00v\x00g\
\x00\x0b\
\x07\x8e\xbcg\
\x00u\
\x00p\x00l\x00o\x00a\x00d\x003\x00.\x00s\x00v\x00g\
\x00#\
\x0eA\x9aG\
\x00e\
\x00d\x00i\x00t\x00-\x00s\x00e\x00l\x00e\x00c\x00t\x00-\x00a\x00r\x00e\x00a\x00-\
\x00r\x00e\x00c\x00t\x00a\x00n\x00g\x00l\x00e\x00-\x00d\x00a\x00s\x00h\x00.\x00s\
\x00v\x00g\
\x00\x0c\
\x0b\xdf,\xc7\
\x00s\
\x00e\x00t\x00t\x00i\x00n\x00g\x00s\x00.\x00s\x00v\x00g\
\x00\x0d\
\x0b\x0b\xc9G\
\x00z\
\x00o\x00o\x00m\x00r\x00e\x00s\x00e\x00t\x00.\x00s\x00v\x00g\
\x00\x0a\
\x09\xb2jG\
\x00c\
\x00a\x00n\x00c\x00e\x00l\x00.\x00s\x00v\x00g\
\x00\x1d\
\x0d\xfe\x94\x07\
\x00f\
\x00i\x00l\x00e\x00-\x00d\x00o\x00w\x00n\x00l\x00o\x00a\x00d\x00-\x00s\x00v\x00g\
\x00r\x00e\x00p\x00o\x00-\x00c\x00o\x00m\x00.\x00s\x00v\x00g\
\x00\x09\
\x08/\xae\xa7\
\x00s\
\x00m\x00a\x00l\x00l\x00.\x00s\x00v\x00g\
\x00\x08\
\x0f\x07WG\
\x00e\
\x00x\x00i\x00t\x00.\x00s\x00v\x00g\
\x00\x07\
\x07\x01Z'\
\x00p\
\x00i\x00n\x00.\x00s\x00v\x00g\
\x00\x08\
\x06\xc1T\x07\
\x00o\
\x00p\x00e\x00n\x00.\x00s\x00v\x00g\
\x00\x09\
\x0c\x9b\x89\xe7\
\x00b\
\x00r\x00u\x00s\x00h\x00.\x00s\x00v\x00g\
\x00\x0e\
\x03\xe6t\xa7\
\x00f\
\x00u\x00l\x00l\x00s\x00c\x00r\x00e\x00e\x00n\x00.\x00s\x00v\x00g\
\x00\x08\
\x09\xf8W\x07\
\x00h\
\x00c\x00i\x00e\x00.\x00s\x00v\x00g\
\x00\x0b\
\x05`\xc5\x87\
\x00u\
\x00n\x00i\x00c\x00o\x00d\x00e\x00.\x00s\x00v\x00g\
\x00\x06\
\x07\xb9Z\xc7\
\x00t\
\x00v\x00.\x00s\x00v\x00g\
\x00\x09\
\x0a\xa8\xb7\xc7\
\x00p\
\x00a\x00s\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x0e\
\x09\xb2m\x07\
\x00e\
\x00y\x00e\x00d\x00r\x00o\x00p\x00p\x00e\x00r\x00.\x00s\x00v\x00g\
\x00\x09\
\x07\xd8\xba\xa7\
\x00i\
\x00m\x00a\x00g\x00e\x00.\x00s\x00v\x00g\
\x00\x0b\
\x09\xdeI'\
\x00v\
\x00i\x00s\x00i\x00b\x00l\x00e\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0a-\x1b\xc7\
\x00c\
\x00i\x00r\x00c\x00l\x00e\x00.\x00s\x00v\x00g\
\x00\x08\
\x03\xc5W\xe7\
\x00b\
\x00l\x00u\x00r\x00.\x00s\x00v\x00g\
\x00\x12\
\x01\x9eQG\
\x00s\
\x00e\x00l\x00e\x00c\x00t\x00i\x00o\x00n\x00l\x00a\x00s\x00s\x00o\x00.\x00s\x00v\
\x00g\
\x00\x0a\
\x0el*'\
\x00d\
\x00r\x00a\x00g\x00o\x00n\x00.\x00s\x00v\x00g\
\x00\x07\
\x06\xc1Z'\
\x00p\
\x00e\x00n\x00.\x00s\x00v\x00g\
\x00\x0b\
\x0b\xba\x81\xb5\
\x00i\
\x00n\x00d\x00e\x00x\x00.\x00t\x00h\x00e\x00m\x00e\
\x00\x09\
\x08\x8c\xae'\
\x00s\
\x00p\x00r\x00a\x00y\x00.\x00s\x00v\x00g\
\x00\x0a\
\x09\xc8\xcb\xc7\
\x00e\
\x00r\x00a\x00s\x00e\x00r\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\xc8U\xe7\
\x00s\
\x00a\x00v\x00e\x00.\x00s\x00v\x00g\
\x00\x10\
\x0c6\xe4G\
\x00t\
\x00h\x00e\x00m\x00e\x00p\x00a\x00l\x00e\x00t\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x08\
\x0bb\xf0\x14\
\x00i\
\x00e\x00_\x00l\x00i\x00g\x00h\x00t\
\x00\x1f\
\x08,\x11G\
\x00s\
\x00e\x00r\x00i\x00a\x00l\x00-\x00p\x00o\x00r\x00t\x00-\x00s\x00v\x00g\x00r\x00e\
\x00p\x00o\x00-\x00c\x00o\x00m\x00-\x00i\x00n\x00v\x00.\x00s\x00v\x00g\
\x00&\
\x02\x16P\x07\
\x00p\
\x00i\x00c\x00t\x00o\x00g\x00r\x00a\x00m\x00m\x00e\x00r\x00s\x00-\x00m\x00a\x00t\
\x00e\x00r\x00i\x00a\x00l\x00-\x00s\x00e\x00r\x00i\x00a\x00l\x00-\x00p\x00o\x00r\
\x00t\x00.\x00s\x00v\x00g\
\x00\x0a\
\x09\xf1\x82G\
\x00p\
\x00e\x00n\x00c\x00i\x00l\x00.\x00s\x00v\x00g\
\x00\x0c\
\x06T}\x07\
\x00p\
\x00e\x00n\x00-\x00g\x00r\x00a\x00y\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00*\x00\x02\x00\x00\x00\x01\x00\x00\x00\xa5\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x16\x00\x02\x00\x00\x00\x01\x00\x00\x00V\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x04\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x006\x00\x02\x00\x00\x00\x01\x00\x00\x00\x05\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x9c\x00\x02\x00\x00\x00\x01\x00\x00\x00\x06\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x09\x82\x00\x02\x00\x00\x00O\x00\x00\x00\x07\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x04t\x00\x00\x00\x00\x00\x01\x00\x03\x80\xc8\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x01\x0c\x00\x00\x00\x00\x00\x01\x00\x02\xb3\x8b\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x02P\x00\x00\x00\x00\x00\x01\x00\x03\x04,\
\x00\x00\x01\x96\x12\xaa\x030\
\x00\x00\x05\x14\x00\x00\x00\x00\x00\x01\x00\x03\x9b.\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x02\x9a\x00\x01\x00\x00\x00\x01\x00\x03\x15\x89\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x03\xfc\x00\x01\x00\x00\x00\x01\x00\x03g\xa9\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x05\x8c\x00\x00\x00\x00\x00\x01\x00\x03\xb7\x0f\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x08\xa0\x00\x00\x00\x00\x00\x01\x00\x04o\x95\
\x00\x00\x01\x96\x12\xc5K\x90\
\x00\x00\x02f\x00\x00\x00\x00\x00\x01\x00\x03\x0b\x0a\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x09\xdc\x00\x00\x00\x00\x00\x01\x00\x03C\xc4\
\x00\x00\x01\x95\xf2?F\xa0\
\x00\x00\x03\xd8\x00\x01\x00\x00\x00\x01\x00\x03d\x1f\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x08\x8a\x00\x00\x00\x00\x00\x01\x00\x04g~\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x07\x9c\x00\x00\x00\x00\x00\x01\x00\x04$H\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x05\xd6\x00\x00\x00\x00\x00\x01\x00\x03\xc3\xd1\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x01\x8e\x00\x00\x00\x00\x00\x01\x00\x02\xd6%\
\x00\x00\x01\x96\x12\xc2\x0fp\
\x00\x00\x04\xd6\x00\x00\x00\x00\x00\x01\x00\x03\x91\xc2\
\x00\x00\x01\x96\x12\xab\xd7\xf0\
\x00\x00\x07\xd4\x00\x00\x00\x00\x00\x01\x00\x04-\xad\
\x00\x00\x01\x93S\x87z\xc0\
\x00\x00\x00\xc2\x00\x00\x00\x00\x00\x01\x00\x02\x9e\xd7\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x03 \x00\x00\x00\x00\x00\x01\x00\x035{\
\x00\x00\x01\x95\xf2;\xcc\x00\
\x00\x00\x05@\x00\x00\x00\x00\x00\x01\x00\x03\xa3+\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x03~\x00\x00\x00\x00\x00\x01\x00\x03L\xa0\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x028\x00\x01\x00\x00\x00\x01\x00\x02\xf7:\
\x00\x00\x01\x91K\xdf\x9e\x80\
\x00\x00\x0aH\x00\x00\x00\x00\x00\x01\x00\x04\x84\xf4\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x03\xc2\x00\x00\x00\x00\x00\x01\x00\x03]\xda\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x05\x00\x00\x00\x00\x00\x00\x01\x00\x03\x97\x0d\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x07n\x00\x00\x00\x00\x00\x01\x00\x04\x07\xd8\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x08\xe4\x00\x00\x00\x00\x00\x01\x00\x04\x8b\x91\
\x00\x00\x01\x96\x11M\x90\x10\
\x00\x00\x04.\x00\x00\x00\x00\x00\x01\x00\x03s\x82\
\x00\x00\x01\x96\x12\xc8\x22 \
\x00\x00\x07Z\x00\x01\x00\x00\x00\x01\x00\x04\x022\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x01\xa2\x00\x00\x00\x00\x00\x01\x00\x02\xd9\x8b\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x03b\x00\x00\x00\x00\x00\x01\x00\x03J\xea\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x03\x18\xfd\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x02\x06\x00\x00\x00\x00\x00\x01\x00\x02\xf1r\
\x00\x00\x01\x93\xbb\xfa\x86\x10\
\x00\x00\x06,\x00\x00\x00\x00\x00\x01\x00\x03\xdc{\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x07\xf0\x00\x00\x00\x00\x00\x01\x00\x04B\xb7\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x02\xda\x00\x00\x00\x00\x00\x01\x00\x03(\xfc\
\x00\x00\x01\x96\x17\xd1Q`\
\x00\x00\x08<\x00\x00\x00\x00\x00\x01\x00\x04S\x85\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x09\x98\x00\x00\x00\x00\x00\x01\x00\x03\x1a`\
\x00\x00\x01\x93\xbb\xf7\x13@\
\x00\x00\x07,\x00\x00\x00\x00\x00\x01\x00\x03\xf6\x18\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x00\xf6\x00\x00\x00\x00\x00\x01\x00\x02\xa8*\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x01\xf0\x00\x01\x00\x00\x00\x01\x00\x02\xe93\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x03H\x00\x00\x00\x00\x00\x01\x00\x03=\x0e\
\x00\x00\x01\x96\x12\xae\x0ap\
\x00\x00\x09\x14\x00\x00\x00\x00\x00\x01\x00\x04\x98`\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x09F\x00\x01\x00\x00\x00\x01\x00\x04\xa6\xc6\
\x00\x00\x01\x96\x12\xc6tp\
\x00\x00\x02\x22\x00\x01\x00\x00\x00\x01\x00\x02\xf3\xf5\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x04\x94\x00\x00\x00\x00\x00\x01\x00\x03\x8a(\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x05r\x00\x00\x00\x00\x00\x01\x00\x03\xaa\x18\
\x00\x00\x01\x96\x12\xd1\x9f\xd0\
\x00\x00\x01P\x00\x00\x00\x00\x00\x01\x00\x02\xc7m\
\x00\x00\x01\x95\xf2I)\xe0\
\x00\x00\x06\xd2\x00\x00\x00\x00\x00\x01\x00\x03\xf1Q\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x08\x1a\x00\x00\x00\x00\x00\x01\x00\x04L\xbd\
\x00\x00\x01\x95\xf29\x14\xb0\
\x00\x00\x09,\x00\x00\x00\x00\x00\x01\x00\x04\x9f\xf6\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x08T\x00\x00\x00\x00\x00\x01\x00\x04W\xd4\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x01\xc4\x00\x00\x00\x00\x00\x01\x00\x02\xe0\xd6\
\x00\x00\x01\x96\x12\xc5\xb8\xf0\
\x00\x00\x0a.\x00\x00\x00\x00\x00\x01\x00\x04\x0fR\
\x00\x00\x01\x95\xf2=\x98\xf0\
\x00\x00\x07\xbe\x00\x01\x00\x00\x00\x01\x00\x04(>\
\x00\x00\x01\x96\x0a\xdb\xff\x00\
\x00\x00\x05\xb6\x00\x00\x00\x00\x00\x01\x00\x03\xbb\x15\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x08p\x00\x00\x00\x00\x00\x01\x00\x04_e\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x00\xdc\x00\x00\x00\x00\x00\x01\x00\x02\xa2U\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x05\xf0\x00\x00\x00\x00\x00\x01\x00\x03\xcd\xb8\
\x00\x00\x01\x94\x11xr\xf0\
\x00\x00\x08\x02\x00\x00\x00\x00\x00\x01\x00\x04D\x8f\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x05,\x00\x00\x00\x00\x00\x01\x00\x03\x9e\xa4\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x06\xb2\x00\x00\x00\x00\x00\x01\x00\x03\xe9J\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x01\x22\x00\x00\x00\x00\x00\x01\x00\x02\xbc*\
\x00\x00\x01\x95\xf2E\x97\xd0\
\x00\x00\x08\xf8\x00\x00\x00\x00\x00\x01\x00\x04\x970\
\x00\x00\x01\x96\x11n\xfa\xc0\
\x00\x00\x08\xf8\x00\x00\x00\x00\x00\x01\x00\x04\x97\xc8\
\x00\x00\x01\x96\x11n\xfa\xc0\
\x00\x00\x06\x94\x00\x00\x00\x00\x00\x01\x00\x03\xe2\x07\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x02\xf6\x00\x00\x00\x00\x00\x01\x00\x03!\xf6\
\x00\x00\x01\x96\x12\xc7\xa5 \
\x00\x00\x09\x5c\x00\x00\x00\x00\x00\x01\x00\x04\xa8\x0f\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x07\x84\x00\x00\x00\x00\x00\x01\x00\x04\x16[\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x02\x80\x00\x00\x00\x00\x00\x01\x00\x03\x0dx\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x03\x9a\x00\x00\x00\x00\x00\x01\x00\x03U\xe0\
\x00\x00\x01\x95\xf2E\x0b0\
\x00\x00\x04\x18\x00\x00\x00\x00\x00\x01\x00\x03j\xba\
\x00\x00\x01\x96\x12\xae\xfc\xa0\
\x00\x00\x01n\x00\x01\x00\x00\x00\x01\x00\x02\xd2\xa1\
\x00\x00\x01\x96\x12\xc4x\xa0\
\x00\x00\x06\xec\x00\x00\x00\x00\x00\x01\x00\x03\xf3\xa4\
\x00\x00\x01\x93\xbb\xf9&\x80\
\x00\x00\x06H\x00\x00\x00\x00\x00\x01\x00\x03\xdf@\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x08\xca\x00\x00\x00\x00\x00\x01\x00\x04~v\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x07D\x00\x00\x00\x00\x00\x01\x00\x03\xfa\x1e\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x04T\x00\x00\x00\x00\x00\x01\x00\x03z\x8b\
\x00\x00\x01\x96\x12\xaa\xc6\x80\
\x00\x00\x04\xaa\x00\x00\x00\x00\x00\x01\x00\x03\x8d\x01\
\x00\x00\x01\x96\x12\xc4p\xd0\
\x00\x00\x006\x00\x02\x00\x00\x00\x01\x00\x00\x00W\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x9c\x00\x02\x00\x00\x00\x01\x00\x00\x00X\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\xae\x00\x02\x00\x00\x00L\x00\x00\x00Y\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x04t\x00\x00\x00\x00\x00\x01\x00\x00\xf0c\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x01\x0c\x00\x00\x00\x00\x00\x01\x00\x00\x1a\x05\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x02P\x00\x00\x00\x00\x00\x01\x00\x00w\xad\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x05\x14\x00\x00\x00\x00\x00\x01\x00\x01f\x5c\
\x00\x00\x01\x96\x16\x93\xd0 \
\x00\x00\x02\x9a\x00\x01\x00\x00\x00\x01\x00\x00\x8c\xee\
\x00\x00\x01\x96\x16\x9eWp\
\x00\x00\x03\xfc\x00\x01\x00\x00\x00\x01\x00\x00\xd7\x0f\
\x00\x00\x01\x96\x12\xdf\xd0\xa0\
\x00\x00\x05\x8c\x00\x00\x00\x00\x00\x01\x00\x01\x8e\x1b\
\x00\x00\x01\x96\x16\x8990\
\x00\x00\x08\xa0\x00\x00\x00\x00\x00\x01\x00\x02f\x7f\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x02f\x00\x00\x00\x00\x00\x01\x00\x00~\x8b\
\x00\x00\x01\x96\x16\xb1\x14P\
\x00\x00\x03\xd8\x00\x01\x00\x00\x00\x01\x00\x00\xd3\x89\
\x00\x00\x01\x96\x12\xd5h\x90\
\x00\x00\x08\x8a\x00\x00\x00\x00\x00\x01\x00\x02[\xeb\
\x00\x00\x01\x96\x16\x97\xb0P\
\x00\x00\x07\x9c\x00\x00\x00\x00\x00\x01\x00\x02\x0b\xc5\
\x00\x00\x01\x96\x16\x88\xc4\x00\
\x00\x00\x05\xd6\x00\x00\x00\x00\x00\x01\x00\x01\x9f!\
\x00\x00\x01\x96\x12\xd5h\x90\
\x00\x00\x01\x8e\x00\x00\x00\x00\x00\x01\x00\x00<\xbc\
\x00\x00\x01\x96\x16{\xcb\xb0\
\x00\x00\x04\xd6\x00\x00\x00\x00\x00\x01\x00\x01Vo\
\x00\x00\x01\x96\x16\x93\x14\xa0\
\x00\x00\x07\xd4\x00\x00\x00\x00\x00\x01\x00\x02\x19v\
\x00\x00\x01\x96\x12\xd5h\x90\
\x00\x00\x00\xc2\x00\x00\x00\x00\x00\x01\x00\x00\x01-\
\x00\x00\x01\x96\x16\x88\x1f\xf0\
\x00\x00\x03 \x00\x00\x00\x00\x00\x01\x00\x00\xa71\
\x00\x00\x01\x96\x16j^\xc0\
\x00\x00\x05@\x00\x00\x00\x00\x00\x01\x00\x01w\xbc\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x03~\x00\x00\x00\x00\x00\x01\x00\x00\xbb\xef\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x028\x00\x01\x00\x00\x00\x01\x00\x00j\xb7\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x03\xc2\x00\x00\x00\x00\x00\x01\x00\x00\xcdD\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x05\x00\x00\x00\x00\x00\x00\x01\x00\x01^/\
\x00\x00\x01\x96\x16\xb5\x0b\xf0\
\x00\x00\x07n\x00\x00\x00\x00\x00\x01\x00\x01\xf6^\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x08\xe4\x00\x00\x00\x00\x00\x01\x00\x02{\xde\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x04.\x00\x00\x00\x00\x00\x01\x00\x00\xe2\xfe\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x07Z\x00\x01\x00\x00\x00\x01\x00\x01\xee~\
\x00\x00\x01\x96\x16\x86\xef@\
\x00\x00\x01\xa2\x00\x00\x00\x00\x00\x01\x00\x00D*\
\x00\x00\x01\x96\x16\xb9\x900\
\x00\x00\x03b\x00\x00\x00\x00\x00\x01\x00\x00\xb5r\
\x00\x00\x01\x96\x16\x8e\xee \
\x00\x00\x02\xbc\x00\x00\x00\x00\x00\x01\x00\x00\x92\x99\
\x00\x00\x01\x96\x16[;\xc0\
\x00\x00\x02\x06\x00\x00\x00\x00\x00\x01\x00\x00d\x80\
\x00\x00\x01\x96\x12\xd5h\x90\
\x00\x00\x06,\x00\x00\x00\x00\x00\x01\x00\x01\xb7\xcb\
\x00\x00\x01\x96\x12\xd5h\x90\
\x00\x00\x07\xf0\x00\x00\x00\x00\x00\x01\x00\x02.\x80\
\x00\x00\x01\x96\x12\xd5h\x90\
\x00\x00\x02\xda\x00\x00\x00\x00\x00\x01\x00\x00\x97\xd1\
\x00\x00\x01\x96\x12\xd5h\x90\
\x00\x00\x08<\x00\x00\x00\x00\x00\x01\x00\x02?\x8b\
\x00\x00\x01\x96\x16\xb7'\x00\
\x00\x00\x07,\x00\x00\x00\x00\x00\x01\x00\x01\xe2d\
\x00\x00\x01\x96\x12\xd5h\x90\
\x00\x00\x00\xf6\x00\x00\x00\x00\x00\x01\x00\x00\x0e\xa4\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x01\xf0\x00\x01\x00\x00\x00\x01\x00\x00Y\x9d\
\x00\x00\x01\x96\x16\xac\x03p\
\x00\x00\x03H\x00\x00\x00\x00\x00\x01\x00\x00\xae\xbc\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x09\x14\x00\x00\x00\x00\x00\x01\x00\x02\x88\xab\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x09F\x00\x01\x00\x00\x00\x01\x00\x02\x97\x11\
\x00\x00\x01\x96\x16\x84\x8d\xe0\
\x00\x00\x02\x22\x00\x01\x00\x00\x00\x01\x00\x00g\x03\
\x00\x00\x01\x96\x16\x9bR\x00\
\x00\x00\x04\x94\x00\x00\x00\x00\x00\x01\x00\x00\xf9\xc3\
\x00\x00\x01\x96\x16\x8eB@\
\x00\x00\x05r\x00\x00\x00\x00\x00\x01\x00\x01~\xa9\
\x00\x00\x01\x96\x16\x98\xd1`\
\x00\x00\x01P\x00\x00\x00\x00\x00\x01\x00\x00.\x05\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x06\xd2\x00\x00\x00\x00\x00\x01\x00\x01\xd9\x84\
\x00\x00\x01\x96\x16\xabO\xc0\
\x00\x00\x08\x1a\x00\x00\x00\x00\x00\x01\x00\x028\x86\
\x00\x00\x01\x96\x16l\xfe\xa0\
\x00\x00\x09,\x00\x00\x00\x00\x00\x01\x00\x02\x90A\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x08T\x00\x00\x00\x00\x00\x01\x00\x02H[\
\x00\x00\x01\x96\x16zl \
\x00\x00\x01\xc4\x00\x00\x00\x00\x00\x01\x00\x00Q@\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x07\xbe\x00\x01\x00\x00\x00\x01\x00\x02\x14\x07\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x04\xc0\x00\x00\x00\x00\x00\x01\x00\x01\x0a\xdc\
\x00\x00\x01\x96\x0b\x0eq\x10\
\x00\x00\x05\xb6\x00\x00\x00\x00\x00\x01\x00\x01\x96e\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x08p\x00\x00\x00\x00\x00\x01\x00\x02S\xd2\
\x00\x00\x01\x96\x16b\xf4P\
\x00\x00\x00\xdc\x00\x00\x00\x00\x00\x01\x00\x00\x08\xcf\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x05\xf0\x00\x00\x00\x00\x00\x01\x00\x01\xa9\x08\
\x00\x00\x01\x96\x16s\xcc\xd0\
\x00\x00\x08\x02\x00\x00\x00\x00\x00\x01\x00\x020X\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x05,\x00\x00\x00\x00\x00\x01\x00\x01o!\
\x00\x00\x01\x96\x16_\x1b\xf0\
\x00\x00\x06\xb2\x00\x00\x00\x00\x00\x01\x00\x01\xd1}\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x01\x22\x00\x00\x00\x00\x00\x01\x00\x00\x22\xa4\
\x00\x00\x01\x96\x16q\x15\x80\
\x00\x00\x08\xf8\x00\x00\x00\x00\x00\x01\x00\x02\x88\x14\
\x00\x00\x01\x96\x11n\xfa\xc0\
\x00\x00\x08\xf8\x00\x00\x00\x00\x00\x01\x00\x02\x87}\
\x00\x00\x01\x96\x11n\xfa\xc0\
\x00\x00\x06\x94\x00\x00\x00\x00\x00\x01\x00\x01\xc5M\
\x00\x00\x01\x96\x16t\xfd\x80\
\x00\x00\x02\xf6\x00\x00\x00\x00\x00\x01\x00\x00\xa0+\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x09\x5c\x00\x00\x00\x00\x00\x01\x00\x02\x9a\x08\
\x00\x00\x01\x96\x12\xd5h\x90\
\x00\x00\x07\x84\x00\x00\x00\x00\x00\x01\x00\x01\xfd\xd8\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x02\x80\x00\x00\x00\x00\x00\x01\x00\x00\x84\xe2\
\x00\x00\x01\x96\x16_y\xb0\
\x00\x00\x03\x9a\x00\x00\x00\x00\x00\x01\x00\x00\xc5/\
\x00\x00\x01\x96\x16p\xaf\xf0\
\x00\x00\x04\x18\x00\x00\x00\x00\x00\x01\x00\x00\xda6\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x01n\x00\x01\x00\x00\x00\x01\x00\x0099\
\x00\x00\x01\x96\x12\xd5h\x90\
\x00\x00\x06\xec\x00\x00\x00\x00\x00\x01\x00\x01\xdf\xf0\
\x00\x00\x01\x96\x12\xd5h\x90\
\x00\x00\x06H\x00\x00\x00\x00\x00\x01\x00\x01\xba\x90\
\x00\x00\x01\x96\x16\xae\xda\x00\
\x00\x00\x08\xca\x00\x00\x00\x00\x00\x01\x00\x02u`\
\x00\x00\x01\x95\xf22]\xf0\
\x00\x00\x07D\x00\x00\x00\x00\x00\x01\x00\x01\xe6j\
\x00\x00\x01\x96\x16c\xb7\xa0\
\x00\x00\x04T\x00\x00\x00\x00\x00\x01\x00\x00\xea\x07\
\x00\x00\x01\x96\x16\x80\xe4`\
\x00\x00\x04\xaa\x00\x00\x00\x00\x00\x01\x00\x01\x00\xbe\
\x00\x00\x01\x96\x16\x85\x87\xe0\
\x00\x00\x006\x00\x02\x00\x00\x00\x01\x00\x00\x00\xa6\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00N\x00\x02\x00\x00\x00\x02\x00\x00\x00\xa7\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00`\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x95\x81\xcc\x130\
\x00\x00\x00|\x00\x00\x00\x00\x00\x01\x00\x00\x00\xa3\
\x00\x00\x01\x96^\xa5/0\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
