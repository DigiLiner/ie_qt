import os
import sys

from logging import exception
import PySide6
from PySide6.QtCore import Qt
from PySide6 import QtWidgets, QtCore
from PySide6.QtCore import QRect
from PySide6.QtGui import QPen, QColor, QBrush, QImage, QPainter, QMouseEvent, QIcon
import PySide6.QtGui
from PySide6.QtWidgets import (QWidget,QApplication, QMainWindow, QGraphicsScene, QLabel, QHBoxLayout,
                               QDialog, QVBoxLayout, QGroupBox, QRadioButton, QSlider, QSpinBox, QDialogButtonBox, QCheckBox, QFileDialog, QInputDialog)
from typing import Type, cast

import ie_globals,ie_editor,yedekle
from main_ui import Ui_MainWindow
from float_window_ui import Ui_floatWindow as float_window_ui


class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        yedekle.yedekle()
        QMainWindow.__init__(self)
        self.colorHeight = None
        self.colorWidth = None
        self.colors = None
        self.ui = Ui_MainWindow()
        self.setupUi(self)
        self.old_tool_button = None


        # Load settings first
        ie_globals.load_settings()

        self.tabWidget.removeTab(0)
        import ie_editor
        self.tabWidget.addTab(ie_editor.Editor(), "Picture" + str(ie_globals.filenamecounter))
        self.tabWidget.setCurrentIndex(self.tabWidget.count() - 1)
        ie_globals.filenamecounter += 1
        self.tabifyDockWidget(self.dwTools, self.dwFilters)
        self.dwTools.raise_()

        self.actionOpen.triggered.connect(self.open_file)
        self.actionSave.triggered.connect(self.save_file)
        self.actionNew.triggered.connect(self.new_file)
        self.actionUndo.triggered.connect(self.undo)
        self.actionRedo.triggered.connect(self.redo)
        self.dwColorBox.dockLocationChanged.connect(self.colorBox)

        self.actionGenerateImage = PySide6.QtGui.QAction("Generate Image...")
        self.menuFile.addAction(self.actionGenerateImage)
        self.actionGenerateImage.triggered.connect(self.generate_image)

        self.actionRemoveObject = PySide6.QtGui.QAction("Remove Object (AI)...")
        self.menuFile.addAction(self.actionRemoveObject)
        self.actionRemoveObject.triggered.connect(self.remove_object)

        self.actionBlur.triggered.connect(self.filter_blur)
        self.toolButton_blur.clicked.connect(self.filter_blur)
        self.actionMelt.triggered.connect(self.filter_melt)
        self.toolButton_melt.clicked.connect(self.filter_melt)
        self.actionMosaic.triggered.connect(self.filter_mosaic)
        self.toolButton_mosaic.clicked.connect(self.filter_mosaic)
        self.actionShear.triggered.connect(self.filter_shear)
        self.toolButton_shear.clicked.connect(self.filter_shear)
        self.actionSepia.triggered.connect(self.filter_sepia)
        self.toolButton_sepia.clicked.connect(self.filter_sepia)

        self.actionGaussianBlur = PySide6.QtGui.QAction("Gaussian Blur")
        self.menuBlur.addAction(self.actionGaussianBlur)
        self.actionGaussianBlur.triggered.connect(self.filter_gaussian_blur)

        self.closeEvent = self.close_event

        for obj in self.dwTools.findChildren(QtWidgets.QToolButton):
            self.set_button_events(obj)

        self.setSvgColors()
        self.widgetColors.setMouseTracking(True)
        self.widgetColors.mousePressEvent = self.colorbox_on_click

        self.horizontalSlider_width.valueChanged.connect(self.on_slider_change_width)
        self.horizontalSlider_radius.valueChanged.connect(self.on_slider_change_radius)
        self.horizontalSlider_density.valueChanged.connect(self.on_slider_change_density)
        self.horizontalSlider_softness.valueChanged.connect(self.on_slider_change_softness)
        self.horizontalSlider_opacity.valueChanged.connect(self.on_slider_change_opacity)
        self.horizontalSlider_tolerance.valueChanged.connect(self.on_slider_change_tolerance)

        self.disable_slider_events = False
        self.toolButtonBrushSettings.clicked.connect(self.open_brush_dialog)

        self.statusLabel = QLabel(self.statusbar)
        self.statusLabel.setMinimumSize(500, 20)
        self.colorBox()

        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.timer_update)
        self.timer.start(200)

        # Set initial tool and update sliders
        self.on_tool_button_click(self.toolButtonPen)

    def set_button_events(self, tool_button: QtWidgets.QToolButton):
        tool_button.setMouseTracking(True)
        # Use a lambda to capture the specific button being clicked
        tool_button.clicked.connect(lambda: self.on_tool_button_click(tool_button))

    def update_sliders_for_tool(self, tool_name: str):
        """Updates the UI sliders based on the selected tool's settings."""
        self.disable_slider_events = True
        
        settings = ie_globals.tool_settings.get(tool_name, {})
        
        # Helper to set visibility and value
        def setup_slider(slider, label, setting_key, is_visible, min_val=0, max_val=100):
            label.setVisible(is_visible)
            slider.setVisible(is_visible)
            if is_visible:
                slider.setRange(min_val, max_val)
                slider.setValue(settings.get(setting_key, (min_val + max_val) // 2))

        # Width/Size (Common for many tools)
        has_width = "width" in settings
        setup_slider(self.horizontalSlider_width, self.label_width, "width", has_width, 1, 300)
        
        # Hardness (Brush, Eraser)
        has_hardness = "hardness" in settings
        setup_slider(self.horizontalSlider_softness, self.label_softness, "hardness", has_hardness, 0, 100)
        
        # Opacity (Most drawing tools)
        has_opacity = "opacity" in settings
        setup_slider(self.horizontalSlider_opacity, self.label_5, "opacity", has_opacity, 0, 100)
        
        # Tolerance (Fill, Wand)
        has_tolerance = "tolerance" in settings
        setup_slider(self.horizontalSlider_tolerance, self.label_6, "tolerance", has_tolerance, 0, 255)
        
        # Density (Spray)
        has_density = "density" in settings
        setup_slider(self.horizontalSlider_density, self.label_3, "density", has_density, 1, 100)
        
        # Radius (Spray - uses width setting)
        self.label_2_radius.setVisible(tool_name == "spray")
        self.horizontalSlider_radius.setVisible(tool_name == "spray")
        if tool_name == "spray":
            self.horizontalSlider_radius.setRange(1, 300)
            self.horizontalSlider_radius.setValue(settings.get("width", 50))

        self.disable_slider_events = False

    def on_tool_button_click(self, tool_button: QtWidgets.QToolButton):
        tool_map = {
            "toolButtonPen": "pen",
            "toolButtonBrush": "brush",
            "toolButtonEraser": "eraser",
            "toolButtonLine": "line",
            "toolButtonRectangle": "rect",
            "toolButtonRoundRectangle": "round_rect",
            "toolButtonCircle": "circle",
            "toolButtonCircleOutline": "circle_outline",
            "toolButtonSpray": "spray",
            "toolButtonFill": "fill",
            "toolButtonWand": "wand",
            "toolButtonDropper": "dropper",
            "toolButtonSelectRectangle": "select_rect",
            "toolButtonSelectCircle": "select_circle",
        }
        
        tool_name = tool_map.get(tool_button.objectName())

        # Handle non-tool buttons separately
        if tool_name is None:
            if tool_button.objectName() == "toolButtonClearSelection":
                self.clear_selection()
            # ... other non-tool buttons
            return

        # Set the current tool name
        ie_globals.current_tool_name = tool_name
        
        # Update UI sliders to reflect the new tool's settings
        self.update_sliders_for_tool(tool_name)
        
        # Update legacy globals for drawing functions
        ie_globals.update_legacy_globals(tool_name)

        # Update button styles
        if self.old_tool_button and self.old_tool_button != tool_button:
            self.old_tool_button.setChecked(False)
        tool_button.setCheckable(True)
        tool_button.setChecked(True)
        self.old_tool_button = tool_button

        ie_globals.statusText.tool = f"Mode: {tool_name}"

    def on_slider_change(self, setting_key: str, value: int):
        """A generic function to handle slider changes."""
        if self.disable_slider_events:
            return
        
        tool_name = ie_globals.current_tool_name
        if tool_name in ie_globals.tool_settings and setting_key in ie_globals.tool_settings[tool_name]:
            ie_globals.tool_settings[tool_name][setting_key] = value
            
            # Special case for spray radius, which is linked to width
            if tool_name == "spray" and setting_key == "width":
                 ie_globals.tool_settings[tool_name]["density"] = value

            ie_globals.update_legacy_globals(tool_name)
            ie_globals.save_settings()

    def on_slider_change_width(self, value):
        self.on_slider_change("width", value)
        if ie_globals.current_tool_name == "spray":
            self.disable_slider_events = True
            self.horizontalSlider_radius.setValue(value)
            self.disable_slider_events = False

    def on_slider_change_radius(self, value):
        # This is only for spray, and it controls the 'width' setting
        self.on_slider_change("width", value)
        self.disable_slider_events = True
        self.horizontalSlider_width.setValue(value)
        self.disable_slider_events = False

    def on_slider_change_density(self, value):
        self.on_slider_change("density", value)

    def on_slider_change_softness(self, value):
        self.on_slider_change("hardness", value)

    def on_slider_change_opacity(self, value):
        self.on_slider_change("opacity", value)

    def on_slider_change_tolerance(self, value):
        self.on_slider_change("tolerance", value)

    def generate_image(self):
        prompt, ok = QInputDialog.getText(self, "Generate Image from Prompt", "Enter a prompt:")
        if ok and prompt:
            import ie_editor
            doc = ie_editor.Editor()
            self.tabWidget.addTab(doc, "Generated - " + prompt[:20])
            self.tabWidget.setCurrentWidget(doc)
            doc.generate_image_from_prompt(prompt)

    def remove_object(self):
        import ie_editor
        activeDoc = self.tabWidget.currentWidget()
        if isinstance(activeDoc, ie_editor.Editor):
            activeDoc.remove_object_with_ai()

    def add_brush_controls(self):
        self.toolButtonBrushSettings.clicked.connect(self.open_brush_dialog)

    def open_brush_dialog(self):
        # This can be simplified or removed if all settings are on the main panel
        dialog = QDialog(self)
        dialog.setWindowTitle("Brush Settings")
        layout = QVBoxLayout(dialog)
        label = QLabel("Brush settings are now controlled from the main panel.")
        layout.addWidget(label)
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok)
        button_box.accepted.connect(dialog.accept)
        layout.addWidget(button_box)
        dialog.exec()

    def clear_selection(self):
        ie_globals.has_selection = False
        ie_globals.selection_region = None
        # ... reset other selection globals
        current_widget = self.tabWidget.currentWidget()
        if isinstance(current_widget, ie_editor.Editor):
            current_widget.update()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape and ie_globals.has_selection:
            self.clear_selection()
        super().keyPressEvent(event)

    def timer_update(self):
        self.statusLabel.setText(f"{ie_globals.statusText.tool} | Pos: {ie_globals.statusText.pos} | Zoom: {ie_globals.statusText.zoom}")
        self.repaint()

    def open_file(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Open File", ".", "Image Files (*.png *.jpg *.jpeg *.gif)")
        if filename:
            import ie_editor
            doc = ie_editor.Editor(image_path=filename)
            doc.picOrg = QImage(filename)
            # Important: After loading, we need to resize the editor widget to the image size
            doc.widgetPicture1.setFixedSize(doc.picOrg.size())
            doc.pic1_update()
            self.tabWidget.addTab(doc, os.path.basename(filename))
            self.tabWidget.setCurrentWidget(doc)


    def save_file(self):
        import ie_editor
        activeDoc = self.tabWidget.currentWidget()
        if isinstance(activeDoc, ie_editor.Editor):
            # Suggest a filename if the document was opened from a file
            suggested_path = activeDoc.image_path if activeDoc.image_path else os.getcwd()
            filename, _ = QFileDialog.getSaveFileName(self, "Save File", suggested_path, "PNG Image (*.png);;JPEG Image (*.jpg *.jpeg)")
            if filename:
                activeDoc.picOrg.save(filename)
                # Update tab text and image_path after saving
                self.tabWidget.setTabText(self.tabWidget.currentIndex(), os.path.basename(filename))
                activeDoc.image_path = filename


    def new_file(self):
        import dialog_newImage_ui
        dialog = dialog_newImage_ui.Ui_Dialog()
        dialog_instance = QtWidgets.QDialog()
        dialog.setupUi(dialog_instance)
        
        sizes = ["100x100", "500x500", "800x600", "1024x768", "1280x1024", "1600x1200", "1920x1080", "2048x1536"]
        dialog.comboBoxSizeList.addItems(sizes)
        dialog.comboBoxSizeList.setCurrentIndex(3)

        def update_text_fields(selected_text):
            try:
                w_str, h_str = selected_text.replace(',', 'x').split('x')
                dialog.plainTextEditWidth.setPlainText(w_str)
                dialog.plainTextEditHeight.setPlainText(h_str)
            except ValueError:
                pass

        dialog.comboBoxSizeList.currentTextChanged.connect(update_text_fields)
        update_text_fields(dialog.comboBoxSizeList.currentText())

        if dialog_instance.exec() == QtWidgets.QDialog.DialogCode.Accepted:
            try:
                w = int(dialog.plainTextEditWidth.toPlainText())
                h = int(dialog.plainTextEditHeight.toPlainText())
            except (ValueError, TypeError):
                w, h = 1024, 768

            import ie_editor
            doc = ie_editor.Editor(width=w, height=h)
            self.tabWidget.addTab(doc, "Untitled-" + str(ie_globals.filenamecounter))
            ie_globals.filenamecounter += 1
            self.tabWidget.setCurrentWidget(doc)

    def undo(self):
        activeDoc = self.tabWidget.currentWidget()
        if isinstance(activeDoc, ie_editor.Editor):
            activeDoc.undoImage()

    def redo(self):
        activeDoc = self.tabWidget.currentWidget()
        if isinstance(activeDoc, ie_editor.Editor):
            activeDoc.redoImage()

    def _create_slider_dialog(self, title, label, min_val, max_val, initial_val):
        dialog = QDialog(self)
        dialog.setWindowTitle(title)
        layout = QVBoxLayout(dialog)
        group = QGroupBox(label)
        h_layout = QHBoxLayout()
        slider = QSlider(Qt.Orientation.Horizontal)
        slider.setRange(min_val, max_val)
        slider.setValue(initial_val)
        spinbox = QSpinBox()
        spinbox.setRange(min_val, max_val)
        spinbox.setValue(initial_val)
        slider.valueChanged.connect(spinbox.setValue)
        spinbox.valueChanged.connect(slider.setValue)
        h_layout.addWidget(slider)
        h_layout.addWidget(spinbox)
        group.setLayout(h_layout)
        layout.addWidget(group)
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)
        layout.addWidget(button_box)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return slider.value()
        return None

    def filter_blur(self):
        activeDoc = self.tabWidget.currentWidget()
        if not isinstance(activeDoc, ie_editor.Editor): return
        val = self._create_slider_dialog("Blur Filter", "Radius", 1, 100, ie_globals.blur_radius)
        if val is not None:
            ie_globals.blur_radius = val
            activeDoc.apply_blur_filter()

    def filter_gaussian_blur(self):
        activeDoc = self.tabWidget.currentWidget()
        if not isinstance(activeDoc, ie_editor.Editor): return
        val = self._create_slider_dialog("Gaussian Blur Filter", "Radius", 1, 100, ie_globals.gaussian_blur_radius)
        if val is not None:
            ie_globals.gaussian_blur_radius = val
            activeDoc.apply_gaussian_blur_filter()

    def filter_melt(self):
        activeDoc = self.tabWidget.currentWidget()
        if not isinstance(activeDoc, ie_editor.Editor): return
        val = self._create_slider_dialog("Melt Filter", "Amount", 1, 100, ie_globals.melt_amount)
        if val is not None:
            ie_globals.melt_amount = val
            activeDoc.apply_melt_filter()

    def filter_mosaic(self):
        activeDoc = self.tabWidget.currentWidget()
        if not isinstance(activeDoc, ie_editor.Editor): return
        val = self._create_slider_dialog("Mosaic Filter", "Block Size", 2, 100, ie_globals.mosaic_block_size)
        if val is not None:
            ie_globals.mosaic_block_size = val
            activeDoc.apply_mosaic_filter()

    def filter_sepia(self):
        activeDoc = self.tabWidget.currentWidget()
        if not isinstance(activeDoc, ie_editor.Editor): return
        activeDoc.apply_sepia_filter()

    def filter_shear(self):
        activeDoc = self.tabWidget.currentWidget()
        if not isinstance(activeDoc, ie_editor.Editor): return
        # ... (dialog implementation)
        pass

    def colorBox(self):
        # ... (implementation unchanged)
        pass

    def colorbox_on_click(self, event:QMouseEvent):
        img = self.widgetColors.grab()
        color = img.toImage().pixelColor(event.pos())
        
        # Update the color for the current tool, preserving its opacity
        tool_name = ie_globals.current_tool_name
        opacity = ie_globals.tool_settings.get(tool_name, {}).get("opacity", 100)
        color.setAlphaF(opacity / 100.0)
        
        # Update the global pen and brush for immediate visual feedback
        ie_globals.current_pen.setColor(color)
        ie_globals.current_brush.setColor(color)
        
        self.repaint()

    def paintEvent(self, event):
        # ... (implementation unchanged)
        pass

    def close_event(self, event):
        ie_globals.save_settings() # Save settings on close
        super(MainWindow, self).closeEvent(event)

    def setSvgColors(self):
        # ... (implementation unchanged)
        pass

if __name__ == "__main__":
    os.environ["QT_ENABLE_HIGHDPI_SCALING"] = "0"
    os.environ["QT_AUTO_SCREEN_SCALE_FACTOR"] = "1"
    os.environ["QT_SCALE_FACTOR"] = "1"
    app = QApplication(sys.argv)
    app.setApplicationName("HC Image Editor")
    app.setOrganizationName("HC")
    app.setApplicationVersion("2.9.3")
    app.setAttribute(Qt.ApplicationAttribute.AA_Use96Dpi)
    app.setStyle("macOS")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
