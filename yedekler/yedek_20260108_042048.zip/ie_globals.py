import json
import os
from dataclasses import dataclass, field
from enum import Enum, auto
from PySide6.QtGui import QPen, QColor, QBrush, QImage, QRegion, QFont
from PySide6.QtCore import QRect, QPoint

# --- Enums and Data Classes ---

class Tool(Enum):
    PEN = auto()
    BRUSH = auto()
    LINE = auto()
    RECT = auto()
    ROUND_RECT = auto()
    CIRCLE = auto()
    CIRCLE_OUTLINE = auto()
    SPRAY = auto()
    FILL = auto()
    ERASER = auto()
    WAND = auto()
    DROPPER = auto()
    CROP = auto()
    SELECT_RECT = auto()
    SELECT_CIRCLE = auto()

@dataclass
class StatusText:
    tool: str = "Current Tool: None"
    pos: str = "Mouse Position: 0, 0"
    zoom: str = "Zoom: 1.00"

@dataclass
class Layer:
    name: str
    visible: bool = True
    opacity: int = 100
    image: QImage | None = None
    rasterized: bool = True
    locked: bool = False
    active: bool = False
    id: int = -1

# --- Global Variables ---

# Application settings
filenamecounter: int = 1
max_undo_steps: int = 20
image_width: int = 1024
image_height: int = 768
zoomInFactor: float = 1.25
zoomOutFactor: float = 0.8

# Tool settings will be stored here
tool_settings = {}

# Default settings for each tool
def get_default_tool_settings():
    return {
        "pen": {"width": 5, "opacity": 100, "hardness": 100},
        "brush": {"width": 50, "opacity": 100, "hardness": 50},
        "eraser": {"width": 50, "opacity": 100, "hardness": 100},
        "line": {"width": 5, "opacity": 100},
        "rect": {"width": 2, "opacity": 100},
        "round_rect": {"width": 2, "opacity": 100},
        "circle": {"width": 2, "opacity": 100},
        "circle_outline": {"width": 2, "opacity": 100},
        "spray": {"width": 50, "density": 50, "opacity": 100},
        "fill": {"tolerance": 10, "opacity": 100},
        "wand": {"tolerance": 10},
    }

# Current tool state
current_tool_name: str = "pen"
current_pen: QPen = QPen()
current_brush: QBrush = QBrush()
statusText: StatusText = StatusText()

# Selection state
has_selection: bool = False
selection_region: QRegion | None = None
selection_type: str | None = None
current_selection: set = field(default_factory=set)
selection_edge_pixels: set = field(default_factory=set)
selection_bounds: QRect = QRect()
selection_colors = [QColor("magenta"), QColor("cyan")]
current_selection_color_index: int = 0
selection_animation_active: bool = False

# Legacy variables (to be phased out or managed by tool_settings)
brush_size: int = 50
brush_hardness: int = 50
spray_radius: int = 50
spray_density: int = 50
fill_tolerance: int = 10
pen_blur: int = 0
melt_amount: int = 10
shear_amount: int = 10
shear_horizontal: bool = True
shear_direction: int = 1
blur_radius: int = 5
gaussian_blur_radius: int = 5
mosaic_block_size: int = 10

# --- Functions ---

def get_settings_path():
    """Returns the path to the settings file."""
    return os.path.join(os.path.expanduser("~"), "ie_qt_settings.json")

def save_settings():
    """Saves the entire tool_settings dictionary to a JSON file."""
    path = get_settings_path()
    try:
        with open(path, 'w') as f:
            json.dump(tool_settings, f, indent=4)
        print(f"Settings saved to {path}")
    except Exception as e:
        print(f"Error saving settings: {e}")

def load_settings():
    """Loads tool settings from a JSON file, merging with defaults."""
    global tool_settings
    path = get_settings_path()
    
    # Start with defaults
    defaults = get_default_tool_settings()
    
    if os.path.exists(path):
        try:
            with open(path, 'r') as f:
                loaded_settings = json.load(f)
            # Merge loaded settings into defaults. This preserves defaults for
            # any new tools not in the settings file.
            for tool, settings in defaults.items():
                if tool in loaded_settings:
                    settings.update(loaded_settings[tool])
            tool_settings = defaults
            print(f"Settings loaded from {path}")
        except Exception as e:
            print(f"Error loading settings, using defaults: {e}")
            tool_settings = defaults
    else:
        print("No settings file found, using defaults.")
        tool_settings = defaults

    # Initialize legacy and current tool objects from the loaded settings
    # This is for compatibility until all tools are refactored.
    update_legacy_globals(current_tool_name)

def update_legacy_globals(tool_name: str):
    """Updates legacy global variables and QObjects from the new settings structure."""
    global brush_size, brush_hardness, spray_radius, spray_density, fill_tolerance
    global current_pen, current_brush

    settings = tool_settings.get(tool_name, {})
    
    width = settings.get("width", 10)
    opacity = settings.get("opacity", 100)
    
    # Update QPen
    pen_color = current_pen.color()
    pen_color.setAlphaF(opacity / 100.0)
    current_pen.setColor(pen_color)
    current_pen.setWidth(width)

    # Update QBrush
    brush_color = current_brush.color()
    brush_color.setAlphaF(opacity / 100.0)
    current_brush.setColor(brush_color)

    # Update legacy globals for UI sliders and non-refactored tools
    brush_size = width
    brush_hardness = settings.get("hardness", 50)
    spray_radius = width
    spray_density = settings.get("density", 50)
    fill_tolerance = settings.get("tolerance", 10)

# Initialize settings on startup
load_settings()
